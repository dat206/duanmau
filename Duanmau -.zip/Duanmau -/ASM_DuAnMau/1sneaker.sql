
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";




CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



INSERT INTO `cart` (`id`, `user_id`, `product_id`, `quantity`) VALUES
(10, 6, 1, 1);


CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



INSERT INTO `categories` (`id`, `name`) VALUES
(1, 'Nike'),
(2, 'Adidas'),
(3, 'Puma');



CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `content` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


INSERT INTO `comments` (`id`, `product_id`, `user_id`, `content`, `created_at`) VALUES
(2, 1, 6, 'ưerwqewerdsfsdfwe', '2025-08-06 04:24:01');



CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'Chờ xử lý',
  `order_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



INSERT INTO `orders` (`id`, `user_id`, `total_price`, `status`, `order_date`) VALUES
(2, 6, 360.00, 'Đã hoàn thành', '2025-08-05 12:37:28'),
(3, 6, 120.00, 'Đã hoàn thành', '2025-08-05 12:37:31'),
(4, 6, 380.00, 'Đã hoàn thành', '2025-08-06 05:09:35');


CREATE TABLE `order_details` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



INSERT INTO `order_details` (`id`, `order_id`, `product_id`, `quantity`, `price`) VALUES
(4, 2, 1, 3, 120.00),
(5, 3, 1, 1, 120.00),
(6, 4, 1, 1, 120.00),
(7, 4, 2, 1, 180.00),
(8, 4, 3, 1, 80.00);



CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `description` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `stock_quantity` int(11) NOT NULL DEFAULT 0,
  `category_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



INSERT INTO `products` (`id`, `name`, `price`, `description`, `image`, `stock_quantity`, `category_id`) VALUES
(1, 'Nike Court', 2500000.00, 'Giày thể thao cổ điển của Nike.', 'https://myshoes.vn/image/cache/catalog/2025/nike/nike8/giay-nike-court-shot-nam-den-nau-01-1600x1600.jpg', 1000, 1),
(2, 'Adidas Ultraboost', 1800000.00, 'Giày chạy bộ cực kỳ êm ái.', 'https://myshoes.vn/image/cache/catalog/2025/adidas/giay-adidas-campus-2-nam-xam-02-1600x1600.jpg', 8465, 2),
(3, 'Adidas Pureboost 5', 1200000.00, 'Giày thể thao phong cách đường phố.', 'https://myshoes.vn/image/cache/catalog/2025/adidas/giay-adidas-pureboost-5-nam-xanh-den-02-1600x1600.jpg', 52341, 2),
(7, 'Nike Big Low Đen', 3000000.00, '', 'https://myshoes.vn/image/cache/catalog/2025/nike/nike7/giay-nike-big-low-nam-den-trang-01-1600x1600.jpg', 457, 1),
(8, 'Nike Big Low Navy', 5200000.00, '', 'https://myshoes.vn/image/cache/catalog/2025/nike/nike7/giay-nike-big-low-nam-trang-navy-01-1600x1600.jpg', 567, 1),
(9, 'Nike Revolution 8', 6500000.00, '', 'https://myshoes.vn/image/cache/catalog/2025/nike/nike6/giay-nike-revolution-8-nam-trang-xam-01-1600x1600.jpg', 978, 1),
(10, 'Adidas Forum CL 2', 1500000.00, '', 'https://myshoes.vn/image/cache/catalog/2025/adidas/giay-adidas-forum-low-cl-nu-trang-xanh-ngoc-02-1600x1600.jpg', 864, 2),
(11, 'Adidas Duramo SL 2', 1000000.00, '', 'https://myshoes.vn/image/cache/catalog/2025/adidas/giay-adidas-duramo-sl-2-nu-trang-do-02-1600x1600.jpg', 966, 2),
(12, 'Puma Skye Clean Distressed', 1390000.00, 'Giày siêu đẹp', 'https://myshoes.vn/image/cache/catalog/2025/puma/giay-puma-skye-clean-distressed-nu-trang-01-1600x1600.jpg', 500, 3),
(13, 'Puma Scend Pro', 1690000.00, '', 'https://myshoes.vn/image/cache/catalog/2025/puma/giay-puma-scend-pro-nam-den-cam-01-1600x1600.jpg', 876, 3),
(14, 'Puma Tramp OG', 1990000.00, '', 'https://myshoes.vn/image/cache/catalog/2024_11/puma/giay-puma-caven-mix-nam-navy-trang-01-1600x1600.jpg', 683, 3),
(15, 'Puma Caven Mix', 1690000.00, '', 'https://myshoes.vn/image/cache/catalog/2025/puma/giay-puma-caven-mix-nam-xanh-den-trang-01-1600x1600.jpg', 8386, 3);
(16, 'Puma Oven Mix', 1690000.00, '', 'https://myshoes.vn/image/cache/catalog/2025/puma/giay-puma-caven-mix-nam-xanh-den-trang-01-1600x1600.jpg', 8386, 3);


CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` tinyint(4) NOT NULL DEFAULT 0 COMMENT '0: user, 1: admin',
  `age` int(11) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `phone_number` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



INSERT INTO `users` (`id`, `username`, `password`, `role`, `age`, `address`, `phone_number`) VALUES
(1, 'admin', '$2y$10$DuOtguMDfHO90b.qXAHGy.XIHqlCeifMS3vvp/QwCu1yjyihlaXiG', 1, 18, 'Đông Sơn - Thanh Hóa', '978914708'),
(6, 'quyn', '$2y$10$FfY73dRr0w2h0QYBmuOB9OoZIZ7RgKOl6cO83fHyTGt2gHJtZZ1Qe', 0, 18, 'Đông Lĩnh - Thanh Hóa', '987654321');


ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `product_id` (`product_id`);


ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);


ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `user_id` (`user_id`);

ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);


ALTER TABLE `order_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `product_id` (`product_id`);


ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`);


ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);


ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;


ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;


ALTER TABLE `order_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;


ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;


ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;




ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);


ALTER TABLE `comments`
  ADD CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  ADD CONSTRAINT `comments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);


ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);


ALTER TABLE `order_details`
  ADD CONSTRAINT `order_details_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`),
  ADD CONSTRAINT `order_details_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);


ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`);
COMMIT;


