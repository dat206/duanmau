<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>1Sneaker - Youth Fashion Style</title>
    <link rel="stylesheet" href="/Duanmau/ASM_DuAnMau/public/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f9f9f9;
        }

        a {
            text-decoration: none;
            color: inherit;
        }

        button {
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .main-header {
            background-color: #fff;
            box-shadow: 0 2px 4px rgba(240, 239, 239, 0.1);
            padding: 10px 0;
            position: sticky;
            top: 0;
            z-index: 999;
        }

        .main-nav {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 20px;
        }

        .logo-container {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .logo-img {
            height: 55px;
            width: auto;
            object-fit: contain;
        }

        .logo-text {
            display: flex;
            flex-direction: column;
            line-height: 1.2;
            font-weight: bold;
        }

        .logo-main {
            font-size: 20px;
            color: #f6f3f3ff;
        }

        .logo-subtitle {
            font-size: 10px;
            color: #c5c5c5ff;
            letter-spacing: 1px;
        }

        .nav-links {
            display: flex;
            gap: 15px;
            margin-left: 20px;
        }

        .nav-link {
            font-size: 15px;
            color: #f9f6f6ff;
            padding: 8px 12px;
            border-radius: 6px;
            transition: 0.3s;
        }

        .nav-link:hover {
            background-color: #f0f0f0;
            color: #111;
        }

        .header-search-form {
            display: flex;
            align-items: center;
            background: #f1f1f1;
            border-radius: 20px;
            overflow: hidden;
            padding: 2px 10px;
        }

        .header-search-input {
            border: none;
            outline: none;
            background: transparent;
            padding: 8px 10px;
            font-size: 14px;
            width: 200px;
        }

        .header-search-btn {
            border: none;
            background: #000;
            color: #fff;
            border-radius: 20px;
            padding: 6px 14px;
            margin-left: 5px;
            transition: 0.3s;
        }

        .header-search-btn:hover {
            background-color: #ffffffff;
        }

        .nav-right {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .nav-right .nav-link {
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .logout-link i {
            color: rgba(251, 51, 51, 1);
        }

        @media (max-width: 768px) {
            .main-nav {
                flex-direction: column;
                gap: 10px;
            }
            .nav-links {
                flex-wrap: wrap;
                justify-content: center;
            }
            .header-search-input {
                width: 150px;
            }
        }
    </style>
</head>
<body>
    <header class="main-header">
        <nav class="main-nav">
            <div class="nav-left" style="display:flex; align-items:center; gap:20px;">
                <a href="index.php" class="logo-container">
                    <img class="logo-img" src="/Duanmau/ASM_DuAnMau/Logo1Sneaker.png" alt="1Sneaker Logo"
                        onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                    <div class="logo-text" style="display: none;">
                        <span class="logo-main">1Sneaker</span>
                        <span class="logo-subtitle">YOUTH FASHION STYLE</span>
                    </div>
                </a>

                <div class="nav-links">
                    <a href="index.php" class="nav-link">Trang chủ</a>
                    <a href="index.php?controller=product&action=list" class="nav-link">Sản phẩm</a>
                </div>
            </div>

            <div class="nav-center">
                <form method="GET" action="index.php" class="header-search-form">
                    <input type="hidden" name="controller" value="product">
                    <input type="hidden" name="action" value="search">
                    <input type="text" name="keyword" placeholder="Tìm kiếm sản phẩm..."
                        value="<?php echo isset($_GET['keyword']) ? htmlspecialchars($_GET['keyword']) : ''; ?>"
                        class="header-search-input">
                    <button type="submit" class="header-search-btn">
                        <i class="fas fa-search"></i>
                    </button>
                </form>
            </div>

            <div class="nav-right">
                <?php if (isset($_SESSION['user_id'])): ?>
                    <?php if ($_SESSION['role'] == 0): ?>
                        <a href="index.php?controller=cart&action=view" class="nav-link">
                            <i class="fas fa-shopping-cart"></i> Giỏ hàng
                        </a>
                        <a href="index.php?controller=order&action=myOrders" class="nav-link">
                            <i class="fas fa-box"></i> Đơn hàng
                        </a>
                        <a href="index.php?controller=user&action=profile" class="nav-link user-greeting">
                            <i class="fas fa-user"></i> Xin chào, 
                            <?php echo htmlspecialchars($_SESSION['username']); ?>
                        </a>
                    <?php else: ?>
                        <a href="index.php?controller=admin&action=dashboard" class="nav-link">
                            <i class="fas fa-cog"></i> Quản trị
                        </a>
                    <?php endif; ?>
                    <a href="index.php?controller=user&action=logout" class="nav-link logout-link">
                        <i class="fas fa-sign-out-alt"></i> Đăng xuất
                    </a>
                <?php else: ?>
                    <a href="index.php?controller=user&action=login" class="nav-link">
                        <i class="fas fa-sign-in-alt"></i> Đăng nhập
                    </a>
                    <a href="index.php?controller=user&action=register" class="nav-link">
                        <i class="fas fa-user-plus"></i> Đăng ký
                    </a>
                <?php endif; ?>
            </div>
        </nav>
    </header>
    <div class="container">
