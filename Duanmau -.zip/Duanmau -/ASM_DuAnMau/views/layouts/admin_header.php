<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link rel="stylesheet" href="public/css/style.css">
    <style>
        body {
            display: flex;
            min-height: 100vh;
            flex-direction: column;
        }
        .admin-wrapper {
            display: flex;
            flex: 1;
        }
        .admin-sidebar {
            width: 250px;
            background-color: #84bfeeff;
            color: #ecf0f1;
            padding: 20px;
            box-shadow: 2px 0 5px rgba(70, 65, 65, 0.2);
        }
        .admin-sidebar h2 {
            text-align: center;
            color: #ecf0f1;
            margin-bottom: 30px;
            border-bottom: 1px solid #b4ababff;
            padding-bottom: 15px;
        }
        .admin-sidebar ul {
            list-style: none;
            padding: 0;
        }
        .admin-sidebar ul li {
            margin-bottom: 15px;
        }
        .admin-sidebar ul li a {
            color: #ecf0f1;
            text-decoration: none;
            display: block;
            padding: 10px 15px;
            border-radius: 5px;
            transition: background-color 0.3s ease, color 0.3s ease;
        }
        .admin-sidebar ul li a:hover {
            background-color: #f3ebebff;
            color: #bc2c2cff;
        }
        .admin-content {
            flex: 1;
            padding: 20px;
            background-color: #f9fefeff;
        }
        .admin-header {
            background-color: #84bfeeff;
            color: white;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 5px rgba(247, 243, 243, 1);
        }
        .admin-header h1 {
            margin: 0;
            color: white;
            border-bottom: none;
            padding-bottom: 0;
        }
        .admin-header .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        .admin-header .user-info a {
            color: white;
            text-decoration: none;
            font-weight: bold;
            transition: color 0.3s ease;
        }
        .admin-header .user-info a:hover {
            color: #dfdadaff;
        }
    </style>
</head>
<body>
    <div class="admin-wrapper">
        <div class="admin-sidebar">
            <img style="width: 150px; height: 150px;" src="Logo1Sneaker.png" alt="">
            <ul>
                <li><a href="index.php?controller=admin&action=dashboard">Dashboard</a></li>
                <li><a href="index.php?controller=admin&action=products">Quản lý sản phẩm</a></li>
                <li><a href="index.php?controller=admin&action=categories">Quản lý danh mục</a></li>
                <li><a href="index.php?controller=admin&action=users">Quản lý người dùng</a></li>
                <li><a href="index.php?controller=admin&action=orders">Quản lý đơn hàng</a></li>
                <li><a href="index.php?controller=admin&action=comments">Quản lý bình luận</a></li>
            </ul>
        </div>
        <div class="admin-content">
            <div class="admin-header">
                <h1>Xin chào, <?php echo htmlspecialchars($_SESSION['username'] ?? 'Admin'); ?>!</h1>
                <div class="user-info">
                    <span>Vai trò: Admin</span>
                    <a href="index.php?controller=user&action=logout">Đăng xuất</a>
                </div>
            </div>
            <div class="container">
