<style>
    .main-footer {
        background: linear-gradient(135deg, #090808ff 0%, #0a0a0cff 100%);
        color: white;
        padding: 50px 30px 30px;
        margin-top: 50px;
        box-shadow: 0 -4px 15px rgba(0, 0, 0, 0.2);
    }

    .footer-content {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 30px;
        max-width: 1400px;
        margin: 0 auto;
        margin-bottom: 30px;
    }

    .footer-logo {
        display: flex;
        flex-direction: column;
        align-items: flex-start;
    }

    .footer-logo img {
        width: 150px;
        height: auto;
        margin-bottom: 15px;
        filter: brightness(0) invert(1);
    }

    .footer-logo p {
        color: rgba(255, 255, 255, 0.8);
        font-size: 14px;
        line-height: 1.6;
    }

    .footer-section h3 {
        color: white;
        font-size: 18px;
        margin-bottom: 20px;
        padding-bottom: 10px;
        border-bottom: 2px solid rgba(255, 255, 255, 0.3);
        font-weight: 600;
    }

    .footer-section a {
        color: rgba(255, 255, 255, 0.9);
        text-decoration: none;
        display: block;
        margin-bottom: 12px;
        font-size: 14px;
        transition: all 0.3s ease;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .footer-section a:hover {
        color: #ffd700;
        transform: translateX(5px);
    }

    .footer-section a i {
        font-size: 12px;
    }

    .footer-section p {
        color: rgba(255, 255, 255, 0.7);
        font-size: 13px;
        line-height: 1.6;
        margin-bottom: 8px;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .footer-section p i {
        font-size: 14px;
        width: 20px;
        color: rgba(255, 255, 255, 0.9);
    }

    .footer-map {
        border-radius: 10px;
        overflow: hidden;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
        height: 250px;
    }

    .footer-map iframe {
        width: 100%;
        height: 100%;
        border: none;
    }

    .footer-bottom {
        text-align: center;
        padding-top: 30px;
        border-top: 1px solid rgba(255, 255, 255, 0.2);
        color: rgba(255, 255, 255, 0.7);
        font-size: 14px;
    }

    .footer-social {
        display: flex;
        gap: 15px;
        margin-top: 15px;
        justify-content: center;
    }

    .footer-social a {
        width: 40px;
        height: 40px;
        background: rgba(255, 255, 255, 0.1);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        transition: all 0.3s ease;
        text-decoration: none;
    }

    .footer-social a:hover {
        background: rgba(255, 255, 255, 0.2);
        transform: translateY(-3px);
    }

    @media (max-width: 968px) {
        .footer-content {
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 25px;
        }
        
        .footer-map {
            grid-column: 1 / -1;
            height: 200px;
        }
    }

    @media (max-width: 768px) {
        .main-footer {
            padding: 30px 20px 20px;
        }
        
        .footer-content {
            grid-template-columns: 1fr;
            gap: 20px;
        }
    }
</style>
</div>
<footer class="main-footer">
    <div class="footer-content">
        <div class="footer-logo">
            <img src="Logo1Sneaker.png" alt="1Sneaker Logo" onerror="this.style.display='none';">
            <p><strong>1Sneaker</strong> - Thương hiệu giày thể thao hàng đầu Việt Nam. Chúng tôi cam kết mang đến những sản phẩm chất lượng cao với giá cả hợp lý nhất.</p>
        </div>
        
        <div class="footer-section">
            <h3><i class="fas fa-concierge-bell"></i> Dịch vụ</h3>
            <a href="#"><i class="fas fa-headset"></i> Tư vấn khách hàng</a>
            <p><i class="fas fa-info-circle"></i> Hỗ trợ 24/7 qua hotline và chat</p>
            <a href="#"><i class="fas fa-exchange-alt"></i> Đổi trả hàng</a>
            <p><i class="fas fa-info-circle"></i> Chính sách đổi trả trong 30 ngày</p>
            <a href="index.php?controller=order&action=myOrders"><i class="fas fa-truck"></i> Theo dõi đơn hàng</a>
            <p><i class="fas fa-info-circle"></i> Tra cứu trạng thái đơn hàng</p>
        </div>
        
        <div class="footer-section">
            <h3><i class="fas fa-info-circle"></i> Về chúng tôi</h3>
            <a href="#"><i class="fas fa-building"></i> Giới thiệu</a>
            <p><i class="fas fa-info-circle"></i> Thương hiệu giày thể thao hàng đầu</p>
            <a href="#"><i class="fas fa-briefcase"></i> Tuyển dụng</a>
            <p><i class="fas fa-info-circle"></i> Cơ hội nghề nghiệp tại Sneaker</p>
            <a href="#"><i class="fas fa-newspaper"></i> Blog/Tin tức</a>
            <p><i class="fas fa-info-circle"></i> Cập nhật xu hướng giày mới nhất</p>
        </div>
        
        <div class="footer-section">
            <h3><i class="fas fa-map-marker-alt"></i> Thông tin liên hệ</h3>
            <p><i class="fas fa-map-pin"></i> 123 Đường ABC, Quận XYZ, TP.HCM</p>
            <p><i class="fas fa-phone"></i> Hotline: 1900-1234</p>
            <p><i class="fas fa-envelope"></i> Email: info@1sneaker.com</p>
            <p><i class="fas fa-clock"></i> Giờ làm việc: 8:00 - 22:00</p>
            <div class="footer-social">
                <a href="#" title="Facebook"><i class="fab fa-facebook-f"></i></a>
                <a href="#" title="Instagram"><i class="fab fa-instagram"></i></a>
                <a href="#" title="YouTube"><i class="fab fa-youtube"></i></a>
                <a href="#" title="Zalo"><i class="fab fa-google"></i></a>
            </div>
        </div>
        
        <div class="footer-map">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3754.5529645790584!2d105.77987237473745!3d19.774138829686017!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3136f98a5d8d886b%3A0x752428b3be1349a8!2zVHLGsOG7nW5nIENhbyDEkOG6s25nIEZQVCBQb2x5dGVjaG5pYw!5e0!3m2!1svi!2s!4v1762311539436!5m2!1svi!2s" 
                allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
    </div>
    
    <div class="footer-bottom">
        <p>&copy; <?php echo date('Y'); ?> 1Sneaker. Tất cả quyền được bảo lưu.</p>
        <p>Địa chỉ: 123 Đường ABC, Quận XYZ, TP.Thanh Hoa | Hotline: 1900-1234 | Email: info@1sneaker.com</p>
    </div>
</footer>
</body>
</html>