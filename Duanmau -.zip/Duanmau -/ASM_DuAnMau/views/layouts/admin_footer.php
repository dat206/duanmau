<!-- FOOTER -->
<footer class="footer">
  <div class="footer-container">
    <div class="footer-top">
      <!-- Logo -->
      <div class="footer-logo">
        <img src="Logo1Sneaker.png" alt="1Sneaker" onerror="this.style.display='none';">
        <p>1Sneaker – Nâng tầm phong cách trẻ Việt.</p>
      </div>

      <!-- Dịch vụ -->
      <div class="footer-col">
        <h4>Dịch vụ</h4>
        <ul>
          <li><a href="#">Tư vấn khách hàng</a></li>
          <li><a href="#">Đổi trả hàng</a></li>
          <li><a href="#">Theo dõi đơn hàng</a></li>
        </ul>
      </div>

      <!-- Về chúng tôi -->
      <div class="footer-col">
        <h4>Về chúng tôi</h4>
        <ul>
          <li><a href="#">Giới thiệu</a></li>
          <li><a href="#">Tuyển dụng</a></li>
          <li><a href="#">Blog / Tin tức</a></li>
        </ul>
      </div>

      <!-- Liên hệ -->
      <div class="footer-col">
        <h4>Liên hệ</h4>
        <p><i class="fas fa-map-marker-alt"></i> 123 Đường ABC, TP.Thanh Hóa</p>
        <p><i class="fas fa-phone"></i> 1900-1234</p>
        <p><i class="fas fa-envelope"></i> info@1sneaker.com</p>
        <div class="social-icons">
          <a href="#"><i class="fab fa-facebook-f"></i></a>
          <a href="#"><i class="fab fa-instagram"></i></a>
          <a href="#"><i class="fab fa-youtube"></i></a>
        </div>
      </div>
    </div>

    <!-- Map -->
    <div class="footer-map">
      <iframe 
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3754.5529645790584!2d105.77987237473745!3d19.774138829686017!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3136f98a5d8d886b%3A0x752428b3be1349a8!2zVHLGsOG7nW5nIENhbyDEkOG6s25nIEZQVCBQb2x5dGVjaG5pYw!5e0!3m2!1svi!2s!4v1762311539436!5m2!1svi!2s"
        allowfullscreen="" loading="lazy"></iframe>
    </div>

    <!-- Copyright -->
    <div class="footer-bottom">
      <p>&copy; <?php echo date('Y'); ?> 1Sneaker. Tất cả quyền được bảo lưu.</p>
    </div>
  </div>
</footer>

<!-- CSS -->
<style>
.footer {
  background: linear-gradient(135deg, #84d7f3ff, #85c2f4ff);
  color: #f5f5f5;
  font-family: "Poppins", sans-serif;
  padding-top: 40px;
  border-top: 3px solid #e63946; 
}

.footer-container {
  width: 90%;
  max-width: 1200px;
  margin: auto;
}

.footer-top {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  gap: 30px;
  padding-bottom: 30px;
  border-bottom: 1px solid rgba(255, 255, 255, 0.15);
}

.footer-logo img {
  width: 150px;
  margin-bottom: 12px;
  filter: #aaa3a3ff;
}

.footer-logo p {
  color: #e5e8edff;
  font-size: 14px;
}

.footer-col h4 {
  color: #f6f3f4ff;
  margin-bottom: 12px;
  font-size: 18px;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.footer-col ul {
  list-style: none;
  padding: 0;
}

.footer-col ul li {
  margin: 8px 0;
}

.footer-col ul li a {
  color: #f5f5f5;
  text-decoration: none;
  transition: all 0.3s ease;
}

.footer-col ul li a:hover {
  color: #ece3e4ff;
  padding-left: 6px;
}

.footer-col p {
  margin: 5px 0;
  color: #eaebecff;
  font-size: 14px;
}

.social-icons {
  margin-top: 10px;
}

.social-icons a {
  display: inline-block;
  width: 36px;
  height: 36px;
  background: rgba(255,255,255,0.05);
  color: #f5f5f5;
  border-radius: 50%;
  text-align: center;
  line-height: 36px;
  margin-right: 8px;
  transition: all 0.3s ease;
}

.social-icons a:hover {
  background: #e6d4d5ff;
  color: #fff;
  transform: translateY(-3px);
}

.footer-map iframe {
  width: 100%;
  height: 200px;
  border: 0;
  margin-top: 25px;
  border-radius: 10px;
  box-shadow: 0 0 10px rgba(0,0,0,0.4);
}

.footer-bottom {
  text-align: center;
  font-size: 14px;
  color: #eff2f8ff;
  padding: 18px 0;
  border-top: 1px solid rgba(243, 239, 239, 0.1);
  margin-top: 20px;
  letter-spacing: 0.5px;
}

@media (max-width: 768px) {
  .footer-top {
    flex-direction: column;
    text-align: center;
  }
  .footer-col, .footer-logo {
    width: 100%;
  }
}

</style>

<!-- Font Awesome -->
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
