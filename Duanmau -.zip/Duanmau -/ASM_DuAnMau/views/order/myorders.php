<style>
    .orders-container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 20px;
    }

    .orders-header {
        text-align: center;
        color: #000c40ff;
        margin-bottom: 30px;
        padding-bottom: 15px;
        border-bottom: 2px solid #000c40ff;
    }

    .orders-list {
        display: flex;
        flex-direction: column;
        gap: 20px;
    }

    .order-card {
        background: white;
        padding: 25px;
        border-radius: 10px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .order-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
    }

    .order-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 15px;
        padding-bottom: 15px;
        border-bottom: 1px solid #eee;
    }

    .order-id {
        font-size: 1.2em;
        font-weight: bold;
        color: #000c40ff;
    }

    .order-status {
        padding: 6px 15px;
        border-radius: 20px;
        font-size: 0.9em;
        font-weight: bold;
        text-transform: uppercase;
    }

    .status-pending {
        background-color: #ffc107;
        color: #856404;
    }

    .status-processing {
        background-color: #17a2b8;
        color: white;
    }

    .status-completed {
        background-color: #28a745;
        color: white;
    }

    .status-cancelled {
        background-color: #dc3545;
        color: white;
    }

    .order-info {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 15px;
        margin-bottom: 15px;
    }

    .info-item {
        display: flex;
        flex-direction: column;
    }

    .info-label {
        font-size: 0.85em;
        color: #6c757d;
        margin-bottom: 5px;
    }

    .info-value {
        font-size: 1em;
        font-weight: bold;
        color: #333;
    }

    .order-actions {
        display: flex;
        gap: 10px;
        margin-top: 15px;
    }

    .btn-view {
        padding: 8px 20px;
        background-color: #000c40ff;
        color: white;
        text-decoration: none;
        border-radius: 5px;
        transition: background-color 0.3s ease;
    }

    .btn-view:hover {
        background-color: #001a66;
    }

    .empty-orders {
        text-align: center;
        padding: 60px 20px;
        color: #6c757d;
    }

    .empty-orders p {
        font-size: 1.2em;
        margin-bottom: 20px;
    }

    .empty-orders a {
        display: inline-block;
        padding: 12px 25px;
        background-color: #000c40ff;
        color: white;
        text-decoration: none;
        border-radius: 6px;
        transition: background-color 0.3s ease;
    }

    .empty-orders a:hover {
        background-color: #001a66;
    }
</style>

<div class="orders-container">
    <h1 class="orders-header">Đơn hàng của tôi</h1>

    <?php if (empty($orders)): ?>
        <div class="empty-orders">
            <p>Bạn chưa có đơn hàng nào.</p>
            <a href="index.php?controller=product&action=list">Tiếp tục mua sắm</a>
        </div>
    <?php else: ?>
        <div class="orders-list">
            <?php foreach ($orders as $order): ?>
                <div class="order-card">
                    <div class="order-header">
                        <div class="order-id">Đơn hàng #<?php echo htmlspecialchars($order['id']); ?></div>
                        <span class="order-status status-<?php 
                            $status = strtolower(str_replace(' ', '-', $order['status']));
                            echo $status === 'chờ-xử-lý' ? 'pending' : ($status === 'đang-giao' ? 'processing' : ($status === 'đã-hoàn-thành' ? 'completed' : 'cancelled'));
                        ?>">
                            <?php echo htmlspecialchars($order['status']); ?>
                        </span>
                    </div>

                    <div class="order-info">
                        <div class="info-item">
                            <span class="info-label">Ngày đặt hàng</span>
                            <span class="info-value"><?php echo date('d/m/Y H:i', strtotime($order['order_date'])); ?></span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Tổng tiền</span>
                            <span class="info-value" style="color: #e74c3c;"><?php echo number_format($order['total_price'], 0, ',', '.'); ?> VNĐ</span>
                        </div>
                        <?php if (isset($order['receiver_name'])): ?>
                            <div class="info-item">
                                <span class="info-label">Người nhận</span>
                                <span class="info-value"><?php echo htmlspecialchars($order['receiver_name']); ?></span>
                            </div>
                        <?php endif; ?>
                        <?php if (isset($order['phone'])): ?>
                            <div class="info-item">
                                <span class="info-label">Số điện thoại</span>
                                <span class="info-value"><?php echo htmlspecialchars($order['phone']); ?></span>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="order-actions">
                        <a href="index.php?controller=order&action=detail&id=<?php echo $order['id']; ?>" class="btn-view">Xem chi tiết</a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

