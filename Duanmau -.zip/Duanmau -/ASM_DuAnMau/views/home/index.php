<style>
    button {
        background: red;
        padding: 10px;
        border: none;
        color: white;
        border-radius: 20px;
    }

    button:hover {
        background: white;
        color: red;
        transition: 0.5s;
    }

    .xemthem {
        text-align: center;
    }

    .xemthem a {
        display: inline-block;
        justify-content: center;
        text-align: center;
        padding: 10px 20px;
        background-color: #000c40ff;
        color: #ffffffff;
        text-decoration: none;
        border: 1px solid #ccc;
        border-radius: 5px;
        transition: background-color 0.3s ease, color 0.3s ease;
    }

    .xemthem a:hover {
        background-color: #ffffffff;
        color: #000c40ff;
        border-color: #000c40ff;
    }

    .slideshow-container {
        width: 100%;
        position: relative;
        margin: auto;
    }

    .mySlides {
        display: none;
    }

    .mySlides img {
        border-radius: 15px;
    }

    .fade {
        animation-name: fade;
        animation-duration: 1.5s;
    }

    @keyframes fade {
        from {
            opacity: .4
        }

        to {
            opacity: 1
        }
    }

    .prev,
    .next {
        cursor: pointer;
        position: absolute;
        top: 50%;
        width: auto;
        padding: 16px;
        margin-top: -22px;
        color: white;
        font-weight: bold;
        font-size: 18px;
        transition: 0.6s ease;
        border-radius: 0 3px 3px 0;
        user-select: none;
    }

    .next {
        right: 0;
        border-radius: 3px 0 0 3px;
    }

    .prev:hover,
    .next:hover {
        background-color: rgba(0, 0, 0, 0.8);
    }
</style>
<div class="slideshow-container">
    <div class="mySlides fade">
        <img src="https://i.pinimg.com/1200x/08/c2/a8/08c2a8cf3a4628c43c12989d63902086.jpg" style="width:100%">
    </div>
    <div class="mySlides fade">
        <img src="https://i.pinimg.com/1200x/a6/55/5a/a6555a98d10be0ffbd985a095c4165cd.jpg" style="width:100%">
    </div>
    <div class="mySlides fade">
        <img src="https://i.pinimg.com/1200x/a7/fe/04/a7fe04213769cc117649ca37750419c7.jpg" style="width:100%">
    </div>
    <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
    <a class="next" onclick="plusSlides(1)">&#10095;</a>
</div>
<br>

<div class="brand-categories">
    <a style="font-size: 2.5em;" href="index.php?controller=product&action=search&keyword=nike" class="brand-category">Nike</a>
    <a style="font-size: 2.5em;" href="index.php?controller=product&action=search&keyword=puma" class="brand-category">Puma</a>
    <a style="font-size: 2.5em;" href="index.php?controller=product&action=search&keyword=adidas" class="brand-category">Adidas</a>
</div>

<div class="product-grid">
    <?php if (!empty($featuredProducts)): ?>        
        <?php foreach ($featuredProducts as $product): ?>
            <?php
            $image = $product['image'];
            if (!$image || $image == '0') {
                $imgSrc = 'https://placehold.co/200x200/cccccc/333333?text= Chưa+có+ảnh';
            } elseif (filter_var($image, FILTER_VALIDATE_URL)) {
                $imgSrc = $image;
            } else {
                $imgSrc = 'public/images/products/' . htmlspecialchars($image);
            }
            ?>
            <div class="product-item">
                <img src="<?php echo $imgSrc; ?>" alt="<?php echo htmlspecialchars($product['name']); ?>"
                    onerror="this.onerror=null; this.src='https://placehold.co/200x200/cccccc/333333?text=Chưa+có+ảnh';">
                <h3><a href="index.php?controller=product&action=detail&id=<?php echo htmlspecialchars($product['id']); ?>"><?php echo htmlspecialchars($product['name']); ?></a></h3>
                <p>Giá: <?php echo number_format($product['price'], 0, ',', '.'); ?> VNĐ</p>
                <?php if (isset($_SESSION['user_id']) && $_SESSION['role'] == 0): ?>
                    <form action="index.php?controller=cart&action=addToCart" method="POST">
                        <input type="hidden" name="product_id" value="<?php echo htmlspecialchars($product['id']); ?>">
                        <input type="hidden" name="quantity" value="1">
                        <a href="index.php?controller="></a>
                        <button style="background: #000c40ff; border-radius:5px; color:white;" type="submit">Thêm vào giỏ hàng</button>
                    </form>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p>Không có sản phẩm nào để hiển thị</p>
    <?php endif; ?>
</div>
<br><br>
<div class="xemthem">
    <a href="index.php?controller=product&action=list">Xem thêm</a>
</div>
<script>
    let slideIndex = 0;
    showSlides();

    function showSlides() {
        let i;
        let slides = document.getElementsByClassName("mySlides");
        for (i = 0; i < slides.length; i++) {
            slides[i].style.display = "none";
        }
        slideIndex++;
        if (slideIndex > slides.length) {
            slideIndex = 1
        }
        slides[slideIndex - 1].style.display = "block";
        setTimeout(showSlides, 5000);
    }
</script>