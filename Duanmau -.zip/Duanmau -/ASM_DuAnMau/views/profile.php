<style>
    .profile-container {
        background-color: white;
        padding: 30px;
        border-radius: 10px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        max-width: 700px;
        margin: auto;
    }

    .profile-container h1 {
        border-bottom: 2px solid #000c40ff;
        padding-bottom: 10px;
        margin-bottom: 25px;
        color: #000c40ff;
    }

    .profile-container h2 {
        color: #000c40ff;
        border-bottom: 1px solid #000c40ff;
        padding-bottom: 8px;
        margin-bottom: 20px;
        font-size: 1.5em;
    }

    .profile-container p {
        font-size: 1.1em;
        line-height: 1.8;
        color: #555;
        margin-bottom: 10px;
    }

    .profile-container strong {
        color: #000c40ff;
        font-weight: bold;
    }

    .profile-info {
        background-color: #f8f9fa;
        padding: 20px;
        border-radius: 8px;
        margin-bottom: 30px;
        border-left: 4px solid #000c40ff;
    }

    .profile-container form {
        margin-top: 30px;
        border-top: 1px solid #eee;
        padding-top: 25px;
    }

    .profile-container form label {
        display: block;
        margin-bottom: 8px;
        font-weight: bold;
        color: #000c40ff;
    }

    .profile-container form input[type="text"],
    .profile-container form input[type="password"],
    .profile-container form input[type="number"],
    .profile-container form input[type="tel"] {
        width: calc(100% - 24px);
        padding: 12px;
        margin-bottom: 15px;
        border: 1px solid #ddd;
        border-radius: 6px;
        font-size: 1em;
        box-sizing: border-box;
        transition: border-color 0.3s ease, box-shadow 0.3s ease;
    }

    .profile-container form input[type="text"]:focus,
    .profile-container form input[type="password"]:focus,
    .profile-container form input[type="number"]:focus,
    .profile-container form input[type="tel"]:focus {
        outline: none;
        border-color: #000c40ff;
        box-shadow: 0 0 0 3px rgba(0, 12, 64, 0.1);
    }

    .profile-container form button {
        padding: 12px 25px;
        border: none;
        border-radius: 6px;
        background-color: #000c40ff;
        color: white;
        font-size: 1.1em;
        cursor: pointer;
        transition: background-color 0.3s ease, transform 0.2s ease;
    }

    .profile-container form button:hover {
        background-color: #ffffffff;
        border: #000c40ff solid 1px;
        color: #000c40ff;
        transform: translateY(-2px);
    }

    .profile-container .error-message {
        color: #dc3545;
        background-color: #f8d7da;
        padding: 10px;
        border-radius: 4px;
        margin-bottom: 15px;
        border-left: 4px solid #dc3545;
    }

    .profile-container .success-message {
        color: #155724;
        background-color: #d4edda;
        padding: 10px;
        border-radius: 4px;
        margin-bottom: 15px;
        border-left: 4px solid #28a745;
    }
</style>

<div class="profile-container">
    <h1 style="text-align: center;">Thông tin cá nhân</h1>
    <?php if ($user): ?>
        <div class="profile-info">
            <p><strong>Tên đăng nhập:</strong> <?php echo htmlspecialchars($user['username']); ?></p>
            <p><strong>Vai trò:</strong> <?php echo ($user['role'] == 1) ? 'Admin' : 'User'; ?></p>
            <p><strong>Tuổi:</strong> <?php echo htmlspecialchars($user['age'] ?? 'Chưa cập nhật'); ?></p>
            <p><strong>Địa chỉ:</strong> <?php echo htmlspecialchars($user['address'] ?? 'Chưa cập nhật'); ?></p>
            <p><strong>Số điện thoại:</strong> <?php echo htmlspecialchars($user['phone_number'] ?? 'Chưa cập nhật'); ?></p>
        </div>

        <div style="margin-top: 20px;">
            <h2>Cập nhật thông tin</h2>
            <form action="index.php?controller=user&action=profile" method="POST">
                <label for="username">Tên đăng nhập mới:</label>
                <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required>
                <br>
                <label for="age">Tuổi:</label>
                <input type="number" id="age" name="age" value="<?php echo htmlspecialchars($user['age'] ?? ''); ?>">
                <br>
                <label for="address">Địa chỉ:</label>
                <input type="text" id="address" name="address" value="<?php echo htmlspecialchars($user['address'] ?? ''); ?>">
                <br>
                <label for="phone_number">Số điện thoại:</label>
                <input type="tel" id="phone_number" name="phone_number" value="<?php echo htmlspecialchars($user['phone_number'] ?? ''); ?>">
                <br>
                <label for="password">Mật khẩu mới (để trống nếu không đổi):</label>
                <input type="password" id="password" name="password">
                <br>
                <button type="submit">Cập nhật</button>
            </form>
        </div>
    <?php else: ?>
        <div class="error-message">
            <p>Không tìm thấy thông tin người dùng.</p>
        </div>
    <?php endif; ?>
</div>