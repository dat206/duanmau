<style>
    .data-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }
    .data-table th, .data-table td {
        padding: 12px;
        border: 1px solid #ddd;
        text-align: left;
    }
    .data-table th {
        background-color: #f2f2f2;
        font-weight: bold;
    }
    .action-links a {
        background: #000c40ff;
        padding: 10px;
        text-decoration: none;
        color: white;
    }
    .action-links a:hover {
        background: white;
        color: #000c40ff;
        border: #000c40ff solid 1px;
    }
    h1{
        text-align: center;
    }
</style>

<h1>Quản lý người dùng</h1>
<table class="data-table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Tên đăng nhập</th>
            <th>Vai trò</th>
            <th>Tuổi</th>
            <th>Địa chỉ</th>
            <th>Số điện thoại</th>
            <th>Thao tác</th>
        </tr>
    </thead>
    <tbody>
        <?php if (!empty($users)): ?>
            <?php foreach ($users as $user): ?>
                <tr>
                    <td><?php echo htmlspecialchars($user['id']); ?></td>
                    <td><?php echo htmlspecialchars($user['username']); ?></td>
                    <td><?php echo ($user['role'] == 1) ? 'Admin' : 'User'; ?></td>
                    <td><?php echo htmlspecialchars($user['age'] ?? 'N/A'); ?></td>
                    <td><?php echo htmlspecialchars($user['address'] ?? 'N/A'); ?></td>
                    <td><?php echo htmlspecialchars($user['phone_number'] ?? 'N/A'); ?></td>
                    <td class="action-links">
                        <a href="index.php?controller=admin&action=editUser&id=<?php echo htmlspecialchars($user['id']); ?>">Sửa</a>
                        <?php if ($user['id'] != $_SESSION['user_id']):?>
                            <?php if ($user['role'] == 0): ?>
                                <a href="index.php?controller=admin&action=updateUserRole&id=<?php echo htmlspecialchars($user['id']); ?>&role=1">Đặt làm Admin</a>
                            <?php else: ?>
                                <a href="index.php?controller=admin&action=updateUserRole&id=<?php echo htmlspecialchars($user['id']); ?>&role=0">Đặt làm User</a>
                            <?php endif; ?>
                            <a href="index.php?controller=admin&action=deleteUser&id=<?php echo htmlspecialchars($user['id']); ?>" onclick="return confirm('Bạn có chắc chắn muốn xóa người dùng này?');">Xóa</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="7">Không có người dùng nào.</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>