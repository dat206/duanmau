<style>
    .data-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }
    .data-table th, .data-table td {
        padding: 12px;
        border: 1px solid #ddd;
        text-align: left;
    }
    .data-table th {
        background-color: #f2f2f2;
        font-weight: bold;
    }
    .link a{
        background: #000c40ff;
        color: white;
        padding: 10px;
        border-radius: 5px;
        text-decoration: none;
    }
    .link a:hover{
        background: white;
        color: #000c40ff;
        border: #000c40ff solid 1px;
        transition: 0.5s;
    }
    h1{
        text-align: center;
    }
</style>

<h1>Quản lý Danh mục</h1>
<a href="index.php?controller=admin&action=addCategory" style="display: inline-block; padding: 10px 15px; background-color:#000c40ff; color: white; text-decoration: none; border-radius: 5px; margin-bottom: 20px;">Thêm danh mục mới</a>
<table class="data-table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Tên</th>
            <th>Hành động</th>
        </tr>
    </thead>
    <tbody>
        <?php if (!empty($categories)): ?>
            <?php foreach ($categories as $category): ?>
            <tr>
                <td><?php echo htmlspecialchars($category['id']); ?></td>
                <td><?php echo htmlspecialchars($category['name']); ?></td>
                <td class="link">
                    <a href="index.php?controller=admin&action=editCategory&id=<?php echo htmlspecialchars($category['id']); ?>">Sửa</a>
                    <a href="index.php?controller=admin&action=deleteCategory&id=<?php echo htmlspecialchars($category['id']); ?>" onclick="return confirm('Bạn có chắc chắn muốn xóa danh mục này?');">Xóa</a>
                </td>
            </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="3">Không có danh mục nào.</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>