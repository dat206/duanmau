<style>
    .data-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }
    .data-table th, .data-table td {
        padding: 12px;
        border: 1px solid #ddd;
        text-align: left;
    }
    .data-table th {
        background-color: #f2f2f2;
        font-weight: bold;
    }
    a{
        background: #000c40ff;
        color: white;
        padding: 10px;
        text-decoration: none;
        border-radius: 5px;
    }
    a:hover{
        background: white;
        color: #000c40ff;
        border: #000c40ff solid 1px;
        transition: 0.5s;
    }
    h1{
        text-align: center;
    }
</style>

<h1>Quản lý Bình luận</h1>
<table class="data-table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Người dùng</th>
            <th>Sản phẩm</th>
            <th>Nội dung</th>
            <th>Ngày tạo</th>
            <th>Hành động</th>
        </tr>
    </thead>
    <tbody>
        <?php if (!empty($comments)): ?>
            <?php foreach ($comments as $comment): ?>
            <tr>
                <td><?php echo htmlspecialchars($comment['id']); ?></td>
                <td><?php echo htmlspecialchars($comment['username']); ?></td>
                <td><?php echo htmlspecialchars($comment['product_name']); ?></td>
                <td><?php echo htmlspecialchars($comment['content']); ?></td>
                <td><?php echo htmlspecialchars($comment['created_at']); ?></td>
                <td>
                    <a href="index.php?controller=admin&action=deleteComment&id=<?php echo htmlspecialchars($comment['id']); ?>" onclick="return confirm('Bạn có chắc chắn muốn xóa bình luận này?');">Xóa</a>
                </td>
            </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="6">Không có bình luận nào.</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>