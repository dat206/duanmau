<style>
    .data-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }
    .data-table th, .data-table td {
        padding: 12px;
        border: 1px solid #ddd;
        text-align: left;
    }
    .data-table th {
        background-color: #f2f2f2;
        font-weight: bold;
    }
    .data-table img {
        width: 60px;
        height: 60px;
        object-fit: cover;
        border-radius: 5px;
    }
    .action-links a {
        background: #000c40ff;
        margin-right: 10px;
        text-decoration: none;
        color: #ffffffff;
        font-size: 1.1em;
    }
    .action-links a:hover{
        color: #000c40ff;
        background: white;
        border: #000c40ff solid 1px;
    }
    h1{
        text-align: center;
    }
</style>

<h1>Quản lý sản phẩm</h1>
<a class="them" href="index.php?controller=admin&action=addProduct" style="display: inline-block; padding: 10px 15px; background-color: #000c40ff; color: white; text-decoration: none; border-radius: 5px; margin-bottom: 20px;">Thêm sản phẩm mới</a>
<table class="data-table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Tên sản phẩm</th>
            <th>Hình ảnh</th>
            <th>Loại hàng</th>
            <th>Giá</th>
            <th>Tồn kho</th>
            <th>Thao tác</th>
        </tr>
    </thead>
    <tbody>
        <?php if (!empty($products)): ?>
            <?php foreach ($products as $product): ?>
                <tr>
                    <td><?php echo htmlspecialchars($product['id']); ?></td>
                    <td><?php echo htmlspecialchars($product['name']); ?></td>
                    <td>
                        <?php
                            $image = $product['image'];
                            if (!$image || $image == '0') {
                                $imgSrc = 'https://placehold.co/60x60/cccccc/333333?text=Không+có+ảnh';
                            } elseif (filter_var($image, FILTER_VALIDATE_URL)) {
                                $imgSrc = $image;
                            } else {
                                $imgSrc = 'public/images/products/' . htmlspecialchars($image);
                            }
                        ?>
                        <img src="<?php echo $imgSrc; ?>" alt="<?php echo htmlspecialchars($product['name']); ?>"
                             onerror="this.onerror=null; this.src='https://placehold.co/60x60/cccccc/333333?text=Chưa+có+ảnh';">
                    </td>
                    <td><?php echo htmlspecialchars($product['category_name']); ?></td>
                    <td><?php echo number_format($product['price'], 2); ?> VNĐ</td>
                    <td><?php echo htmlspecialchars($product['stock_quantity']); ?></td>
                    <td class="action-links">
                        <a href="index.php?controller=admin&action=editProduct&id=<?php echo htmlspecialchars($product['id']); ?>">Sửa</a>
                        <a href="index.php?controller=admin&action=deleteProduct&id=<?php echo htmlspecialchars($product['id']); ?>" onclick="return confirm('Bạn có chắc chắn muốn xóa sản phẩm này?');">Xóa</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="7">Không có sản phẩm nào.</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>