<style>
    .admin-form {
        background-color: white;
        padding: 30px;
        border-radius: 10px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        max-width: 600px;
        margin: 30px auto;
    }

    .admin-form h1 {
        color: #000c40ff;
        border-bottom: 2px solid #000c40ff;
        padding-bottom: 10px;
        margin-bottom: 25px;
    }

    .admin-form label {
        display: block;
        margin-bottom: 8px;
        font-weight: bold;
        color: #000c40ff;
    }

    .admin-form input[type="text"],
    .admin-form input[type="number"],
    .admin-form textarea,
    .admin-form select,
    .admin-form input[type="file"] {
        width: calc(100% - 24px);
        padding: 12px;
        margin-bottom: 15px;
        border: 1px solid #ddd;
        border-radius: 6px;
        font-size: 1em;
        box-sizing: border-box;
        transition: border-color 0.3s ease, box-shadow 0.3s ease;
    }

    .admin-form input[type="text"]:focus,
    .admin-form input[type="number"]:focus,
    .admin-form textarea:focus,
    .admin-form select:focus {
        outline: none;
        border-color: #000c40ff;
        box-shadow: 0 0 0 3px rgba(0, 12, 64, 0.1);
    }

    .admin-form input[type="file"] {
        padding: 8px;
        border: 2px dashed #ddd;
        background-color: #f9f9f9;
        cursor: pointer;
    }

    .admin-form input[type="file"]:hover {
        border-color: #000c40ff;
        background-color: #f0f0f0;
    }

    .admin-form button[type="submit"] {
        padding: 12px 25px;
        border: none;
        border-radius: 6px;
        background-color: #28a745;
        color: white;
        font-size: 1.1em;
        cursor: pointer;
        transition: background-color 0.3s ease, transform 0.2s ease;
    }

    .admin-form button[type="submit"]:hover {
        background-color: #218838;
        transform: translateY(-2px);
    }

    .admin-form .current-image {
        margin-top: 10px;
        margin-bottom: 15px;
    }
    .admin-form .current-image img {
        max-width: 150px;
        height: auto;
        border: 1px solid #ddd;
        border-radius: 5px;
    }
</style>

<div class="admin-form">
    <h1>Sửa Sản phẩm</h1>
    <?php if ($product): ?>
    <form action="index.php?controller=admin&action=handleEditProduct" method="POST" enctype="multipart/form-data">
        <input type="hidden" name="id" value="<?php echo htmlspecialchars($product['id']); ?>">
        <input type="hidden" name="current_image" value="<?php echo htmlspecialchars($product['image']); ?>">
        
        <label for="name">Tên sản phẩm:</label>
        <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($product['name']); ?>" required>
        
        <label for="price">Giá:</label>
        <input type="number" id="price" name="price" step="0.01" value="<?php echo htmlspecialchars($product['price']); ?>" required>
        
        <label for="description">Mô tả:</label>
        <textarea id="description" name="description"><?php echo htmlspecialchars($product['description']); ?></textarea>
        
        <label for="image">Ảnh sản phẩm:</label>
        <div class="current-image">
            <p>Ảnh hiện tại:</p>
            <?php
                $image = $product['image'] ?? '';
                if (!$image || $image === '0') {
                    $imgSrc = 'https://placehold.co/150x150/cccccc/333333?text=Không+có+ảnh';
                } elseif (filter_var($image, FILTER_VALIDATE_URL)) {
                    $imgSrc = $image;
                } else {
                    $imgSrc = 'public/images/products/' . htmlspecialchars($image);
                }
            ?>
            <img id="imagePreview" src="<?php echo $imgSrc; ?>" alt="Preview" style="max-width:150px; margin-bottom:10px;"
                 onerror="this.onerror=null; this.src='https://placehold.co/150x150/cccccc/333333?text=Chưa+có+ảnh';">
        </div>
        <input type="file" id="imageInput" name="image" accept="image/*">
        
        <label for="category_id">Danh mục:</label>
        <select id="category_id" name="category_id" required>
            <?php foreach ($categories as $category): ?>
                <option value="<?php echo htmlspecialchars($category['id']); ?>" <?php echo ($category['id'] == $product['category_id']) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($category['name']); ?>
                </option>
            <?php endforeach; ?>
        </select>
        
        <label for="stock_quantity">Số lượng tồn kho:</label>
        <input type="number" id="stock_quantity" name="stock_quantity" value="<?php echo htmlspecialchars($product['stock_quantity']); ?>" min="0" required>
        
        <button style="background: #000c40ff; color:white;" type="submit">Cập nhật sản phẩm</button>
    </form>
    <script>
    document.getElementById('imageInput').addEventListener('change', function(event) {
        const [file] = event.target.files;
        if (file) {
            const preview = document.getElementById('imagePreview');
            preview.src = URL.createObjectURL(file);
            preview.style.display = 'block';
        }
    });
    </script>
    <?php else: ?>
        <p>Không tìm thấy sản phẩm.</p>
    <?php endif; ?>
</div>