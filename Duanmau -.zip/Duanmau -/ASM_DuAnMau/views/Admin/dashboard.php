<style>
    .dashboard-stats {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }

    .stat-card {
        background-color: white;
        padding: 25px;
        border-radius: 10px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.08);
        text-align: center;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .stat-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 6px 20px rgba(0,0,0,0.12);
    }

    .stat-card h3 {
        color: #7f8c8d;
        font-size: 1.1em;
        margin: 0 0 15px 0;
        border-bottom: none;
        padding-bottom: 0;
    }

    .stat-card .value {
        font-size: 2em;
        font-weight: bold;
        color: #2c3e50;
        margin: 0;
    }

    .stat-card.revenue { border-left: 4px solid #27ae60; }
    .stat-card.orders { border-left: 4px solid #3498db; }
    .stat-card.products { border-left: 4px solid #e74c3c; }
    .stat-card.users { border-left: 4px solid #f39c12; }

    .dashboard-section {
        background: white;
        padding: 25px;
        border-radius: 10px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.08);
        margin-bottom: 30px;
    }

    .dashboard-section h2 {
        color: #000c40ff;
        border-bottom: 2px solid #000c40ff;
        padding-bottom: 10px;
        margin-bottom: 20px;
    }

    .status-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 15px;
        margin-bottom: 20px;
    }

    .status-item {
        padding: 15px;
        background: #f8f9fa;
        border-radius: 8px;
        text-align: center;
    }

    .status-item .label {
        color: #6c757d;
        font-size: 0.9em;
        margin-bottom: 5px;
    }

    .status-item .value {
        font-size: 1.5em;
        font-weight: bold;
        color: #2c3e50;
    }

    .top-products {
        display: grid;
        gap: 15px;
    }

    .product-item {
        display: flex;
        align-items: center;
        gap: 15px;
        padding: 15px;
        background: #f8f9fa;
        border-radius: 8px;
    }

    .product-item img {
        width: 60px;
        height: 60px;
        object-fit: cover;
        border-radius: 5px;
    }

    .product-item-info {
        flex: 1;
    }

    .product-item-info h4 {
        margin: 0 0 5px 0;
        color: #2c3e50;
    }

    .product-item-info p {
        margin: 0;
        color: #6c757d;
        font-size: 0.9em;
    }

    .chart-container {
        margin-top: 20px;
        padding: 20px;
        background: #f8f9fa;
        border-radius: 8px;
    }

    .chart-bar {
        display: flex;
        align-items: center;
        margin-bottom: 10px;
    }

    .chart-label {
        width: 100px;
        font-size: 0.9em;
        color: #6c757d;
    }

    .chart-bar-visual {
        flex: 1;
        height: 30px;
        background: #e0e0e0;
        border-radius: 5px;
        position: relative;
        overflow: hidden;
    }

    .chart-bar-fill {
        height: 100%;
        background: linear-gradient(90deg, #3498db, #2980b9);
        border-radius: 5px;
        transition: width 0.3s ease;
    }

    .chart-value {
        width: 80px;
        text-align: right;
        font-weight: bold;
        color: #2c3e50;
    }

    .inventory-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 15px;
    }

    .inventory-table th,
    .inventory-table td {
        padding: 12px;
        text-align: left;
        border-bottom: 1px solid #eee;
    }

    .inventory-table th {
        background-color: #f8f9fa;
        color: #000c40ff;
        font-weight: bold;
    }

    .inventory-table tr:hover {
        background-color: #f8f9fa;
    }
</style>

<h1 style="text-align: center; color: #000c40ff; margin-bottom: 30px;">Báo cáo thống kê</h1>

<div class="dashboard-stats">
    <div class="stat-card revenue">
        <h3>Tổng doanh thu</h3>
        <p class="value"><?php echo number_format($totalRevenue, 0, ',', '.'); ?> VNĐ</p>
        <?php if ($currentMonthRevenue > 0): ?>
            <p style="color: #27ae60; margin-top: 10px; font-size: 0.9em;">
                Tháng này: <?php echo number_format($currentMonthRevenue, 0, ',', '.'); ?> VNĐ
            </p>
        <?php endif; ?>
    </div>
    
    <div class="stat-card orders">
        <h3>Tổng số đơn hàng</h3>
        <p class="value"><?php echo htmlspecialchars($totalOrders); ?></p>
        <?php if ($currentMonthOrders > 0): ?>
            <p style="color: #3498db; margin-top: 10px; font-size: 0.9em;">
                Tháng này: <?php echo $currentMonthOrders; ?> đơn
            </p>
        <?php endif; ?>
    </div>
    
    <div class="stat-card products">
        <h3>Tổng số sản phẩm</h3>
        <p class="value"><?php echo htmlspecialchars($totalProducts); ?></p>
    </div>
    
    <div class="stat-card users">
        <h3>Tổng số người dùng</h3>
        <p class="value"><?php echo htmlspecialchars($totalUsers); ?></p>
        <?php if ($newUsersThisMonth > 0): ?>
            <p style="color: #f39c12; margin-top: 10px; font-size: 0.9em;">
                Tháng này: +<?php echo $newUsersThisMonth; ?> người dùng mới
            </p>
        <?php endif; ?>
    </div>
</div>

<div class="dashboard-section">
    <h2>Trạng thái đơn hàng</h2>
    <div class="status-grid">
        <div class="status-item">
            <div class="label">Chờ xử lý</div>
            <div class="value" style="color: #ffc107;"><?php echo $pendingOrders; ?></div>
        </div>
        <div class="status-item">
            <div class="label">Đang giao</div>
            <div class="value" style="color: #17a2b8;"><?php echo $processingOrders; ?></div>
        </div>
        <div class="status-item">
            <div class="label">Đã hoàn thành</div>
            <div class="value" style="color: #28a745;"><?php echo $completedOrders; ?></div>
        </div>
    </div>
</div>

<?php if (!empty($topSellingProducts)): ?>
<div class="dashboard-section">
    <h2>Top 5 sản phẩm bán chạy</h2>
    <div class="top-products">
        <?php foreach ($topSellingProducts as $index => $product): ?>
            <div class="product-item">
                <span style="font-size: 1.5em; font-weight: bold; color: #000c40ff; width: 30px;">
                    #<?php echo $index + 1; ?>
                </span>
                <?php
                $image = $product['image'];
                if (!$image || $image == '0') {
                    $imgSrc = 'https://placehold.co/60x60/cccccc/333333?text=N/A';
                } elseif (filter_var($image, FILTER_VALIDATE_URL)) {
                    $imgSrc = $image;
                } else {
                    $imgSrc = 'public/images/products/' . htmlspecialchars($image);
                }
                ?>
                <img src="<?php echo $imgSrc; ?>" alt="<?php echo htmlspecialchars($product['name']); ?>"
                     onerror="this.onerror=null; this.src='https://placehold.co/60x60/cccccc/333333?text=N/A';">
                <div class="product-item-info">
                    <h4><?php echo htmlspecialchars($product['name']); ?></h4>
                    <p>Đã bán: <strong><?php echo $product['total_sold']; ?></strong> sản phẩm</p>
                    <p>Doanh thu: <strong><?php echo number_format($product['total_revenue'], 0, ',', '.'); ?> VNĐ</strong></p>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>

<?php if (!empty($ordersLast7Days)): ?>
<div class="dashboard-section">
    <h2>Thống kê đơn hàng 7 ngày gần nhất</h2>
    <div class="chart-container">
        <?php foreach ($ordersLast7Days as $day): ?>
            <div class="chart-bar">
                <div class="chart-label"><?php echo date('d/m', strtotime($day['date'])); ?></div>
                <div class="chart-bar-visual">
                    <div class="chart-bar-fill" style="width: <?php echo min(100, ($day['count'] / max(1, max(array_column($ordersLast7Days, 'count'))) * 100)); ?>%;"></div>
                </div>
                <div class="chart-value">
                    <?php echo $day['count']; ?> đơn
                    <?php if ($day['revenue'] > 0): ?>
                        (<?php echo number_format($day['revenue'], 0, ',', '.'); ?> VNĐ)
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>

<div class="dashboard-section">
    <h2>Tồn kho sản phẩm</h2>
    <table class="inventory-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Ảnh</th>
                <th>Tên sản phẩm</th>
                <th>Tồn kho</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($productsInStock)): ?>
                <?php foreach ($productsInStock as $product): ?>
                <tr>
                    <td><?php echo htmlspecialchars($product['id']); ?></td>
                    <td>
                        <?php
                            $image = $product['image'];
                            if (!$image || $image == '0') {
                                $imgSrc = 'https://placehold.co/50x50/cccccc/333333?text=Không+có+ảnh';
                            } elseif (filter_var($image, FILTER_VALIDATE_URL)) {
                                $imgSrc = $image;
                            } else {
                                $imgSrc = 'public/images/products/' . htmlspecialchars($image);
                            }
                        ?>
                        <img src="<?php echo $imgSrc; ?>" alt="<?php echo htmlspecialchars($product['name']); ?>"
                             onerror="this.onerror=null; this.src='https://placehold.co/50x50/cccccc/333333?text=Chưa+có+ảnh';">
                    </td>
                    <td><?php echo htmlspecialchars($product['name']); ?></td>
                    <td>
                        <span style="color: <?php echo $product['stock_quantity'] < 10 ? '#e74c3c' : ($product['stock_quantity'] < 50 ? '#f39c12' : '#27ae60'); ?>;">
                            <?php echo htmlspecialchars($product['stock_quantity']); ?>
                        </span>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="4">Không có sản phẩm nào trong kho.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
