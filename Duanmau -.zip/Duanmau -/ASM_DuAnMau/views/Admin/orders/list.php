<style>
  .data-table {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0;
    margin-top: 20px;
    background: white;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 2px 10px rgba(0,0,0,0.08);
}

.data-table th, .data-table td {
    padding: 14px;
    border-bottom: 1px solid #e8e8e8;
    text-align: left;
}

.data-table th {
    background-color: #f5f7ff;
    font-weight: bold;
    color: #1d2d5b;
    font-size: 15px;
}

button{
    background: #0d2c78;
    color: white;
    padding: 8px 14px;
    border-radius: 6px;
    border: none;
    cursor: pointer;
    font-size: 14px;
}

button:hover{
    background: white;
    color: #0d2c78;
    border: 1px solid #0d2c78;
    transition: 0.2s;
}

a{
    background: #0d2c78;
    color:  white;
    padding: 8px 14px;
    text-decoration: none;
    border-radius: 6px;
    font-size: 14px;
}

a:hover{
    background: white;
    color: #0d2c78;
    border: 1px solid #0d2c78;
    transition: 0.2s;
}

select{
    padding: 6px 10px;
    border-radius: 6px;
    border: 1px solid #d1d1d1;
}

h1{
    text-align: center;
    color: #53d0fdff;
    font-weight: bold;
    margin-bottom: 20px;
}

</style>

<h1>Quản lý Đơn hàng</h1>
<table class="data-table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Tên khách hàng</th>
            <th>Tổng tiền</th>
            <th>Ngày đặt</th>
            <th>Trạng thái</th>
            <th>Hành động</th>
        </tr>
    </thead>
    <tbody>
        <?php if (!empty($orders)): ?>
            <?php foreach ($orders as $order): ?>
            <tr>
                <td><?php echo htmlspecialchars($order['id']); ?></td>
                <td><?php echo htmlspecialchars($order['username']); ?></td>
                <td><?php echo number_format($order['total_price'], 2); ?> VNĐ</td>
                <td><?php echo htmlspecialchars($order['order_date']); ?></td>
                <td>
                    <form action="index.php?controller=admin&action=updateOrderStatus&id=<?php echo htmlspecialchars($order['id']); ?>" method="POST" style="display:inline;">
                        <select name="status">
                            <option value="Chờ xử lý" <?php echo ($order['status'] == 'Chờ xử lý') ? 'selected' : ''; ?>>Chờ xử lý</option>
                            <option value="Đã xác nhận" <?php echo ($order['status'] == 'Đã xác nhận') ? 'selected' : ''; ?>>Đã xác nhận</option>
                            <option value="Đang giao hàng" <?php echo ($order['status'] == 'Đang giao hàng') ? 'selected' : ''; ?>>Đang giao hàng</option>
                            <option value="Đã hoàn thành" <?php echo ($order['status'] == 'Đã hoàn thành') ? 'selected' : ''; ?>>Đã hoàn thành</option>
                            <option value="Đã hủy" <?php echo ($order['status'] == 'Đã hủy') ? 'selected' : ''; ?>>Đã hủy</option>
                        </select>
                        <button type="submit">Cập nhật</button>
                    </form>
                </td>
                <td>
                    <a href="index.php?controller=admin&action=deleteOrder&id=<?php echo htmlspecialchars($order['id']); ?>" 
                       onclick="return confirm('Bạn có chắc chắn muốn xóa đơn hàng này?')" >
                        Xóa
                    </a>
                </td>
            </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="6">Không có đơn hàng nào.</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>