<style>
    .cart-container {
        background-color: white;
        padding: 30px;
        border-radius: 10px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        max-width: 900px;
        margin: auto;
    }
    
    .cart-container h1 {
        color: #000c40ff;
        border-bottom: 2px solid #000c40ff;
        padding-bottom: 10px;
        margin-bottom: 25px;
    }
    
    .cart-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 25px;
    }
    
    .cart-table th, .cart-table td {
        padding: 15px;
        text-align: left;
        border-bottom: 1px solid #eee;
    }
    
    .cart-table th {
        background-color: #f8f9fa;
        color: #000c40ff;
        font-weight: bold;
        text-transform: uppercase;
        font-size: 0.9em;
    }
    
    .cart-table tr:last-child td {
        border-bottom: none;
    }
    
    .cart-table tr:hover {
        background-color: #f2f2f2;
    }
    
    .cart-table img {
        width: 70px;
        height: 70px;
        object-fit: cover;
        border-radius: 8px;
    }
    
    .cart-table .item-total {
        font-weight: bold;
        color: #e74c3c;
    }
    
    .cart-table .action-link {
        color: #e74c3c;
        text-decoration: none;
        font-weight: bold;
        transition: color 0.3s ease;
        padding: 6px 12px;
        border-radius: 4px;
        background-color: #f8d7da;
    }
    
    .cart-table .action-link:hover {
        color: #c0392b;
        background-color: #f5c6cb;
    }
    
    .total-price {
        text-align: right;
        font-size: 1.2em;
        font-weight: bold;
        margin-top: 20px;
        padding: 20px;
        background-color: #f8f9fa;
        border-radius: 8px;
        border-left: 4px solid #000c40ff;
    }
    
    .cart-container button {
        padding: 12px 30px;
        background-color: #3498db;
        color: white;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        font-size: 1.1em;
        margin-top: 20px;
        transition: background-color 0.3s ease, transform 0.2s ease;
    }
    
    .cart-container button:hover {
        background-color: #2980b9;
        transform: translateY(-2px);
    }
    
    .empty-cart {
        text-align: center;
        padding: 40px;
        color: #6c757d;
    }
    
    .empty-cart p {
        font-size: 1.2em;
        margin-bottom: 20px;
    }
    
    .empty-cart a {
        display: inline-block;
        padding: 12px 25px;
        background-color: #000c40ff;
        color: white;
        text-decoration: none;
        border-radius: 6px;
        transition: background-color 0.3s ease, transform 0.2s ease;
    }
    
    .empty-cart a:hover {
        background-color: #001a66;
        transform: translateY(-2px);
    }
</style>

<div class="cart-container">
    <h1>Giỏ hàng của bạn</h1>
    <?php if (empty($cartItems)): ?>
        <div class="empty-cart">
            <p>Giỏ hàng của bạn trống.</p>
            <a href="index.php?controller=product&action=list">Tiếp tục mua sắm</a>
        </div>
    <?php else: ?>
        <table class="cart-table">
            <thead>
                <tr>
                    <th>Sản phẩm</th>
                    <th>Hình ảnh</th>
                    <th>Giá</th>
                    <th>Số lượng</th>
                    <th>Tổng</th>
                    <th>Thao tác</th>
                </tr>
            </thead>
            <tbody>
                <?php $grandTotal = 0; ?>
                <?php foreach ($cartItems as $item): ?>
                    <?php $itemTotal = $item['price'] * $item['quantity']; ?>
                    <?php $grandTotal += $itemTotal; ?>
                    <?php
                        $image = $item['image'];
                        if (!$image || $image == '0') {
                            $imgSrc = 'https://placehold.co/70x70/cccccc/333333?text=Chưa+có+ảnh';
                        } elseif (filter_var($image, FILTER_VALIDATE_URL)) {
                            $imgSrc = $image;
                        } else {
                            $imgSrc = 'public/images/products/' . htmlspecialchars($image);
                        }
                    ?>
                    <tr>
                        <td><?php echo htmlspecialchars($item['name']); ?></td>
                        <td>
                            <img src="<?php echo $imgSrc; ?>" alt="<?php echo htmlspecialchars($item['name']); ?>"
                                 onerror="this.onerror=null; this.src='https://placehold.co/70x70/cccccc/333333?text=Chưa+có+ảnh';">
                        </td>
                        <td><?php echo number_format($item['price'], 0, ',', '.'); ?> VNĐ</td>
                        <td>
                            <form action="index.php?controller=cart&action=updateQuantity" method="POST" style="display: inline;">
                                <?php echo CSRF::field(); ?>
                                <input type="hidden" name="cart_id" value="<?php echo htmlspecialchars($item['cart_id']); ?>">
                                <input type="number" name="quantity" value="<?php echo htmlspecialchars($item['quantity']); ?>" min="1" max="<?php echo isset($item['stock_quantity']) ? $item['stock_quantity'] : 999; ?>" style="width: 70px; padding: 5px;">
                                <button type="submit" style="padding: 5px 10px; margin-left: 5px; background: #000c40ff; color: white; border: none; border-radius: 3px; cursor: pointer;">Cập nhật</button>
                            </form>
                        </td>
                        <td class="item-total"><?php echo number_format($itemTotal, 0, ',', '.'); ?> VNĐ</td>
                        <td>
                            <a href="index.php?controller=cart&action=removeFromCart&id=<?php echo htmlspecialchars($item['cart_id']); ?>" class="action-link">Xóa</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <div class="total-price">
            Tổng tiền: <?php echo number_format($grandTotal, 0, ',', '.'); ?> VNĐ
        </div>
        <div style="text-align: right; margin-top: 20px;">
            <a href="index.php?controller=cart&action=checkout" style="display: inline-block; padding: 12px 30px; background-color: #27ae60; color: white; text-decoration: none; border-radius: 6px; font-size: 1.1em; transition: background-color 0.3s ease;">
                Thanh toán
            </a>
        </div>
    <?php endif; ?>
</div>