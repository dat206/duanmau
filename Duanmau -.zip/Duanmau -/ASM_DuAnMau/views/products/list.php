<style>
    .product-list-container {
        padding: 20px 0;
    }

    .search-container {
        margin-bottom: 30px;
        text-align: center;
    }

    .search-form {
        display: inline-flex;
        align-items: center;
        gap: 10px;
        background: white;
        padding: 15px 20px;
        border-radius: 25px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        max-width: 500px;
        width: 100%;
    }

    .search-form input[type="text"] {
        flex: 1;
        border: none;
        outline: none;
        padding: 10px;
        font-size: 16px;
        border-radius: 20px;
        background: #f8f9fa;
    }

    .search-form button {
        padding: 10px 20px;
        background-color: #000c40ff;
        color: white;
        border: none;
        border-radius: 20px;
        cursor: pointer;
        font-size: 16px;
        transition: background-color 0.3s ease;
    }

    .search-form button:hover {
        background-color: #ffffffff;
        color: #000c40ff;
        border: #000c40ff solid 1px;
    }

    .product-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
        gap: 25px;
        margin-top: 30px;
    }

    .product-item {
        background-color: white;
        padding: 20px;
        border-radius: 12px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        text-align: center;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .product-item:hover {
        transform: translateY(-5px);
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
    }

    .product-item img {
        width: 100%;
        height: 220px;
        object-fit: cover;
        border-radius: 8px;
        margin-bottom: 15px;
    }

    .product-item h3 {
        margin: 15px 0 10px 0;
        font-size: 1.3em;
        color: #000c40ff;
    }

    .product-item h3 a {
        text-decoration: none;
        color: inherit;
        transition: color 0.3s ease;
    }

    .product-item h3 a:hover {
        color: #001a66;
    }

    .product-item .price {
        color: #e74c3c;
        font-weight: bold;
        font-size: 1.2em;
        margin: 10px 0;
    }

    .product-item .category {
        color: #7f8c8d;
        font-size: 0.9em;
        margin-bottom: 15px;
    }

    .product-item .stock {
        color: #27ae60;
        font-size: 0.9em;
        margin-bottom: 15px;
    }

    .product-item form {
        margin-top: 15px;
    }

    .product-item button {
        padding: 10px 20px;
        background-color: #000c40ff;
        color: white;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        font-size: 14px;
        transition: background-color 0.3s ease;
        width: 100%;
    }

    .product-item button:hover {
        background-color: #ffffffff;
        color: #000c40ff;
        border: #000c40ff solid 1px;
    }

    .no-products {
        text-align: center;
        color: #7f8c8d;
        font-size: 1.2em;
        margin-top: 50px;
    }

    .page-title {
        text-align: center;
        color: #000c40ff;
        margin-bottom: 20px;

    }

    .pagination {
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 10px;
        margin: 30px 0 0 0;
    }

    .pagination a,
    .pagination span {
        padding: 8px 12px;
        border: 1px solid #ddd;
        border-radius: 4px;
        text-decoration: none;
        color: #000c40ff;
        transition: all 0.3s ease;
    }

    .pagination a:hover {
        background-color: #000c40ff;
        color: white;
        border-color: #000c40ff;
    }

    .pagination .current {
        background-color: #000c40ff;
        color: white;
        border-color: #000c40ff;
    }

    .filter-container {
        background: white;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        margin-bottom: 30px;
    }

    .filter-form {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 15px;
        align-items: end;
    }

    .filter-group {
        display: flex;
        flex-direction: column;
    }

    .filter-group label {
        margin-bottom: 5px;
        color: #000c40ff;
        font-weight: bold;
        font-size: 0.9em;
    }

    .filter-group input,
    .filter-group select {
        padding: 10px;
        border: 1px solid #ddd;
        border-radius: 5px;
        font-size: 14px;
    }

    .filter-group input:focus,
    .filter-group select:focus {
        outline: none;
        border-color: #000c40ff;
    }

    .filter-buttons {
        display: flex;
        gap: 10px;
    }

    .filter-buttons button {
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 14px;
        transition: all 0.3s ease;
    }

    .btn-filter {
        background-color: #000c40ff;
        color: white;
    }

    .btn-filter:hover {
        background-color: #001a66;
    }

    .btn-reset {
        background-color: #6c757d;
        color: white;
    }

    .btn-reset:hover {
        background-color: #5a6268;
    }
</style>

<div class="product-list-container">
    <h1 class="page-title">Tất cả sản phẩm</h1>

    <div class="filter-container">
        <form method="GET" action="index.php" class="filter-form">
            <input type="hidden" name="controller" value="product">
            <input type="hidden" name="action" value="search">
            
            <div class="filter-group">
                <label>Tìm kiếm</label>
                <input type="text" name="keyword" placeholder="Tên sản phẩm..."
                    value="<?php echo isset($_GET['keyword']) ? htmlspecialchars($_GET['keyword']) : ''; ?>">
            </div>
            
            <div class="filter-group">
                <label>Danh mục</label>
                <select name="category">
                    <option value="">Tất cả</option>
                    <?php if (isset($categories)): ?>
                        <?php foreach ($categories as $cat): ?>
                            <option value="<?php echo $cat['id']; ?>" 
                                <?php echo (isset($_GET['category']) && $_GET['category'] == $cat['id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($cat['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </select>
            </div>
            
            <div class="filter-group">
                <label>Giá tối thiểu (VNĐ)</label>
                <input type="number" name="min_price" placeholder="0" min="0" step="1000"
                    value="<?php echo isset($_GET['min_price']) ? htmlspecialchars($_GET['min_price']) : ''; ?>">
            </div>
            
            <div class="filter-group">
                <label>Giá tối đa (VNĐ)</label>
                <input type="number" name="max_price" placeholder="Không giới hạn" min="0" step="1000"
                    value="<?php echo isset($_GET['max_price']) ? htmlspecialchars($_GET['max_price']) : ''; ?>">
            </div>
            
            <div class="filter-buttons">
                <button type="submit" class="btn-filter">Lọc</button>
                <a href="index.php?controller=product&action=search" class="btn-reset" style="text-decoration: none; display: inline-block; padding: 10px 20px; border-radius: 5px;">Đặt lại</a>
            </div>
        </form>
    </div>

    <?php if (isset($_GET['keyword']) && !empty($_GET['keyword'])): ?>
        <p style="text-align: center; color: #7f8c8d; margin-bottom: 20px;">
            Kết quả tìm kiếm cho: "<strong><?php echo htmlspecialchars($_GET['keyword']); ?></strong>"
        </p>
    <?php endif; ?>

    <div class="product-grid">
        <?php if (!empty($products)): ?>
            <?php foreach ($products as $product): ?>
                <?php
                $image = $product['image'];
                if (!$image || $image == '0') {
                    $imgSrc = 'https://placehold.co/280x220/cccccc/333333?text=Chưa+có+ảnh';
                } elseif (filter_var($image, FILTER_VALIDATE_URL)) {
                    $imgSrc = $image;
                } else {
                    $imgSrc = 'public/images/products/' . htmlspecialchars($image);
                }
                ?>
                <div class="product-item">
                    <img src="<?php echo $imgSrc; ?>" alt="<?php echo htmlspecialchars($product['name']); ?>"
                        onerror="this.onerror=null; this.src='https://placehold.co/280x220/cccccc/333333?text=Chưa+có+ảnh';">

                    <h3>
                        <a href="index.php?controller=product&action=detail&id=<?php echo htmlspecialchars($product['id']); ?>">
                            <?php echo htmlspecialchars($product['name']); ?>
                        </a>
                    </h3>

                    <p class="price"><?php echo number_format($product['price'], 0, ',', '.'); ?> VNĐ</p>

                    <?php if (isset($product['category_name'])): ?>
                        <p class="category">Danh mục: <?php echo htmlspecialchars($product['category_name']); ?></p>
                    <?php endif; ?>

                    <p class="stock">Còn lại: <?php echo htmlspecialchars($product['stock_quantity']); ?> sản phẩm</p>

                    <?php if (isset($_SESSION['user_id']) && $_SESSION['role'] == 0): ?>
                        <form action="index.php?controller=cart&action=addToCart" method="POST">
                            <input type="hidden" name="product_id" value="<?php echo htmlspecialchars($product['id']); ?>">
                            <input type="hidden" name="quantity" value="1">
                            <button type="submit">Thêm vào giỏ hàng</button>
                        </form>
                    <?php else: ?>
                        <p style="font-size: 0.9em; color: #7f8c8d;">
                            <a href="index.php?controller=user&action=login">Đăng nhập</a> để mua hàng
                        </p>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="no-products">
                <?php if (isset($_GET['keyword']) && !empty($_GET['keyword'])): ?>
                    Không tìm thấy sản phẩm nào với từ khóa "<?php echo htmlspecialchars($_GET['keyword']); ?>"
                <?php else: ?>
                    Không có sản phẩm nào để hiển thị.
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>

    <?php
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $totalPages = isset($totalPages) ? (int)$totalPages : 1;
    ?>
    <?php if ($totalPages > 1): ?>
        <div class="pagination">
            <?php
            // Build pagination URL with filters
            $filterParams = [];
            if (isset($_GET['keyword']) && !empty($_GET['keyword'])) $filterParams['keyword'] = $_GET['keyword'];
            if (isset($_GET['category']) && !empty($_GET['category'])) $filterParams['category'] = $_GET['category'];
            if (isset($_GET['min_price']) && !empty($_GET['min_price'])) $filterParams['min_price'] = $_GET['min_price'];
            if (isset($_GET['max_price']) && !empty($_GET['max_price'])) $filterParams['max_price'] = $_GET['max_price'];
            $filterQuery = !empty($filterParams) ? '&' . http_build_query($filterParams) : '';
            ?>
            
            <?php if ($page > 1): ?>
                <a href="index.php?controller=product&action=search&page=<?php echo $page - 1; ?><?php echo $filterQuery; ?>">« Trước</a>
            <?php else: ?>
                <span class="current">« Trước</span>
            <?php endif; ?>

            <?php for ($p = 1; $p <= $totalPages; $p++): ?>
                <?php if ($p == $page): ?>
                    <span class="current"><?php echo $p; ?></span>
                <?php else: ?>
                    <a href="index.php?controller=product&action=search&page=<?php echo $p; ?><?php echo $filterQuery; ?>"><?php echo $p; ?></a>
                <?php endif; ?>
            <?php endfor; ?>

            <?php if ($page < $totalPages): ?>
                <a href="index.php?controller=product&action=search&page=<?php echo $page + 1; ?><?php echo $filterQuery; ?>">Sau »</a>
            <?php else: ?>
                <span class="current">Sau »</span>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>