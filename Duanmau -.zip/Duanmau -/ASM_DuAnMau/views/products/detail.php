<style>
    .product-detail-container {
        background-color: white;
        padding: 30px;
        border-radius: 10px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        display: flex;
        flex-wrap: wrap;
        gap: 40px;
        align-items: flex-start;
    }

    .product-detail-image {
        flex: 1;
        min-width: 300px;
        max-width: 45%;
    }

    .product-detail-image img {
        width: 100%;
        height: auto;
        border-radius: 8px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    }

    .product-detail-info {
        flex: 1;
        min-width: 350px;
    }

    .product-detail-info h1 {
        font-size: 2.2em;
        color: #000c40ff;
        margin-top: 0;
        border-bottom: 2px solid #000c40ff;
        padding-bottom: 10px;
    }

    .product-detail-info .price {
        font-size: 1.8em;
        color: #e74c3c;
        font-weight: bold;
        margin: 15px 0;
    }

    .product-detail-info .description {
        font-size: 1.1em;
        color: #555;
        margin-bottom: 25px;
    }

    .product-detail-info form {
        display: flex;
        align-items: center;
        gap: 15px;
        margin-bottom: 20px;
    }

    .product-detail-info label {
        font-weight: bold;
        color: #000c40ff;
    }

    .product-detail-info input[type="number"] {
        width: 80px;
        padding: 8px;
        border: 1px solid #ccc;
        border-radius: 5px;
        font-size: 1em;
    }

    .product-detail-info button {
        padding: 10px 20px;
        background-color: #000c40ff;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 1em;
        transition: background-color 0.3s ease;
    }

    .product-detail-info button:hover {
        background-color: #ffffffff;
        color: #000c40ff;
        border: #000c40ff solid 1px;
    }

    .comments-section {
        margin-top: 40px;
        background-color: white;
        padding: 30px;
        border-radius: 10px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
    }

    .comments-section h2 {
        color: #000c40ff;
        border-bottom: 1px solid #eee;
        padding-bottom: 10px;
        margin-bottom: 20px;
    }

    .comments-section textarea {
        width: 100%;
        padding: 10px;
        border: 1px solid #ddd;
        border-radius: 5px;
        min-height: 80px;
        margin-bottom: 10px;
        box-sizing: border-box;
    }

    .comments-section button {
        padding: 10px 20px;
        background-color: #000c40ff;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }

    .comments-section button:hover {
        background-color: #ffffffff;
        color: #000c40ff;
        border: #000c40ff solid 1px;
    }

    .comment-list {
        margin-top: 20px;
    }

    .comment {
        background-color: #f9f9f9;
        padding: 15px;
        border-radius: 8px;
        border: 1px solid #eee;
        margin-bottom: 15px;
    }

    .comment p {
        margin: 5px 0;
    }

    .comment strong {
        color: #000c40ff;
    }

    .comment small {
        color: #7f8c8d;
        font-size: 0.85em;
    }
</style>

<?php if ($product): ?>
    <div class="product-detail-container">
        <div class="product-detail-image">
            <?php
            $image = $product['image'];
            if (!$image || $image == '0') {
                $imgSrc = 'https://placehold.co/400x300/cccccc/333333?text=Chưa+có+ảnh';
            } elseif (filter_var($image, FILTER_VALIDATE_URL)) {
                $imgSrc = $image;
            } else {
                $imgSrc = 'public/images/products/' . htmlspecialchars($image);
            }
            ?>
            <img src="<?php echo $imgSrc; ?>" alt="<?php echo htmlspecialchars($product['name']); ?>"
                onerror="this.onerror=null; this.src='https://placehold.co/400x300/cccccc/333333?text=Chưa+có+ảnh';">
        </div>
        <div class="product-detail-info">
            <h1><?php echo htmlspecialchars($product['name']); ?></h1>
            <p class="price"><?php echo number_format($product['price'], 0, ',', '.'); ?> VNĐ</p>
            <?php if (isset($ratingInfo) && $ratingInfo['total_ratings'] > 0): ?>
                <div style="margin: 15px 0; display: flex; align-items: center; gap: 10px;">
                    <div style="display: flex; align-items: center;">
                        <?php 
                        $avgRating = $ratingInfo['avg_rating'];
                        for ($i = 1; $i <= 5; $i++): 
                        ?>
                            <span style="font-size: 1.5em; color: <?php echo $i <= $avgRating ? '#ffc107' : '#ddd'; ?>;">★</span>
                        <?php endfor; ?>
                    </div>
                    <span style="color: #666; font-size: 1.1em;">
                        <strong><?php echo $avgRating; ?></strong>/5 
                        (<?php echo $ratingInfo['total_ratings']; ?> đánh giá)
                    </span>
                </div>
            <?php endif; ?>
            <p class="description"><strong>Mô tả:</strong> <?php echo nl2br(htmlspecialchars($product['description'])); ?></p>
            <p class="description"><strong>Tồn kho:</strong> <?php echo htmlspecialchars($product['stock_quantity']); ?></p>

            <?php if (isset($_SESSION['user_id']) && $_SESSION['role'] == 0): ?>
                <form action="index.php?controller=cart&action=addToCart" method="POST">
                    <input type="hidden" name="product_id" value="<?php echo htmlspecialchars($product['id']); ?>">
                    <label for="quantity">Số lượng:</label>
                    <input type="number" name="quantity" id="quantity" value="1" min="1" max="<?php echo htmlspecialchars($product['stock_quantity']); ?>" required>
                    <button type="submit">Thêm vào giỏ hàng</button>
                </form>
                <form action="index.php?controller=cart&action=placeOrderDirectly" method="POST" style="margin-top: 15px;">
                    <input type="hidden" name="product_id" value="<?php echo htmlspecialchars($product['id']); ?>">
                    <input type="hidden" name="quantity" value="1">
                    <button type="submit" style="background-color: #001058a0;">Đặt hàng ngay</button>
                </form>
            <?php else: ?>
                <p>Vui lòng <a href="index.php?controller=user&action=login">đăng nhập</a> để mua hàng.</p>
            <?php endif; ?>
        </div>
    </div>

    <div class="comments-section">
        <h2>Đánh giá và bình luận</h2>
        <?php if (isset($_SESSION['user_id'])): ?>
            <form action="index.php?controller=product&action=addComment" method="POST">
                <?php echo CSRF::field(); ?>
                <input type="hidden" name="product_id" value="<?php echo htmlspecialchars($product['id']); ?>">
                <div style="margin-bottom: 15px;">
                    <label style="display: block; margin-bottom: 8px; font-weight: bold; color: #000c40ff;">Đánh giá (tùy chọn):</label>
                    <div style="display: flex; align-items: center; gap: 10px;">
                        <select name="rating" style="padding: 8px; border: 1px solid #ddd; border-radius: 5px;">
                            <option value="">Chọn đánh giá</option>
                            <option value="5">5 sao - Tuyệt vời</option>
                            <option value="4">4 sao - Rất tốt</option>
                            <option value="3">3 sao - Tốt</option>
                            <option value="2">2 sao - Trung bình</option>
                            <option value="1">1 sao - Kém</option>
                        </select>
                        <div id="star-preview" style="display: flex; gap: 3px; font-size: 1.2em;">
                            <span style="color: #ddd;">★★★★★</span>
                        </div>
                    </div>
                </div>
                <textarea name="content" placeholder="Viết bình luận của bạn..." required></textarea><br>
                <button type="submit">Gửi đánh giá</button>
            </form>
            <script>
                document.querySelector('select[name="rating"]').addEventListener('change', function() {
                    const rating = parseInt(this.value) || 0;
                    const stars = document.querySelectorAll('#star-preview span');
                    if (stars.length > 0) {
                        let html = '';
                        for (let i = 1; i <= 5; i++) {
                            html += '<span style="color: ' + (i <= rating ? '#ffc107' : '#ddd') + ';">★</span>';
                        }
                        stars[0].innerHTML = html;
                    }
                });
            </script>
        <?php else: ?>
            <p>Vui lòng <a href="index.php?controller=user&action=login">đăng nhập</a> để bình luận.</p>
        <?php endif; ?>

        <div class="comment-list">
            <?php if (!empty($comments)): ?>
                <?php foreach ($comments as $comment): ?>
                    <div class="comment">
                        <p>
                            <strong><?php echo htmlspecialchars($comment['username']); ?></strong>
                            <?php if (isset($comment['rating']) && $comment['rating'] > 0): ?>
                                <span style="margin-left: 10px; display: inline-flex; align-items: center; gap: 3px;">
                                    <?php for ($i = 1; $i <= 5; $i++): ?>
                                        <span style="color: <?php echo $i <= $comment['rating'] ? '#ffc107' : '#ddd'; ?>;">★</span>
                                    <?php endfor; ?>
                                </span>
                            <?php endif; ?>
                            - <small><?php echo htmlspecialchars($comment['created_at']); ?></small>
                        </p>
                        <p><?php echo nl2br(htmlspecialchars($comment['content'])); ?></p>
                        <?php if (isset($_SESSION['role']) && $_SESSION['role'] == 1): ?>
                            <a href="index.php?controller=admin&action=deleteComment&id=<?php echo htmlspecialchars($comment['id']); ?>" onclick="return confirm('Bạn có chắc chắn muốn xóa bình luận này?');" style="color: red; text-decoration: none;">Xóa</a>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>Chưa có bình luận nào.</p>
            <?php endif; ?>
        </div>
    </div>

<?php else: ?>
    <p>Không tìm thấy sản phẩm.</p>
<?php endif; ?>