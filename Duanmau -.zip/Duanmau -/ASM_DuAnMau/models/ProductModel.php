<?php
require_once __DIR__ . '/BaseModel.php';

class ProductModel extends BaseModel
{
    private $table = 'products';

    public function __construct($conn)
    {
        parent::__construct($conn);
    }

    public function getAllProducts()
    {
        $sql = "SELECT p.*, c.name as category_name FROM " . $this->table . " p JOIN categories c ON p.category_id = c.id";
        $result = $this->conn->query($sql);
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    //lấy danh sách sản phẩm có phân trang
    public function getProductsPaginated(int $limit, int $offset)
    {
        $sql = "SELECT p.*, c.name as category_name FROM " . $this->table . " p JOIN categories c ON p.category_id = c.id ORDER BY p.id DESC LIMIT ? OFFSET ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("ii", $limit, $offset);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    public function countAllProducts(): int
    {
        $sql = "SELECT COUNT(*) as total FROM " . $this->table;
        $result = $this->conn->query($sql);
        $row = $result->fetch_assoc();
        return (int)($row['total'] ?? 0);
    }

    //lấy một sản phẩm theo ID
    public function getProductById($id)
    {
        $sql = "SELECT * FROM " . $this->table . " WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }

    //đếm tổng số sản phẩm
    public function getTotalProducts()
    {
        $sql = "SELECT COUNT(*) as total_products FROM " . $this->table;
        $result = $this->conn->query($sql);
        $row = $result->fetch_assoc();
        return $row['total_products'] ?? 0;
    }

    //thêm sản phẩm mới
    public function addProduct($data)
    {
        $sql = "INSERT INTO " . $this->table . " (name, price, description, image, category_id, stock_quantity) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("sdssii", $data['name'], $data['price'], $data['description'], $data['image'], $data['category_id'], $data['stock_quantity']);
        return $stmt->execute();
    }

    //cập nhật thông tin sản phẩm
    public function updateProduct($id, $data)
    {
        $sql = "UPDATE " . $this->table . " SET name = ?, price = ?, description = ?, image = ?, category_id = ?, stock_quantity = ? WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("sdssiii", $data['name'], $data['price'], $data['description'], $data['image'], $data['category_id'], $data['stock_quantity'], $id);
        return $stmt->execute();
    }

    //xóa sản phẩm
    public function deleteProduct($id)
    {
        $sql = "DELETE FROM " . $this->table . " WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $id);
        return $stmt->execute();
    }

    //tìm kiếm sản phẩm theo từ khóa
    public function searchProducts($keyword)
    {
        $sql = "SELECT p.*, c.name as category_name FROM " . $this->table . " p JOIN categories c ON p.category_id = c.id WHERE p.name LIKE ? OR p.description LIKE ? OR c.name LIKE ?";
        $stmt = $this->conn->prepare($sql);
        $searchTerm = '%' . $keyword . '%';
        $stmt->bind_param("sss", $searchTerm, $searchTerm, $searchTerm);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    //lọc sản phẩm theo danh mục, giá
    public function filterProducts($categoryId = null, $minPrice = null, $maxPrice = null, $keyword = null, $limit = null, $offset = 0)
    {
        $sql = "SELECT p.*, c.name as category_name FROM " . $this->table . " p JOIN categories c ON p.category_id = c.id WHERE 1=1";
        $params = [];
        $types = "";
        
        if ($categoryId !== null && $categoryId > 0) {
            $sql .= " AND p.category_id = ?";
            $params[] = $categoryId;
            $types .= "i";
        }
        
        if ($minPrice !== null && $minPrice > 0) {
            $sql .= " AND p.price >= ?";
            $params[] = $minPrice;
            $types .= "d";
        }
        
        if ($maxPrice !== null && $maxPrice > 0) {
            $sql .= " AND p.price <= ?";
            $params[] = $maxPrice;
            $types .= "d";
        }
        
        if ($keyword !== null && !empty($keyword)) {
            $sql .= " AND (p.name LIKE ? OR p.description LIKE ? OR c.name LIKE ?)";
            $searchTerm = '%' . $keyword . '%';
            $params[] = $searchTerm;
            $params[] = $searchTerm;
            $params[] = $searchTerm;
            $types .= "sss";
        }
        
        $sql .= " ORDER BY p.id DESC";
        
        if ($limit !== null && $limit > 0) {
            $sql .= " LIMIT ? OFFSET ?";
            $params[] = $limit;
            $params[] = $offset;
            $types .= "ii";
        }
        
        $stmt = $this->conn->prepare($sql);
        if (!empty($params)) {
            $stmt->bind_param($types, ...$params);
        }
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    //đếm sản phẩm sau khi lọc
    public function countFilteredProducts($categoryId = null, $minPrice = null, $maxPrice = null, $keyword = null)
    {
        $sql = "SELECT COUNT(*) as total FROM " . $this->table . " p JOIN categories c ON p.category_id = c.id WHERE 1=1";
        $params = [];
        $types = "";
        
        if ($categoryId !== null && $categoryId > 0) {
            $sql .= " AND p.category_id = ?";
            $params[] = $categoryId;
            $types .= "i";
        }
        
        if ($minPrice !== null && $minPrice > 0) {
            $sql .= " AND p.price >= ?";
            $params[] = $minPrice;
            $types .= "d";
        }
        
        if ($maxPrice !== null && $maxPrice > 0) {
            $sql .= " AND p.price <= ?";
            $params[] = $maxPrice;
            $types .= "d";
        }
        
        if ($keyword !== null && !empty($keyword)) {
            $sql .= " AND (p.name LIKE ? OR p.description LIKE ? OR c.name LIKE ?)";
            $searchTerm = '%' . $keyword . '%';
            $params[] = $searchTerm;
            $params[] = $searchTerm;
            $params[] = $searchTerm;
            $types .= "sss";
        }
        
        $stmt = $this->conn->prepare($sql);
        if (!empty($params)) {
            $stmt->bind_param($types, ...$params);
        }
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        return (int)($row['total'] ?? 0);
    }

    //lấy sản phẩm nổi bật (sản phẩm mới nhất hoặc có lượt mua nhiều)
    public function getFeaturedProducts($limit = 8)
    {
        $sql = "SELECT p.*, c.name as category_name FROM " . $this->table . " p JOIN categories c ON p.category_id = c.id ORDER BY p.id DESC LIMIT ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $limit);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }
}
