<?php
require_once __DIR__ . '/BaseModel.php'; 

class OrderModel extends BaseModel {
    private $orderTable = 'orders';
    private $orderDetailTable = 'order_details';

    public function __construct($conn) { 
        parent::__construct($conn);
    }

    public function createOrder($userId, $totalPrice, $cartItems) {
        $this->conn->begin_transaction();
        try {
            $sqlOrder = "INSERT INTO " . $this->orderTable . " (user_id, total_price) VALUES (?, ?)";
            $stmtOrder = $this->conn->prepare($sqlOrder);
            $stmtOrder->bind_param("id", $userId, $totalPrice);
            $stmtOrder->execute();
            $orderId = $this->conn->insert_id;
            
            $sqlDetail = "INSERT INTO " . $this->orderDetailTable . " (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)";
            $stmtDetail = $this->conn->prepare($sqlDetail);
            
            foreach ($cartItems as $item) {
                $stmtDetail->bind_param("iiid", $orderId, $item['product_id'], $item['quantity'], $item['price']);
                $stmtDetail->execute();
            }
            $this->conn->commit();
            return true;
        } catch (Exception $e) {
            $this->conn->rollback();
            return false;
        }
    }

    public function createOrderWithDetails($userId, $totalPrice, $cartItems, $receiverName = null, $phone = null, $address = null, $note = null, $paymentMethod = 'COD') {
        $this->conn->begin_transaction();
        try {
            $columns = "user_id, total_price";
            $values = "?, ?";
            $params = [$userId, $totalPrice];
            $types = "id";

            $checkColumns = $this->conn->query("DESCRIBE " . $this->orderTable);
            $existingColumns = [];
            while ($row = $checkColumns->fetch_assoc()) {
                $existingColumns[] = $row['Field'];
            }

            if (in_array('receiver_name', $existingColumns) && $receiverName !== null) {
                $columns .= ", receiver_name";
                $values .= ", ?";
                $params[] = $receiverName;
                $types .= "s";
            }
            if (in_array('phone', $existingColumns) && $phone !== null) {
                $columns .= ", phone";
                $values .= ", ?";
                $params[] = $phone;
                $types .= "s";
            }
            if (in_array('address', $existingColumns) && $address !== null) {
                $columns .= ", address";
                $values .= ", ?";
                $params[] = $address;
                $types .= "s";
            }
            if (in_array('note', $existingColumns) && $note !== null) {
                $columns .= ", note";
                $values .= ", ?";
                $params[] = $note;
                $types .= "s";
            }
            if (in_array('payment_method', $existingColumns)) {
                $columns .= ", payment_method";
                $values .= ", ?";
                $params[] = $paymentMethod;
                $types .= "s";
            }

            $sqlOrder = "INSERT INTO " . $this->orderTable . " (" . $columns . ") VALUES (" . $values . ")";
            $stmtOrder = $this->conn->prepare($sqlOrder);
            $stmtOrder->bind_param($types, ...$params);
            $stmtOrder->execute();
            $orderId = $this->conn->insert_id;
            
            $sqlDetail = "INSERT INTO " . $this->orderDetailTable . " (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)";
            $stmtDetail = $this->conn->prepare($sqlDetail);
            
            foreach ($cartItems as $item) {
                $stmtDetail->bind_param("iiid", $orderId, $item['product_id'], $item['quantity'], $item['price']);
                $stmtDetail->execute();
            }
            $this->conn->commit();
            return true;
        } catch (Exception $e) {
            $this->conn->rollback();
            return false;
        }
    }

    public function getOrdersByUserId($userId) {
        $sql = "SELECT o.*, u.username FROM " . $this->orderTable . " o JOIN users u ON o.user_id = u.id WHERE o.user_id = ? ORDER BY o.order_date DESC";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    public function getOrderDetails($orderId) {
        $sql = "SELECT od.*, p.name, p.image FROM " . $this->orderDetailTable . " od JOIN products p ON od.product_id = p.id WHERE od.order_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $orderId);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    public function getOrderById($orderId) {
        $sql = "SELECT o.*, u.username FROM " . $this->orderTable . " o JOIN users u ON o.user_id = u.id WHERE o.id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $orderId);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }
    
    public function getAllOrders() {
        $sql = "SELECT o.*, u.username FROM " . $this->orderTable . " o JOIN users u ON o.user_id = u.id ORDER BY o.order_date DESC";
        $result = $this->conn->query($sql);
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
    public function getTotalRevenue() {
        $sql = "SELECT SUM(total_price) as total_revenue FROM " . $this->orderTable . " WHERE status = 'Đã hoàn thành'";
        $result = $this->conn->query($sql);
        $row = $result->fetch_assoc();
        return $row['total_revenue'] ?? 0;
    }
    
    public function getTotalOrders() {
        $sql = "SELECT COUNT(*) as total_orders FROM " . $this->orderTable;
        $result = $this->conn->query($sql);
        $row = $result->fetch_assoc();
        return $row['total_orders'] ?? 0;
    }

    public function getOrdersByStatus($status) {
        $sql = "SELECT COUNT(*) as count FROM " . $this->orderTable . " WHERE status = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("s", $status);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        return $row['count'] ?? 0;
    }

    public function getRevenueByDate($date) {
        $sql = "SELECT SUM(total_price) as revenue FROM " . $this->orderTable . " WHERE DATE(order_date) = ? AND status = 'Đã hoàn thành'";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("s", $date);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        return $row['revenue'] ?? 0;
    }

    public function getRevenueByMonth($year, $month) {
        $sql = "SELECT SUM(total_price) as revenue FROM " . $this->orderTable . " WHERE YEAR(order_date) = ? AND MONTH(order_date) = ? AND status = 'Đã hoàn thành'";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("ii", $year, $month);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        return $row['revenue'] ?? 0;
    }

    public function getCurrentMonthRevenue() {
        $sql = "SELECT SUM(total_price) as revenue FROM " . $this->orderTable . " WHERE YEAR(order_date) = YEAR(CURDATE()) AND MONTH(order_date) = MONTH(CURDATE()) AND status = 'Đã hoàn thành'";
        $result = $this->conn->query($sql);
        $row = $result->fetch_assoc();
        return $row['revenue'] ?? 0;
    }

    public function getCurrentMonthOrders() {
        $sql = "SELECT COUNT(*) as count FROM " . $this->orderTable . " WHERE YEAR(order_date) = YEAR(CURDATE()) AND MONTH(order_date) = MONTH(CURDATE())";
        $result = $this->conn->query($sql);
        $row = $result->fetch_assoc();
        return $row['count'] ?? 0;
    }

    public function getTopSellingProducts($limit = 5) {
        $sql = "SELECT p.id, p.name, p.image, SUM(od.quantity) as total_sold, SUM(od.quantity * od.price) as total_revenue 
                FROM " . $this->orderDetailTable . " od 
                JOIN products p ON od.product_id = p.id 
                JOIN " . $this->orderTable . " o ON od.order_id = o.id 
                WHERE o.status = 'Đã hoàn thành'
                GROUP BY p.id, p.name, p.image 
                ORDER BY total_sold DESC 
                LIMIT ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $limit);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    public function getOrdersLast7Days() {
        $sql = "SELECT DATE(order_date) as date, COUNT(*) as count, SUM(total_price) as revenue 
                FROM " . $this->orderTable . " 
                WHERE order_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
                GROUP BY DATE(order_date)
                ORDER BY date ASC";
        $result = $this->conn->query($sql);
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
    public function updateOrderStatus($orderId, $status) {
        $sql = "UPDATE " . $this->orderTable . " SET status = ? WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("si", $status, $orderId);
        return $stmt->execute();
    }

    public function deleteOrder($orderId) {
        $this->conn->begin_transaction();
        try {
            $sqlDetail = "DELETE FROM " . $this->orderDetailTable . " WHERE order_id = ?";
            $stmtDetail = $this->conn->prepare($sqlDetail);
            $stmtDetail->bind_param("i", $orderId);
            $stmtDetail->execute();
            
            $sqlOrder = "DELETE FROM " . $this->orderTable . " WHERE id = ?";
            $stmtOrder = $this->conn->prepare($sqlOrder);
            $stmtOrder->bind_param("i", $orderId);
            $stmtOrder->execute();
            
            $this->conn->commit();
            return true;
        } catch (Exception $e) {
            $this->conn->rollback();
            return false;
        }
    }
}
?>