<?php
require_once __DIR__ . '/BaseModel.php'; 

class CartModel extends BaseModel {
    private $table = 'cart';

    public function __construct($conn) { 
        parent::__construct($conn);
    }

    //thêm sản phẩm vào giỏ hàng
    public function addToCart($userId, $productId, $quantity) {
        $sqlCheck = "SELECT * FROM " . $this->table . " WHERE user_id = ? AND product_id = ?";
        $stmtCheck = $this->conn->prepare($sqlCheck);
        $stmtCheck->bind_param("ii", $userId, $productId);
        $stmtCheck->execute();
        $resultCheck = $stmtCheck->get_result();
        $existingItem = $resultCheck->fetch_assoc();

        if ($existingItem) {
            $newQuantity = $existingItem['quantity'] + $quantity;
            $sqlUpdate = "UPDATE " . $this->table . " SET quantity = ? WHERE id = ?";
            $stmtUpdate = $this->conn->prepare($sqlUpdate);
            $stmtUpdate->bind_param("ii", $newQuantity, $existingItem['id']);
            return $stmtUpdate->execute();
        } else {
            $sqlInsert = "INSERT INTO " . $this->table . " (user_id, product_id, quantity) VALUES (?, ?, ?)";
            $stmtInsert = $this->conn->prepare($sqlInsert);
            $stmtInsert->bind_param("iii", $userId, $productId, $quantity);
            return $stmtInsert->execute();
        }
    }

    //hiện tất cả sản phẩm trong giỏ hàng
    public function getCartItems($userId) {
        $sql = "SELECT c.id as cart_id, c.quantity, p.id as product_id, p.name, p.price, p.image, p.stock_quantity FROM " . $this->table . " c JOIN products p ON c.product_id = p.id WHERE c.user_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    //xóa 1 sản phẩm trong giot hàng
    public function removeCartItem($cartId) {
        $sql = "DELETE FROM " . $this->table . " WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $cartId);
        return $stmt->execute();
    }

        //xóa toàn bộ sản phẩm trong giò hàng
    public function clearCart($userId) {
        $sql = "DELETE FROM " . $this->table . " WHERE user_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $userId);
        return $stmt->execute();
    }

    //lấy một item trong giỏ hàng theo ID
    public function getCartItemById($cartId) {
        $sql = "SELECT c.*, p.stock_quantity FROM " . $this->table . " c JOIN products p ON c.product_id = p.id WHERE c.id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $cartId);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }

    //cập nhật số lượng sản phẩm trong giỏ hàng
    public function updateCartQuantity($cartId, $quantity) {
        $sql = "UPDATE " . $this->table . " SET quantity = ? WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("ii", $quantity, $cartId);
        return $stmt->execute();
    }
}
?>