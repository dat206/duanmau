<?php
require_once __DIR__ . '/BaseModel.php';

class CommentModel extends BaseModel {
    private $table = 'comments';

    public function __construct($conn) {
        parent::__construct($conn);
    }

    public function getCommentsByProductId($productId) {
        $sql = "SELECT c.*, u.username FROM " . $this->table . " c JOIN users u ON c.user_id = u.id WHERE c.product_id = ? ORDER BY c.created_at DESC";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $productId);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    public function getAverageRating($productId) {
        $sql = "SELECT AVG(rating) as avg_rating, COUNT(*) as total_ratings FROM " . $this->table . " WHERE product_id = ? AND rating IS NOT NULL";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $productId);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        return [
            'avg_rating' => $row['avg_rating'] ? round($row['avg_rating'], 1) : 0,
            'total_ratings' => $row['total_ratings'] ?? 0
        ];
    }
    
    public function getAllComments() {
        $sql = "SELECT c.*, u.username, p.name as product_name FROM " . $this->table . " c JOIN users u ON c.user_id = u.id JOIN products p ON c.product_id = p.id ORDER BY c.created_at DESC";
        $result = $this->conn->query($sql);
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    public function addComment($productId, $userId, $content, $rating = null) {
        $checkColumns = $this->conn->query("DESCRIBE " . $this->table);
        $existingColumns = [];
        while ($row = $checkColumns->fetch_assoc()) {
            $existingColumns[] = $row['Field'];
        }

        if (in_array('rating', $existingColumns)) {
            $sql = "INSERT INTO " . $this->table . " (product_id, user_id, content, rating) VALUES (?, ?, ?, ?)";
            $stmt = $this->conn->prepare($sql);
            $rating = $rating !== null ? (int)$rating : null;
            $stmt->bind_param("iisi", $productId, $userId, $content, $rating);
        } else {
            $sql = "INSERT INTO " . $this->table . " (product_id, user_id, content) VALUES (?, ?, ?)";
            $stmt = $this->conn->prepare($sql);
            $stmt->bind_param("iis", $productId, $userId, $content);
        }
        return $stmt->execute();
    }
    
    public function deleteComment($commentId) {
        $sql = "DELETE FROM " . $this->table . " WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $commentId);
        return $stmt->execute();
    }
}
?>