<?php
require_once __DIR__ . '/BaseModel.php';

class UserModel extends BaseModel {
    private $table = 'users';

    public function __construct($conn) {
        parent::__construct($conn);
    }

    /** Đăng nhập */
    public function login($username, $password) {
        $sql = "SELECT * FROM {$this->table} WHERE username = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

        if ($user && password_verify($password, $user['password'])) {
            return $user;
        }
        return false;
    }

    /** Đăng ký */
    public function register($username, $password) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $sql = "INSERT INTO {$this->table} (username, password) VALUES (?, ?)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("ss", $username, $hashedPassword);
        return $stmt->execute();
    }

    /** Lấy danh sách tất cả người dùng */
    public function getAllUsers() {
        $sql = "SELECT * FROM {$this->table}";
        $result = $this->conn->query($sql);
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    /** Lấy thông tin người dùng theo ID */
    public function getUserById($id) {
        $sql = "SELECT * FROM {$this->table} WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }

    /** Cập nhật vai trò (role) người dùng */
    public function updateUserRole($userId, $newRole) {
        $sql = "UPDATE {$this->table} SET role = ? WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("ii", $newRole, $userId);
        return $stmt->execute();
    }

    /** Cập nhật thông tin người dùng */
    public function updateUserInfo($userId, $username, $age, $address, $phoneNumber) {
        $sql = "UPDATE {$this->table} SET username = ?, age = ?, address = ?, phone_number = ? WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("sisii", $username, $age, $address, $phoneNumber, $userId);
        return $stmt->execute();
    }

    /** Cập nhật mật khẩu */
    public function updatePassword($userId, $newPassword) {
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
        $sql = "UPDATE {$this->table} SET password = ? WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("si", $hashedPassword, $userId);
        return $stmt->execute();
    }

    /** Tổng số người dùng */
    public function getTotalUsers() {
        $sql = "SELECT COUNT(*) as total FROM {$this->table}";
        $result = $this->conn->query($sql);
        $row = $result->fetch_assoc();
        return $row['total'] ?? 0;
    }

    /** Người dùng mới trong tháng này */
    public function getNewUsersThisMonth() {
        $sql = "SELECT COUNT(*) as count FROM {$this->table} 
                WHERE YEAR(created_at) = YEAR(CURDATE()) 
                AND MONTH(created_at) = MONTH(CURDATE())";
        $result = $this->conn->query($sql);
        $row = $result->fetch_assoc();
        return $row['count'] ?? 0;
    }

    /** Xóa người dùng + dữ liệu liên quan */
    public function deleteUser($id) {
        // Tắt khóa ngoại
        $this->conn->query("SET FOREIGN_KEY_CHECKS = 0");

        // Xóa dữ liệu liên quan
        $this->conn->query("DELETE FROM order_details WHERE order_id IN (SELECT id FROM orders WHERE user_id = $id)");
        $this->conn->query("DELETE FROM orders WHERE user_id = $id");
        $this->conn->query("DELETE FROM cart WHERE user_id = $id");
        $this->conn->query("DELETE FROM comments WHERE user_id = $id");

        // Xóa người dùng
        $stmt = $this->conn->prepare("DELETE FROM {$this->table} WHERE id = ?");
        $stmt->bind_param("i", $id);
        $result = $stmt->execute();

        // Bật lại khóa ngoại
        $this->conn->query("SET FOREIGN_KEY_CHECKS = 1");

        return $result;
    }
}
?>
