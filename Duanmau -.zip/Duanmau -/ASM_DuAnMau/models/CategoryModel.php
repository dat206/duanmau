<?php
require_once __DIR__ . '/BaseModel.php';

class CategoryModel extends BaseModel {
    private $table = 'categories';

    public function __construct($conn) { 
        parent::__construct($conn);
    }

    //lấy tất cả danh mục
    public function getAllCategories() {
        $sql = "SELECT * FROM " . $this->table;
        $result = $this->conn->query($sql);
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    //lấy một danh mục theo ID
    public function getCategoryById($id) {
        $sql = "SELECT * FROM " . $this->table . " WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }

    ///thêm danh mục mới
    public function addCategory($name) {
        $sql = "INSERT INTO " . $this->table . " (name) VALUES (?)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("s", $name);
        return $stmt->execute();
    }

    //cập nhật danh mục
    public function updateCategory($id, $name) {
        $sql = "UPDATE " . $this->table . " SET name = ? WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("si", $name, $id);
        return $stmt->execute();
    }

    //xóa danh mục
    public function deleteCategory($id) {
        $sql = "DELETE FROM " . $this->table . " WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $id);
        return $stmt->execute();
    }
}
?>