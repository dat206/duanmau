<?php
session_start();

require_once 'config/database.php';
require_once 'helpers/CSRF.php'; 

require_once 'models/BaseModel.php';
require_once 'models/CategoryModel.php';
require_once 'models/CommentModel.php';
require_once 'models/OrderModel.php';
require_once 'models/ProductModel.php';
require_once 'models/UserModel.php';
require_once 'models/CartModel.php'; 

require_once 'controllers/Homecontroller.php';
require_once 'controllers/UserController.php';
require_once 'controllers/AdminController.php';
require_once 'controllers/ProductController.php';
require_once 'controllers/CartController.php';
require_once 'controllers/OrderController.php';


$controller = isset($_GET['controller']) ? $_GET['controller'] : 'home';
$action = isset($_GET['action']) ? $_GET['action'] : 'index';

switch ($controller) {
    case 'home':
        $controllerInstance = new HomeController();
        break;
    case 'user':
        $controllerInstance = new UserController();
        break;
    case 'admin':
        $controllerInstance = new AdminController();
        break;
    case 'product':
        $controllerInstance = new ProductController();
        break;
    case 'cart': 
        $controllerInstance = new CartController();
        break;
    case 'order':
        $controllerInstance = new OrderController();
        break;
    default:
        $controllerInstance = new HomeController();
        break;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    switch ($controller) {
        case 'user':
            if ($action === 'login') {
                $controllerInstance->handleLogin();
                exit();
            } elseif ($action === 'register') {
                $controllerInstance->handleRegister();
                exit();
            } elseif ($action === 'profile') {
                $controllerInstance->handleProfileUpdate();
                exit();
            }
            break;
    }
}

if (method_exists($controllerInstance, $action)) {
    $controllerInstance->$action();
} else {
    http_response_code(404);
    echo "Không tìm thấy trang.";
}

?>