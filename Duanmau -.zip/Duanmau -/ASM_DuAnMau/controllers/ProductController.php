<?php
require_once __DIR__ . '/../models/ProductModel.php';
require_once __DIR__ . '/../models/CommentModel.php';

class ProductController {

    //phân trang 8 sản phẩm mỗi trang
    public function list() {
        global $conn;
        require_once __DIR__ . '/../models/CategoryModel.php';
        $productModel = new ProductModel($conn); 
        $categoryModel = new CategoryModel($conn);

        $perPage = 8;
        $page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
        $total = $productModel->countAllProducts();
        $totalPages = max(1, (int)ceil($total / $perPage));
        if ($page > $totalPages) { $page = $totalPages; }
        $offset = ($page - 1) * $perPage;

        $products = $productModel->getProductsPaginated($perPage, $offset);
        $categories = $categoryModel->getAllCategories();

        require_once __DIR__ . '/../views/layouts/user_header.php'; 
        require_once __DIR__ . '/../views/products/list.php';
        require_once __DIR__ . '/../views/layouts/user_footer.php'; 
    }

    //xem chi tiêts sản phẩm
    public function detail() {
        global $conn;
        $productModel = new ProductModel($conn);
        $commentModel = new CommentModel($conn);
        $product = null;
        $comments = [];
        $ratingInfo = ['avg_rating' => 0, 'total_ratings' => 0];
        
        if (isset($_GET['id'])) {
            $product = $productModel->getProductById($_GET['id']);
            if ($product) {
                $comments = $commentModel->getCommentsByProductId($_GET['id']);
                $ratingInfo = $commentModel->getAverageRating($_GET['id']);
            }
        }
        
        require_once __DIR__ . '/../views/layouts/user_header.php'; 
        require_once __DIR__ . '/../views/products/detail.php'; 
        require_once __DIR__ . '/../views/layouts/user_footer.php'; 
    }
    
    //bình luận
    public function addComment() {
        if (!isset($_SESSION['user_id'])) {
            header('Location: index.php?controller=user&action=login');
            exit();
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['product_id']) && isset($_POST['content'])) {
            // CSRF Protection
            if (!isset($_POST['csrf_token']) || !CSRF::verify($_POST['csrf_token'])) {
                echo "<script>alert('Invalid security token. Please try again.');</script>";
                $productId = $_POST['product_id'] ?? 0;
                header('refresh:0; url=index.php?controller=product&action=detail&id=' . $productId);
                exit();
            }

            global $conn; 
            $userId = $_SESSION['user_id'];
            $productId = $_POST['product_id'];
            $content = trim($_POST['content']);
            $rating = isset($_POST['rating']) && $_POST['rating'] !== '' ? (int)$_POST['rating'] : null;
            
            if (empty($content)) {
                echo "<script>alert('Vui lòng nhập nội dung bình luận!');</script>";
                header('refresh:0; url=index.php?controller=product&action=detail&id=' . $productId);
                exit();
            }
            
            if ($rating !== null && ($rating < 1 || $rating > 5)) {
                $rating = null;
            }
            
            $commentModel = new CommentModel($conn); 
            if ($commentModel->addComment($productId, $userId, $content, $rating)) {
                header('Location: index.php?controller=product&action=detail&id=' . $productId);
                exit();
            } else {
                echo "<script>alert('Có lỗi khi thêm bình luận');</script>";
                header('refresh:0; url=index.php?controller=product&action=detail&id=' . $productId);
                exit();
            }
        }
        header('Location: index.php');
        exit();
    }
    
    public function search() {
        global $conn; 
        require_once __DIR__ . '/../models/CategoryModel.php';
        $productModel = new ProductModel($conn);
        $categoryModel = new CategoryModel($conn);
        
        $keyword = isset($_GET['keyword']) ? trim($_GET['keyword']) : '';
        $categoryId = isset($_GET['category']) ? (int)$_GET['category'] : null;
        $minPrice = isset($_GET['min_price']) && $_GET['min_price'] !== '' ? (float)$_GET['min_price'] : null;
        $maxPrice = isset($_GET['max_price']) && $_GET['max_price'] !== '' ? (float)$_GET['max_price'] : null;
        
        $perPage = 8;
        $page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
        $total = $productModel->countFilteredProducts($categoryId, $minPrice, $maxPrice, $keyword);
        $totalPages = max(1, (int)ceil($total / $perPage));
        if ($page > $totalPages) { $page = $totalPages; }
        $offset = ($page - 1) * $perPage;
        
        $products = $productModel->filterProducts($categoryId, $minPrice, $maxPrice, $keyword, $perPage, $offset);
        $categories = $categoryModel->getAllCategories();
        
        require_once __DIR__ . '/../views/layouts/user_header.php'; 
        require_once __DIR__ . '/../views/products/list.php';
        require_once __DIR__ . '/../views/layouts/user_footer.php';
    }
}
?>