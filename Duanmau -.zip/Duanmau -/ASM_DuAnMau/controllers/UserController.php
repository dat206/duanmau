<?php
require_once __DIR__ . '/../models/UserModel.php';

class UserController {
    public function login() {
        require_once __DIR__ . '/../views/layouts/user_header.php';
        require_once __DIR__ . '/../views/auth/login.php';
        require_once __DIR__ . '/../views/layouts/user_footer.php';
    }

    public function handleLogin() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!isset($_POST['csrf_token']) || !CSRF::verify($_POST['csrf_token'])) {
                echo "<script>alert('Invalid security token. Please try again.');</script>";
                header('refresh:0; url=index.php?controller=user&action=login');
                exit();
            }

            global $conn;
            $username = trim($_POST['username'] ?? '');
            $password = $_POST['password'] ?? '';
            
            if (empty($username) || empty($password)) {
                echo "<script>alert('Vui lòng nhập đầy đủ thông tin!');</script>";
                header('refresh:0; url=index.php?controller=user&action=login');
                exit();
            }
            
            $userModel = new UserModel($conn);
            $user = $userModel->login($username, $password);

            if ($user) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $user['role'];
                
                if ($_SESSION['role'] == 1) {
                    header('Location: index.php?controller=admin&action=dashboard');
                } else {
                    header('Location: index.php');
                }
                exit();
            } else {
                echo "<script>alert('Tên đăng nhập hoặc mật khẩu không đúng.');</script>";
                header('refresh:0; url=index.php?controller=user&action=login');
                exit();
            }
        }
    }


    public function register() {
        require_once __DIR__ . '/../views/layouts/user_header.php'; 
        require_once __DIR__ . '/../views/auth/register.php'; 
        require_once __DIR__ . '/../views/layouts/user_footer.php';
    }

    public function handleRegister() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!isset($_POST['csrf_token']) || !CSRF::verify($_POST['csrf_token'])) {
                echo "<script>alert('Invalid security token. Please try again.');</script>";
                header('refresh:0; url=index.php?controller=user&action=register');
                exit();
            }

            global $conn; 
            $username = trim($_POST['username'] ?? '');
            $password = $_POST['password'] ?? '';

            if (empty($username) || empty($password)) {
                echo "<script>alert('Vui lòng nhập đầy đủ thông tin!');</script>";
                header('refresh:0; url=index.php?controller=user&action=register');
                exit();
            }

            if (strlen($username) < 3 || strlen($username) > 50) {
                echo "<script>alert('Tên đăng nhập phải từ 3-50 ký tự!');</script>";
                header('refresh:0; url=index.php?controller=user&action=register');
                exit();
            }

            if (strlen($password) < 6) {
                echo "<script>alert('Mật khẩu phải có ít nhất 6 ký tự!');</script>";
                header('refresh:0; url=index.php?controller=user&action=register');
                exit();
            }

            $userModel = new UserModel($conn); 
            if ($userModel->register($username, $password)) {
                echo "<script>alert('Đăng ký thành công');</script>";
                header('refresh:0; url=index.php?controller=user&action=login');
                exit();
            } else {
                echo "<script>alert('Đăng ký thất bại - Tên đăng nhập có thể đã tồn tại');</script>";
                header('refresh:0; url=index.php?controller=user&action=register');
                exit();
            }
        }
    }

    public function logout() {
        session_destroy();
        header('Location: index.php');
        exit();
    }
    
    public function profile() {
        if (!isset($_SESSION['user_id'])) {
            header('Location: index.php?controller=user&action=login');
            exit();
        }

        global $conn;
        $userModel = new UserModel($conn); 
        $user = $userModel->getUserById($_SESSION['user_id']);

        require_once __DIR__ . '/../views/layouts/user_header.php'; 
        require_once __DIR__ . '/../views/profile.php';
        require_once __DIR__ . '/../views/layouts/user_footer.php';
    }

    public function handleProfileUpdate() {
        if (!isset($_SESSION['user_id'])) {
            header('Location: index.php?controller=user&action=login');
            exit();
        }
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            global $conn; 
            $userId = $_SESSION['user_id'];
            $newUsername = $_POST['username'] ?? '';
            $newPassword = $_POST['password'] ?? '';
            $age = $_POST['age'] ?? null;
            $address = $_POST['address'] ?? '';
            $phoneNumber = $_POST['phone_number'] ?? '';

            $userModel = new UserModel($conn);
            
            if ($userModel->updateUserInfo($userId, $newUsername, $age, $address, $phoneNumber)) {
                $_SESSION['username'] = $newUsername;
                echo "<script>alert('Cập nhật thông tin thành công!');</script>";
            } else {
                echo "<script>alert('Cập nhật thông tin thất bại.');</script>";
            }
            
            if (!empty($newPassword)) {
                if ($userModel->updatePassword($userId, $newPassword)) {
                    echo "<script>alert('Cập nhật mật khẩu thành công!');</script>";
                } else {
                    echo "<script>alert('Cập nhật mật khẩu thất bại.');</script>";
                }
            }
            header('refresh:0; url=index.php?controller=user&action=profile');
            exit();
        }
    }
}
?>