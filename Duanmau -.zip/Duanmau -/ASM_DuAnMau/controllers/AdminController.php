<?php
require_once __DIR__ . '/../models/ProductModel.php';
require_once __DIR__ . '/../models/UserModel.php';
require_once __DIR__ . '/../models/OrderModel.php';
require_once __DIR__ . '/../models/CommentModel.php';
require_once __DIR__ . '/../models/CategoryModel.php';

class AdminController {
    private function checkAdmin() {
        if (!isset($_SESSION['role']) || $_SESSION['role'] != 1) {
            header('Location: index.php');
            exit();
        }
    }

    //thống kê 
    public function dashboard() {
        $this->checkAdmin();
        global $conn;
        $orderModel = new OrderModel($conn);
        $productModel = new ProductModel($conn);
        $userModel = new UserModel($conn);
        
        $totalRevenue = $orderModel->getTotalRevenue();
        $totalOrders = $orderModel->getTotalOrders();
        $totalProducts = $productModel->getTotalProducts();
        $totalUsers = $userModel->getTotalUsers();
        $productsInStock = $productModel->getAllProducts();
        
        // Thống kê chi tiết
        $currentMonthRevenue = $orderModel->getCurrentMonthRevenue();
        $currentMonthOrders = $orderModel->getCurrentMonthOrders();
        $pendingOrders = $orderModel->getOrdersByStatus('Chờ xử lý');
        $processingOrders = $orderModel->getOrdersByStatus('Đang giao');
        $completedOrders = $orderModel->getOrdersByStatus('Đã hoàn thành');
        $newUsersThisMonth = $userModel->getNewUsersThisMonth();
        $topSellingProducts = $orderModel->getTopSellingProducts(5);
        $ordersLast7Days = $orderModel->getOrdersLast7Days();

        require_once __DIR__ . '/../views/layouts/admin_header.php';
        require_once __DIR__ . '/../views/admin/dashboard.php';
        require_once __DIR__ . '/../views/layouts/admin_footer.php';
    }

    //hiện tất cả các đơn hàng ra
    public function orders() {
        $this->checkAdmin();
        global $conn;
        $orderModel = new OrderModel($conn);
        $orders = $orderModel->getAllOrders();
        
        require_once __DIR__ . '/../views/layouts/admin_header.php';
        require_once __DIR__ . '/../views/admin/orders/list.php';
        require_once __DIR__ . '/../views/layouts/admin_footer.php';
    }
    
    //sửa trạng thái đơn hàng
    public function updateOrderStatus() {
        $this->checkAdmin();
        if (isset($_GET['id']) && isset($_POST['status'])) {
            global $conn;
            $orderId = $_GET['id'];
            $status = $_POST['status'];
            $orderModel = new OrderModel($conn);
            $orderModel->updateOrderStatus($orderId, $status);
        }
        header('Location: index.php?controller=admin&action=orders');
        exit();
    }

    //xóa đơn hàng
    public function deleteOrder() {
        $this->checkAdmin();
        if (isset($_GET['id'])) {
            global $conn;
            $orderId = $_GET['id'];
            $orderModel = new OrderModel($conn);
            $orderModel->deleteOrder($orderId);
        }
        header('Location: index.php?controller=admin&action=orders');
        exit();
    }

    //danh sách người dùng
    public function users() {
        $this->checkAdmin();
        global $conn;
        $userModel = new UserModel($conn);
        $users = $userModel->getAllUsers();
        require_once __DIR__ . '/../views/layouts/admin_header.php';
        require_once __DIR__ . '/../views/admin/users/list.php';
        require_once __DIR__ . '/../views/layouts/admin_footer.php';
    }
    
    //cấp quyền admin cho user
    public function updateUserRole() {
        $this->checkAdmin();
        if (isset($_GET['id']) && isset($_GET['role'])) {
            global $conn;
            $userId = $_GET['id'];
            $newRole = $_GET['role'];
            $userModel = new UserModel($conn);
            $userModel->updateUserRole($userId, $newRole);
        }
        header('Location: index.php?controller=admin&action=users');
        exit();
    }

    //xóa người dùng
    public function deleteUser() {
        $this->checkAdmin();
        if (isset($_GET['id'])) {
            global $conn;
            $userId = $_GET['id'];
            $userModel = new UserModel($conn);
            $userModel->deleteUser($userId);
        }
        header('Location: index.php?controller=admin&action=users');
        exit();
    }
    
    //sửa người dùng
    public function editUser() {
        $this->checkAdmin();
        if (isset($_GET['id'])) {
            global $conn;
            $userModel = new UserModel($conn);
            $user = $userModel->getUserById($_GET['id']);
            require_once __DIR__ . '/../views/layouts/admin_header.php';
            require_once __DIR__ . '/../views/admin/users/edit.php';
            require_once __DIR__ . '/../views/layouts/admin_footer.php';
        } else {
            header('Location: index.php?controller=admin&action=users');
            exit();
        }
    }

    //cập nhật thông tin user
    public function handleEditUser() {
        $this->checkAdmin();
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
            global $conn;
            $userId = $_POST['id'];
            $username = $_POST['username'] ?? '';
            $age = $_POST['age'] ?? null;
            $address = $_POST['address'] ?? '';
            $phoneNumber = $_POST['phone_number'] ?? '';
            $password = $_POST['password'] ?? '';

            $userModel = new UserModel($conn);
            
            if ($userModel->updateUserInfo($userId, $username, $age, $address, $phoneNumber)) {
                if (!empty($password)) {
                    $userModel->updatePassword($userId, $password);
                }
                header('Location: index.php?controller=admin&action=users');
                exit();
            } else {
                echo "<script>alert('Cập nhật thông tin người dùng thất bại');</script>";
                header('refresh:0; url=index.php?controller=admin&action=editUser&id=' . $userId);
                exit();
            }
        }
        header('Location: index.php?controller=admin&action=users');
        exit();
    }

    //lấy tất cả sản phẩm
    public function products() {
        $this->checkAdmin();
        global $conn;
        $productModel = new ProductModel($conn);
        $products = $productModel->getAllProducts();
        require_once __DIR__ . '/../views/layouts/admin_header.php';
        require_once __DIR__ . '/../views/admin/products/list.php';
        require_once __DIR__ . '/../views/layouts/admin_footer.php';
    }

    //thêm sản phẩm
    public function addProduct() {
        $this->checkAdmin();
        global $conn;
        $categoryModel = new CategoryModel($conn);
        $categories = $categoryModel->getAllCategories();
        require_once __DIR__ . '/../views/layouts/admin_header.php';
        require_once __DIR__ . '/../views/admin/products/add.php';
        require_once __DIR__ . '/../views/layouts/admin_footer.php';
    }


    public function handleAddProduct() {
        $this->checkAdmin();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            global $conn;
            $data = $_POST;
            $imageName = null;

            //upload ảnh
            if (isset($_FILES['image'])) {
                if ($_FILES['image']['error'] == UPLOAD_ERR_OK) {
                    $targetDir = "public/images/products/";
                    if (!is_dir($targetDir)) {
                        mkdir($targetDir, 0775, true); 
                    }

                    $imageName = basename($_FILES["image"]["name"]);
                    $targetFilePath = $targetDir . $imageName;
                    $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);

                    $allowTypes = array('jpg','png','jpeg','gif');
                    if(in_array(strtolower($fileType), $allowTypes)){ 
                        if(move_uploaded_file($_FILES["image"]["tmp_name"], $targetFilePath)){
                            $data['image'] = $imageName;
                        } else {
                            error_log("Lỗi di chuyển file: " . $_FILES["image"]["tmp_name"] . " đến " . $targetFilePath);
                            echo "<script>alert('Có lỗi khi di chuyển ảnh lên server - Vui lòng kiểm tra quyền ghi thư mục');</script>";
                            header('refresh:0; url=index.php?controller=admin&action=addProduct');
                            exit();
                        }
                    } else {
                        echo "<script>alert('Chỉ chấp nhận file JPG, JPEG, PNG, GIF. Định dạng file của bạn là: " . htmlspecialchars($fileType) . "');</script>";
                        header('refresh:0; url=index.php?controller=admin&action=addProduct');
                        exit();
                    }
                } else {
                    $errorMessage = "Lỗi upload file: ";
                    switch ($_FILES['image']['error']) {
                        case UPLOAD_ERR_INI_SIZE:
                        case UPLOAD_ERR_FORM_SIZE:
                            $errorMessage .= "Kích thước file quá lớn so với giới hạn của server";
                            break;
                        case UPLOAD_ERR_PARTIAL:
                            $errorMessage .= "File chỉ được upload một phần";
                            break;
                        case UPLOAD_ERR_NO_FILE:
                            $errorMessage .= "Không có file nào được chọn";
                            break;
                        case UPLOAD_ERR_NO_TMP_DIR:
                            $errorMessage .= "Thiếu thư mục tạm thời để upload";
                            break;
                        case UPLOAD_ERR_CANT_WRITE:
                            $errorMessage .= "Không thể ghi file vào đĩa (Kiểm tra quyền ghi thư mục tạm thời của PHP)";
                            break;
                        case UPLOAD_ERR_EXTENSION:
                            $errorMessage .= "Một extension PHP đã dừng quá trình upload file";
                            break;
                        default:
                            $errorMessage .= "Lỗi không xác định khi upload file";
                            break;
                    }
                    echo "<script>alert('" . $errorMessage . "');</script>";
                    header('refresh:0; url=index.php?controller=admin&action=addProduct');
                    exit();
                }
            } else {
                $data['image'] = '';
            }

            $productModel = new ProductModel($conn);
            if ($productModel->addProduct($data)) {
                header('Location: index.php?controller=admin&action=products');
                exit();
            } else {
                echo "<script>alert('Thêm sản phẩm vào cơ sở dữ liệu thất bại');</script>";
                header('refresh:0; url=index.php?controller=admin&action=addProduct');
                exit();
            }
        }
    }

    //sửa sản phẩm
    public function editProduct() {
        $this->checkAdmin();
        if (isset($_GET['id'])) {
            global $conn;
            $productModel = new ProductModel($conn);
            $product = $productModel->getProductById($_GET['id']);
            $categoryModel = new CategoryModel($conn);
            $categories = $categoryModel->getAllCategories();
            require_once __DIR__ . '/../views/layouts/admin_header.php';
            require_once __DIR__ . '/../views/admin/products/edit.php';
            require_once __DIR__ . '/../views/layouts/admin_footer.php';
        } else {
            header('Location: index.php?controller=admin&action=products');
            exit();
        }
    }
    
    public function handleEditProduct() {
        $this->checkAdmin();
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
            global $conn;
            $data = $_POST;
            $productId = $_POST['id'];
            $imageName = $_POST['current_image'] ?? '';

            if (isset($_FILES['image']) && $_FILES['image']['error'] == UPLOAD_ERR_OK) {
                $targetDir = "public/images/products/";
                if (!is_dir($targetDir)) {
                    mkdir($targetDir, 0775, true);
                }
                $imageName = basename($_FILES["image"]["name"]);
                $targetFilePath = $targetDir . $imageName;
                $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);

                $allowTypes = array('jpg','png','jpeg','gif');
                if(in_array(strtolower($fileType), $allowTypes)){
                    if(move_uploaded_file($_FILES["image"]["tmp_name"], $targetFilePath)){
                        $data['image'] = $imageName;
                    } else {
                        error_log("Lỗi di chuyển file: " . $_FILES["image"]["tmp_name"] . " đến " . $targetFilePath);
                        echo "<script>alert('Có lỗi khi di chuyển ảnh mới lên server. Vui lòng kiểm tra quyền ghi thư mục');</script>";
                        header('refresh:0; url=index.php?controller=admin&action=editProduct&id=' . $productId);
                        exit();
                    }
                } else {
                    echo "<script>alert('Chỉ chấp nhận file JPG, JPEG, PNG, GIF cho ảnh mới. Định dạng file của bạn là: " . htmlspecialchars($fileType) . "');</script>";
                    header('refresh:0; url=index.php?controller=admin&action=editProduct&id=' . $productId);
                    exit();
                }
            } else {
                $data['image'] = $imageName;
                if (isset($_FILES['image']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE && $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
                    $errorMessage = "Lỗi upload file mới: ";
                    switch ($_FILES['image']['error']) {
                        case UPLOAD_ERR_INI_SIZE:
                        case UPLOAD_ERR_FORM_SIZE:
                            $errorMessage .= "Kích thước file quá lớn.";
                            break;
                        case UPLOAD_ERR_PARTIAL:
                            $errorMessage .= "File chỉ được upload một phần.";
                            break;
                        case UPLOAD_ERR_NO_TMP_DIR:
                            $errorMessage .= "Thiếu thư mục tạm thời.";
                            break;
                        case UPLOAD_ERR_CANT_WRITE:
                            $errorMessage .= "Không thể ghi file vào đĩa.";
                            break;
                        case UPLOAD_ERR_EXTENSION:
                            $errorMessage .= "Một extension PHP đã dừng quá trình upload.";
                            break;
                        default:
                            $errorMessage .= "Lỗi không xác định.";
                            break;
                    }
                    echo "<script>alert('" . $errorMessage . "');</script>";
                    header('refresh:0; url=index.php?controller=admin&action=editProduct&id=' . $productId);
                    exit();
                }
            }

            $productModel = new ProductModel($conn);
            if ($productModel->updateProduct($productId, $data)) {
                header('Location: index.php?controller=admin&action=products');
                exit();
            } else {
                echo "<script>alert('Cập nhật sản phẩm vào cơ sở dữ liệu thất bại.');</script>";
                header('refresh:0; url=index.php?controller=admin&action=editProduct&id=' . $productId);
                exit();
            }
        }
        header('Location: index.php?controller=admin&action=products');
        exit();
    }

    public function deleteProduct() {
        $this->checkAdmin();
        if (isset($_GET['id'])) {
            global $conn;
            $productModel = new ProductModel($conn);
            $productModel->deleteProduct($_GET['id']);
        }
        header('Location: index.php?controller=admin&action=products');
        exit();
    }
    
    public function comments() {
        $this->checkAdmin();
        global $conn;
        $commentModel = new CommentModel($conn);
        $comments = $commentModel->getAllComments();
        
        require_once __DIR__ . '/../views/layouts/admin_header.php';
        require_once __DIR__ . '/../views/admin/comments/list.php';
        require_once __DIR__ . '/../views/layouts/admin_footer.php';
    }

    public function deleteComment() {
        $this->checkAdmin();
        if (isset($_GET['id'])) {
            global $conn;
            $commentModel = new CommentModel($conn);
            $commentModel->deleteComment($_GET['id']);
        }
        header('Location: ' . $_SERVER['HTTP_REFERER']);
        exit();
    }
    
    public function categories() {
        $this->checkAdmin();
        global $conn;
        $categoryModel = new CategoryModel($conn);
        $categories = $categoryModel->getAllCategories();
        require_once __DIR__ . '/../views/layouts/admin_header.php';
        require_once __DIR__ . '/../views/admin/categories/list.php';
        require_once __DIR__ . '/../views/layouts/admin_footer.php';
    }
    
    public function addCategory() {
        $this->checkAdmin();
        require_once __DIR__ . '/../views/layouts/admin_header.php';
        require_once __DIR__ . '/../views/admin/categories/add.php';
        require_once __DIR__ . '/../views/layouts/admin_footer.php';
    }
    
    public function handleAddCategory() {
        $this->checkAdmin();
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['name'])) {
            global $conn;
            $categoryModel = new CategoryModel($conn);
            if ($categoryModel->addCategory($_POST['name'])) {
                header('Location: index.php?controller=admin&action=categories');
                exit();
            } else {
                echo "<script>alert('Thêm danh mục thất bại');</script>";
                header('refresh:0; url=index.php?controller=admin&action=addCategory');
                exit();
            }
        }
        header('Location: index.php?controller=admin&action=categories');
        exit();
    }
    
    public function editCategory() {
        $this->checkAdmin();
        if (isset($_GET['id'])) {
            global $conn;
            $categoryModel = new CategoryModel($conn);
            $category = $categoryModel->getCategoryById($_GET['id']);
            require_once __DIR__ . '/../views/layouts/admin_header.php';
            require_once __DIR__ . '/../views/admin/categories/edit.php';
            require_once __DIR__ . '/../views/layouts/admin_footer.php';
        } else {
            header('Location: index.php?controller=admin&action=categories');
            exit();
        }
    }
    
    public function handleEditCategory() {
        $this->checkAdmin();
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id']) && isset($_POST['name'])) {
            global $conn;
            $categoryModel = new CategoryModel($conn);
            if ($categoryModel->updateCategory($_POST['id'], $_POST['name'])) {
                header('Location: index.php?controller=admin&action=categories');
                exit();
            } else {
                echo "<script>alert('Cập nhật danh mục thất bại');</script>";
                header('refresh:0; url=index.php?controller=admin&action=editCategory&id=' . $_POST['id']);
                exit();
            }
        }
        header('Location: index.php?controller=admin&action=categories');
        exit();
    }
    
    public function deleteCategory() {
        $this->checkAdmin();
        if (isset($_GET['id'])) {
            global $conn;
            $categoryModel = new CategoryModel($conn);
            $categoryModel->deleteCategory($_GET['id']);
        }
        header('Location: index.php?controller=admin&action=categories');
        exit();
    }
}
?>