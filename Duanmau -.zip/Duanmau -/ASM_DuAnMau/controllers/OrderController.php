<?php
require_once __DIR__ . '/../models/OrderModel.php';

class OrderController {
    
    public function myOrders() {
        if (!isset($_SESSION['user_id'])) {
            header('Location: index.php?controller=user&action=login');
            exit();
        }

        global $conn;
        $userId = $_SESSION['user_id'];
        $orderModel = new OrderModel($conn);
        $orders = $orderModel->getOrdersByUserId($userId);

        require_once __DIR__ . '/../views/layouts/user_header.php';
        require_once __DIR__ . '/../views/order/myorders.php';
        require_once __DIR__ . '/../views/layouts/user_footer.php';
    }

    public function detail() {
        if (!isset($_SESSION['user_id'])) {
            header('Location: index.php?controller=user&action=login');
            exit();
        }

        if (!isset($_GET['id'])) {
            header('Location: index.php?controller=order&action=myOrders');
            exit();
        }

        global $conn;
        $orderId = (int)$_GET['id'];
        $userId = $_SESSION['user_id'];
        $orderModel = new OrderModel($conn);
        
        $order = $orderModel->getOrderById($orderId);
        
        if (!$order || ($order['user_id'] != $userId && (!isset($_SESSION['role']) || $_SESSION['role'] != 1))) {
            echo "<script>alert('Không tìm thấy đơn hàng!');</script>";
            header('refresh:0; url=index.php?controller=order&action=myOrders');
            exit();
        }

        $orderDetails = $orderModel->getOrderDetails($orderId);

        require_once __DIR__ . '/../views/layouts/user_header.php';
        require_once __DIR__ . '/../views/order/detail.php';
        require_once __DIR__ . '/../views/layouts/user_footer.php';
    }
}
?>

