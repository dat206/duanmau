<!-- Trang Liên Hệ -->
<section class="contact-page py-5">
    <div class="container">
        <!-- Header Section -->
        <div class="text-center mb-5">
            <h1 class="display-4 fw-bold mb-3">Liên Hệ Với Chúng Tôi</h1>
            <p class="lead text-muted">Chúng tôi luôn sẵn sàng lắng nghe và hỗ trợ bạn</p>
        </div>

        <div class="row justify-content-center">
            <!-- Thông tin liên hệ -->
            <div class="col-lg-8">
                <div class="contact-info-card h-100 p-4 shadow-sm border rounded bg-white">
                    <h3 class="fw-bold mb-4 text-center">Thông Tin Liên Hệ</h3>
                    
                    <div class="row g-4">
                        <div class="col-md-6">
                            <div class="contact-item d-flex align-items-start">
                                <div class="contact-icon me-3 d-flex align-items-center justify-content-center bg-dark text-white rounded-3 flex-shrink-0" style="width: 60px; height: 60px; font-size: 1.5rem;">
                                    <i class="bi bi-geo-alt-fill"></i>
                                </div>
                                <div class="contact-details">
                                    <h5 class="fw-semibold mb-1">Địa Chỉ</h5>
                                    <p class="text-muted mb-0">245 Đường Thanh Chương, Phố Tân Trọng<br>Phường Quảng Phú, Hà Nội</p>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="contact-item d-flex align-items-start">
                                <div class="contact-icon me-3 d-flex align-items-center justify-content-center bg-dark text-white rounded-3 flex-shrink-0" style="width: 60px; height: 60px; font-size: 1.5rem;">
                                    <i class="bi bi-telephone-fill"></i>
                                </div>
                                <div class="contact-details">
                                    <h5 class="fw-semibold mb-1">Điện Thoại</h5>
                                    <p class="text-muted mb-0">
                                        <a href="tel:0393561314" class="text-decoration-none text-muted">0393 561 314</a>
                                    </p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="contact-item d-flex align-items-start">
                                <div class="contact-icon me-3 d-flex align-items-center justify-content-center bg-dark text-white rounded-3 flex-shrink-0" style="width: 60px; height: 60px; font-size: 1.5rem;">
                                    <i class="bi bi-envelope-fill"></i>
                                </div>
                                <div class="contact-details">
                                    <h5 class="fw-semibold mb-1">Email</h5>
                                    <p class="text-muted mb-0">
                                        <a href="mailto:le3221981@gmail.com" class="text-decoration-none text-muted">le3221981@gmail.com</a>
                                    </p>
                                </div>
                            </div>
                        </div>
                            
                        <div class="col-md-6">
                            <div class="contact-item d-flex align-items-start">
                                <div class="contact-icon me-3 d-flex align-items-center justify-content-center bg-dark text-white rounded-3 flex-shrink-0" style="width: 60px; height: 60px; font-size: 1.5rem;">
                                    <i class="bi bi-clock-fill"></i>
                                </div>
                                <div class="contact-details">
                                    <h5 class="fw-semibold mb-1">Giờ Làm Việc</h5>
                                    <p class="text-muted mb-0">
                                        Thứ 2 - Thứ 6: 9:00 - 18:00<br>
                                        Thứ 7 - Chủ Nhật: 10:00 - 17:00
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Social Media -->
                    <div class="mt-4 pt-4 border-top text-center">
                        <h5 class="fw-semibold mb-3">Theo Dõi Chúng Tôi</h5>
                        <div class="social-links-contact d-flex justify-content-center gap-3">
                            <a href="#" class="social-link fs-4 text-dark" title="Facebook"><i class="bi bi-facebook"></i></a>
                            <a href="#" class="social-link fs-4 text-dark" title="Instagram"><i class="bi bi-instagram"></i></a>
                            <a href="#" class="social-link fs-4 text-dark" title="TikTok"><i class="bi bi-tiktok"></i></a>
                            <a href="#" class="social-link fs-4 text-dark" title="YouTube"><i class="bi bi-youtube"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Map Section -->
        <div class="row mt-5">
            <div class="col-12">
                <div class="map-section">
                    <h3 class="fw-bold mb-4 text-center">Vị Trí Cửa Hàng</h3>
                    <div class="map-placeholder shadow-sm rounded overflow-hidden">
                        <iframe 
                            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3724.096466609128!2d105.84115931540247!3d21.02816378599847!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3135ab9bd9861ca1%3A0xe7887f7b6ca21b87!2zSMOgIE5vaQ!5e0!3m2!1svi!2s!4v1234567890" 
                            width="100%" 
                            height="450" 
                            class="map-frame border-0" 
                            allowfullscreen="" 
                            loading="lazy" 
                            referrerpolicy="no-referrer-when-downgrade">
                        </iframe>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
