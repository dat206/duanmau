<?php
require_once 'config/database.php';

$db = new Database();
$conn = $db->getConnection();

// Check if is_locked column exists
$checkSql = "SHOW COLUMNS FROM users LIKE 'is_locked'";
$result = $conn->query($checkSql);

if ($result->num_rows == 0) {
    $sql = "ALTER TABLE users ADD COLUMN is_locked TINYINT(1) DEFAULT 0";
    if ($conn->query($sql) === TRUE) {
        echo "Successfully added 'is_locked' column to users table.\n";
    } else {
        echo "Error adding column: " . $conn->error . "\n";
    }
} else {
    echo "'is_locked' column already exists.\n";
}
?>
