<style>
    /* Styling for the modern slider */
    .hero-slider {
        position: relative;
        max-width: 100%;
        margin: auto;
        overflow: hidden;
        border-radius: 15px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    }

    .slider-wrapper {
        display: flex;
        transition: transform 0.6s ease-in-out;
    }

    .slide {
        min-width: 100%;
        box-sizing: border-box;
    }

    .slide img {
        width: 100%;
        height: 500px;
        display: block;
        object-fit: cover;
    }

    @media (max-width: 768px) {
        .slide img {
            height: 250px;
        }
        .hero-slider {
            border-radius: 0;
        }
    }

    /* Navigation arrows */
    .info-btn {
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        background-color: rgba(255, 255, 255, 0.7);
        color: #333;
        border: none;
        padding: 10px 15px;
        cursor: pointer;
        z-index: 10;
        border-radius: 50%;
        transition: background-color 0.3s, transform 0.2s;
        font-size: 18px;
    }

    .info-btn:hover {
        background-color: rgba(255, 255, 255, 1);
        transform: translateY(-50%) scale(1.1);
    }

    .prev-btn { left: 20px; }
    .next-btn { right: 20px; }

    /* Pagination dots */
    .pagination {
        position: absolute;
        bottom: 20px;
        left: 50%;
        transform: translateX(-50%);
        display: flex;
        gap: 10px;
    }

    .dot {
        width: 12px;
        height: 12px;
        background-color: rgba(255, 255, 255, 0.5);
        border-radius: 50%;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    .dot.active {
        background-color: white;
        transform: scale(1.2);
    }
    
    /* Enhance existing styles */
    .xemthem a {
        display: inline-block;
        padding: 12px 25px;
        background-color: #ff6b6b;
        color: white;
        text-decoration: none;
        border-radius: 30px;
        transition: all 0.3s ease;
        font-weight: bold;
    }

    .xemthem a:hover {
        background-color: white;
        color: #ff6b6b;
        border: 2px solid #ff6b6b;
        transform: translateY(-2px);
    }
</style>

<div class="hero-slider">
    <div class="slider-wrapper">
        <div class="slide">
            <img src="https://hoangphuconline.vn/media/magefan_blog/2022/12/Giay-do-1.jpg" alt="Giày Đỏ Đón Tết">
        </div>
        <div class="slide">
            <img src="https://images.unsplash.com/photo-1607522370275-f14bc3a8d0f1?q=80&w=1200&auto=format&fit=crop" alt="Sneaker Thời Trang">
        </div>
        <div class="slide">
            <img src="https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?q=80&w=1200&auto=format&fit=crop" alt="Sneaker Học Sinh">
        </div>
    </div>
    <button class="info-btn prev-btn">&#10094;</button>
    <button class="info-btn next-btn">&#10095;</button>
    <div class="pagination"></div>
</div>

<br>

<div class="brand-categories" style="text-align: center; margin: 30px 0;">
    <a style="font-size: 1.5em; margin: 0 15px; color: #333; text-decoration: none; font-weight: bold; text-transform: uppercase;" href="index.php?controller=product&action=search&keyword=nike">Nike</a>
    <a style="font-size: 1.5em; margin: 0 15px; color: #333; text-decoration: none; font-weight: bold; text-transform: uppercase;" href="index.php?controller=product&action=search&keyword=puma">Puma</a>
    <a style="font-size: 1.5em; margin: 0 15px; color: #333; text-decoration: none; font-weight: bold; text-transform: uppercase;" href="index.php?controller=product&action=search&keyword=adidas">Adidas</a>
</div>

<div class="product-grid">
    <?php if (!empty($featuredProducts)): ?>        
        <?php foreach ($featuredProducts as $product): ?>
            <?php
            $image = $product['image'];
            if (!$image || $image == '0') {
                $imgSrc = 'https://placehold.co/300x300/e0e0e0/333333?text=No+Image';
            } elseif (filter_var($image, FILTER_VALIDATE_URL)) {
                $imgSrc = $image;
            } else {
                $imgSrc = 'public/images/products/' . htmlspecialchars($image);
            }
            ?>
            <div class="product-item" style="transition: transform 0.3s; border-radius: 10px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
                <div style="height: 250px; overflow: hidden;">
                    <img src="<?php echo $imgSrc; ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" style="width: 100%; height: 100%; object-fit: cover;"
                        onerror="this.onerror=null; this.src='https://placehold.co/300x300/e0e0e0/333333?text=No+Image';">
                </div>
                <div style="padding: 15px;">
                    <h3 style="margin: 0 0 10px; font-size: 1.1em;"><a href="index.php?controller=product&action=detail&id=<?php echo htmlspecialchars($product['id']); ?>" style="color: #333; text-decoration: none;"><?php echo htmlspecialchars($product['name']); ?></a></h3>
                    <p style="color: #e74c3c; font-weight: bold; font-size: 1.1em;">Price: <?php echo number_format($product['price'], 0, ',', '.'); ?> VNĐ</p>
                    <?php if (isset($_SESSION['user_id']) && $_SESSION['role'] == 0): ?>
                        <form action="index.php?controller=cart&action=addToCart" method="POST" style="margin-top: 10px;">
                            <input type="hidden" name="product_id" value="<?php echo htmlspecialchars($product['id']); ?>">
                            <input type="hidden" name="quantity" value="1">
                            <button style="background: #ff6b6b; border: 1px solid white; border-radius: 5px; color: white; width: 100%; padding: 10px; cursor: pointer; transition: background 0.2s;" type="submit">Thêm vào giỏ hàng</button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p style="text-align: center; width: 100%;">Không có sản phẩm nào để hiển thị</p>
    <?php endif; ?>
</div>

<br><br>
<div class="xemthem" style="text-align: center; margin-bottom: 40px;">
    <a href="index.php?controller=product&action=list">Xem tất cả sản phẩm</a>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const sliderWrapper = document.querySelector('.slider-wrapper');
        const slides = document.querySelectorAll('.slide');
        const prevBtn = document.querySelector('.prev-btn');
        const nextBtn = document.querySelector('.next-btn');
        const pagination = document.querySelector('.pagination');
        
        let currentIndex = 0;
        const totalSlides = slides.length;
        let slideInterval;

        // Create pagination dots
        slides.forEach((_, index) => {
            const dot = document.createElement('div');
            dot.classList.add('dot');
            if (index === 0) dot.classList.add('active');
            dot.addEventListener('click', () => goToSlide(index));
            pagination.appendChild(dot);
        });

        const dots = document.querySelectorAll('.dot');

        function updateSlider() {
            sliderWrapper.style.transform = `translateX(-${currentIndex * 100}%)`;
            dots.forEach(dot => dot.classList.remove('active'));
            dots[currentIndex].classList.add('active');
        }

        function nextSlide() {
            currentIndex = (currentIndex + 1) % totalSlides;
            updateSlider();
        }

        function prevSlide() {
            currentIndex = (currentIndex - 1 + totalSlides) % totalSlides;
            updateSlider();
        }

        function goToSlide(index) {
            currentIndex = index;
            updateSlider();
            resetInterval();
        }

        function startInterval() {
            slideInterval = setInterval(nextSlide, 5000); // 5 seconds
        }

        function resetInterval() {
            clearInterval(slideInterval);
            startInterval();
        }

        // Event listeners
        nextBtn.addEventListener('click', () => {
            nextSlide();
            resetInterval();
        });

        prevBtn.addEventListener('click', () => {
            prevSlide();
            resetInterval();
        });

        // Initialize audio start
        startInterval();
    });
</script>