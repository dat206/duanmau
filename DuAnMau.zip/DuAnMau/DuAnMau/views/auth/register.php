<style>
    .auth-container {
        max-width: 450px;
        margin: 50px auto;
        padding: 30px;
        background-color: white;
        border-radius: 10px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        text-align: center;
    }
    
    .auth-container h1 {
        color: #000c40ff;
        margin-bottom: 25px;
        border-bottom: 2px solid #ff6b6b;
        padding-bottom: 10px;
    }
    
    .auth-container form {
        display: flex;
        flex-direction: column;
        gap: 18px;
    }
    
    .auth-container input[type="text"],
    .auth-container input[type="password"],
    .auth-container input[type="number"] {
        padding: 12px;
        border: 1px solid #ddd;
        border-radius: 6px;
        font-size: 1em;
        transition: border-color 0.3s ease, box-shadow 0.3s ease;
    }
    
    .auth-container input[type="text"]:focus,
    .auth-container input[type="password"]:focus,
    .auth-container input[type="number"]:focus {
        outline: none;
        border-color: #ff6b6b;
        box-shadow: 0 0 0 3px rgba(255, 107, 107, 0.1);
    }
    
    .auth-container button {
        padding: 12px 25px;
        border: none;
        border-radius: 6px;
        background-color: #ff6b6b;
        color: white;
        font-size: 1.1em;
        cursor: pointer;
        transition: background-color 0.3s ease, transform 0.2s ease;
    }
    
    .auth-container button:hover {
        background-color: #ffffffff;
        color: #ff6b6b;
        border: #ff6b6b solid 1px;
        transform: translateY(-2px);
    }
    
    .auth-container p {
        margin-top: 20px;
        color: #555;
    }
    
    .auth-container p a {
        color: #ff4757;
        text-decoration: none;
        font-weight: bold;
        transition: color 0.3s ease;
    }
    
    .auth-container p a:hover {
        color: #ff6b6b;
        text-decoration: underline;
    }
</style>

<div class="auth-container">
    <h1>Đăng ký</h1>
    <form action="index.php?controller=user&action=register" method="POST">
        <?php echo CSRF::field(); ?>
        <input type="text" name="username" placeholder="Tên đăng nhập *" required minlength="3" maxlength="50">
        <input type="password" name="password" placeholder="Mật khẩu *" required minlength="6">
        
        <div style="display: flex; gap: 10px;">
            <input type="number" name="age" placeholder="Tuổi" min="1" max="150" style="flex: 1;">
            <input type="text" name="phone_number" placeholder="Số điện thoại" style="flex: 2;">
        </div>
        <input type="text" name="address" placeholder="Địa chỉ">

        <button type="submit">Đăng ký</button>
    </form>
    <p>Đã có tài khoản? <a href="index.php?controller=user&action=login">Đăng nhập</a></p>
</div>