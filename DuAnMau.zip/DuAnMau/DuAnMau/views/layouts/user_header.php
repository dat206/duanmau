<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>1Sneaker - Youth Fashion Style</title>
    <link rel="stylesheet" href="public/css/style.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

</head>
<body>
    <header class="main-header">
        <nav class="main-nav">
            <div class="nav-left">
                <a href="index.php" class="logo-container">
                    <img class="logo-img" src="Logo1Sneaker_new.png" alt="1Sneaker Logo"
                        onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                    <div class="logo-text" style="display: none;">
                        <span class="logo-main">1Sneaker</span>
                        <span class="logo-subtitle">YOUTH FASHION STYLE</span>
                    </div>
                </a>
            </div>

            <div class="nav-links">
                <a href="index.php" class="nav-link">Trang chủ</a>
                <a href="index.php?controller=product&action=list" class="nav-link">Sản phẩm</a>
            </div>

            <div class="nav-center">
                <form method="GET" action="index.php" class="header-search-form">
                    <input type="hidden" name="controller" value="product">
                    <input type="hidden" name="action" value="search">
                    <input type="text" name="keyword" placeholder="Tìm kiếm sản phẩm..."
                        value="<?php echo isset($_GET['keyword']) ? htmlspecialchars($_GET['keyword']) : ''; ?>"
                        class="header-search-input">
                    <button type="submit" class="header-search-btn">
                        <i class="fas fa-search"></i>
                    </button>
                </form>
            </div>

            <div class="nav-right">
                <?php if (isset($_SESSION['user_id'])): ?>
                    <?php if ($_SESSION['role'] == 0): ?>
                        <a href="index.php?controller=cart&action=view" class="nav-link">
                            <i class="fas fa-shopping-cart"></i> Giỏ hàng
                        </a>
                        <a href="index.php?controller=order&action=myOrders" class="nav-link">
                            <i class="fas fa-box"></i> Đơn hàng
                        </a>
                        <a href="index.php?controller=user&action=profile" class="nav-link user-greeting">
                            <i class="fas fa-user"></i> Xin chào, 
                            <?php echo htmlspecialchars($_SESSION['username']); ?>
                        </a>
                    <?php else: ?>
                        <a href="index.php?controller=admin&action=dashboard" class="nav-link">
                            <i class="fas fa-cog"></i> Quản trị
                        </a>
                    <?php endif; ?>
                    <a href="index.php?controller=user&action=logout" class="nav-link logout-link">
                        <i class="fas fa-sign-out-alt"></i> Đăng xuất
                    </a>
                <?php else: ?>
                    <a href="index.php?controller=user&action=login" class="nav-link">
                        <i class="fas fa-sign-in-alt"></i> Đăng nhập
                    </a>
                    <a href="index.php?controller=user&action=register" class="nav-link">
                        <i class="fas fa-user-plus"></i> Đăng ký
                    </a>
                <?php endif; ?>
            </div>
        </nav>
    </header>

    <script>
        function toggleMenu() {
            const navLinks = document.querySelector('.nav-links');
            const navRight = document.querySelector('.nav-right');
            // search is always visible now
            
            navLinks.classList.toggle('active');
            navRight.classList.toggle('active');
        }
    </script>

    <div class="container">
