<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link rel="stylesheet" href="public/css/style.css">
    <style>
        body {
            display: flex;
            min-height: 100vh;
            flex-direction: column;
        }
        .admin-wrapper {
            display: flex;
            flex: 1;
        }
        .admin-sidebar {
            width: 250px;
            background-color: #ff6b6b;
            color: #ecf0f1;
            padding: 20px;
            box-shadow: 2px 0 5px rgba(70, 65, 65, 0.2);
            position: sticky;
            top: 0;
            height: 100vh;
            overflow-y: auto;
        }
        .admin-sidebar h2 {
            text-align: center;
            color: #ecf0f1;
            margin-bottom: 30px;
            border-bottom: 1px solid #b4ababff;
            padding-bottom: 15px;
        }
        .admin-sidebar ul {
            list-style: none;
            padding: 0;
        }
        .admin-sidebar ul li {
            margin-bottom: 15px;
        }
        .admin-sidebar ul li a {
            color: #ecf0f1;
            text-decoration: none;
            display: block;
            padding: 10px 15px;
            border-radius: 5px;
            transition: background-color 0.3s ease, color 0.3s ease;
        }
        .admin-sidebar ul li a:hover, .admin-sidebar ul li a.active {
            background-color: #ffffff;
            color: #ff6b6b;
            font-weight: bold;
        }
        .admin-content {
            flex: 1;
            padding: 20px;
            background-color: #f9fefeff;
        }
        .admin-header {
            background-color: #ff6b6b;
            color: white;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 5px rgba(247, 243, 243, 1);
        }
        .admin-header h1 {
            margin: 0;
            color: white;
            border-bottom: none;
            padding-bottom: 0;
        }
        .admin-header .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        .admin-header .user-info a {
            color: white;
            text-decoration: none;
            font-weight: bold;
            transition: color 0.3s ease;
        }
        .admin-header .user-info a:hover {
            color: #e0e0e0;
        }
        
        @media (max-width: 768px) {
            .admin-wrapper {
                flex-direction: column;
            }
            .admin-sidebar {
                width: 100%;
                height: auto;
                position: relative;
                padding: 10px;
                box-sizing: border-box;
            }
            .admin-sidebar img {
                width: 80px !important;
                height: 80px !important;
                margin: 0 auto;
                display: block;
            }
            .admin-sidebar ul li {
                display: inline-block;
                margin: 5px;
            }
             .admin-sidebar h2 {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="admin-wrapper">
        <div class="admin-sidebar">
            <img style="width: 150px; height: 150px;" src="Logo1Sneaker_new.png" alt="">
            <ul>
                <?php $action = $_GET['action'] ?? 'dashboard'; ?>
                <li><a href="index.php?controller=admin&action=dashboard" class="<?php echo $action == 'dashboard' ? 'active' : ''; ?>">Dashboard</a></li>
                <li><a href="index.php?controller=admin&action=products" class="<?php echo $action == 'products' || $action == 'addProduct' || $action == 'editProduct' ? 'active' : ''; ?>">Quản lý sản phẩm</a></li>
                <li><a href="index.php?controller=admin&action=categories" class="<?php echo $action == 'categories' || $action == 'addCategory' || $action == 'editCategory' ? 'active' : ''; ?>">Quản lý danh mục</a></li>
                <li><a href="index.php?controller=admin&action=users" class="<?php echo $action == 'users' || $action == 'editUser' ? 'active' : ''; ?>">Quản lý người dùng</a></li>
                <li><a href="index.php?controller=admin&action=orders" class="<?php echo $action == 'orders' ? 'active' : ''; ?>">Quản lý đơn hàng</a></li>
                <li><a href="index.php?controller=admin&action=comments" class="<?php echo $action == 'comments' ? 'active' : ''; ?>">Quản lý bình luận</a></li>
            </ul>
        </div>
        <div class="admin-content">
            <div class="admin-header">
                <h1>Xin chào, <?php echo htmlspecialchars($_SESSION['username'] ?? 'Admin'); ?>!</h1>
                <div class="user-info">
                    <span>Vai trò: Admin</span>
                    <a href="index.php?controller=user&action=logout">Đăng xuất</a>
                </div>
            </div>
            <div class="container">
