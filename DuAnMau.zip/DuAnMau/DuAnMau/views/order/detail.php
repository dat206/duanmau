<style>
    .order-detail-container {
        max-width: 1000px;
        margin: 0 auto;
        padding: 20px;
    }

    .order-detail-header {
        text-align: center;
        color: #000c40ff;
        margin-bottom: 30px;
        padding-bottom: 15px;
        border-bottom: 2px solid #000c40ff;
    }

    .order-section {
        background: white;
        padding: 25px;
        border-radius: 10px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        margin-bottom: 20px;
    }

    .order-section h3 {
        color: #000c40ff;
        margin-bottom: 20px;
        padding-bottom: 10px;
        border-bottom: 1px solid #eee;
    }

    .order-info-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 15px;
    }

    .info-row {
        display: flex;
        flex-direction: column;
    }

    .info-label {
        font-size: 0.85em;
        color: #6c757d;
        margin-bottom: 5px;
    }

    .info-value {
        font-size: 1em;
        font-weight: bold;
        color: #333;
    }

    .order-status {
        display: inline-block;
        padding: 8px 20px;
        border-radius: 20px;
        font-weight: bold;
        text-transform: uppercase;
    }

    .status-pending {
        background-color: #ffc107;
        color: #856404;
    }

    .status-processing {
        background-color: #17a2b8;
        color: white;
    }

    .status-completed {
        background-color: #28a745;
        color: white;
    }

    .order-details-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 15px;
    }

    .order-details-table th,
    .order-details-table td {
        padding: 12px;
        text-align: left;
        border-bottom: 1px solid #eee;
    }

    .order-details-table th {
        background-color: #f8f9fa;
        color: #000c40ff;
        font-weight: bold;
    }

    .order-details-table tr:hover {
        background-color: #f8f9fa;
    }

    .product-image {
        width: 60px;
        height: 60px;
        object-fit: cover;
        border-radius: 5px;
    }

    .order-total {
        text-align: right;
        margin-top: 20px;
        padding-top: 20px;
        border-top: 2px solid #000c40ff;
    }

    .total-amount {
        font-size: 1.5em;
        font-weight: bold;
        color: #000c40ff;
    }

    .btn-back {
        display: inline-block;
        padding: 10px 20px;
        background-color: #6c757d;
        color: white;
        text-decoration: none;
        border-radius: 5px;
        margin-top: 20px;
        transition: background-color 0.3s ease;
    }

    .btn-back:hover {
        background-color: #5a6268;
    }
</style>

<div class="order-detail-container">
    <h1 class="order-detail-header">Chi tiết đơn hàng #<?php echo htmlspecialchars($order['id']); ?></h1>

    <div class="order-section">
        <h3>Thông tin đơn hàng</h3>
        <div class="order-info-grid">
            <div class="info-row">
                <span class="info-label">Mã đơn hàng</span>
                <span class="info-value">#<?php echo htmlspecialchars($order['id']); ?></span>
            </div>
            <div class="info-row">
                <span class="info-label">Ngày đặt hàng</span>
                <span class="info-value"><?php echo date('d/m/Y H:i:s', strtotime($order['order_date'])); ?></span>
            </div>
            <div class="info-row">
                <span class="info-label">Trạng thái</span>
                <span class="order-status status-<?php 
                    $status = strtolower(str_replace(' ', '-', $order['status']));
                    echo $status === 'chờ-xử-lý' ? 'pending' : ($status === 'đang-giao' ? 'processing' : ($status === 'đã-hoàn-thành' ? 'completed' : 'cancelled'));
                ?>">
                    <?php echo htmlspecialchars($order['status']); ?>
                </span>
            </div>
            <?php if (isset($order['payment_method'])): ?>
                <div class="info-row">
                    <span class="info-label">Phương thức thanh toán</span>
                    <span class="info-value">
                        <?php 
                        echo $order['payment_method'] === 'COD' ? 'Thanh toán khi nhận hàng (COD)' : 'Chuyển khoản ngân hàng';
                        ?>
                    </span>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <?php if (isset($order['receiver_name']) || isset($order['phone']) || isset($order['address'])): ?>
        <div class="order-section">
            <h3>Thông tin người nhận</h3>
            <div class="order-info-grid">
                <?php if (isset($order['receiver_name'])): ?>
                    <div class="info-row">
                        <span class="info-label">Họ và tên</span>
                        <span class="info-value"><?php echo htmlspecialchars($order['receiver_name']); ?></span>
                    </div>
                <?php endif; ?>
                <?php if (isset($order['phone'])): ?>
                    <div class="info-row">
                        <span class="info-label">Số điện thoại</span>
                        <span class="info-value"><?php echo htmlspecialchars($order['phone']); ?></span>
                    </div>
                <?php endif; ?>
                <?php if (isset($order['address'])): ?>
                    <div class="info-row" style="grid-column: 1 / -1;">
                        <span class="info-label">Địa chỉ nhận hàng</span>
                        <span class="info-value"><?php echo htmlspecialchars($order['address']); ?></span>
                    </div>
                <?php endif; ?>
                <?php if (isset($order['note']) && !empty($order['note'])): ?>
                    <div class="info-row" style="grid-column: 1 / -1;">
                        <span class="info-label">Ghi chú</span>
                        <span class="info-value"><?php echo htmlspecialchars($order['note']); ?></span>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>

    <div class="order-section">
        <h3>Chi tiết sản phẩm</h3>
        <table class="order-details-table">
            <thead>
                <tr>
                    <th>Hình ảnh</th>
                    <th>Sản phẩm</th>
                    <th>Số lượng</th>
                    <th>Đơn giá</th>
                    <th>Thành tiền</th>
                    <?php if ($order['status'] === 'Đã hoàn thành'): ?>
                        <th>Hành động</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($orderDetails as $detail): ?>
                    <?php
                    $image = $detail['image'];
                    if (!$image || $image == '0') {
                        $imgSrc = 'https://placehold.co/60x60/cccccc/333333?text=N/A';
                    } elseif (filter_var($image, FILTER_VALIDATE_URL)) {
                        $imgSrc = $image;
                    } else {
                        $imgSrc = 'public/images/products/' . htmlspecialchars($image);
                    }
                    ?>
                    <tr>
                        <td>
                            <img src="<?php echo $imgSrc; ?>" alt="<?php echo htmlspecialchars($detail['name']); ?>" class="product-image"
                                onerror="this.onerror=null; this.src='https://placehold.co/60x60/cccccc/333333?text=N/A';">
                        </td>

                        <td>
                            <?php echo htmlspecialchars($detail['name']); ?>
                            <div style="font-size: 0.85em; color: #666; margin-top: 5px;">
                                <?php if (!empty($detail['size'])): ?>
                                    <span style="margin-right: 10px;">Size: <?php echo htmlspecialchars($detail['size']); ?></span>
                                <?php endif; ?>
                                <?php if (!empty($detail['color'])): ?>
                                    <span>Màu: <?php echo htmlspecialchars($detail['color']); ?></span>
                                <?php endif; ?>
                            </div>
                        </td>
                        <td><?php echo $detail['quantity']; ?></td>
                        <td><?php echo number_format($detail['price'], 0, ',', '.'); ?> VNĐ</td>
                        <td><strong><?php echo number_format($detail['price'] * $detail['quantity'], 0, ',', '.'); ?> VNĐ</strong></td>
                        <?php if ($order['status'] === 'Đã hoàn thành'): ?>
                            <td>
                                <a href="index.php?controller=product&action=detail&id=<?php echo $detail['product_id']; ?>" 
                                   style="display: inline-block; padding: 5px 10px; background-color: #ffc107; color: #000; text-decoration: none; border-radius: 4px; font-weight: bold; font-size: 0.9em;">
                                   Đánh giá
                                </a>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <div class="order-total">
            <div class="total-amount">
                Tổng cộng: <?php echo number_format($order['total_price'], 0, ',', '.'); ?> VNĐ
            </div>
        </div>
    </div>

    <a href="index.php?controller=order&action=myOrders" class="btn-back">← Quay lại danh sách đơn hàng</a>
</div>

