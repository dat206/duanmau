<style>
    /* Global Product Container */
    .product-detail-container {
        background-color: white;
        padding: 40px;
        border-radius: 8px;
        box-shadow: 0 2px 20px rgba(0, 0, 0, 0.06);
        display: flex;
        flex-wrap: wrap;
        gap: 50px;
        align-items: flex-start;
        font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
    }

    /* Image Section */
    .product-detail-image {
        flex: 1;
        min-width: 350px;
        max-width: 500px;
    }
    .product-detail-image img {
        width: 100%;
        height: auto;
        border-radius: 4px;
        display: block;
    }

    /* Info Section */
    .product-detail-info {
        flex: 1.2;
        min-width: 350px;
    }

    /* Typography */
    .product-detail-info h1 {
        font-size: 2em;
        font-weight: 600;
        color: #111;
        margin: 0 0 10px 0;
        line-height: 1.2;
    }

    .product-detail-info .price {
        font-size: 1.8em;
        color: #e74c3c;
        font-weight: 700;
        margin: 15px 0 20px 0;
    }

    .product-detail-info .description {
        font-size: 1em;
        color: #555;
        line-height: 1.6;
        margin-bottom: 25px;
    }

    /* Attributes (Size/Color) */
    .attribute-group {
        margin-bottom: 25px;
        display: flex;
        align-items: center; /* Aligns label with options center */
        flex-wrap: wrap;
    }

    .attribute-title {
        min-width: 100px;
        font-weight: 600;
        color: #333;
        font-size: 1em;
        margin-right: 20px;
    }

    .attribute-options {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
        flex: 1;
    }

    /* Radio Button Hiding & Styling */
    .option-label {
        cursor: pointer;
        position: relative;
        margin: 0;
    }
    
    .option-label input {
        /* display: none !important;  <-- Caused validation issues */
        opacity: 0;
        position: absolute;
        width: 0;
        height: 0;
    }

    .option-text {
        display: flex;
        align-items: center;
        justify-content: center;
        min-width: 45px;
        height: 40px;
        padding: 0 15px;
        border: 1px solid #e0e0e0;
        background-color: white;
        color: #333;
        font-size: 0.95em;
        font-weight: 500;
        transition: all 0.2s ease;
        border-radius: 4px;
        box-sizing: border-box;
    }

    .option-label:hover .option-text {
        border-color: #333;
    }

    .option-label input:checked + .option-text {
        border-color: #ff6b6b;
        background-color: #ff6b6b;
        color: white;
    }

    /* Size Guide Link */
    .size-guide-link {
        display: inline-block;
        color: #666;
        text-decoration: underline;
        font-size: 0.9em;
        margin: -5px 0 20px 120px; /* Aligned with options */
        cursor: pointer;
    }
    .size-guide-link:hover {
        color: #111;
    }

    /* Quantity Section */
    .quantity-section {
        display: flex;
        align-items: center;
        margin-bottom: 30px;
    }
    
    .quantity-section label {
        min-width: 100px;
        font-weight: 600;
        color: #333;
        margin-right: 20px;
    }

    .quantity-control {
        display: flex;
        align-items: center;
        border: 1px solid #e0e0e0;
        border-radius: 4px;
        height: 40px;
        width: 120px;
    }

    .quantity-btn {
        width: 35px;
        height: 100%;
        background: none;
        border: none;
        font-size: 1.2em;
        color: #333;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: background 0.1s;
    }
    .quantity-btn:hover {
        background-color: #f5f5f5;
    }

    .quantity-input {
        flex: 1;
        height: 100%;
        border: none;
        border-left: 1px solid #e0e0e0;
        border-right: 1px solid #e0e0e0;
        text-align: center;
        font-size: 1em;
        color: #333;
        outline: none;
        -moz-appearance: textfield;
    }
    .quantity-input::-webkit-outer-spin-button,
    .quantity-input::-webkit-inner-spin-button {
      -webkit-appearance: none;
      margin: 0;
    }

    .stock-info {
        margin-left: 15px;
        color: #777;
        font-size: 0.9em;
    }

    /* Action Buttons */
    .action-buttons {
        display: flex;
        gap: 15px;
        margin-top: 10px;
    }
    
    @media (max-width: 768px) {
        .action-buttons {
            flex-direction: column;
        }
    }

    .btn-add-cart, .btn-buy-now {
        flex: 1;
        height: 48px;
        border: none;
        border-radius: 4px;
        font-weight: 600;
        font-size: 1em;
        text-transform: uppercase;
        cursor: pointer;
        transition: all 0.2s;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 10px;
    }

    .btn-add-cart {
        background-color: #ff6b6b;
        color: white;
        border: 1px solid #ff6b6b;
    }
    .btn-add-cart:hover {
        background-color: white;
        color: #ff6b6b;
        border-color: #ff6b6b;
    }

    .btn-buy-now {
        background-color: #ff4757;
        color: white;
        border: 1px solid #ff4757;
    }
    .btn-buy-now:hover {
        background-color: white;
        color: #ff4757;
        border-color: #ff4757;
    }

 /* Comments Section Styles - Minimal adjustment */
    .comments-section {
        margin-top: 50px;
        background: #fff;
        padding: 30px;
        border-radius: 8px;
    }
    .comments-section h2 {
        font-size: 1.5em;
        margin-bottom: 20px;
        border-bottom: 1px solid #eee;
        padding-bottom: 10px;
    }
    .comment { 
        padding: 15px 0;
        border-bottom: 1px solid #f0f0f0;
    }
    .comment:last-child { border-bottom: none; }
    .comment strong { color: #333; }
    .comments-section button {
        background: #333; color: white; padding: 10px 20px; border:none; border-radius: 4px; cursor: pointer;
    }
    .comments-section textarea {
        width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px;
    }
</style>

<?php if ($product): ?>
    <div class="product-detail-container">
        <div class="product-detail-image">
            <?php
            $image = $product['image'];
            if (!$image || $image == '0') {
                $imgSrc = 'https://placehold.co/400x300/cccccc/333333?text=Chưa+có+ảnh';
            } elseif (filter_var($image, FILTER_VALIDATE_URL)) {
                $imgSrc = $image;
            } else {
                $imgSrc = 'public/images/products/' . htmlspecialchars($image);
            }
            ?>
            <img src="<?php echo $imgSrc; ?>" alt="<?php echo htmlspecialchars($product['name']); ?>"
                onerror="this.onerror=null; this.src='https://placehold.co/400x300/cccccc/333333?text=Chưa+có+ảnh';">
        </div>
        <div class="product-detail-info">
            <h1><?php echo htmlspecialchars($product['name']); ?></h1>
            <p class="price"><?php echo number_format($product['price'], 0, ',', '.'); ?> VNĐ</p>
            <?php if (isset($ratingInfo) && $ratingInfo['total_ratings'] > 0): ?>
                <div style="margin: 15px 0; display: flex; align-items: center; gap: 10px;">
                    <div style="display: flex; align-items: center;">
                        <?php 
                        $avgRating = $ratingInfo['avg_rating'];
                        for ($i = 1; $i <= 5; $i++): 
                        ?>
                            <span style="font-size: 1.5em; color: <?php echo $i <= $avgRating ? '#ffc107' : '#ddd'; ?>;">★</span>
                        <?php endfor; ?>
                    </div>
                    <span style="color: #666; font-size: 1.1em;">
                        <strong><?php echo $avgRating; ?></strong>/5 
                        (<?php echo $ratingInfo['total_ratings']; ?> đánh giá)
                    </span>
                </div>
            <?php endif; ?>
            <p class="description"><strong>Mô tả:</strong> <?php echo nl2br(htmlspecialchars($product['description'])); ?></p>
            <p class="description"><strong>Tồn kho:</strong> <?php echo htmlspecialchars($product['stock_quantity']); ?></p>


            <?php if (isset($_SESSION['user_id']) && $_SESSION['role'] == 0): ?>
                <form id="add-to-cart-form" action="index.php?controller=cart&action=addToCart" method="POST">
                    <input type="hidden" name="product_id" value="<?php echo htmlspecialchars($product['id']); ?>">
                    

                    <?php 
                        $sizes = !empty($product['sizes']) ? array_map('trim', explode(',', $product['sizes'])) : ['38', '39', '40', '41', '42'];
                        $colors = !empty($product['colors']) ? array_map('trim', explode(',', $product['colors'])) : ['Trắng', 'Đen', 'Xanh', 'Đỏ'];
                    ?>

                    <?php if (!empty($sizes)): ?>
                        <div class="attribute-group">
                            <span class="attribute-title">Chọn Kích thước:</span>
                            <div class="attribute-options">
                                <?php foreach ($sizes as $size): ?>
                                    <?php if($size): ?>
                                    <label class="option-label">
                                        <input type="radio" name="size" value="<?php echo htmlspecialchars($size); ?>"> 
                                        <span class="option-text"><?php echo htmlspecialchars($size); ?></span>
                                    </label>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if (!empty($colors)): ?>
                        <div class="attribute-group">
                            <span class="attribute-title">Chọn Màu sắc:</span>
                            <div class="attribute-options">
                                <?php foreach ($colors as $color): ?>
                                    <?php if($color): ?>
                                    <label class="option-label">
                                        <input type="radio" name="color" value="<?php echo htmlspecialchars($color); ?>"> 
                                        <span class="option-text"><?php echo htmlspecialchars($color); ?></span>
                                    </label>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endif; ?>



                    <a href="#" class="size-guide-link">Bảng Quy Đổi Kích Cỡ ></a>

                    <div class="quantity-section">
                        <label style="color: #757575;">Số Lượng</label>
                        <div class="quantity-control">
                            <button type="button" class="quantity-btn" onclick="decreaseQuantity()">-</button>
                            <input type="number" name="quantity" id="quantity" value="1" min="1" max="<?php echo htmlspecialchars($product['stock_quantity']); ?>" class="quantity-input">
                            <button type="button" class="quantity-btn" onclick="increaseQuantity()">+</button>
                        </div>
                        <span style="color: #757575; font-size: 0.9em;"><?php echo htmlspecialchars($product['stock_quantity']); ?> sản phẩm có sẵn</span>
                    </div>

                    <div class="action-buttons">
                        <button type="submit" class="btn-add-cart" formaction="index.php?controller=cart&action=addToCart">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <circle cx="9" cy="21" r="1"></circle>
                                <circle cx="20" cy="21" r="1"></circle>
                                <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
                            </svg>
                            Thêm Vào Giỏ Hàng
                        </button>
                        <button type="submit" class="btn-buy-now" formaction="index.php?controller=cart&action=placeOrderDirectly">Mua Ngay</button>
                    </div>
                </form>

                <script>
                    document.getElementById('add-to-cart-form').addEventListener('submit', function(e) {
                        const form = this;
                        const sizes = form.querySelectorAll('input[name="size"]');
                        const colors = form.querySelectorAll('input[name="color"]');
                        
                        let sizeSelected = sizes.length === 0; // True if no size options exist
                        let colorSelected = colors.length === 0; // True if no color options exist

                        if (sizes.length > 0) {
                            for (let i = 0; i < sizes.length; i++) {
                                if (sizes[i].checked) {
                                    sizeSelected = true;
                                    break;
                                }
                            }
                        }

                        if (colors.length > 0) {
                            for (let i = 0; i < colors.length; i++) {
                                if (colors[i].checked) {
                                    colorSelected = true;
                                    break;
                                }
                            }
                        }

                        if (!sizeSelected || !colorSelected) {
                            e.preventDefault(); // Stop submission
                            alert('Vui lòng chọn Kích thước và Màu sắc để tiếp tục!');
                            return false;
                        }
                    });

                    function decreaseQuantity() {
                        var input = document.getElementById('quantity');
                        var value = parseInt(input.value);
                        if (value > 1) {
                            input.value = value - 1;
                        }
                    }
                    function increaseQuantity() {
                        var input = document.getElementById('quantity');
                        var value = parseInt(input.value);
                        var max = parseInt(input.getAttribute('max'));
                        if (value < max) {
                            input.value = value + 1;
                        }
                    }
                </script>
            <?php else: ?>
                <p>Vui lòng <a href="index.php?controller=user&action=login">đăng nhập</a> để mua hàng.</p>
            <?php endif; ?>
        </div>
    </div>

    <div class="comments-section">
        <h2>Đánh giá và bình luận</h2>
        <?php if (isset($_SESSION['user_id'])): ?>
            <?php if (isset($hasPurchased) && $hasPurchased): ?>
                <!-- DEBUG INFO (Remove after checking) -->
                <p style="color: blue; font-size: 0.8em;">
                    Debug: Mua: <?php echo $purchasedCount; ?> | Đánh giá: <?php echo $reviewedCount; ?> 
                    | CanReview: <?php echo $canReview ? 'True' : 'False'; ?>
                </p>
                <!-- END DEBUG -->
                <?php if (isset($canReview) && $canReview): ?>
                    <form action="index.php?controller=product&action=addComment" method="POST">
                        <?php echo CSRF::field(); ?>
                        <input type="hidden" name="product_id" value="<?php echo htmlspecialchars($product['id']); ?>">
                        <div style="margin-bottom: 15px;">
                            <label style="display: block; margin-bottom: 8px; font-weight: bold; color: #000c40ff;">Đánh giá (tùy chọn):</label>
                            <div style="display: flex; align-items: center; gap: 10px;">
                                <select name="rating" style="padding: 8px; border: 1px solid #ddd; border-radius: 5px;">
                                    <option value="">Chọn đánh giá</option>
                                    <option value="5">5 sao - Tuyệt vời</option>
                                    <option value="4">4 sao - Rất tốt</option>
                                    <option value="3">3 sao - Tốt</option>
                                    <option value="2">2 sao - Trung bình</option>
                                    <option value="1">1 sao - Kém</option>
                                </select>
                                <div id="star-preview" style="display: flex; gap: 3px; font-size: 1.2em;">
                                    <span style="color: #ddd;">★★★★★</span>
                                </div>
                            </div>
                        </div>
                        <textarea name="content" placeholder="Viết bình luận của bạn..." required></textarea><br>
                        <button type="submit">Gửi đánh giá</button>
                    </form>
                    <script>
                        document.querySelector('select[name="rating"]').addEventListener('change', function() {
                            const rating = parseInt(this.value) || 0;
                            const stars = document.querySelectorAll('#star-preview span');
                            if (stars.length > 0) {
                                let html = '';
                                for (let i = 1; i <= 5; i++) {
                                    html += '<span style="color: ' + (i <= rating ? '#ffc107' : '#ddd') + ';">★</span>';
                                }
                                stars[0].innerHTML = html;
                            }
                        });
                    </script>
                <?php else: ?>
                    <p style="color: green; font-weight: bold; margin-bottom: 20px;">Cảm ơn bạn đã đánh giá sản phẩm này!</p>
                <?php endif; ?>
            <?php else: ?>
                <p style="color:red; font-weight: bold;">Bạn cần mua sản phẩm này để có thể đánh giá.</p>
            <?php endif; ?>
        <?php else: ?>
            <p>Vui lòng <a href="index.php?controller=user&action=login">đăng nhập</a> để bình luận.</p>
        <?php endif; ?>

        <div class="comment-list">
            <?php if (!empty($comments)): ?>
                <?php foreach ($comments as $comment): ?>
                    <div class="comment">
                        <p>
                            <strong><?php echo htmlspecialchars($comment['username']); ?></strong>
                            <?php if (isset($comment['rating']) && $comment['rating'] > 0): ?>
                                <span style="margin-left: 10px; display: inline-flex; align-items: center; gap: 3px;">
                                    <?php for ($i = 1; $i <= 5; $i++): ?>
                                        <span style="color: <?php echo $i <= $comment['rating'] ? '#ffc107' : '#ddd'; ?>;">★</span>
                                    <?php endfor; ?>
                                </span>
                            <?php endif; ?>
                            - <small><?php echo htmlspecialchars($comment['created_at']); ?></small>
                        </p>
                        <p><?php echo nl2br(htmlspecialchars($comment['content'])); ?></p>
                        <?php if (isset($_SESSION['role']) && $_SESSION['role'] == 1): ?>
                            <a href="index.php?controller=admin&action=deleteComment&id=<?php echo htmlspecialchars($comment['id']); ?>" onclick="return confirm('Bạn có chắc chắn muốn xóa bình luận này?');" style="color: red; text-decoration: none;">Xóa</a>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>Chưa có bình luận nào.</p>
            <?php endif; ?>
        </div>
    </div>

<?php else: ?>
    <p>Không tìm thấy sản phẩm.</p>
<?php endif; ?>