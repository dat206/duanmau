<style>
    .data-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }
    .data-table th, .data-table td {
        padding: 12px;
        border: 1px solid #ddd;
        text-align: left;
    }
    .data-table th {
        background-color: #f2f2f2;
        font-weight: bold;
    }
    .action-btn {
        background: #000c40ff;
        color: white;
        padding: 10px;
        text-decoration: none;
        border-radius: 5px;
        margin-right: 5px;
        display: inline-block;
    }
    .action-btn:hover {
        background: white;
        color: #000c40ff;
        border: #000c40ff solid 1px;
        transition: 0.3s;
    }
    h1{
        text-align: center;
    }
</style>

<h1>Quản lý Bình luận</h1>
<table class="data-table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Người dùng</th>
            <th>Sản phẩm</th>
            <th>Nội dung</th>
            <th>Ngày tạo</th>
            <th>Trạng thái</th>
            <th>Hành động</th>
        </tr>
    </thead>
    <tbody>
        <?php if (!empty($comments)): ?>
            <?php foreach ($comments as $comment): ?>
            <tr>
                <td><?php echo htmlspecialchars($comment['id']); ?></td>
                <td><?php echo htmlspecialchars($comment['username']); ?></td>
                <td><?php echo htmlspecialchars($comment['product_name']); ?></td>
                <td><?php echo htmlspecialchars($comment['content']); ?></td>
                <td><?php echo htmlspecialchars($comment['created_at']); ?></td>
                <td>
                    <?php 
                    $status = isset($comment['status']) ? $comment['status'] : 1;
                    echo $status == 1 ? '<span style="color:green; font-weight:bold;">Hiển thị</span>' : '<span style="color:red; font-weight:bold;">Đã ẩn</span>';
                    ?>
                </td>
                <td>
                    <?php if ($status == 1): ?>
                        <a href="index.php?controller=admin&action=toggleCommentStatus&id=<?php echo htmlspecialchars($comment['id']); ?>&status=0" class="action-btn" style="background-color: #ffc107; color: black;">Ẩn</a>
                    <?php else: ?>
                        <a href="index.php?controller=admin&action=toggleCommentStatus&id=<?php echo htmlspecialchars($comment['id']); ?>&status=1" class="action-btn" style="background-color: #28a745;">Hiện</a>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="7">Không có bình luận nào.</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>