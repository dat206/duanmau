<style>
    .admin-form {
        background-color: white;
        padding: 30px;
        border-radius: 10px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        max-width: 600px;
        margin: 30px auto;
    }

    .admin-form h1 {
        color: #000c40ff;
        border-bottom: 2px solid #000c40ff;
        padding-bottom: 10px;
        margin-bottom: 25px;
    }

    .admin-form label {
        display: block;
        margin-bottom: 8px;
        font-weight: bold;
        color: #000c40ff;
    }

    .admin-form input[type="text"],
    .admin-form input[type="number"],
    .admin-form textarea,
    .admin-form select,
    .admin-form input[type="file"] {
        width: calc(100% - 24px);
        padding: 12px;
        margin-bottom: 15px;
        border: 1px solid #ddd;
        border-radius: 6px;
        font-size: 1em;
        box-sizing: border-box;
        transition: border-color 0.3s ease, box-shadow 0.3s ease;
    }

    .admin-form input[type="text"]:focus,
    .admin-form input[type="number"]:focus,
    .admin-form textarea:focus,
    .admin-form select:focus {
        outline: none;
        border-color: #000c40ff;
        box-shadow: 0 0 0 3px rgba(0, 12, 64, 0.1);
    }

    .admin-form input[type="file"] {
        padding: 8px;
        border: 2px dashed #ddd;
        background-color: #f9f9f9;
        cursor: pointer;
    }

    .admin-form input[type="file"]:hover {
        border-color: #000c40ff;
        background-color: #f0f0f0;
    }

    .admin-form button[type="submit"] {
        padding: 12px 25px;
        border: none;
        border-radius: 6px;
        background-color: #28a745;
        color: white;
        font-size: 1.1em;
        cursor: pointer;
        transition: background-color 0.3s ease, transform 0.2s ease;
    }

    .admin-form button[type="submit"]:hover {
        background-color: #218838;
        transform: translateY(-2px);
    }
</style>

<div class="admin-form">
    <h1 style="text-align: center;">Thêm Sản phẩm mới</h1>
    <form action="index.php?controller=admin&action=handleAddProduct" method="POST" enctype="multipart/form-data">
        <label for="name">Tên sản phẩm:</label>
        <input type="text" id="name" name="name" required>
        
        <label for="price">Giá:</label>
        <input type="number" id="price" name="price" step="0.01" required>
        
        <label for="description">Mô tả:</label>
        <textarea id="description" name="description"></textarea>
        
        <label for="image">Ảnh sản phẩm:</label>
        <img id="imagePreview" src="#" alt="Preview" style="display:none; max-width:200px; margin-bottom:10px;">
        <input type="file" id="imageInput" name="image" accept="image/*" required>
        
        <label for="category_id">Danh mục:</label>
        <select id="category_id" name="category_id" required>
            <?php foreach ($categories as $category): ?>
                <option value="<?php echo htmlspecialchars($category['id']); ?>">
                    <?php echo htmlspecialchars($category['name']); ?>
                </option>
            <?php endforeach; ?>
        </select>
        

        <label for="sizes">Kích thước (phân cách bằng dấu phẩy, ví dụ: 38,39,40):</label>
        <input type="text" id="sizes" name="sizes" placeholder="38,39,40,41">

        <label for="colors">Màu sắc (phân cách bằng dấu phẩy, ví dụ: Đen,Trắng):</label>
        <input type="text" id="colors" name="colors" placeholder="Trắng,Đen,Xanh">

        <label for="stock_quantity">Số lượng tồn kho:</label>
        <input type="number" id="stock_quantity" name="stock_quantity" value="0" min="0" required>
        
        <button style="background:#000c40ff; color:white;" type="submit">Thêm sản phẩm</button>
    </form>
    <script>
    document.getElementById('imageInput').addEventListener('change', function(event) {
        const [file] = event.target.files;
        if (file) {
            const preview = document.getElementById('imagePreview');
            preview.src = URL.createObjectURL(file);
            preview.style.display = 'block';
        }
    });
    </script>
</div>