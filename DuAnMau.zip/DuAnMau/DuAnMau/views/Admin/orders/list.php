<style>
    .data-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }
    .data-table th, .data-table td {
        padding: 12px;
        border: 1px solid #ddd;
        text-align: left;
    }
    .data-table th {
        background-color: #f2f2f2;
        font-weight: bold;
    }
    .action-btn {
        background: #000c40ff;
        color: white;
        padding: 8px 14px;
        border-radius: 6px;
        border: none;
        cursor: pointer;
        font-size: 14px;
        text-decoration: none;
        display: inline-block;
    }
    .action-btn:hover {
        background: white;
        color: #000c40ff;
        border: 1px solid #000c40ff;
        transition: 0.2s;
    }
    select {
        padding: 6px 10px;
        border-radius: 6px;
        border: 1px solid #d1d1d1;
    }
    h1 {
        text-align: center;
    }
</style>

<h1>Quản lý Đơn hàng</h1>
<table class="data-table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Tên khách hàng</th>
            <th>Tổng tiền</th>
            <th>Ngày đặt</th>
            <th>Trạng thái</th>
            <th>Hành động</th>
        </tr>
    </thead>
    <tbody>
        <?php if (!empty($orders)): ?>
            <?php foreach ($orders as $order): ?>
            <tr>
                <td><?php echo htmlspecialchars($order['id']); ?></td>
                <td><?php echo htmlspecialchars($order['username']); ?></td>
                <td><?php echo number_format($order['total_price'], 0, ',', '.'); ?> VNĐ</td>
                <td><?php echo htmlspecialchars($order['order_date']); ?></td>
                <td>
                    <form action="index.php?controller=admin&action=updateOrderStatus&id=<?php echo htmlspecialchars($order['id']); ?>" method="POST" style="display:inline;">
                        <select name="status">
                            <option value="Chờ xử lý" <?php echo ($order['status'] == 'Chờ xử lý') ? 'selected' : ''; ?>>Chờ xử lý</option>
                            <option value="Đã xác nhận" <?php echo ($order['status'] == 'Đã xác nhận') ? 'selected' : ''; ?>>Đã xác nhận</option>
                            <option value="Đang giao hàng" <?php echo ($order['status'] == 'Đang giao hàng') ? 'selected' : ''; ?>>Đang giao hàng</option>
                            <option value="Đã hoàn thành" <?php echo ($order['status'] == 'Đã hoàn thành') ? 'selected' : ''; ?>>Đã hoàn thành</option>
                            <option value="Đã hủy" <?php echo ($order['status'] == 'Đã hủy') ? 'selected' : ''; ?>>Đã hủy</option>
                        </select>
                        <button type="submit" class="action-btn">Cập nhật</button>
                    </form>
                </td>
                <td>
                   <a href="index.php?controller=admin&action=detailOrder&id=<?php echo htmlspecialchars($order['id']); ?>" class="action-btn" style="background-color: #17a2b8;">Xem chi tiết</a>
                   <!-- Delete button removed as per requirements -->
                </td>
            </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="6">Không có đơn hàng nào.</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>