<style>
    .order-detail-container {
        padding: 20px;
        background: #fff;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0,0,0,0.1);
        margin-top: 20px;
    }
    .section-title {
        color: #000c40ff;
        border-bottom: 2px solid #000c40ff;
        padding-bottom: 10px;
        margin-bottom: 20px;
        margin-top: 30px;
    }
    .info-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 20px;
    }
    .info-box {
        background: #f8f9fa;
        padding: 15px;
        border-radius: 5px;
        border: 1px solid #e9ecef;
    }
    .info-row {
        margin-bottom: 10px;
        display: flex;
        justify-content: space-between;
    }
    .info-label {
        font-weight: bold;
        color: #666;
    }
    .info-val {
        font-weight: bold;
        color: #333;
    }
    .product-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 15px;
    }
    .product-table th, .product-table td {
        padding: 12px;
        border: 1px solid #ddd;
        text-align: left;
    }
    .product-table th {
        background-color: #000c40ff;
        color: white;
    }
    .back-btn {
        display: inline-block;
        padding: 10px 20px;
        background-color: #6c757d;
        color: white;
        text-decoration: none;
        border-radius: 5px;
        margin-bottom: 20px;
    }
    .back-btn:hover {
        background-color: #5a6268;
    }
    .status-badge {
        padding: 5px 10px;
        border-radius: 15px;
        font-size: 0.9em;
        font-weight: bold;
    }
</style>

<div class="order-detail-container">
    <a href="index.php?controller=admin&action=orders" class="back-btn">← Quay lại danh sách</a>
    
    <h1 style="text-align: center; color: #000c40ff;">Chi tiết đơn hàng #<?php echo htmlspecialchars($order['id']); ?></h1>

    <div class="info-grid">
        <div class="info-box">
            <h3 style="margin-top: 0;">Thông tin chung</h3>
            <div class="info-row">
                <span class="info-label">Mã đơn hàng:</span>
                <span class="info-val">#<?php echo htmlspecialchars($order['id']); ?></span>
            </div>
            <div class="info-row">
                <span class="info-label">Khách hàng:</span>
                <span class="info-val"><?php echo htmlspecialchars($order['username']); ?></span>
            </div>
            <div class="info-row">
                <span class="info-label">Ngày đặt:</span>
                <span class="info-val"><?php echo date('d/m/Y H:i:s', strtotime($order['order_date'])); ?></span>
            </div>
            <div class="info-row">
                <span class="info-label">Trạng thái:</span>
                <span class="info-val">
                    <span class="status-badge" style="background-color: #e9ecef;">
                        <?php echo htmlspecialchars($order['status']); ?>
                    </span>
                </span>
            </div>
        </div>

        <?php if (isset($order['receiver_name'])): ?>
        <div class="info-box">
            <h3 style="margin-top: 0;">Thông tin giao hàng</h3>
            <div class="info-row">
                <span class="info-label">Người nhận:</span>
                <span class="info-val"><?php echo htmlspecialchars($order['receiver_name']); ?></span>
            </div>
            <div class="info-row">
                <span class="info-label">SĐT:</span>
                <span class="info-val"><?php echo htmlspecialchars($order['phone']); ?></span>
            </div>
            <div class="info-row">
                <span class="info-label">Địa chỉ:</span>
                <span class="info-val" style="text-align: right; max-width: 60%;"><?php echo htmlspecialchars($order['address']); ?></span>
            </div>
             <?php if (!empty($order['note'])): ?>
            <div class="info-row">
                <span class="info-label">Ghi chú:</span>
                <span class="info-val"><?php echo htmlspecialchars($order['note']); ?></span>
            </div>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>

    <h3 class="section-title">Danh sách sản phẩm</h3>
    <table class="product-table">
        <thead>
            <tr>
                <th>Hình ảnh</th>
                <th>Sản phẩm</th>
                <th>Số lượng</th>
                <th>Đơn giá</th>
                <th>Thành tiền</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($orderDetails as $item): ?>
                <?php
                    $image = $item['image'];
                    if (!$image || $image == '0') {
                        $imgSrc = 'https://placehold.co/50x50/cccccc/333333?text=N/A';
                    } elseif (filter_var($image, FILTER_VALIDATE_URL)) {
                        $imgSrc = $image;
                    } else {
                        $imgSrc = 'public/images/products/' . htmlspecialchars($image);
                    }
                ?>
                <tr>
                    <td><img src="<?php echo $imgSrc; ?>" width="50" height="50" style="object-fit:cover; border-radius:4px;"></td>
                    <td><?php echo htmlspecialchars($item['name']); ?></td>
                    <td><?php echo $item['quantity']; ?></td>
                    <td><?php echo number_format($item['price'], 0, ',', '.'); ?> VNĐ</td>
                    <td><strong><?php echo number_format($item['price'] * $item['quantity'], 0, ',', '.'); ?> VNĐ</strong></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="4" style="text-align: right; font-weight: bold; font-size: 1.1em;">Tổng cộng:</td>
                <td style="font-weight: bold; font-size: 1.1em; color: #d63031;"><?php echo number_format($order['total_price'], 0, ',', '.'); ?> VNĐ</td>
            </tr>
        </tfoot>
    </table>
</div>
