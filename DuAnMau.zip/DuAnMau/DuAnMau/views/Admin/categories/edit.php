<style>
    .admin-form {
        background-color: white;
        padding: 30px;
        border-radius: 10px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        max-width: 600px;
        margin: 30px auto;
    }

    .admin-form h1 {
        color: #000c40ff;
        border-bottom: 2px solid #000c40ff;
        padding-bottom: 10px;
        margin-bottom: 25px;
    }

    .admin-form label {
        display: block;
        margin-bottom: 8px;
        font-weight: bold;
        color: #000c40ff;
    }

    .admin-form input[type="text"] {
        width: calc(100% - 24px);
        padding: 12px;
        margin-bottom: 15px;
        border: 1px solid #ddd;
        border-radius: 6px;
        font-size: 1em;
        box-sizing: border-box;
        transition: border-color 0.3s ease, box-shadow 0.3s ease;
    }

    .admin-form input[type="text"]:focus {
        outline: none;
        border-color: #000c40ff;
        box-shadow: 0 0 0 3px rgba(0, 12, 64, 0.1);
    }

    .admin-form button[type="submit"] {
        padding: 12px 25px;
        border: none;
        border-radius: 6px;
        background-color: #000c40ff;
        color: white;
        font-size: 1.1em;
        cursor: pointer;
        transition: background-color 0.3s ease, transform 0.2s ease;
    }

    .admin-form button[type="submit"]:hover {
        background-color: #ffffffff;
        color: #000c40ff;
        border: #000c40ff solid 1px;
        transform: translateY(-2px);
    }
</style>

<div class="admin-form">
    <h1>Sửa Danh mục</h1>
    <?php if ($category): ?>
    <form action="index.php?controller=admin&action=handleEditCategory" method="POST">
        <input type="hidden" name="id" value="<?php echo htmlspecialchars($category['id']); ?>">
        <label for="name">Tên danh mục:</label>
        <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($category['name']); ?>" required>
        <button type="submit">Cập nhật</button>
    </form>
    <?php else: ?>
        <p>Không tìm thấy danh mục.</p>
    <?php endif; ?>
</div>  