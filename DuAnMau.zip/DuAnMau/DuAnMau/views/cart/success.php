<style>
    .order-success-message {
        text-align: center;
        padding: 50px;
        background-color: white;
        border-radius: 10px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        max-width: 600px;
        margin: 50px auto;
    }

    .order-success-message h1 {
        color: #28a745;
        font-size: 2.5em;
        margin-bottom: 20px;
        border-bottom: none;
    }

    .order-success-message p {
        font-size: 1.2em;
        color: #555;
        margin-bottom: 30px;
    }

    .order-success-message a {
        display: inline-block;
        padding: 12px 30px;
        background-color: #3498db;
        color: white;
        text-decoration: none;
        border-radius: 6px;
        font-size: 1.1em;
        transition: background-color 0.3s ease, transform 0.2s ease;
    }

    .order-success-message a:hover {
        background-color: #2980b9;
        transform: translateY(-2px);
    }
</style>

<div class="order-success-message">
    <h1>Đặt hàng thành công!</h1>
    <p>Cảm ơn bạn đã mua sắm tại 1Sneaker. Chúng tôi sẽ xử lý đơn hàng của bạn trong thời gian sớm nhất.</p>
    <a href="index.php">Tiếp tục mua sắm</a>
</div>