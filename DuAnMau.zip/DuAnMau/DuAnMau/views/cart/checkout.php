<style>
    .checkout-container {
        max-width: 1000px;
        margin: 0 auto;
        padding: 20px;
    }

    .checkout-header {
        text-align: center;
        color: #000c40ff;
        margin-bottom: 30px;
        padding-bottom: 15px;
        border-bottom: 2px solid #000c40ff;
    }

    .checkout-content {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 30px;
        margin-top: 30px;
    }

    @media (max-width: 768px) {
        .checkout-content {
            grid-template-columns: 1fr;
        }
    }

    .checkout-section {
        background: white;
        padding: 25px;
        border-radius: 10px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
    }

    .checkout-section h3 {
        color: #000c40ff;
        margin-bottom: 20px;
        padding-bottom: 10px;
        border-bottom: 1px solid #eee;
    }

    .form-group {
        margin-bottom: 20px;
    }

    .form-group label {
        display: block;
        margin-bottom: 8px;
        color: #333;
        font-weight: bold;
    }

    .form-group input,
    .form-group textarea,
    .form-group select {
        width: 100%;
        padding: 12px;
        border: 1px solid #ddd;
        border-radius: 5px;
        font-size: 14px;
        box-sizing: border-box;
    }

    .form-group input:focus,
    .form-group textarea:focus,
    .form-group select:focus {
        outline: none;
        border-color: #000c40ff;
    }

    .payment-method {
        display: flex;
        flex-direction: column;
        gap: 10px;
    }

    .payment-option {
        display: flex;
        align-items: center;
        padding: 12px;
        border: 2px solid #ddd;
        border-radius: 5px;
        cursor: pointer;
        transition: all 0.3s ease;
    }

    .payment-option:hover {
        border-color: #000c40ff;
        background-color: #f8f9fa;
    }

    .payment-option input[type="radio"] {
        width: auto;
        margin-right: 10px;
    }

    .order-summary {
        background: #f8f9fa;
        padding: 20px;
        border-radius: 8px;
        margin-top: 20px;
    }

    .order-item {
        display: flex;
        justify-content: space-between;
        padding: 10px 0;
        border-bottom: 1px solid #ddd;
    }

    .order-item:last-child {
        border-bottom: none;
    }

    .order-total {
        margin-top: 20px;
        padding-top: 20px;
        border-top: 2px solid #000c40ff;
        display: flex;
        justify-content: space-between;
        font-size: 1.3em;
        font-weight: bold;
        color: #000c40ff;
    }

    .btn-submit {
        width: 100%;
        padding: 15px;
        background-color: #27ae60;
        color: white;
        border: none;
        border-radius: 5px;
        font-size: 1.1em;
        font-weight: bold;
        cursor: pointer;
        transition: background-color 0.3s ease;
        margin-top: 20px;
    }

    .btn-submit:hover {
        background-color: #229954;
    }

    .btn-back {
        display: inline-block;
        padding: 10px 20px;
        background-color: #6c757d;
        color: white;
        text-decoration: none;
        border-radius: 5px;
        margin-top: 10px;
    }

    .btn-back:hover {
        background-color: #5a6268;
    }
</style>

<div class="checkout-container">
    <h1 class="checkout-header">Thanh toán</h1>

    <form action="index.php?controller=cart&action=processCheckout" method="POST">
        <?php echo CSRF::field(); ?>
        <div class="checkout-content">
            <div class="checkout-section">
                <h3>Thông tin người nhận</h3>
                
                <div class="form-group">
                    <label>Họ và tên *</label>
                    <input type="text" name="receiver_name" required 
                        value="<?php echo isset($_SESSION['username']) ? htmlspecialchars($_SESSION['username']) : ''; ?>">
                </div>

                <div class="form-group">
                    <label>Số điện thoại *</label>
                    <input type="tel" name="phone" required placeholder="09xxxxxxxx">
                </div>

                <div class="form-group">
                    <label>Địa chỉ nhận hàng *</label>
                    <textarea name="address" rows="3" required placeholder="Nhập địa chỉ chi tiết"></textarea>
                </div>

                <div class="form-group">
                    <label>Ghi chú</label>
                    <textarea name="note" rows="3" placeholder="Ghi chú cho đơn hàng (tùy chọn)"></textarea>
                </div>

                <div class="form-group">
                    <label>Phương thức thanh toán *</label>
                    <div class="payment-method">
                        <label class="payment-option">
                            <input type="radio" name="payment_method" value="COD" checked required>
                            <span>Thanh toán khi nhận hàng (COD)</span>
                        </label>
                        <label class="payment-option">
                            <input type="radio" name="payment_method" value="BANK_TRANSFER" required>
                            <span>Chuyển khoản ngân hàng</span>
                        </label>
                    </div>
                </div>
            </div>

            <div class="checkout-section">
                <h3>Đơn hàng của bạn</h3>
                
                <div class="order-summary">
                    <?php foreach ($cartItems as $item): ?>
                        <div class="order-item">
                            <div>
                                <strong><?php echo htmlspecialchars($item['name']); ?></strong>
                                <br>
                                <small>Số lượng: <?php echo $item['quantity']; ?> x <?php echo number_format($item['price'], 0, ',', '.'); ?> VNĐ</small>
                            </div>
                            <div>
                                <strong><?php echo number_format($item['price'] * $item['quantity'], 0, ',', '.'); ?> VNĐ</strong>
                            </div>
                        </div>
                    <?php endforeach; ?>
                    
                    <div class="order-total">
                        <span>Tổng cộng:</span>
                        <span><?php echo number_format($totalPrice, 0, ',', '.'); ?> VNĐ</span>
                    </div>
                </div>

                <button type="submit" class="btn-submit">Xác nhận đặt hàng</button>
                <a href="index.php?controller=cart&action=view" class="btn-back">Quay lại giỏ hàng</a>
            </div>
        </div>
    </form>
</div>

