<?php
require_once __DIR__ . '/BaseModel.php';

class CommentModel extends BaseModel {
    private $table = 'comments';

    public function __construct($conn) {
        parent::__construct($conn);
    }

    public function getCommentsByProductId($productId) {
        // Only show visible comments (status = 1)
        $sql = "SELECT c.*, u.username FROM " . $this->table . " c JOIN users u ON c.user_id = u.id WHERE c.product_id = ? AND c.status = 1 ORDER BY c.created_at DESC";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $productId);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    public function countUserReviews($userId, $productId) {
        $sql = "SELECT COUNT(*) as count FROM " . $this->table . " WHERE user_id = ? AND product_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("ii", $userId, $productId);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        return (int)$row['count'];
    }

    public function getAverageRating($productId) {
        // Only count visible comments
        $sql = "SELECT AVG(rating) as avg_rating, COUNT(*) as total_ratings FROM " . $this->table . " WHERE product_id = ? AND rating IS NOT NULL AND status = 1";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $productId);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        return [
            'avg_rating' => $row['avg_rating'] ? round($row['avg_rating'], 1) : 0,
            'total_ratings' => $row['total_ratings'] ?? 0
        ];
    }
    
    public function getAllComments() {
        // Admin sees all comments
        $sql = "SELECT c.*, u.username, p.name as product_name FROM " . $this->table . " c JOIN users u ON c.user_id = u.id JOIN products p ON c.product_id = p.id ORDER BY c.created_at DESC";
        $result = $this->conn->query($sql);
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    public function addComment($productId, $userId, $content, $rating = null) {
        $checkColumns = $this->conn->query("DESCRIBE " . $this->table);
        $existingColumns = [];
        while ($row = $checkColumns->fetch_assoc()) {
            $existingColumns[] = $row['Field'];
        }

        if (in_array('rating', $existingColumns)) {
            // Default status = 1 (Visible)
            $sql = "INSERT INTO " . $this->table . " (product_id, user_id, content, rating, status) VALUES (?, ?, ?, ?, 1)";
            $stmt = $this->conn->prepare($sql);
            $rating = $rating !== null ? (int)$rating : null;
            $stmt->bind_param("iisi", $productId, $userId, $content, $rating);
        } else {
            $sql = "INSERT INTO " . $this->table . " (product_id, user_id, content, status) VALUES (?, ?, ?, 1)";
            $stmt = $this->conn->prepare($sql);
            $stmt->bind_param("iis", $productId, $userId, $content);
        }
        return $stmt->execute();
    }
    
    public function updateCommentStatus($id, $status) {
        $sql = "UPDATE " . $this->table . " SET status = ? WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("ii", $status, $id);
        return $stmt->execute();
    }
    
    public function deleteComment($commentId) {
        $sql = "DELETE FROM " . $this->table . " WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $commentId);
        return $stmt->execute();
    }
}
?>