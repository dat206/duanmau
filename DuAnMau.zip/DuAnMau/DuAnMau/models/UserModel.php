<?php
require_once __DIR__ . '/BaseModel.php';

class UserModel extends BaseModel {
    private $table = 'users';

    public function __construct($conn) {
        parent::__construct($conn);
    }

    public function login($username, $password) {
        $sql = "SELECT * FROM {$this->table} WHERE username = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            if (password_verify($password, $user['password'])) {
                if (isset($user['is_locked']) && $user['is_locked'] == 1) {
                    return 'locked'; // Indicate account is locked
                }
                return $user;
            }
        }
        return false;
    }

    public function toggleLock($id) {
        // Toggle is_locked status: 0 -> 1, 1 -> 0
        $sql = "UPDATE {$this->table} SET is_locked = NOT is_locked WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $id);
        return $stmt->execute();
    }

    public function register($username, $password, $age = null, $address = null, $phoneNumber = null) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $sql = "INSERT INTO {$this->table} (username, password, age, address, phone_number) VALUES (?, ?, ?, ?, ?)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("ssiss", $username, $hashedPassword, $age, $address, $phoneNumber);
        return $stmt->execute();
    }

    public function getAllUsers() {
        $sql = "SELECT * FROM {$this->table}";
        $result = $this->conn->query($sql);
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    public function getUserById($id) {
        $sql = "SELECT * FROM {$this->table} WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }

    public function updateUserRole($userId, $newRole) {
        $sql = "UPDATE {$this->table} SET role = ? WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("ii", $newRole, $userId);
        return $stmt->execute();
    }


    public function updateUserInfo($userId, $username, $age, $address, $phoneNumber) {
        // Check if username already exists for OTHER users
        $sqlCheck = "SELECT id FROM {$this->table} WHERE username = ? AND id != ?";
        $stmtCheck = $this->conn->prepare($sqlCheck);
        $stmtCheck->bind_param("si", $username, $userId);
        $stmtCheck->execute();
        $resultCheck = $stmtCheck->get_result();
        if ($resultCheck->num_rows > 0) {
            return false; // Username exists
        }

        $sql = "UPDATE {$this->table} SET username = ?, age = ?, address = ?, phone_number = ? WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("sissi", $username, $age, $address, $phoneNumber, $userId);
        
        try {
            return $stmt->execute();
        } catch (mysqli_sql_exception $e) {
            // Log error or handle specific code
            return false;
        }
    }

    public function updatePassword($userId, $newPassword) {
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
        $sql = "UPDATE {$this->table} SET password = ? WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("si", $hashedPassword, $userId);
        return $stmt->execute();
    }

    public function getTotalUsers() {
        $sql = "SELECT COUNT(*) as total FROM {$this->table}";
        $result = $this->conn->query($sql);
        $row = $result->fetch_assoc();
        return $row['total'] ?? 0;
    }

    public function getNewUsersThisMonth() {
        $sql = "SELECT COUNT(*) as count FROM {$this->table} 
                WHERE YEAR(created_at) = YEAR(CURDATE()) 
                AND MONTH(created_at) = MONTH(CURDATE())";
        $result = $this->conn->query($sql);
        $row = $result->fetch_assoc();
        return $row['count'] ?? 0;
    }

    public function deleteUser($id) {
        $this->conn->query("SET FOREIGN_KEY_CHECKS = 0");

        $this->conn->query("DELETE FROM order_details WHERE order_id IN (SELECT id FROM orders WHERE user_id = $id)");
        $this->conn->query("DELETE FROM orders WHERE user_id = $id");
        $this->conn->query("DELETE FROM cart WHERE user_id = $id");
        $this->conn->query("DELETE FROM comments WHERE user_id = $id");

        $stmt = $this->conn->prepare("DELETE FROM {$this->table} WHERE id = ?");
        $stmt->bind_param("i", $id);
        $result = $stmt->execute();

        $this->conn->query("SET FOREIGN_KEY_CHECKS = 1");

        return $result;
    }
}
?>
