<?php
// Load necessary files
require_once 'config/database.php';
require_once 'models/CartModel.php';
require_once 'models/ProductModel.php';

// Simulate User Session
session_start();
$_SESSION['user_id'] = 1; // Assuming user ID 1 exists
$userId = $_SESSION['user_id'];

echo "<h1>Debug: Verifying Buy Now Logic</h1>";

// 0. Setup: Clear Cart and Add Initial Item
echo "<h3>0. Setup: Clearing Cart and Adding Initial Item...</h3>";
$cartModel = new CartModel($conn);
$cartModel->clearCart($userId);

// Add Product A (ID: 5, Size: 38, Color: Trắng)
$cartModel->addToCart($userId, 5, 1, '38', 'Trắng');
echo "Added Product 5 (Size: 38, Color: Trắng) to cart.<br>";

$items = $cartModel->getCartItems($userId);
echo "Current Cart Items: " . count($items) . "<br>";
if (count($items) !== 1) {
    echo "<strong style='color:red'>FAIL: Cart should have 1 item.</strong><br>";
}

// 1. Simulate 'Buy Now' Action (addToCart + redirect logic)
echo "<h3>1. Simulating 'Buy Now' for Product B...</h3>";
// Add Product B (ID: 6, Size: 39, Color: Đen)
$cartModel->addToCart($userId, 6, 2, '39', 'Đen');
echo "Executed 'Buy Now' (addToCart) for Product 6 (Size: 39, Color: Đen).<br>";


// 2. Verify Final Cart State
echo "<h3>2. Verify Final Cart State (What Checkout Page Sees)</h3>";
$finalItems = $cartModel->getCartItems($userId);

echo "<table border='1' cellpadding='5'>";
echo "<tr><th>Product ID</th><th>Name</th><th>Quantity</th><th>Size</th><th>Color</th></tr>";
foreach ($finalItems as $item) {
    echo "<tr>";
    echo "<td>" . $item['product_id'] . "</td>";
    echo "<td>" . (isset($item['name']) ? $item['name'] : 'Unknown') . "</td>";
    echo "<td>" . $item['quantity'] . "</td>";
    echo "<td>" . $item['size'] . "</td>";
    echo "<td>" . $item['color'] . "</td>";
    echo "</tr>";
}
echo "</table>";

if (count($finalItems) === 2) {
    echo "<h2 style='color:green'>SUCCESS: Cart contains 2 items. Grouping works.</h2>";
} else {
    echo "<h2 style='color:red'>FAIL: Cart contains " . count($finalItems) . " items. Grouping failed.</h2>";
}
?>
