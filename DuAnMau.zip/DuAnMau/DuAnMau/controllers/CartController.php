<?php
require_once __DIR__ . '/../models/ProductModel.php'; 
require_once __DIR__ . '/../models/CartModel.php';
require_once __DIR__ . '/../models/OrderModel.php';

class CartController {

    public function addToCart() {
        if (!isset($_SESSION['user_id'])) {
            header('Location: index.php?controller=user&action=login');
            exit();
        }

        if (isset($_POST['product_id']) && isset($_POST['quantity'])) {
            global $conn; 
            $userId = $_SESSION['user_id'];
            $productId = $_POST['product_id'];
            $quantity = $_POST['quantity'];
            $size = isset($_POST['size']) ? $_POST['size'] : null;
            $color = isset($_POST['color']) ? $_POST['color'] : null;

            $cartModel = new CartModel($conn);
            $cartModel->addToCart($userId, $productId, $quantity, $size, $color);
            header('Location: index.php?controller=cart&action=view');
            exit();
        }
        header('Location: index.php');
        exit();
    }

    //hiện giỏ hàng
    public function view() {
        if (!isset($_SESSION['user_id'])) {
            header('Location: index.php?controller=user&action=login');
            exit();
        }
        global $conn; 
        $userId = $_SESSION['user_id'];
        $cartModel = new CartModel($conn); 
        $cartItems = $cartModel->getCartItems($userId);
        
        require_once __DIR__ . '/../views/layouts/user_header.php'; 
        require_once __DIR__ . '/../views/cart/view.php'; 
        require_once __DIR__ . '/../views/layouts/user_footer.php'; 
    }
    
    //đặt hàng (deprecated - sử dụng processCheckout)
    public function placeOrder() {
        if (!isset($_SESSION['user_id'])) {
            header('Location: index.php?controller=user&action=login');
            exit();
        }
        
        global $conn;
        $userId = $_SESSION['user_id'];
        $cartModel = new CartModel($conn); 
        $orderModel = new OrderModel($conn); 
        
        $cartItems = $cartModel->getCartItems($userId);
        if (empty($cartItems)) {
            echo "<script>alert('Giỏ hàng của bạn đang trống!');</script>";
            header('refresh:0; url=index.php?controller=cart&action=view');
            exit();
        }
        
        $totalPrice = 0;
        foreach ($cartItems as $item) {
            $totalPrice += $item['price'] * $item['quantity'];
        }
        
        if ($orderModel->createOrder($userId, $totalPrice, $cartItems)) {
            $cartModel->clearCart($userId);
            header('Location: index.php?controller=cart&action=success');
        } else {
            echo "<script>alert('Có lỗi xảy ra trong quá trình đặt hàng. Vui lòng thử lại.');</script>";
            header('refresh:0; url=index.php?controller=cart&action=view');
            exit();
        }
        exit();
    }

    //xử lý thanh toán
    public function processCheckout() {
        if (!isset($_SESSION['user_id'])) {
            header('Location: index.php?controller=user&action=login');
            exit();
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // CSRF Protection
            if (!isset($_POST['csrf_token']) || !CSRF::verify($_POST['csrf_token'])) {
                echo "<script>alert('Invalid security token. Please try again.');</script>";
                header('refresh:0; url=index.php?controller=cart&action=checkout');
                exit();
            }

            global $conn;
            $userId = $_SESSION['user_id'];
            $cartModel = new CartModel($conn);
            $orderModel = new OrderModel($conn);
            $productModel = new ProductModel($conn);

            // Validate form data
            $receiverName = trim($_POST['receiver_name'] ?? '');
            $phone = trim($_POST['phone'] ?? '');
            $address = trim($_POST['address'] ?? '');
            $note = trim($_POST['note'] ?? '');
            $paymentMethod = $_POST['payment_method'] ?? 'COD';

            if (empty($receiverName) || empty($phone) || empty($address)) {
                echo "<script>alert('Vui lòng điền đầy đủ thông tin!');</script>";
                header('refresh:0; url=index.php?controller=cart&action=checkout');
                exit();
            }

            $cartItems = $cartModel->getCartItems($userId);
            if (empty($cartItems)) {
                echo "<script>alert('Giỏ hàng của bạn đang trống!');</script>";
                header('refresh:0; url=index.php?controller=cart&action=view');
                exit();
            }

            // Kiểm tra tồn kho
            foreach ($cartItems as $item) {
                $product = $productModel->getProductById($item['product_id']);
                if (!$product || $product['stock_quantity'] < $item['quantity']) {
                    echo "<script>alert('Sản phẩm " . htmlspecialchars($item['name']) . " không đủ số lượng trong kho!');</script>";
                    header('refresh:0; url=index.php?controller=cart&action=view');
                    exit();
                }
            }

            $totalPrice = 0;
            foreach ($cartItems as $item) {
                $totalPrice += $item['price'] * $item['quantity'];
            }

            // Tạo đơn hàng với thông tin đầy đủ
            if ($orderModel->createOrderWithDetails($userId, $totalPrice, $cartItems, $receiverName, $phone, $address, $note, $paymentMethod)) {
                // Cập nhật tồn kho
                foreach ($cartItems as $item) {
                    $product = $productModel->getProductById($item['product_id']);
                    $newStock = $product['stock_quantity'] - $item['quantity'];
                    $productModel->updateProduct($item['product_id'], array_merge($product, ['stock_quantity' => $newStock]));
                }
                
                $cartModel->clearCart($userId);
                header('Location: index.php?controller=cart&action=success');
            } else {
                echo "<script>alert('Có lỗi xảy ra trong quá trình đặt hàng. Vui lòng thử lại.');</script>";
                header('refresh:0; url=index.php?controller=cart&action=checkout');
            }
            exit();
        }
        
        header('Location: index.php?controller=cart&action=view');
        exit();
    }

    //check đăng nhập hayc chưa
    // Mua ngay -> Thêm vào giỏ và chuyển đến trang thanh toán
    public function placeOrderDirectly() {
        if (!isset($_SESSION['user_id'])) {
            header('Location: index.php?controller=user&action=login');
            exit();
        }

        if (isset($_POST['product_id']) && isset($_POST['quantity'])) {
            global $conn;
            $userId = $_SESSION['user_id'];
            $productId = $_POST['product_id'];
            $quantity = $_POST['quantity'];
            $size = isset($_POST['size']) ? $_POST['size'] : null;
            $color = isset($_POST['color']) ? $_POST['color'] : null;

            $cartModel = new CartModel($conn);
            $cartModel->addToCart($userId, $productId, $quantity, $size, $color);
            
            // Chuyển hướng đến trang thanh toán (checkout) thay vì tạo đơn hàng ngay
            header('Location: index.php?controller=cart&action=checkout');
            exit();
        }
        header('Location: index.php');
        exit();
    }

    //hoàn thành đơn hàng
    public function success() {
        require_once __DIR__ . '/../views/layouts/user_header.php';
        require_once __DIR__ . '/../views/cart/success.php'; 
        require_once __DIR__ . '/../views/layouts/user_footer.php';
    }

    //xóa sản phẩm trong giỏ hàng
    public function removeFromCart() {
        if (!isset($_SESSION['user_id'])) {
            header('Location: index.php?controller=user&action=login');
            exit();
        }
        if (isset($_GET['id'])) {
            global $conn; 
            $cartId = $_GET['id'];
            $cartModel = new CartModel($conn);
            $cartModel->removeCartItem($cartId);
        }
        header('Location: index.php?controller=cart&action=view');
        exit();
    }

    //cập nhật số lượng sản phẩm trong giỏ hàng
    public function updateQuantity() {
        if (!isset($_SESSION['user_id'])) {
            header('Location: index.php?controller=user&action=login');
            exit();
        }
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cart_id']) && isset($_POST['quantity'])) {
            // CSRF Protection
            if (!isset($_POST['csrf_token']) || !CSRF::verify($_POST['csrf_token'])) {
                echo "<script>alert('Invalid security token. Please try again.');</script>";
                header('refresh:0; url=index.php?controller=cart&action=view');
                exit();
            }

            global $conn;
            $cartId = (int)$_POST['cart_id'];
            $quantity = max(1, (int)$_POST['quantity']);
            
            $cartModel = new CartModel($conn);
            $cartItem = $cartModel->getCartItemById($cartId);
            
            if ($cartItem && $cartItem['user_id'] == $_SESSION['user_id']) {
                // Kiểm tra tồn kho
                $productModel = new ProductModel($conn);
                $product = $productModel->getProductById($cartItem['product_id']);
                
                if ($product && $quantity <= $product['stock_quantity']) {
                    $cartModel->updateCartQuantity($cartId, $quantity);
                } else {
                    echo "<script>alert('Số lượng sản phẩm không đủ trong kho');</script>";
                }
            }
        }
        header('Location: index.php?controller=cart&action=view');
        exit();
    }

    //trang thanh toán
    public function checkout() {
        if (!isset($_SESSION['user_id'])) {
            header('Location: index.php?controller=user&action=login');
            exit();
        }
        
        global $conn;
        $userId = $_SESSION['user_id'];
        $cartModel = new CartModel($conn);
        $cartItems = $cartModel->getCartItems($userId);
        
        if (empty($cartItems)) {
            echo "<script>alert('Giỏ hàng của bạn đang trống!');</script>";
            header('refresh:0; url=index.php?controller=cart&action=view');
            exit();
        }
        
        $totalPrice = 0;
        foreach ($cartItems as $item) {
            $totalPrice += $item['price'] * $item['quantity'];
        }
        
        require_once __DIR__ . '/../views/layouts/user_header.php';
        require_once __DIR__ . '/../views/cart/checkout.php';
        require_once __DIR__ . '/../views/layouts/user_footer.php';
    }
}
?>