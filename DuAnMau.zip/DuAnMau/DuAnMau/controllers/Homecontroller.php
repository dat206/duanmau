<?php
require_once __DIR__ . '/../models/ProductModel.php';
require_once __DIR__ . '/../models/CategoryModel.php';

class HomeController {
    public function index() {
        global $conn; 
        $productModel = new ProductModel($conn);
        $categoryModel = new CategoryModel($conn);
        
        $featuredProducts = $productModel->getFeaturedProducts(9);
        $categories = $categoryModel->getAllCategories();
        
        require_once __DIR__ . '/../views/layouts/user_header.php'; 
        require_once __DIR__ . '/../views/home/index.php'; 
        require_once __DIR__ . '/../views/layouts/user_footer.php';
    }
}
?>