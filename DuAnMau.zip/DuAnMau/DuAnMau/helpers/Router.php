<?php

class Router {
    private $routes = [];

    public function get($uri, $action) {
        $this->addRoute('GET', $uri, $action);
    }

    public function post($uri, $action) {
        $this->addRoute('POST', $uri, $action);
    }

    private function addRoute($method, $uri, $action) {
        // Remove helper/admin/ or any prefix if needed, but for now just store exact match
        // Or better, normalize the URI
        $this->routes[] = [
            'method' => $method,
            'uri' => $this->normalizeUri($uri),
            'action' => $action
        ];
    }
    
    private function normalizeUri($uri) {
        return trim($uri, '/');
    }



    public function dispatch() {
        // 1. Priority: Legacy Query String Routing (?controller=x&action=y)
        // This must come first to ensure existing links (index.php?controller=...) work correctly
        // instead of falling through to the default '/' route.
        if (isset($_GET['controller'])) {
            $controllerName = ucfirst($_GET['controller']) . 'Controller';
            $actionName = isset($_GET['action']) ? $_GET['action'] : 'index';
            
            // Check POST special actions (from old index.php logic)
            if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_GET['controller'] === 'user') {
                if ($actionName === 'login') $actionName = 'handleLogin';
                if ($actionName === 'register') $actionName = 'handleRegister';
                if ($actionName === 'profile') $actionName = 'handleProfileUpdate';
            }

            $this->executeController($controllerName, $actionName);
            return;
        }

        $uri = $_SERVER['REQUEST_URI'];
        $method = $_SERVER['REQUEST_METHOD'];

        // Normalize URI: remove query string
        if (false !== $pos = strpos($uri, '?')) {
            $uri = substr($uri, 0, $pos);
        }
        
        // Handle subdirectory
        $scriptName = dirname($_SERVER['SCRIPT_NAME']);
        // Ensure scriptName is not just backslash on Windows or something weird
        $scriptName = str_replace('\\', '/', $scriptName);
        
        if ($scriptName !== '/' && strpos($uri, $scriptName) === 0) {
            $uri = substr($uri, strlen($scriptName));
        }

        $uri = $this->normalizeUri($uri);
        
        // Treat 'index.php' as root/home
        if ($uri === 'index.php') {
            $uri = '';
        }

        // 2. Try to match defined routes
        foreach ($this->routes as $route) {
            if ($route['method'] === $method && $route['uri'] === $uri) {
                // ... same old dispatch logic ...
                $this->executeRoute($route['action']);
                return;
            }
        }
        
        // 404
        http_response_code(404);
        require_once __DIR__ . '/../views/layouts/user_header.php';
        echo "<div class='container my-5'><h2>404 - Trang không tìm thấy</h2><p>Đường dẫn: " . htmlspecialchars($uri) . "</p></div>";
        require_once __DIR__ . '/../views/layouts/user_footer.php';
    }

    private function executeRoute($action) {
        $parts = explode('@', $action);
        $this->executeController($parts[0], $parts[1]);
    }

    private function executeController($controllerName, $methodName) {
        // Assume controllers are loaded or can be loaded
        // In the current setup, we might need to require them if not already
        // But index.php requires them at the top.
        
        if (class_exists($controllerName)) {
            $controller = new $controllerName();
            if (method_exists($controller, $methodName)) {
                $controller->$methodName();
            } else {
                echo "Method $methodName not found in $controllerName";
            }
        } else {
             echo "Controller $controllerName not found";
        }
    }
}
