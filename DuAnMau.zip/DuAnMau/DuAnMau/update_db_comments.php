<?php
require_once 'config/database.php';

function addColumnIfNotExists($conn, $table, $column, $definition) {
    $check = $conn->query("SHOW COLUMNS FROM $table LIKE '$column'");
    if ($check->num_rows == 0) {
        $sql = "ALTER TABLE $table ADD COLUMN $column $definition";
        if ($conn->query($sql) === TRUE) {
            echo "Successfully added '$column' column to '$table' table.<br>";
        } else {
            echo "Error adding '$column': " . $conn->error . "<br>";
        }
    } else {
        echo "Column '$column' already exists in '$table'.<br>";
    }
}

addColumnIfNotExists($conn, 'comments', 'rating', "INT(11) DEFAULT NULL AFTER content");
addColumnIfNotExists($conn, 'comments', 'status', "TINYINT(1) DEFAULT 1 COMMENT '1: Visible, 0: Hidden' AFTER rating");

echo "Database update completed.";
?>
