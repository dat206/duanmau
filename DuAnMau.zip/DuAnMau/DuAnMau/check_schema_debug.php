<?php
require_once 'config/database.php';

function getTableSchema($conn, $table) {
    echo "<h2>Schema for table: $table</h2>";
    $result = $conn->query("DESCRIBE $table");
    if ($result) {
        echo "<table border='1'><tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            foreach ($row as $key => $val) {
                echo "<td>" . htmlspecialchars($val) . "</td>";
            }
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "Error: " . $conn->error;
    }
}

getTableSchema($conn, 'users');
?>
