<?php

$router = new Router();

// Home
$router->get('/', 'HomeController@index');
$router->get('/home', 'HomeController@index');

// Admin
$router->get('/admin/dashboard', 'AdminController@dashboard');
$router->get('/admin/products', 'AdminController@products');
$router->get('/admin/orders', 'AdminController@orders');
$router->get('/admin/users', 'AdminController@users');
$router->get('/admin/categories', 'AdminController@categories');
$router->get('/admin/comments', 'AdminController@comments');

// Product
$router->get('/products', 'ProductController@list');


// User
$router->get('/login', 'UserController@login');
$router->get('/register', 'UserController@register');
$router->post('/login', 'UserController@handleLogin');
$router->post('/register', 'UserController@handleRegister');
$router->get('/logout', 'UserController@logout');

// Cart
$router->post('/cart/add', 'CartController@addToCart');
$router->get('/cart/view', 'CartController@view');
$router->get('/cart', 'CartController@view'); // Alias
$router->get('/cart/checkout', 'CartController@checkout');
$router->post('/cart/checkout', 'CartController@processCheckout');
$router->post('/cart/placeOrderDirectly', 'CartController@placeOrderDirectly');
$router->get('/cart/success', 'CartController@success');
$router->get('/cart/remove', 'CartController@removeFromCart');
$router->post('/cart/update', 'CartController@updateQuantity');

// Order
$router->get('/order/my-orders', 'OrderController@myOrders');
$router->get('/order/detail', 'OrderController@detail');

// Product Actions
$router->get('/product/detail', 'ProductController@detail');
$router->post('/product/comment', 'ProductController@addComment');
$router->get('/product/search', 'ProductController@search');


