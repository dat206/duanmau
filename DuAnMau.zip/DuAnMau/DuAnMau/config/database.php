<?php
class Database
{
    // private $host = "localhost";
    // private $user = "root";
    // private $password = "";
    // private $dbname = "1sneaker_1";
    // private $conn;

    private $host = "localhost";
    private $db_name = "sneaker_mvc1";
    private $username = "root";
    private $password = "";   
    private $port = "3306";       
    private $conn;

    public function __construct()
    {
        $this->conn = new mysqli($this->host, $this->username, $this->password, $this->db_name);
        if ($this->conn->connect_error) {
            die("Kết nối database thất bại: " . $this->conn->connect_error);
        }
        $this->conn->set_charset("utf8mb4");
    }

    public function getConnection()
    {
        return $this->conn;
    }
}

$db = new Database();
$conn = $db->getConnection();
