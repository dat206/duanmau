<?php
require_once 'config/database.php';

echo "<h2>Table Columns (products)</h2>";
$result = $conn->query("SHOW COLUMNS FROM products");
while ($row = $result->fetch_assoc()) {
    echo $row['Field'] . " - " . $row['Type'] . "<br>";
}

echo "<h2>Product Data</h2>";
$result = $conn->query("SELECT id, name, sizes, colors FROM products LIMIT 5");
while ($row = $result->fetch_assoc()) {
    echo "ID: " . $row['id'] . " | Name: " . $row['name'] . " | Sizes: [" . var_export($row['sizes'], true) . "] | Colors: [" . var_export($row['colors'], true) . "]<br>";
}
?>
