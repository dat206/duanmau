<?php
session_start();
require_once 'config/database.php';

// Global lock check
if (isset($_SESSION['user_id'])) {
    $db = new Database();
    $conn = $db->getConnection();
    
    $checkLockSql = "SELECT is_locked FROM users WHERE id = ?";
    $checkLockStmt = $conn->prepare($checkLockSql);
    $checkLockStmt->bind_param("i", $_SESSION['user_id']);
    $checkLockStmt->execute();
    $checkLockResult = $checkLockStmt->get_result();
    
    if ($checkLockResult->num_rows > 0) {
        $checkLockRow = $checkLockResult->fetch_assoc();
        if ($checkLockRow['is_locked'] == 1) {
            session_destroy();
            echo "<script>alert('Tài khoản của bạn đã bị khóa!'); window.location.href='index.php?controller=user&action=login';</script>";
            exit();
        }
    }
}

require_once 'helpers/CSRF.php'; 

require_once 'models/BaseModel.php';
require_once 'models/CategoryModel.php';
require_once 'models/CommentModel.php';
require_once 'models/OrderModel.php';
require_once 'models/ProductModel.php';
require_once 'models/UserModel.php';
require_once 'models/CartModel.php'; 

require_once 'controllers/Homecontroller.php';
require_once 'controllers/UserController.php';
require_once 'controllers/AdminController.php';
require_once 'controllers/ProductController.php';
require_once 'controllers/CartController.php';
require_once 'controllers/OrderController.php';



require_once 'helpers/Router.php';

// Load Routes
require_once 'config/routes.php';

// Dispatch
$router->dispatch();
