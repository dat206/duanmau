const dailyCtx = document.getElementById('dailyRevenueChart');
        if (dailyCtx) {
            const dailyRevenueChart = new Chart(dailyCtx.getContext('2d'), {
            type: 'line',
            data: {
                labels: <?php echo $chartLabelsJson ?? '[]'; ?>,
                datasets: [{
                    label: 'Doanh thu (VNĐ)',
                    data: <?php echo $chartDataJson ?? '[]'; ?>,
                    borderColor: '#00bf00ff',
                    backgroundColor: 'rgba(102, 126, 234, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4,
                    pointRadius: 4,
                    pointBackgroundColor: '#00bf00ff',
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointHoverRadius: 6,
                    pointHoverBackgroundColor: '#00bf00ff',
                    pointHoverBorderColor: '#fff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        padding: 12,
                        titleFont: {
                            size: 13
                        },
                        bodyFont: {
                            size: 14
                        },
                        callbacks: {
                            label: function(context) {
                                let label = context.dataset.label || '';
                                if (label) {
                                    label += ': ';
                                }
                                label += new Intl.NumberFormat('vi-VN').format(context.parsed.y) + ' VNĐ';
                                return label;
                            }
                        }
                    }
                },
                    scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.05)',
                            drawBorder: false
                        },
                        ticks: {
                            callback: function(value) {
                                return new Intl.NumberFormat('vi-VN', { 
                                    notation: 'compact',
                                    compactDisplay: 'short'
                                }).format(value);
                            },
                            font: {
                                size: 11
                            },
                            color: '#666'
                        }
                    },
                    x: {
                        grid: {
                            display: false,
                            drawBorder: false
                        },
                        ticks: {
                            font: {
                                size: 11
                            },
                            color: '#666',
                            maxRotation: 0,
                            autoSkip: true,
                            maxTicksLimit: 15
                        }
                    }
                }
            }
        });
        }
        
        const monthlyCtx = document.getElementById('monthlyRevenueChart');
        if (monthlyCtx) {
            const monthlyRevenueChart = new Chart(monthlyCtx.getContext('2d'), {
                type: 'bar',
                data: {
                    labels: <?php echo $monthlyLabelsJson ?? '[]'; ?>,
                    datasets: [{
                        label: 'Doanh thu (VNĐ)',
                        data: <?php echo $monthlyDataJson ?? '[]'; ?>,
                        backgroundColor: function(context) {
                            const gradient = context.chart.ctx.createLinearGradient(0, 0, 0, 400);
                            gradient.addColorStop(0, '#00bf00ff');
                            gradient.addColorStop(1, '#00bf00ff');
                            return gradient;
                        },
                        borderColor: '#00bf00ff',
                        borderWidth: 2,
                        borderRadius: 8,
                        barThickness: 40,
                        borderSkipped: false
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        },
                        tooltip: {
                            backgroundColor: 'rgba(0, 0, 0, 0.8)',
                            padding: 12,
                            titleFont: {
                                size: 13
                            },
                            bodyFont: {
                                size: 14
                            },
                            callbacks: {
                                label: function(context) {
                                    let label = context.dataset.label || '';
                                    if (label) {
                                        label += ': ';
                                    }
                                    label += new Intl.NumberFormat('vi-VN').format(context.parsed.y) + ' VNĐ';
                                    return label;
                                }
                            }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.05)',
                            drawBorder: false
                        },
                        ticks: {
                            callback: function(value) {
                                return new Intl.NumberFormat('vi-VN', { 
                                    notation: 'compact',
                                    compactDisplay: 'short'
                                }).format(value);
                            },
                            font: {
                                size: 11
                            },
                            color: '#666'
                        }
                    },
                    x: {
                        grid: {
                            display: false,
                            drawBorder: false
                        },
                        ticks: {
                            font: {
                                size: 11
                            },
                            color: '#666',
                            maxRotation: 45,
                            minRotation: 0
                        }
                    }
                }
            }
        });
        }