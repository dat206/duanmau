document.addEventListener('DOMContentLoaded', function () {
    const statusSelects = document.querySelectorAll('.status-select');

    statusSelects.forEach(select => {
        select.addEventListener('change', function () {
            const orderId = this.getAttribute('data-order-id');
            const newStatusId = this.value;
            const originalValue = this.querySelector('option[selected]').value;

            if (!confirm('Bạn có chắc chắn muốn thay đổi trạng thái đơn hàng này?')) {
                this.value = originalValue;
                return;
            }

            const formData = new FormData();
            formData.append('order_id', orderId);
            formData.append('status_id', newStatusId);

            fetch(BASE_URL + `admin/don-hang/${orderId}/cap-nhat-trang-thai`, {
                method: 'POST',
                headers: {
                    'Accept': 'application/json'
                },
                body: formData
            })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.success) {
                        alert('Cập nhật trạng thái thành công!');
                        location.reload();
                    } else {
                        alert('Lỗi: ' + (data.message || 'Không thể cập nhật trạng thái'));
                        this.value = originalValue;
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Có lỗi xảy ra khi cập nhật trạng thái');
                    this.value = originalValue;
                });
        });
    });
});