document.addEventListener('DOMContentLoaded', () => {
    const shippingMethods = window.checkoutData.shippingMethods;
    const subtotal = window.checkoutData.subtotal;
    let shippingFee = window.checkoutData.shippingFee;
    let voucherDiscount = window.checkoutData.voucherDiscount;

    const shippingList = document.getElementById('shippingOptionList');
    const shippingLabel = document.getElementById('shippingLabel');
    const shippingDesc = document.getElementById('shippingDesc');
    const shippingFeeText = document.getElementById('shippingFeeText');
    const changeShippingBtn = document.getElementById('changeShippingBtn');
    const applyShippingBtn = document.getElementById('applyShippingBtn');

    const voucherModal = document.getElementById('voucherModal');
    const openVoucherBtn = document.getElementById('openVoucherBtn');
    const closeVoucherModal = document.getElementById('closeVoucherModal');
    const voucherSelected = document.getElementById('voucherSelected');
    const voucherSelectedLabel = document.getElementById('voucherSelectedLabel');
    const removeVoucherBtn = document.getElementById('removeVoucherBtn');

    const shippingSummaryValue = document.getElementById('shippingSummaryValue');
    const voucherSummaryValue = document.getElementById('voucherSummaryValue');
    const grandTotalValue = document.getElementById('grandTotalValue');

    const shippingMethodInput = document.getElementById('shippingMethodInput');
    const shippingFeeInput = document.getElementById('shippingFeeInput');
    const voucherCodeInput = document.getElementById('voucherCodeInput');
    const voucherDiscountInput = document.getElementById('voucherDiscountInput');

    const paymentTabs = document.querySelectorAll('.payment-tab');
    const paymentInfo = document.querySelectorAll('.payment-info p');
    const paymentMethodInput = document.getElementById('paymentMethodInput');

    const addressPanel = document.getElementById('addressEditPanel');
    const toggleAddressEdit = document.getElementById('toggleAddressEdit');
    const cancelAddressEdit = document.getElementById('cancelAddressEdit');
    const saveAddressBtn = document.getElementById('saveAddressBtn');
    const displayRecipient = document.getElementById('displayRecipient');
    const displayPhone = document.getElementById('displayPhone');
    const displayAddress = document.getElementById('displayAddress');

    const hiddenFields = {
        name: document.getElementById('hiddenName'),
        phone: document.getElementById('hiddenPhone'),
        address: document.getElementById('hiddenAddress')
    };
    const inputs = {
        name: document.getElementById('inputName'),
        phone: document.getElementById('inputPhone'),
        address: document.getElementById('inputAddress')
    };

    function formatMoney(value) {
        return value.toLocaleString('vi-VN') + 'đ';
    }

    function updateTotals() {
        const total = Math.max(0, subtotal + shippingFee - voucherDiscount);
        shippingSummaryValue.textContent = formatMoney(shippingFee);
        voucherSummaryValue.textContent = '-' + formatMoney(voucherDiscount);
        grandTotalValue.textContent = formatMoney(total);
    }

    changeShippingBtn.addEventListener('click', () => {
        shippingList.classList.toggle('open');
    });

    shippingList.querySelectorAll('input[name="shipping_option_temp"]').forEach((input) => {
        input.addEventListener('change', () => {
            shippingList.querySelectorAll('.shipping-option').forEach((opt) => opt.classList.remove('active'));
            input.closest('.shipping-option').classList.add('active');
        });
    });

    applyShippingBtn.addEventListener('click', () => {
        const selectedInput = shippingList.querySelector('input[name="shipping_option_temp"]:checked');
        if (selectedInput) {
            const method = selectedInput.value;
            const label = selectedInput.dataset.label;
            const desc = selectedInput.dataset.desc;
            const fee = parseFloat(selectedInput.dataset.fee);

            shippingLabel.textContent = label;
            shippingDesc.textContent = desc;
            shippingFee = fee;
            shippingFeeText.textContent = formatMoney(shippingFee);

            shippingMethodInput.value = method;
            shippingFeeInput.value = shippingFee;

            shippingList.classList.remove('open');
            updateTotals();
            showToast('Đã cập nhật phương thức vận chuyển', 'success');
        }
    });

    openVoucherBtn.addEventListener('click', () => {
        voucherModal.classList.add('active');
    });

    closeVoucherModal.addEventListener('click', () => {
        voucherModal.classList.remove('active');
    });

    voucherModal.addEventListener('click', (e) => {
        if (e.target === voucherModal) {
            voucherModal.classList.remove('active');
        }
    });

    document.querySelectorAll('.btn-apply-voucher').forEach(btn => {
        btn.addEventListener('click', function () {
            const item = this.closest('.voucher-item');
            const code = item.dataset.code;
            const minSubtotal = parseFloat(item.dataset.min);

            if (subtotal < minSubtotal) {
                showToast(`Đơn hàng tối thiểu để dùng mã này là ${formatMoney(minSubtotal)}`, 'error');
                return;
            }

            fetch(BASE_URL + 'gio-hang/kiem-tra-voucher', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `code=${encodeURIComponent(code)}&subtotal=${subtotal}&shipping_fee=${shippingFee}`
            })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        voucherDiscount = parseFloat(data.discount);
                        voucherCodeInput.value = data.code;
                        voucherDiscountInput.value = voucherDiscount;

                        voucherSelectedLabel.textContent = `Đã áp dụng mã ${data.code} (-${formatMoney(voucherDiscount)})`;
                        voucherSelected.style.display = 'flex';

                        voucherModal.classList.remove('active');
                        updateTotals();
                        showToast('Áp dụng mã giảm giá thành công', 'success');
                    } else {
                        showToast(data.message || 'Mã giảm giá không hợp lệ', 'error');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    showToast('Có lỗi xảy ra khi kiểm tra mã', 'error');
                });
        });
    });

    removeVoucherBtn.addEventListener('click', function () {
        voucherDiscount = 0;
        voucherCodeInput.value = '';
        voucherDiscountInput.value = 0;
        voucherSelected.style.display = 'none';
        updateTotals();
        showToast('Đã xóa mã giảm giá', 'info');
    });

    paymentTabs.forEach((tab) => {
        tab.addEventListener('click', () => {
            paymentTabs.forEach((t) => t.classList.remove('active'));
            tab.classList.add('active');
            paymentMethodInput.value = tab.dataset.method;

            paymentInfo.forEach((info) => {
                info.classList.toggle('active', info.dataset.method === tab.dataset.method);
            });
        });
    });

    function syncAddressDisplay() {
        displayRecipient.textContent = inputs.name.value || 'Khách hàng Turtle';
        displayPhone.textContent = inputs.phone.value || '(+84) 000000000';
        displayAddress.textContent = inputs.address.value || 'Chưa có địa chỉ';

        hiddenFields.name.value = inputs.name.value;
        hiddenFields.phone.value = inputs.phone.value;
        hiddenFields.address.value = inputs.address.value;
    }

    toggleAddressEdit.addEventListener('click', () => {
        addressPanel.classList.toggle('open');
    });

    cancelAddressEdit.addEventListener('click', () => {
        addressPanel.classList.remove('open');
    });

    saveAddressBtn.addEventListener('click', () => {
        const name = inputs.name.value.trim();
        const phone = inputs.phone.value.trim();
        const address = inputs.address.value.trim();

        if (!name || !phone || !address) {
            showToast('Vui lòng điền đầy đủ thông tin', 'warning');
            return;
        }

        const formData = new FormData();
        formData.append('name', name);
        formData.append('phone', phone);
        formData.append('address', address);

        saveAddressBtn.textContent = 'Đang lưu...';
        saveAddressBtn.disabled = true;

        fetch(BASE_URL + 'gio-hang/luu-dia-chi', {
            method: 'POST',
            body: formData
        })
            .then(response => {
                return response.text().then(text => {
                    try {
                        return JSON.parse(text);
                    } catch (e) {
                        console.error('Invalid JSON:', text);
                        throw new Error('Server returned invalid JSON: ' + text.substring(0, 100) + '...');
                    }
                });
            })
            .then(data => {
                if (data.success) {
                    syncAddressDisplay();
                    addressPanel.classList.remove('open');
                    showToast('Lưu địa chỉ thành công!', 'success');
                } else {
                    let msg = data.message || 'Lỗi khi lưu địa chỉ';
                    if (data.debug) {
                        console.log('Debug info:', data.debug);
                        msg += '<br><small>Debug: ' + JSON.stringify(data.debug) + '</small>';
                    }
                    showToast(msg, 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showToast('Có lỗi xảy ra: ' + error.message, 'error');
            })
            .finally(() => {
                saveAddressBtn.textContent = 'Lưu';
                saveAddressBtn.disabled = false;
            });
    });

    updateTotals();

    document.getElementById('checkoutForm').addEventListener('submit', function (e) {
        const name = hiddenFields.name.value.trim();
        const phone = hiddenFields.phone.value.trim();
        const address = hiddenFields.address.value.trim();

        if (!name || !phone || !address) {
            e.preventDefault();
            let missingFields = [];
            if (!name) missingFields.push('Họ và tên');
            if (!phone) missingFields.push('Số điện thoại');
            if (!address) missingFields.push('Địa chỉ');

            showToast('Bạn chưa điền thông tin địa chỉ nhận hàng!<br>Vui lòng nhập: ' + missingFields.join(', '), 'error');
            addressPanel.classList.add('open');
            if (!name) inputs.name.focus();
            else if (!phone) inputs.phone.focus();
            else if (!address) inputs.address.focus();
            return false;
        }

        const phoneRegex = /^[0-9]{10,11}$/;
        if (!phoneRegex.test(phone)) {
            e.preventDefault();
            showToast('Số điện thoại không hợp lệ!<br>Vui lòng nhập 10-11 chữ số.', 'error');
            addressPanel.classList.add('open');
            inputs.phone.focus();
            return false;
        }
    });
});