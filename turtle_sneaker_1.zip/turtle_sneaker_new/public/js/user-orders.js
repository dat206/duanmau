function confirmReceived(orderId, button) {
        if (!confirm('Bạn đã nhận được hàng?')) {
            return;
        }
        button.disabled = true;
        button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Đang xử lý...';
        fetch('index.php?controller=user&action=confirmReceived', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'order_id=' + orderId
        })
        .then(response => response.text())
        .then(data => {
            button.outerHTML = `
                <a href="index.php?controller=user&action=orderDetail&id=${orderId}#reviews" class="btn-review">
                    <i class="fas fa-star"></i> Đánh giá
                </a>
            `;
            alert('Đã xác nhận nhận hàng thành công!');
            const orderCard = button.closest('.order-card');
            const statusBadge = orderCard.querySelector('.order-status');
            statusBadge.textContent = 'Đã hoàn thành';
            statusBadge.className = 'order-status status-7';
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Có lỗi xảy ra. Vui lòng thử lại.');
            button.disabled = false;
            button.innerHTML = '<i class="fas fa-check-circle"></i> Đã nhận hàng';
        });
    }