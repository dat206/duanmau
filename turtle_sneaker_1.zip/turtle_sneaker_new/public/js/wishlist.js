function removeFromWishlist(event, productId) {
    event.preventDefault();
    event.stopPropagation();

    if (!confirm('Bạn có chắc muốn xóa sản phẩm này khỏi danh sách yêu thích?')) {
        return;
    }
    const formData = new FormData();
    formData.append('product_id', productId);

    fetch(BASE_URL + 'yeu-thich/them', {
        method: 'POST',
        body: formData
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert(data.message || 'Có lỗi xảy ra');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Có lỗi xảy ra');
        });
}

function addToCart(event, productId) {
    event.preventDefault();
    event.stopPropagation();
    alert('Chức năng thêm vào giỏ hàng đang được phát triển');
}