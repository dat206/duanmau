function openReviewModal(productId, productName) {
        document.getElementById('modalProductId').value = productId;
        document.getElementById('modalProductName').textContent = productName;
        document.getElementById('reviewModal').style.display = "block";
    }

    function closeReviewModal() {
        document.getElementById('reviewModal').style.display = "none";
    }

    window.onclick = function(event) {
        var modal = document.getElementById('reviewModal');
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }