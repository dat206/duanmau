// Global function for inline onclick handler
function handleRemoveSelected() {
    console.log('handleRemoveSelected called!');
    const itemCheckboxes = document.querySelectorAll('.item-checkbox');
    const selectedItems = Array.from(itemCheckboxes)
        .filter(cb => cb.checked && !cb.disabled)
        .map(cb => cb.getAttribute('data-item-key'))
        .filter(key => key);

    console.log('Selected items to delete:', selectedItems);

    if (selectedItems.length === 0) {
        alert('Vui lòng chọn ít nhất một sản phẩm để xóa');
        return;
    }

    if (!confirm('Bạn có chắc muốn xóa ' + selectedItems.length + ' sản phẩm đã chọn?')) {
        return;
    }

    // Call removeMultipleItems
    console.log('Deleting items:', selectedItems);
    const formData = new FormData();
    selectedItems.forEach(key => {
        formData.append('item_keys[]', key);
    });

    for (let pair of formData.entries()) {
        console.log(pair[0] + ': ' + pair[1]);
    }

    console.log('Sending fetch request to gio-hang/xoa-nhieu');
    const url = BASE_URL + 'gio-hang/xoa-nhieu';
    console.log('Full URL:', url);
    fetch(url, {
        method: 'POST',
        body: formData
    })
        .then(response => {
            console.log('Response status:', response.status);
            console.log('Response redirected:', response.redirected);
            // Wait for response to complete before reloading
            return response.text();
        })
        .then(data => {
            console.log('Response data:', data);
            window.location.reload();
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Có lỗi xảy ra khi xóa sản phẩm');
        });
}

document.addEventListener('DOMContentLoaded', function () {
    const selectAllCheckbox = document.getElementById('select-all-checkbox');
    const selectAllFooter = document.getElementById('select-all-footer');
    const itemCheckboxes = document.querySelectorAll('.item-checkbox');
    const removeSelectedBtn = document.getElementById('remove-selected-btn');
    const checkoutFooterBtn = document.getElementById('checkout-footer-btn');

    function updateSelectedTotal() {
        let selectedCount = 0;
        let selectedSubtotal = 0;

        itemCheckboxes.forEach(function (checkbox) {
            if (checkbox.checked) {
                const row = checkbox.closest('.cart-item-row');
                const quantity = parseInt(row.querySelector('.qty-input').value) || 0;
                const price = parseFloat(row.getAttribute('data-price')) || 0;
                const total = quantity * price;

                selectedCount += quantity;
                selectedSubtotal += total;

                const totalElement = row.querySelector('.item-total');
                if (totalElement) {
                    totalElement.textContent = formatPrice(total);
                }
            }
        });

        const footerSelectedCountEl = document.getElementById('footer-selected-count');
        const footerSelectedTotalEl = document.getElementById('footer-selected-total');

        if (footerSelectedCountEl) footerSelectedCountEl.textContent = selectedCount;
        if (footerSelectedTotalEl) footerSelectedTotalEl.textContent = formatPrice(selectedSubtotal);

        const hasSelected = selectedCount > 0;
        if (checkoutFooterBtn) checkoutFooterBtn.disabled = !hasSelected;
    }

    function formatPrice(price) {
        return new Intl.NumberFormat('vi-VN').format(Math.round(price)) + 'đ';
    }

    function setupSelectAll(checkbox, targetCheckboxes) {
        checkbox.addEventListener('change', function () {
            targetCheckboxes.forEach(function (cb) {
                if (!cb.disabled) {
                    cb.checked = checkbox.checked;
                }
            });
            updateSelectedTotal();
        });
    }

    if (selectAllCheckbox) {
        setupSelectAll(selectAllCheckbox, itemCheckboxes);
    }

    if (selectAllFooter) {
        setupSelectAll(selectAllFooter, itemCheckboxes);
    }

    itemCheckboxes.forEach(function (checkbox) {
        checkbox.addEventListener('change', function () {
            const allChecked = Array.from(itemCheckboxes).every(cb => cb.checked);
            const someChecked = Array.from(itemCheckboxes).some(cb => cb.checked);

            if (selectAllCheckbox) {
                selectAllCheckbox.checked = allChecked;
                selectAllCheckbox.indeterminate = someChecked && !allChecked;
            }
            if (selectAllFooter) {
                selectAllFooter.checked = allChecked;
                selectAllFooter.indeterminate = someChecked && !allChecked;
            }

            updateSelectedTotal();
        });
    });

    document.querySelectorAll('.qty-increment, .qty-decrement').forEach(function (btn) {
        btn.addEventListener('click', function () {
            const itemKey = this.getAttribute('data-item-key');
            const isIncrement = this.classList.contains('qty-increment');
            const input = document.querySelector('.qty-input[data-item-key="' + itemKey + '"]');
            const currentQty = parseInt(input.value) || 1;
            const newQty = isIncrement ? currentQty + 1 : Math.max(1, currentQty - 1);

            updateQuantity(itemKey, newQty);
        });
    });

    function updateQuantity(itemKey, quantity) {
        const formData = new FormData();
        formData.append('item_key', itemKey);
        formData.append('quantity', quantity);

        fetch(BASE_URL + 'gio-hang/cap-nhat', {
            method: 'POST',
            body: formData
        })
            .then(response => {
                if (response.redirected) {
                    window.location.reload();
                } else {
                    return response.text();
                }
            })
            .then(() => {
                window.location.reload();
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Có lỗi xảy ra khi cập nhật số lượng');
            });
    }

    document.querySelectorAll('.remove-item-btn').forEach(function (btn) {
        btn.addEventListener('click', function () {
            if (!confirm('Bạn có chắc muốn xóa sản phẩm này?')) {
                return;
            }

            const itemKey = this.getAttribute('data-item-key');
            removeItem(itemKey);
        });
    });

    function removeItem(itemKey) {
        const formData = new FormData();
        formData.append('item_key', itemKey);

        fetch(BASE_URL + 'gio-hang/xoa', {
            method: 'POST',
            body: formData
        })
            .then(response => {
                if (response.redirected) {
                    window.location.reload();
                } else {
                    return response.text();
                }
            })
            .then(() => {
                window.location.reload();
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Có lỗi xảy ra khi xóa sản phẩm');
            });
    }

    // removeSelectedBtn now uses inline onclick handler (handleRemoveSelected function)

    if (checkoutFooterBtn) {
        checkoutFooterBtn.addEventListener('click', function () {
            if (this.disabled) {
                alert('Vui lòng chọn ít nhất một sản phẩm để tiếp tục đặt hàng.');
                return;
            }

            const selectedItems = Array.from(itemCheckboxes)
                .filter(cb => cb.checked && !cb.disabled)
                .map(cb => cb.getAttribute('data-item-key'))
                .filter(key => key);

            if (selectedItems.length === 0) {
                alert('Vui lòng chọn ít nhất một sản phẩm để tiếp tục đặt hàng.');
                return;
            }

            const formData = new FormData();
            selectedItems.forEach(key => {
                formData.append('selected_items[]', key);
            });

            fetch(BASE_URL + 'gio-hang/chon-san-pham', {
                method: 'POST',
                body: formData
            })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        window.location.href = BASE_URL + 'thanh-toan';
                    } else {
                        alert('Có lỗi xảy ra. Vui lòng thử lại.');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Có lỗi xảy ra. Vui lòng thử lại.');
                });
        });
    }

    function removeMultipleItems(itemKeys) {
        console.log('Deleting items:', itemKeys);
        const formData = new FormData();
        itemKeys.forEach(key => {
            formData.append('item_keys[]', key);
        });

        for (let pair of formData.entries()) {
            console.log(pair[0] + ': ' + pair[1]);
        }

        fetch(BASE_URL + 'gio-hang/xoa-nhieu', {
            method: 'POST',
            body: formData
        })
            .then(response => {
                console.log('Response status:', response.status);
                console.log('Response redirected:', response.redirected);
                window.location.reload();
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Có lỗi xảy ra khi xóa sản phẩm');
            });
    }

    updateSelectedTotal();
});