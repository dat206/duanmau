// User Edit Page - Avatar Preview and Form Validation
document.addEventListener('DOMContentLoaded', function() {
    // Avatar preview functionality
    const avatarInput = document.getElementById('avatar-input');
    if (avatarInput) {
        avatarInput.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const previewImg = document.getElementById('avatar-preview-img');
                    const defaultAvatar = document.getElementById('default-avatar-preview');
                    if (previewImg) {
                        previewImg.src = e.target.result;
                    } else if (defaultAvatar) {
                        defaultAvatar.outerHTML = '<img src="' + e.target.result + '" alt="Avatar" id="avatar-preview-img">';
                    }
                };
                reader.readAsDataURL(file);
            }
        });
    }

    // Form validation
    const profileEditForm = document.querySelector('.profile-edit-form');
    if (profileEditForm) {
        profileEditForm.addEventListener('submit', function(e) {
            const email = document.getElementById('email').value;
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

            if (!emailRegex.test(email)) {
                e.preventDefault();
                alert('Vui lòng nhập email hợp lệ.');
                return false;
            }
        });
    }
});
