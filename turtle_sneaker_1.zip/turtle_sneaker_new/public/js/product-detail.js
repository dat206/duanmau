document.addEventListener('DOMContentLoaded', function () {
    let selectedColor = '';
    let selectedSize = '';
    let currentPrice = window.productDetailData.basePriceRaw;
    const productId = window.productDetailData.productId;
    const basePrice = window.productDetailData.basePriceRaw;
    const priceElement = document.getElementById('product-price');

    function updatePrice() {
        if (!selectedColor || !selectedSize) {
            if (priceElement) {
                priceElement.textContent = basePrice.toLocaleString('vi-VN').replace(/,/g, '.') + '₫';
            }
            currentPrice = basePrice;
            return;
        }

        console.log('Updating price for:', selectedColor, selectedSize);
        const url = BASE_URL + `san-pham/gia?product_id=${productId}&color=${encodeURIComponent(selectedColor)}&size=${encodeURIComponent(selectedSize)}`;
        console.log('Fetching price from:', url);

        fetch(url)
            .then(response => response.json())
            .then(data => {
                if (data.success && data.price) {
                    currentPrice = parseFloat(data.price);
                    if (priceElement) {
                        priceElement.textContent = data.formatted_price || (currentPrice.toLocaleString('vi-VN').replace(/,/g, '.') + '₫');
                    }
                }
            })
            .catch(error => {
                console.error('Error fetching price:', error);
            });
    }

    document.querySelectorAll('.option-btn[data-option="color"]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            if (this.classList.contains('selected')) {
                this.classList.remove('selected');
                selectedColor = '';
            } else {
                document.querySelectorAll('.option-btn[data-option="color"]').forEach(function (b) {
                    b.classList.remove('selected');
                });
                this.classList.add('selected');
                selectedColor = this.dataset.value || '';
            }
            updatePrice();
        });
    });

    document.querySelectorAll('.option-btn[data-option="size"]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            if (this.classList.contains('selected')) {
                this.classList.remove('selected');
                selectedSize = '';
            } else {
                document.querySelectorAll('.option-btn[data-option="size"]').forEach(function (b) {
                    b.classList.remove('selected');
                });
                this.classList.add('selected');
                selectedSize = this.dataset.value || '';
            }
            updatePrice();
        });
    });

    document.querySelectorAll('.quantity-control').forEach(function (control) {
        const input = control.querySelector('input');
        control.querySelectorAll('button[data-action]').forEach(function (button) {
            button.addEventListener('click', function () {
                let value = parseInt(input.value, 10) || 1;
                const min = parseInt(input.min, 10) || 1;
                const max = parseInt(input.max, 10) || 999;

                if (button.dataset.action === 'increase' && value < max) {
                    value++;
                }

                if (button.dataset.action === 'decrease' && value > min) {
                    value--;
                }

                input.value = value;
            });
        });
    });

    const mainImage = document.querySelector('.main-image-wrapper img');
    document.querySelectorAll('.thumbnail-images img').forEach(function (thumb) {
        thumb.addEventListener('click', function () {
            document.querySelectorAll('.thumbnail-images img').forEach(function (img) {
                img.classList.remove('active');
            });
            thumb.classList.add('active');
            if (mainImage) {
                mainImage.src = thumb.src;
            }
        });
    });

    const addToCartBtn = document.getElementById('add-to-cart-btn');
    const buyNowBtn = document.getElementById('buy-now-btn');

    function buildCartPayload(targetBtn) {
        const productId = targetBtn.dataset.productId;
        const quantityInput = document.getElementById('quantity-input');
        const quantity = quantityInput ? parseInt(quantityInput.value, 10) || 1 : 1;

        if (!productId) {
            showNotification('Lỗi: Không tìm thấy sản phẩm', false);
            return null;
        }

        if (!selectedColor || !selectedSize) {
            let message = 'Vui lòng chọn ';
            if (!selectedColor && !selectedSize) {
                message += 'màu sắc và size';
            } else if (!selectedColor) {
                message += 'màu sắc';
            } else {
                message += 'size';
            }
            showNotification(message, false);
            return null;
        }

        const formData = new FormData();
        formData.append('product_id', productId);
        formData.append('quantity', quantity);
        formData.append('color', selectedColor);
        formData.append('size', selectedSize);
        formData.append('price', currentPrice);
        return formData;
    }

    function handleCartRequest(button, formData, endpoint, onSuccess) {
        const originalText = button.textContent;
        button.textContent = 'Đang xử lý...';
        button.style.pointerEvents = 'none';

        fetch(endpoint, {
            method: 'POST',
            body: formData
        })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    onSuccess(data);
                } else {
                    showNotification(data.message || 'Có lỗi xảy ra', false);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showNotification('Có lỗi xảy ra khi xử lý yêu cầu', false);
            })
            .finally(() => {
                button.textContent = originalText;
                button.style.pointerEvents = 'auto';
            });
    }

    if (addToCartBtn) {
        addToCartBtn.addEventListener('click', function (e) {
            e.preventDefault();
            const formData = buildCartPayload(this);
            if (!formData) {
                return;
            }

            handleCartRequest(this, formData, BASE_URL + 'gio-hang/them', (data) => {
                showNotification(data.message || 'Thêm thành công', true);
                updateCartBadge(data.cart_count || 0);
            });
        });
    }

    if (buyNowBtn) {
        buyNowBtn.addEventListener('click', function (e) {
            e.preventDefault();
            const formData = buildCartPayload(this);
            if (!formData) {
                return;
            }

            handleCartRequest(this, formData, BASE_URL + 'gio-hang/mua-ngay', (data) => {
                if (data.redirect) {
                    window.location.href = data.redirect;
                } else {
                    window.location.href = BASE_URL + 'thanh-toan?mode=buy_now';
                }
            });
        });
    }

    function showNotification(message, isSuccess) {
        const notification = document.getElementById('notification');
        const notificationText = document.getElementById('notification-text');

        if (notification && notificationText) {
            notificationText.textContent = message;
            notification.style.background = isSuccess ? '#4CAF50' : '#f44336';
            notification.style.display = 'block';

            setTimeout(function () {
                notification.style.display = 'none';
            }, 3000);
        }
    }
    function updateCartBadge(count) {
        const badge = document.getElementById('cart-badge');
        if (badge) {
            badge.textContent = count;
        }
    }
});