document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('couponForm');
    const codeInput = document.getElementById('couponCode');
    const discountType = document.getElementById('discountType');
    const discountAmount = document.getElementById('discountAmount');
    const minOrderValue = document.getElementById('minOrderValue');
    const quantity = document.getElementById('quantity');
    const expirationDate = document.getElementById('expirationDate');
    const isActive = document.getElementById('isActive');

    const codeCounter = document.getElementById('codeCounter');
    const codeValidation = document.getElementById('codeValidation');

    const previewCode = document.getElementById('previewCode');
    const previewDiscount = document.getElementById('previewDiscount');
    const previewMinOrder = document.getElementById('previewMinOrder');
    const previewQuantity = document.getElementById('previewQuantity');
    const previewExpiry = document.getElementById('previewExpiry');
    const previewStatus = document.getElementById('previewStatus');
    const discountHint = document.getElementById('discountHint');

    codeInput.addEventListener('input', function () {
        const length = this.value.length;
        if (codeCounter) {
            codeCounter.textContent = length;
        }

        previewCode.textContent = this.value || 'SUMMER2025';

        const validFormat = /^[A-Z0-9_]*$/;
        if (this.value && !validFormat.test(this.value.toUpperCase())) {
            codeValidation.className = 'validation-message error';
            codeValidation.innerHTML = '<i class="fas fa-exclamation-circle"></i> Chỉ sử dụng chữ cái, số và gạch dưới';
        } else {
            codeValidation.className = 'validation-message';
            codeValidation.innerHTML = '';
        }

        this.value = this.value.toUpperCase();
    });

    discountType.addEventListener('change', function () {
        updateDiscountHint();
        updatePreviewDiscount();
    });

    discountAmount.addEventListener('input', function () {
        updatePreviewDiscount();
    });

    function updateDiscountHint() {
        const type = discountType.value;
        if (type === 'amount') {
            discountHint.textContent = 'Nhập số tiền (VNĐ)';
            discountAmount.step = '1000';
            discountAmount.placeholder = '50000';
        } else if (type === 'percentage') {
            discountHint.textContent = 'Nhập phần trăm (0-1, VD: 0.1 = 10%)';
            discountAmount.step = '0.01';
            discountAmount.max = '1';
            discountAmount.placeholder = '0.1';
        } else if (type === 'shipping') {
            discountHint.textContent = 'Nhập số tiền giảm phí ship';
            discountAmount.step = '1000';
            discountAmount.placeholder = '30000';
        }
    }

    function updatePreviewDiscount() {
        const type = discountType.value;
        const amount = parseFloat(discountAmount.value) || 0;
        const valueSpan = previewDiscount.querySelector('.value');
        const unitSpan = previewDiscount.querySelector('.unit');

        if (type === 'amount') {
            valueSpan.textContent = amount.toLocaleString('vi-VN');
            unitSpan.textContent = '₫';
        } else if (type === 'percentage') {
            valueSpan.textContent = (amount * 100).toFixed(0);
            unitSpan.textContent = '%';
        } else if (type === 'shipping') {
            valueSpan.textContent = 'FREE';
            unitSpan.textContent = 'SHIP';
        }
    }

    minOrderValue.addEventListener('input', function () {
        const value = parseFloat(this.value) || 0;
        previewMinOrder.textContent = value.toLocaleString('vi-VN') + '₫';
    });

    quantity.addEventListener('input', function () {
        previewQuantity.textContent = this.value || '0';
    });

    expirationDate.addEventListener('change', function () {
        if (this.value) {
            const date = new Date(this.value);
            const formatted = date.toLocaleDateString('vi-VN', {
                day: '2-digit',
                month: '2-digit',
                year: 'numeric'
            });
            previewExpiry.textContent = formatted;
        } else {
            previewExpiry.textContent = '--/--/----';
        }
    });

    isActive.addEventListener('change', function () {
        if (this.checked) {
            previewStatus.className = 'status-indicator active';
            previewStatus.innerHTML = '<i class="fas fa-check-circle"></i> Đang hoạt động';
        } else {
            previewStatus.className = 'status-indicator inactive';
            previewStatus.innerHTML = '<i class="fas fa-times-circle"></i> Chưa kích hoạt';
        }
    });

    form.addEventListener('submit', function (e) {
        const code = codeInput.value.trim();

        const validFormat = /^[A-Z0-9_]+$/;
        if (!validFormat.test(code)) {
            e.preventDefault();
            codeValidation.className = 'validation-message error';
            codeValidation.innerHTML = '<i class="fas fa-exclamation-circle"></i> Mã không hợp lệ! Chỉ sử dụng chữ cái, số và gạch dưới';
            codeInput.focus();
            return false;
        }

        if (discountType.value === 'percentage') {
            const amount = parseFloat(discountAmount.value);
            if (amount < 0 || amount > 1) {
                e.preventDefault();
                alert('Giá trị phần trăm phải từ 0 đến 1 (VD: 0.1 = 10%)');
                discountAmount.focus();
                return false;
            }
        }

        const expiry = new Date(expirationDate.value);
        const now = new Date();
        if (expiry <= now) {
            e.preventDefault();
            alert('Ngày hết hạn phải sau thời điểm hiện tại!');
            expirationDate.focus();
            return false;
        }
    });

    const previewBadge = document.getElementById('previewBadge');
    if (previewBadge) {
        previewBadge.textContent = 'MỚI';
    }

    updateDiscountHint();
    updatePreviewDiscount();
});
