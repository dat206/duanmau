let slideIndex = 1;
const slides = document.querySelectorAll('.slider-wrapper .slide');
const dots = document.querySelectorAll('.slider-dots .dot');
let slideInterval;

function showSlides(n) {
    if (n > slides.length) slideIndex = 1;
    if (n < 1) slideIndex = slides.length;

    slides.forEach(slide => slide.classList.remove('active'));
    dots.forEach(dot => dot.classList.remove('active'));

    if (slides[slideIndex - 1]) {
        slides[slideIndex - 1].classList.add('active');
    }
    if (dots[slideIndex - 1]) {
        dots[slideIndex - 1].classList.add('active');
    }
}

function moveSlide(n) {
    clearInterval(slideInterval);
    showSlides(slideIndex += n);
    startAutoSlide();
}

function currentSlide(n) {
    clearInterval(slideInterval);
    showSlides(slideIndex = n);
    startAutoSlide();
}

function startAutoSlide() {
    slideInterval = setInterval(() => {
        showSlides(slideIndex += 1);
    }, 4000);
}

if (slides.length > 0) {
    showSlides(slideIndex);
    startAutoSlide();
}

const sliderStates = {};

function navigateSlider(sliderId, direction) {
    const slider = document.getElementById(sliderId);
    if (!slider) return;

    const track = slider.querySelector('.product-slider-track');
    const items = track.querySelectorAll('.slider-item');

    if (items.length === 0) return;

    if (!sliderStates[sliderId]) {
        sliderStates[sliderId] = { index: 0, interval: null };
    }

    const state = sliderStates[sliderId];
    let itemsPerView = 4;

    if (window.innerWidth <= 480) itemsPerView = 1;
    else if (window.innerWidth <= 768) itemsPerView = 2;
    else if (window.innerWidth <= 992) itemsPerView = 3;

    state.index += direction;

    if (state.index < 0) state.index = 0;
    if (state.index > items.length - itemsPerView) {
        state.index = items.length - itemsPerView;
    }

    const item = items[0];
    if (item) {
        const itemWidth = item.offsetWidth + 24;
        track.style.transform = `translateX(-${state.index * itemWidth}px)`;
    }

    if (state.interval) {
        clearInterval(state.interval);
        state.interval = null;
    }
}

let currentCategory = 'Giày Sneaker';

function filterByCategory(category) {
    currentCategory = category;

    const buttons = document.querySelectorAll('.category-btn');
    buttons.forEach(btn => {
        if (btn.getAttribute('data-category') === category) {
            btn.classList.add('active');
        } else {
            btn.classList.remove('active');
        }
    });

    fetch(`/turtle_sneaker_new/api/san-pham/danh-muc?category=${encodeURIComponent(category)}`)
        .then(response => response.json())
        .then(data => {
            if (data.success && data.products) {
                updateSneakerSlider(data.products);
            }
        })
        .catch(error => {
            console.error('Error fetching products:', error);
        });
}

function updateSneakerSlider(products) {
    const slider = document.getElementById('sneaker-products-slider');
    if (!slider) return;

    const track = slider.querySelector('.product-slider-track');
    if (!track) return;

    track.innerHTML = '';

    if (sliderStates['sneaker-products-slider']) {
        sliderStates['sneaker-products-slider'].index = 0;
        track.style.transform = 'translateX(0)';
    }

    products.forEach(product => {
        const image = product.main_image || 'https://placehold.co/400x400?text=No+Image';
        const categoryName = product.category_name || 'Chưa rõ';

        const productHTML = `
                <a class="product-card-link slider-item" href="index.php?controller=product&action=detail&id=${product.id}">
                    <div class="product-card-v2">
                        <div class="product-card-image">
                            <img src="${image}" alt="${product.name}">
                            <button class="product-wishlist-btn" onclick="toggleWishlist(event, ${product.id})" title="Thêm vào yêu thích">
                                <i class='bx bx-heart'></i>
                            </button>
                        </div>
                        <div class="product-card-body">
                            <div class="product-card-meta">
                                <span class="product-chip">${categoryName}</span>
                            </div>
                            <h3>${product.name}</h3>
                            <p class="price">${Number(product.price).toLocaleString('vi-VN')}đ</p>
                        </div>
                    </div>
                </a>
            `;

        track.insertAdjacentHTML('beforeend', productHTML);
    });
}

document.addEventListener('DOMContentLoaded', function () {
    function initSlider(sliderId) {
        const slider = document.getElementById(sliderId);
        if (!slider) return;

        const track = slider.querySelector('.product-slider-track');
        let items = track.querySelectorAll('.slider-item');

        if (items.length === 0) return;

        sliderStates[sliderId] = { index: 0, interval: null };
        const state = sliderStates[sliderId];

        const totalItems = items.length;
        let itemsPerView = 4;

        function updateItemsPerView() {
            if (window.innerWidth <= 480) itemsPerView = 1;
            else if (window.innerWidth <= 768) itemsPerView = 2;
            else if (window.innerWidth <= 992) itemsPerView = 3;
            else itemsPerView = 4;
        }
        updateItemsPerView();
        window.addEventListener('resize', updateItemsPerView);

        function startSliding() {
            if (state.interval) clearInterval(state.interval);
            state.interval = setInterval(() => {
                items = track.querySelectorAll('.slider-item');
                if (items.length <= itemsPerView) return;

                state.index++;
                if (state.index > items.length - itemsPerView) {
                    state.index = 0;
                }

                const item = track.querySelector('.slider-item');
                if (item) {
                    const currentItemWidth = item.offsetWidth + 24;
                    track.style.transform = `translateX(-${state.index * currentItemWidth}px)`;
                }
            }, 3000);
        }

        function stopSliding() {
            if (state.interval) {
                clearInterval(state.interval);
                state.interval = null;
            }
        }

        slider.addEventListener('mouseenter', stopSliding);
        slider.addEventListener('mouseleave', startSliding);

        startSliding();
    }

    initSlider('hot-products-slider');
    initSlider('sneaker-products-slider');
});