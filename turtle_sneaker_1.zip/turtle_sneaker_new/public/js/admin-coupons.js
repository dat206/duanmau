document.getElementById('discountType').addEventListener('change', function() {
    const hint = document.getElementById('discountHint');
    if (this.value === 'percentage') {
        hint.textContent = 'Nhập số thập phân (VD: 0.1 cho 10%)';
    } else {
        hint.textContent = 'Nhập số tiền (VNĐ)';
    }
});