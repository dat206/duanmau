function toggleWishlist(event, productId) {
    // Prevent default and stop propagation to parent link
    event.preventDefault();
    event.stopPropagation();

    const button = event.currentTarget;
    const icon = button.querySelector('i');

    const formData = new FormData();
    formData.append('product_id', productId);

    fetch('index.php?controller=user&action=toggleWishlist', {
        method: 'POST',
        body: formData
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                button.classList.toggle('active');

                if (data.action === 'added') {
                    icon.className = 'bx bxs-heart';
                } else {
                    icon.className = 'bx bx-heart';
                }

                const wishlistBadge = document.querySelector('.wishlist-badge');
                if (wishlistBadge) {
                    if (data.wishlist_count > 0) {
                        wishlistBadge.textContent = data.wishlist_count;
                        wishlistBadge.style.display = 'flex';
                    } else {
                        wishlistBadge.style.display = 'none';
                    }
                }
            } else {
                // If not logged in, redirect to login
                if (data.message && data.message.includes('đăng nhập')) {
                    alert('Vui lòng đăng nhập để sử dụng tính năng yêu thích!');
                    window.location.href = 'index.php?controller=auth&action=login';
                } else {
                    alert(data.message || 'Có lỗi xảy ra');
                }
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Có lỗi xảy ra khi thêm vào yêu thích');
        });
}