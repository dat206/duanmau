<?php
/**
 * URL Helper Functions
 * Helper functions for generating URLs
 */

/**
 * Generate full URL
 * @param string $path
 * @return string
 */
function url($path = '')
{
    $basePath = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/');
    $path = ltrim($path, '/');
    
    $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'];
    
    return $protocol . '://' . $host . $basePath . '/' . $path;
}

/**
 * Generate URL from route name
 * @param string $name
 * @param array $params
 * @return string
 */
function route($name, $params = [])
{
    $route = Route::getRouteByName($name);
    
    if (!$route) {
        return url('/');
    }
    
    $uri = $route['uri'];
    
    // Replace parameters in URI
    foreach ($params as $key => $value) {
        $uri = str_replace('{' . $key . '}', $value, $uri);
        $uri = str_replace('{' . $key . '?}', $value, $uri);
    }
    
    // Remove optional parameters that weren't provided
    $uri = preg_replace('/\{[a-zA-Z0-9_]+\?\}/', '', $uri);
    
    return url($uri);
}

/**
 * Redirect to URL
 * @param string $url
 * @param int $statusCode
 */
function redirect($url, $statusCode = 302)
{
    // If URL doesn't start with http, treat as path
    if (!preg_match('/^https?:\/\//', $url)) {
        $url = url($url);
    }
    
    header('Location: ' . $url, true, $statusCode);
    exit;
}

/**
 * Redirect back to previous page
 */
function back()
{
    $previous = Request::previous();
    redirect($previous);
}

/**
 * Generate asset URL
 * @param string $path
 * @return string
 */
function asset($path)
{
    $path = ltrim($path, '/');
    
    // Get base path from SCRIPT_NAME but handle .htaccess rewriting
    $scriptName = $_SERVER['SCRIPT_NAME'];
    $basePath = str_replace('/index.php', '', dirname($scriptName));
    $basePath = rtrim($basePath, '/');
    
    $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'];
    
    return $protocol . '://' . $host . $basePath . '/public/' . $path;
}

/**
 * Get current URL
 * @return string
 */
function current_url()
{
    return url(Request::uri());
}

/**
 * Check if current route matches
 * @param string $routeName
 * @return bool
 */
function is_route($routeName)
{
    $currentUri = Request::uri();
    $route = Route::getRouteByName($routeName);
    
    if (!$route) {
        return false;
    }
    
    return $currentUri === $route['uri'];
}

/**
 * Get active class if route matches
 * @param string $routeName
 * @param string $class
 * @return string
 */
function active_class($routeName, $class = 'active')
{
    return is_route($routeName) ? $class : '';
}
