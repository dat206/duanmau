<?php
class PaymentModel extends BaseModel 
{
 
    public function createPayment(int $orderId, string $method, string $status = 'Pending'): int 
    {
        $id = $this->generateUniqueId('payments');
        $sql = "INSERT INTO payments (id, order_id, method, status, paid_at) VALUES (?, ?, ?, ?, NULL)";
        $ok = $this->execute($sql, [$id, $orderId, $method, $status]);
        return $ok ? $id : 0;
    }

    public function markPaid(int $orderId): bool
    {
        $sql = "UPDATE payments SET status = 'Paid', paid_at = NOW() WHERE order_id = ?";
        $result = $this->execute($sql, [$orderId]);
        
        if ($result) { 
            $updateOrderSql = "UPDATE orders SET current_status_id = 2 WHERE id = ? AND current_status_id = 1";
            $this->execute($updateOrderSql, [$orderId]);
        }
        
        return $result;
    }

    public function getByOrderId(int $orderId): ?array 
    { 
        $sql = "SELECT * FROM payments WHERE order_id = ? LIMIT 1"; 
        return $this->fetchOne($sql, [$orderId]); 
    }

    public function getById(int $id): ?array  
    { 
        $sql = "SELECT * FROM payments WHERE id = ? LIMIT 1"; 
        return $this->fetchOne($sql, [$id]);  
    }

    private function generateUniqueId(string $table): int 
    { 
        $maxAttempts = 5; 
        for ($attempt = 0; $attempt < $maxAttempts; $attempt++) {
            $candidate = random_int(1, 2000000000);
            $exists = $this->fetchValue("SELECT 1 FROM {$table} WHERE id = ? LIMIT 1", [$candidate]);
            if (!$exists) {
                return $candidate;
            }
        } 

        $row = $this->fetchOne("SELECT IFNULL(MAX(id), 0) + 1 AS next_id FROM {$table}");
        return (int)($row['next_id'] ?? 1);
    }
}