<?php
class CartModel extends BaseModel
{
    protected string $table = 'cart_items';

    public function __construct(mysqli $conn)
    {
        parent::__construct($conn);
    }

    public function getCartItems(int $userId): array
    {
        $sql = "
            SELECT 
                ci.id as cart_item_id,
                ci.product_id,
                ci.color,
                ci.size,
                ci.quantity,
                s.name,
                s.product_code,
                sv.price,
                sv.main_image,
                c.name as category_name,
                CASE WHEN s.deleted_at IS NOT NULL THEN 1 ELSE 0 END as is_deleted
            FROM {$this->table} ci
            JOIN shoes s ON s.id = ci.product_id
            LEFT JOIN categories c ON c.id = s.category_id
            LEFT JOIN shoe_variants sv ON sv.shoe_id = s.id
            WHERE ci.user_id = ?
            ORDER BY ci.created_at DESC
        ";
        $items = $this->fetchAll($sql, [$userId]);
        return $items;
    }

    public function addItem(int $userId, int $productId, int $quantity, string $color = '', string $size = ''): bool
    {
        $existing = $this->getItem($userId, $productId, $color, $size);
        if ($existing) {
            $newQuantity = $existing['quantity'] + $quantity;
            return $this->updateQuantity($userId, $productId, $color, $size, $newQuantity);
        } else {
            $sql = "INSERT INTO {$this->table} (user_id, product_id, color, size, quantity) VALUES (?, ?, ?, ?, ?)";
            return $this->execute($sql, [$userId, $productId, $color, $size, $quantity]);
        }
    }

    public function getItem(int $userId, int $productId, string $color = '', string $size = ''): ?array
    {
        $sql = "SELECT * FROM {$this->table} WHERE user_id = ? AND product_id = ? AND color = ? AND size = ? LIMIT 1";
        return $this->fetchOne($sql, [$userId, $productId, $color, $size]);
    }

    public function updateQuantity(int $userId, int $productId, string $color, string $size, int $quantity): bool
    {
        if ($quantity <= 0) {
            return $this->removeItem($userId, $productId, $color, $size);
        }

        $sql = "UPDATE {$this->table} SET quantity = ?, updated_at = NOW() WHERE user_id = ? AND product_id = ? AND color = ? AND size = ?";
        return $this->execute($sql, [$quantity, $userId, $productId, $color, $size]);
    }

    public function removeItem(int $userId, int $productId, string $color = '', string $size = ''): bool
    {
        $sql = "DELETE FROM {$this->table} WHERE user_id = ? AND product_id = ? AND color = ? AND size = ?";
        return $this->execute($sql, [$userId, $productId, $color, $size]);
    }

    public function removeItemById(int $cartItemId, int $userId): bool
    {
        $sql = "DELETE FROM {$this->table} WHERE id = ? AND user_id = ?";
        return $this->execute($sql, [$cartItemId, $userId]);
    }

    public function clearCart(int $userId): bool
    {
        $sql = "DELETE FROM {$this->table} WHERE user_id = ?";
        return $this->execute($sql, [$userId]);
    }

    public function getCartCount(int $userId): int
    {
        $sql = "SELECT SUM(quantity) as total FROM {$this->table} WHERE user_id = ?";
        $result = $this->fetchOne($sql, [$userId]);
        return (int)($result['total'] ?? 0);
    }

    public function mergeSessionCart(int $userId, array $sessionCart): bool
    {
        if (empty($sessionCart)) {
            return true;
        }
        foreach ($sessionCart as $item) {
            $productId = $item['product_id'] ?? 0;
            $quantity = $item['quantity'] ?? 1;
            $color = $item['color'] ?? '';
            $size = $item['size'] ?? '';

            if ($productId > 0) {
                $this->addItem($userId, $productId, $quantity, $color, $size);
            }
        }
        return true;
    }

    public function toSessionFormat(array $dbCartItems): array
    {
        $sessionCart = [];
        foreach ($dbCartItems as $item) {
            $key = $item['product_id'] . '_' . md5(($item['color'] ?? '') . '_' . ($item['size'] ?? ''));
            $sessionCart[$key] = [
                'product_id' => $item['product_id'],
                'name' => $item['name'],
                'category' => $item['category_name'] ?? '',
                'price' => $item['price'],
                'image' => $item['main_image'],
                'quantity' => $item['quantity'],
                'color' => $item['color'] ?? '',
                'size' => $item['size'] ?? '',
                'is_deleted' => $item['is_deleted'] ?? 0
            ];
        }
        return $sessionCart;
    }
}
