<?php
class ProductModel extends BaseModel
{
    protected string $table = 'shoes';
    public function __construct(mysqli $conn)
    {
        parent::__construct($conn);
    }

    public function getHomeHighlightProducts(int $limit = 8): array
    {
        $sql = "
            SELECT s.id, s.name, s.product_code, s.category_id,
                   c.name AS category_name, sv.price, sv.market_price, sv.main_image
            FROM {$this->table} s
            JOIN categories c ON c.id = s.category_id
            JOIN shoe_variants sv ON sv.shoe_id = s.id
            WHERE s.deleted_at IS NULL
            ORDER BY s.created_at DESC
            LIMIT ?
        ";
        return $this->fetchAll($sql, [$limit]);
    }

    public function getHeroProducts(int $limit = 4): array
    {
        return $this->getHomeHighlightProducts($limit);
    }

    public function getHotProducts(int $limit = 8): array
    {
        $sql = "
            SELECT s.id, s.name, s.product_code, s.category_id,
                   c.name AS category_name, 
                   MIN(sv.price) AS price, 
                   MIN(sv.market_price) AS market_price, 
                   (SELECT sv2.main_image FROM shoe_variants sv2 WHERE sv2.shoe_id = s.id LIMIT 1) AS main_image,
                   COALESCE(SUM(oi.quantity), 0) AS sold_count
            FROM {$this->table} s
            JOIN categories c ON c.id = s.category_id
            JOIN shoe_variants sv ON sv.shoe_id = s.id
            LEFT JOIN order_items oi ON oi.shoe_variant_id = sv.id
            WHERE s.deleted_at IS NULL
            GROUP BY s.id, s.name, s.product_code, s.category_id, c.name
            HAVING sold_count > 0
            ORDER BY sold_count DESC
            LIMIT ?
        ";
        return $this->fetchAll($sql, [$limit]);
    }

    public function getProductsByCategoryName(string $categoryName, int $limit = 8): array
    {
        $sql = "
            SELECT s.id, s.name, s.product_code, s.category_id,
                   c.name AS category_name, 
                   MIN(sv.price) AS price, 
                   MIN(sv.market_price) AS market_price, 
                   (SELECT sv2.main_image FROM shoe_variants sv2 WHERE sv2.shoe_id = s.id LIMIT 1) AS main_image,
                   COALESCE(SUM(oi.quantity), 0) AS sold_count
            FROM {$this->table} s
            JOIN categories c ON c.id = s.category_id
            JOIN shoe_variants sv ON sv.shoe_id = s.id
            LEFT JOIN order_items oi ON oi.shoe_variant_id = sv.id
            WHERE c.name = ?
            GROUP BY s.id, s.name, s.product_code, s.category_id, c.name
            ORDER BY s.created_at DESC
            LIMIT ?
        ";
        return $this->fetchAll($sql, [$categoryName, $limit]);
    }

    public function getProductsByCategory(string $categoryName, int $limit = 8): array
    {
        return $this->getProductsByCategoryName($categoryName, $limit);
    }

    public function getCategories(): array
    {
        $sql = "SELECT id, name, description FROM categories ORDER BY id ASC";
        return $this->fetchAll($sql);
    }

    public function getProductsPaginated(int $limit, int $offset): array
    {
        $sql = "
            SELECT DISTINCT s.id, s.name, s.product_code, s.category_id,
                   c.name AS category_name, 
                   (SELECT sv2.price FROM shoe_variants sv2 WHERE sv2.shoe_id = s.id ORDER BY sv2.price ASC LIMIT 1) as price,
                   (SELECT sv2.market_price FROM shoe_variants sv2 WHERE sv2.shoe_id = s.id ORDER BY sv2.price ASC LIMIT 1) as market_price,
                   (SELECT sv2.main_image FROM shoe_variants sv2 WHERE sv2.shoe_id = s.id LIMIT 1) as main_image,
                   (SELECT COALESCE(SUM(oi.quantity), 0) FROM order_items oi JOIN shoe_variants sv2 ON oi.shoe_variant_id = sv2.id WHERE sv2.shoe_id = s.id) as sold_count
            FROM {$this->table} s
            JOIN categories c ON c.id = s.category_id
            WHERE s.deleted_at IS NULL AND EXISTS (SELECT 1 FROM shoe_variants sv WHERE sv.shoe_id = s.id)
            ORDER BY s.created_at DESC
            LIMIT ?, ?
        ";
        return $this->fetchAll($sql, [$offset, $limit]);
    }

    public function getProductsByCategoryPaginated(int $categoryId, int $limit, int $offset): array
    {
        $sql = "
            SELECT DISTINCT s.id, s.name, s.product_code, s.category_id,
                   c.name AS category_name,
                   (SELECT sv2.price FROM shoe_variants sv2 WHERE sv2.shoe_id = s.id ORDER BY sv2.price ASC LIMIT 1) as price,
                   (SELECT sv2.market_price FROM shoe_variants sv2 WHERE sv2.shoe_id = s.id ORDER BY sv2.price ASC LIMIT 1) as market_price,
                   (SELECT sv2.main_image FROM shoe_variants sv2 WHERE sv2.shoe_id = s.id LIMIT 1) as main_image,
                   (SELECT COALESCE(SUM(oi.quantity), 0) FROM order_items oi JOIN shoe_variants sv2 ON oi.shoe_variant_id = sv2.id WHERE sv2.shoe_id = s.id) as sold_count
            FROM {$this->table} s
            JOIN categories c ON c.id = s.category_id
            WHERE s.category_id = ? 
            AND EXISTS (SELECT 1 FROM shoe_variants sv WHERE sv.shoe_id = s.id)
            ORDER BY s.created_at DESC
            LIMIT ?, ?
        ";
        return $this->fetchAll($sql, [$categoryId, $offset, $limit]);
    }

    public function countAllProducts(): int
    {
        $sql = "SELECT COUNT(DISTINCT s.id) AS total 
                FROM {$this->table} s
                WHERE EXISTS (SELECT 1 FROM shoe_variants sv WHERE sv.shoe_id = s.id)";
        $result = $this->fetchOne($sql);
        return (int)($result['total'] ?? 0);
    }

    public function countProductsByCategory(int $categoryId): int
    {
        $sql = "SELECT COUNT(DISTINCT s.id) AS total 
                FROM {$this->table} s
                WHERE s.category_id = ? 
                AND EXISTS (SELECT 1 FROM shoe_variants sv WHERE sv.shoe_id = s.id)";
        $result = $this->fetchOne($sql, [$categoryId]);
        return (int)($result['total'] ?? 0);
    }

    public function getCategoryById(int $categoryId): ?array
    {
        $sql = "SELECT id, name, description FROM categories WHERE id = ? LIMIT 1";
        return $this->fetchOne($sql, [$categoryId]);
    }

    public function getProductDetail(int $id): ?array
    {
        $sql = "
            SELECT s.id, s.name, s.description, s.product_code, s.category_id,
                   c.name AS category_name, sv.id AS variant_id,
                   sv.price, sv.main_image
            FROM {$this->table} s
            JOIN categories c ON c.id = s.category_id
            JOIN shoe_variants sv ON sv.shoe_id = s.id
            WHERE s.id = ?
            LIMIT 1
        ";
        return $this->fetchOne($sql, [$id]);
    }

    public function getVariantOptions(int $shoeId): array
    {
        $sql = "
            SELECT a.name AS attribute_name, av.value
            FROM shoe_variants sv
            JOIN shoe_variant_attribute_map map ON map.variant_id = sv.id
            JOIN shoe_attribute_values av ON av.value_id = map.value_id
            JOIN shoe_attributes a ON a.attribute_id = av.attribute_id
            WHERE sv.shoe_id = ?
            ORDER BY a.attribute_id, av.value
        ";
        $rows = $this->fetchAll($sql, [$shoeId]);
        $options = [
            'sizes' => [],
            'colors' => [],
            'other' => [],
        ];

        foreach ($rows as $row) {
            $attribute = strtolower($row['attribute_name']);
            if (str_contains($attribute, 'kích') || str_contains($attribute, 'size')) {
                $options['sizes'][] = $row['value'];
            } elseif (str_contains($attribute, 'màu')) {
                $options['colors'][] = $row['value'];
            } else {
                $options['other'][] = $row['value'];
            }
        }

        $options['sizes'] = array_values(array_unique($options['sizes']));
        $options['colors'] = array_values(array_unique($options['colors']));
        $options['other'] = array_values(array_unique($options['other']));

        return $options;
    }

    public function getProductImages(int $shoeId): array
    {
        $sql = "
            SELECT si.image_url
            FROM shoe_images si
            JOIN shoe_variants sv ON sv.id = si.shoe_variant_id
            WHERE sv.shoe_id = ?
            ORDER BY si.id ASC
        ";
        return $this->fetchAll($sql, [$shoeId]);
    }

    public function getImagesForProductIds(array $shoeIds): array
    {
        if (empty($shoeIds)) {
            return [];
        }

        $placeholders = implode(',', array_fill(0, count($shoeIds), '?'));
        $sql = "
            SELECT sv.shoe_id AS product_id, si.image_url
            FROM shoe_images si
            JOIN shoe_variants sv ON sv.id = si.shoe_variant_id
            WHERE sv.shoe_id IN ($placeholders)
            ORDER BY sv.shoe_id ASC, si.id ASC
        ";

        return $this->fetchAll($sql, $shoeIds);
    }

    public function getRelatedProducts(int $categoryId, int $excludeId, int $limit = 4): array
    {
        $sql = "
            SELECT s.id, s.name, sv.price, sv.main_image
            FROM {$this->table} s
            LEFT JOIN shoe_variants sv ON sv.id = ( 
                SELECT MIN(id) FROM shoe_variants WHERE shoe_id = s.id LIMIT 1
            ) 
            WHERE s.category_id = ? AND s.id <> ? AND s.deleted_at IS NULL
            ORDER BY s.created_at DESC
            LIMIT ?
        "; 
        return $this->fetchAll($sql, [$categoryId, $excludeId, $limit]);
    }

    public function getProductReviews(int $shoeId): array
    {
        $sql = " 
            SELECT r.id, r.rating, r.comment, r.created_at, u.name AS user_name
            FROM reviews r
            JOIN users u ON u.id = r.user_id
            WHERE r.shoe_id = ? AND r.status = 'approved'
            ORDER BY r.created_at DESC
        ";
        return $this->fetchAll($sql, [$shoeId]);
    } 
 
    public function getAllProducts(): array 
    { 
        $sql = "
            SELECT s.id, s.name, s.product_code, s.category_id, 
                   c.name AS category_name, sv.price, sv.market_price, sv.main_image 
            FROM {$this->table} s
            JOIN categories c ON c.id = s.category_id
            LEFT JOIN shoe_variants sv ON sv.id = (
                SELECT MIN(id) FROM shoe_variants WHERE shoe_id = s.id LIMIT 1 
            ) 
            WHERE s.deleted_at IS NULL 
            ORDER BY s.created_at DESC 
        ";
        return $this->fetchAll($sql);
    } 

    public function getProductById(int $id): ?array
    {
        $sql = "
            SELECT s.*, c.name AS category_name, sv.price, sv.market_price, sv.main_image 
            FROM {$this->table} s  
            LEFT JOIN categories c ON c.id = s.category_id 
            LEFT JOIN shoe_variants sv ON sv.shoe_id = s.id 
            WHERE s.id = ? AND s.deleted_at IS NULL 
            LIMIT 1 
        ";
        return $this->fetchOne($sql, [$id]);
    } 

    public function createProduct(array $data): int
    {
        // Create base product
        $sql = "INSERT INTO {$this->table} (name, product_code, category_id, description, created_at, updated_at) VALUES (?, ?, ?, ?, NOW(), NOW())";
        $this->execute($sql, [
            $data['name'],
            $data['product_code'], 
            $data['category_id'], 
            $data['description'] 
        ]);
        $shoeId = $this->conn->insert_id;
 
        $colors = $data['colors'] ?? []; 
        $sizes = $data['sizes'] ?? [];
        $price = $data['price']; 
        $mainImage = $data['main_image']; 

        // If no colors or sizes specified, create one default variant
        if (empty($colors) && empty($sizes)) { 
            $sku = $data['product_code'] . '-01';
            $sqlVariant = "INSERT INTO shoe_variants (shoe_id, sku, price, main_image) VALUES (?, ?, ?, ?)";
            $this->execute($sqlVariant, [$shoeId, $sku, $price, $mainImage]);
            return $shoeId;
        }

        // Get or create color attributes 
        $colorIds = []; 
        foreach ($colors as $colorName) {
            $colorId = $this->getOrCreateAttribute('Màu sắc', $colorName);
            $colorIds[] = $colorId;
        }

        // Get size attribute IDs
        $sizeIds = [];
        foreach ($sizes as $sizeValue) { 
            $sizeId = $this->getSizeAttributeId($sizeValue); 
            if ($sizeId) {
                $sizeIds[] = $sizeId; 
            }
        }

        // Create variants for each color × size combination
        $variantCounter = 1;
        
        if (!empty($colorIds) && !empty($sizeIds)) {
            // Both colors and sizes: create color × size combinations
            foreach ($colorIds as $colorId) {
                foreach ($sizeIds as $sizeId) {
                    $sku = $data['product_code'] . '-' . str_pad($variantCounter++, 2, '0', STR_PAD_LEFT);
                    $variantId = $this->createVariant($shoeId, $sku, $price, $mainImage);
                    $this->linkAttributeToVariant($variantId, $colorId);
                    $this->linkAttributeToVariant($variantId, $sizeId);
                }
            }
        } elseif (!empty($colorIds)) {
            // Only colors: create one variant per color
            foreach ($colorIds as $colorId) {
                $sku = $data['product_code'] . '-' . str_pad($variantCounter++, 2, '0', STR_PAD_LEFT);
                $variantId = $this->createVariant($shoeId, $sku, $price, $mainImage);
                $this->linkAttributeToVariant($variantId, $colorId);
            }
        } elseif (!empty($sizeIds)) {
            // Only sizes: create one variant per size
            foreach ($sizeIds as $sizeId) {
                $sku = $data['product_code'] . '-' . str_pad($variantCounter++, 2, '0', STR_PAD_LEFT);
                $variantId = $this->createVariant($shoeId, $sku, $price, $mainImage);
                $this->linkAttributeToVariant($variantId, $sizeId);
            }
        }

        return $shoeId;
    }

    private function createVariant(int $shoeId, string $sku, float $price, string $mainImage): int
    {
        $sql = "INSERT INTO shoe_variants (shoe_id, sku, price, main_image) VALUES (?, ?, ?, ?)";
        $this->execute($sql, [$shoeId, $sku, $price, $mainImage]);
        return $this->conn->insert_id;
    }

    private function getOrCreateAttribute(string $type, string $value): int
    {
        // First, get or create the attribute type (e.g., 'color')
        $sql = "SELECT attribute_id FROM shoe_attributes WHERE name = ? LIMIT 1";
        $result = $this->fetchOne($sql, [$type]);
        
        if (!$result) {
            // Create attribute type if doesn't exist
            $sql = "INSERT INTO shoe_attributes (name) VALUES (?)";
            $this->execute($sql, [$type]);
            $attributeId = $this->conn->insert_id;
        } else {
            $attributeId = (int)$result['attribute_id'];
        }
        
        // Now get or create the attribute value
        $sql = "SELECT value_id FROM shoe_attribute_values WHERE attribute_id = ? AND value = ? LIMIT 1";
        $result = $this->fetchOne($sql, [$attributeId, $value]);
        
        if ($result) {
            return (int)$result['value_id'];
        }
        
        // Create new attribute value
        $sql = "INSERT INTO shoe_attribute_values (attribute_id, value) VALUES (?, ?)";
        $this->execute($sql, [$attributeId, $value]);
        return $this->conn->insert_id;
    }

    private function getSizeAttributeId(string $sizeValue): ?int
    {
        // Get 'Kích cỡ' attribute type
        $sql = "SELECT attribute_id FROM shoe_attributes WHERE name = 'Kích cỡ' LIMIT 1";
        $attrResult = $this->fetchOne($sql);
        
        if (!$attrResult) {
            // Create if doesn't exist
            $sql = "INSERT INTO shoe_attributes (name) VALUES ('Kích cỡ')";
            $this->execute($sql);
            $attributeId = $this->conn->insert_id;
        } else {
            $attributeId = (int)$attrResult['attribute_id'];
        }
        
        // Get size value
        $sql = "SELECT value_id FROM shoe_attribute_values WHERE attribute_id = ? AND value = ? LIMIT 1";
        $result = $this->fetchOne($sql, [$attributeId, $sizeValue]);
        
        if ($result) {
            return (int)$result['value_id'];
        }
        
        // Create size value if doesn't exist
        $sql = "INSERT INTO shoe_attribute_values (attribute_id, value) VALUES (?, ?)";
        $this->execute($sql, [$attributeId, $sizeValue]);
        return $this->conn->insert_id;
    }

    private function linkAttributeToVariant(int $variantId, int $attributeValueId): void
    {
        $sql = "INSERT INTO shoe_variant_attribute_map (variant_id, value_id, stock) VALUES (?, ?, 0)";
        $this->execute($sql, [$variantId, $attributeValueId]);
    }

    public function updateProduct(int $id, array $data): bool
    {
        // Update base product info
        $sql = "UPDATE {$this->table} SET name = ?, product_code = ?, category_id = ?, description = ?, updated_at = NOW() WHERE id = ?";
        $this->execute($sql, [
            $data['name'],
            $data['product_code'],
            $data['category_id'],
            $data['description'],
            $id
        ]);

        // If colors/sizes are provided, recreate variants
        if (isset($data['colors']) && isset($data['sizes'])) {
            $colors = $data['colors'];
            $sizes = $data['sizes'];
            $price = $data['price'];
            $mainImage = $data['main_image'];

            // Get all existing variants for this product
            $oldVariants = $this->fetchAll("SELECT id FROM shoe_variants WHERE shoe_id = ?", [$id]);
            
            // Check which variants are used in orders (cannot be deleted due to foreign key)
            $variantsInUse = [];
            foreach ($oldVariants as $variant) {
                $checkSql = "SELECT COUNT(*) as count FROM order_items WHERE shoe_variant_id = ?";
                $result = $this->fetchOne($checkSql, [$variant['id']]);
                if ($result && $result['count'] > 0) {
                    $variantsInUse[] = $variant['id'];
                }
            }

            // Delete attribute mappings for variants NOT in use
            foreach ($oldVariants as $variant) {
                if (!in_array($variant['id'], $variantsInUse)) {
                    $this->execute("DELETE FROM shoe_variant_attribute_map WHERE variant_id = ?", [$variant['id']]);
                }
            }
            
            // Delete shoe_images for variants NOT in use (must delete before deleting variants)
            foreach ($oldVariants as $variant) {
                if (!in_array($variant['id'], $variantsInUse)) {
                    $this->execute("DELETE FROM shoe_images WHERE shoe_variant_id = ?", [$variant['id']]);
                }
            }
            
            // Delete only variants that are NOT referenced by orders
            if (!empty($variantsInUse)) {
                $placeholders = implode(',', array_fill(0, count($variantsInUse), '?'));
                $this->execute("DELETE FROM shoe_variants WHERE shoe_id = ? AND id NOT IN ($placeholders)", 
                    array_merge([$id], $variantsInUse));
                
                // Update existing variants that are in use with new price and image
                foreach ($variantsInUse as $variantId) {
                    $this->execute("UPDATE shoe_variants SET price = ?, main_image = ? WHERE id = ?", 
                        [$price, $mainImage, $variantId]);
                }
            } else {
                // No variants in use, safe to delete all
                // First delete all shoe_images for this product's variants
                $this->execute("DELETE si FROM shoe_images si 
                               JOIN shoe_variants sv ON si.shoe_variant_id = sv.id 
                               WHERE sv.shoe_id = ?", [$id]);
                // Then delete all variants
                $this->execute("DELETE FROM shoe_variants WHERE shoe_id = ?", [$id]);
            }

            // Create new variants (same logic as createProduct)
            if (!empty($colors) && !empty($sizes)) {
                // Get or create color attributes
                $colorIds = [];
                foreach ($colors as $colorName) {
                    $colorId = $this->getOrCreateAttribute('Màu sắc', $colorName);
                    $colorIds[] = $colorId;
                }

                // Get size attribute IDs
                $sizeIds = [];
                foreach ($sizes as $sizeValue) {
                    $sizeId = $this->getSizeAttributeId($sizeValue);
                    if ($sizeId) {
                        $sizeIds[] = $sizeId;
                    }
                }

                // Create variants for each color × size combination
                $variantCounter = 1;
                
                if (!empty($colorIds) && !empty($sizeIds)) {
                    foreach ($colorIds as $colorId) {
                        foreach ($sizeIds as $sizeId) {
                            $sku = $data['product_code'] . '-' . str_pad($variantCounter++, 2, '0', STR_PAD_LEFT);
                            $variantId = $this->createVariant($id, $sku, $price, $mainImage);
                            $this->linkAttributeToVariant($variantId, $colorId);
                            $this->linkAttributeToVariant($variantId, $sizeId);
                        }
                    }
                }
            }
        } else {
            // Just update price and image for existing variants
            $this->execute("UPDATE shoe_variants SET price = ?, main_image = ? WHERE shoe_id = ?", [
                $data['price'],
                $data['main_image'],
                $id
            ]);
        }

        return true;
    }

    public function deleteProduct(int $id): bool
    {
        $sql = "UPDATE {$this->table} SET deleted_at = NOW() WHERE id = ?";
        return $this->execute($sql, [$id]);
    }

    public function searchProducts(string $keyword, array $categoryIds = [], array $priceRanges = [], int $limit = 12, int $offset = 0): array
    {
        $params = [];
        $types = "";
        $whereClauses = [];

        if (!empty($keyword)) {
            $keyword = "%{$keyword}%";
            $whereClauses[] = "(s.name LIKE ? OR s.product_code LIKE ?)";
            $types .= "ss";
            $params[] = $keyword;
            $params[] = $keyword;
        }

        if (!empty($categoryIds)) {
            $placeholders = implode(',', array_fill(0, count($categoryIds), '?'));
            $whereClauses[] = "s.category_id IN ($placeholders)";
            $types .= str_repeat('i', count($categoryIds));
            $params = array_merge($params, $categoryIds);
        }

        if (!empty($priceRanges)) {
            $priceConditions = [];
            foreach ($priceRanges as $range) {
                $parts = explode('-', $range);
                if (count($parts) === 2) {
                    $min = (float)$parts[0];
                    $max = (float)$parts[1];
                    $priceConditions[] = "(sv.price >= ? AND sv.price <= ?)";
                    $types .= "dd";
                    $params[] = $min;
                    $params[] = $max;
                }
            }
            if (!empty($priceConditions)) {
                $whereClauses[] = "(" . implode(' OR ', $priceConditions) . ")";
            }
        }

        $whereClause = !empty($whereClauses) ? "WHERE " . implode(' AND ', $whereClauses) : "";

        $sql = "
            SELECT DISTINCT s.id, s.name, s.product_code, s.category_id,
                   c.name AS category_name, sv.price, sv.market_price, sv.main_image,
                   (SELECT COALESCE(SUM(oi.quantity), 0) FROM order_items oi JOIN shoe_variants sv2 ON oi.shoe_variant_id = sv2.id WHERE sv2.shoe_id = s.id) as sold_count
            FROM {$this->table} s
            JOIN categories c ON c.id = s.category_id
            JOIN shoe_variants sv ON sv.shoe_id = s.id
            $whereClause
            ORDER BY s.created_at DESC
            LIMIT ? OFFSET ?
        ";

        $types .= "ii";
        $params[] = $limit;
        $params[] = $offset;

        return $this->fetchAll($sql, $params);
    }

    public function countSearchProducts(string $keyword, array $categoryIds = [], array $priceRanges = []): int
    {
        $params = [];
        $whereClauses = [];

        if (!empty($keyword)) {
            $keyword = "%{$keyword}%";
            $whereClauses[] = "(s.name LIKE ? OR s.product_code LIKE ?)";
            $params[] = $keyword;
            $params[] = $keyword;
        }

        if (!empty($categoryIds)) {
            $placeholders = implode(',', array_fill(0, count($categoryIds), '?'));
            $whereClauses[] = "s.category_id IN ($placeholders)";
            foreach ($categoryIds as $id) $params[] = $id;
        }

        if (!empty($priceRanges)) {
            $priceConditions = [];
            foreach ($priceRanges as $range) {
                $parts = explode('-', $range);
                if (count($parts) === 2) {
                    $min = (float)$parts[0];
                    $max = (float)$parts[1];
                    $priceConditions[] = "(sv.price >= ? AND sv.price <= ?)";
                    $params[] = $min;
                    $params[] = $max;
                }
            }
            if (!empty($priceConditions)) {
                $whereClauses[] = "(" . implode(' OR ', $priceConditions) . ")";
            }
        }

        $whereClause = !empty($whereClauses) ? "WHERE " . implode(' AND ', $whereClauses) : "";

        $sql = "
            SELECT COUNT(DISTINCT s.id) as total
            FROM {$this->table} s
            JOIN shoe_variants sv ON sv.shoe_id = s.id
            $whereClause
        ";

        $result = $this->fetchOne($sql, $params);
        return (int)($result['total'] ?? 0);
    }

    public function getVariantPriceByAttributes(int $shoeId, string $color = '', string $size = ''): ?float
    {
        $baseProduct = $this->getProductDetail($shoeId);
        if (!$baseProduct) {
            return null;
        }
        $basePrice = (float)($baseProduct['price'] ?? 0);

        if (empty($color) && empty($size)) {
            return $basePrice;
        }

        $sql = "

            SELECT sv.id AS variant_id, sv.price
            FROM shoe_variants sv
            WHERE sv.shoe_id = ?
                AND sv.id IN (
                    SELECT map1.variant_id
                    FROM shoe_variant_attribute_map map1
                    INNER JOIN shoe_attribute_values av1 ON av1.value_id = map1.value_id
                    INNER JOIN shoe_attributes a1 ON a1.attribute_id = av1.attribute_id
                    WHERE a1.name LIKE '%màu%' AND LOWER(TRIM(av1.value)) = LOWER(TRIM(?))
                )
                AND sv.id IN (
                    SELECT map2.variant_id
                    FROM shoe_variant_attribute_map map2
                    INNER JOIN shoe_attribute_values av2 ON av2.value_id = map2.value_id
                    INNER JOIN shoe_attributes a2 ON a2.attribute_id = av2.attribute_id
                    WHERE (a2.name LIKE '%kích%' OR a2.name LIKE '%size%') AND LOWER(TRIM(av2.value)) = LOWER(TRIM(?))
                )
            LIMIT 1
        ";

        $variant = $this->fetchOne($sql, [$shoeId, trim($color), trim($size)]);

        if ($variant && isset($variant['price'])) {
            $variantPrice = (float)$variant['price'];
            if (abs($variantPrice - $basePrice) > 0.01) {
                return $variantPrice;
            }
        }

        return $this->calculateAdjustedPrice($basePrice, $color, $size);
    }

    private function applyPriceAdjustments(float $variantPrice, string $color = '', string $size = ''): float
    {
        $colorKey = trim(strtolower($color));
        $sizeKey = trim($size);

        $hash = md5($colorKey . '_' . $sizeKey);
        $hashNum = hexdec(substr($hash, 0, 8));

        $adjustment = ($hashNum % 60) * ($variantPrice * 0.0005);

        $adjustedPrice = $variantPrice + $adjustment;

        $adjustedPrice = round($adjustedPrice / 1000) * 1000;

        return $adjustedPrice;
    }

    private function calculateAdjustedPrice(float $basePrice, string $color = '', string $size = ''): float
    {
        $colorKey = trim(strtolower($color));
        $sizeKey = trim($size);

        $colorHash = 0;
        $sizeHash = 0;

        if (!empty($colorKey)) {
            for ($i = 0; $i < strlen($colorKey); $i++) {
                $colorHash += ord($colorKey[$i]) * ($i + 1);
            }
        }

        if (!empty($sizeKey)) {
            $sizeNum = (int)$sizeKey;
            if ($sizeNum > 0) {
                $sizeHash = $sizeNum * 1000;
            } else {
                for ($i = 0; $i < strlen($sizeKey); $i++) {
                    $sizeHash += ord($sizeKey[$i]) * ($i + 1);
                }
            }
        }

        $colorMultipliers = [
            'đỏ' => 1.15,
            'xanh dương' => 1.08,
            'xanh' => 1.08,
            'đen' => 1.0,
            'trắng' => 0.92,
            'vàng' => 1.12,
            'hồng' => 1.10
        ];

        $colorMultiplier = 1.0;
        foreach ($colorMultipliers as $key => $multiplier) {
            if (stripos($colorKey, $key) !== false) {
                $colorMultiplier = $multiplier;
                break;
            }
        }

        $sizeMultipliers = [
            '39' => 0.95,
            '40' => 0.97,
            '41' => 1.0,
            '42' => 1.03,
            '43' => 1.06,
            '44' => 1.10,
            '45' => 1.15,
            '46' => 1.20
        ];

        $sizeMultiplier = 1.0;
        if (isset($sizeMultipliers[$sizeKey])) {
            $sizeMultiplier = $sizeMultipliers[$sizeKey];
        } else {
            $sizeNum = (int)$sizeKey;
            if ($sizeNum > 0) {
                $sizeMultiplier = 1.0 + (($sizeNum - 41) * 0.03);
            }
        }

        $price = $basePrice * $colorMultiplier * $sizeMultiplier;

        $uniqueAdjustment = (($colorHash + $sizeHash) % 100) * ($basePrice * 0.0005);
        $price += $uniqueAdjustment;


        $minPrice = $basePrice * 0.5;
        $maxPrice = $basePrice * 1.5;

        return max($minPrice, min($price, $maxPrice));
    }


    public function getAllVariantPrices(int $shoeId): array
    {
        $baseProduct = $this->getProductDetail($shoeId);
        if (!$baseProduct) {
            return [];
        }

        $basePrice = (float)($baseProduct['price'] ?? 0);
        $options = $this->getVariantOptions($shoeId);
        $colors = $options['colors'] ?? [];
        $sizes = $options['sizes'] ?? [];

        $prices = [];

        if (empty($colors) && empty($sizes)) {
            return ['default' => $basePrice];
        }

        foreach ($colors as $color) {
            foreach ($sizes as $size) {
                $key = $color . '_' . $size;
                $price = $this->getVariantPriceByAttributes($shoeId, $color, $size);
                $prices[$key] = $price ?? $basePrice;
            }
        }

        return $prices;
    }

    public function getAllSizes(): array
    {
        $sql = "
            SELECT DISTINCT av.value
            FROM shoe_attribute_values av
            JOIN shoe_attributes a ON a.attribute_id = av.attribute_id
            WHERE a.name LIKE '%kích%' OR a.name LIKE '%size%'
            ORDER BY CAST(av.value AS UNSIGNED), av.value
        ";
        return $this->fetchAll($sql);
    }

    public function getProductSizes(int $shoeId): array
    {
        $sql = "
            SELECT DISTINCT av.value_id, av.value
            FROM shoe_variants sv
            JOIN shoe_variant_attribute_map map ON map.variant_id = sv.id
            JOIN shoe_attribute_values av ON av.value_id = map.value_id
            JOIN shoe_attributes a ON a.attribute_id = av.attribute_id
            WHERE sv.shoe_id = ? AND (a.name LIKE '%kích%' OR a.name LIKE '%size%')
            ORDER BY CAST(av.value AS UNSIGNED), av.value
        ";
        return $this->fetchAll($sql, [$shoeId]);
    }

    public function getProductColors(int $shoeId): array
    {
        $sql = "
            SELECT DISTINCT av.value
            FROM shoe_variants sv
            JOIN shoe_variant_attribute_map map ON map.variant_id = sv.id
            JOIN shoe_attribute_values av ON av.value_id = map.value_id
            JOIN shoe_attributes a ON a.attribute_id = av.attribute_id
            WHERE sv.shoe_id = ? AND a.name LIKE '%màu%'
            ORDER BY av.value
        ";
        $result = $this->fetchAll($sql, [$shoeId]);
        return !empty($result) ? array_column($result, 'value') : [];
    }

    public function getVariantByProductId(int $shoeId): ?array
    {
        $sql = "SELECT * FROM shoe_variants WHERE shoe_id = ? LIMIT 1";
        return $this->fetchOne($sql, [$shoeId]);
    }

    public function updateVariantAttributes(int $variantId, array $sizes = [], array $colors = []): bool
    {
        $sqlDelete = "DELETE FROM shoe_variant_attribute_map WHERE variant_id = ?";
        $this->execute($sqlDelete, [$variantId]);

        $sizeAttrSql = "SELECT attribute_id FROM shoe_attributes WHERE name LIKE '%kích%' OR name LIKE '%size%' LIMIT 1";
        $sizeAttr = $this->fetchOne($sizeAttrSql);

        $colorAttrSql = "SELECT attribute_id FROM shoe_attributes WHERE name LIKE '%màu%' LIMIT 1";
        $colorAttr = $this->fetchOne($colorAttrSql);

        if (!empty($sizes) && $sizeAttr) {
            foreach ($sizes as $sizeValue) {
                $valueId = $this->getOrCreateAttributeValue($sizeAttr['attribute_id'], $sizeValue);
                if ($valueId) {
                    $sqlInsert = "INSERT INTO shoe_variant_attribute_map (variant_id, value_id) VALUES (?, ?)";
                    $this->execute($sqlInsert, [$variantId, $valueId]);
                }
            }
        }

        if (!empty($colors) && $colorAttr) {
            foreach ($colors as $colorValue) {
                if (!empty(trim($colorValue))) {
                    $valueId = $this->getOrCreateAttributeValue($colorAttr['attribute_id'], trim($colorValue));
                    if ($valueId) {
                        $sqlInsert = "INSERT INTO shoe_variant_attribute_map (variant_id, value_id) VALUES (?, ?)";
                        $this->execute($sqlInsert, [$variantId, $valueId]);
                    }
                }
            }
        }

        return true;
    }

    private function getOrCreateAttributeValue(int $attributeId, string $value): ?int
    {
        $sql = "SELECT value_id FROM shoe_attribute_values WHERE attribute_id = ? AND value = ? LIMIT 1";
        $existing = $this->fetchOne($sql, [$attributeId, $value]);

        if ($existing) {
            return (int)$existing['value_id'];
        }

        $sqlInsert = "INSERT INTO shoe_attribute_values (attribute_id, value) VALUES (?, ?)";
        $this->execute($sqlInsert, [$attributeId, $value]);
        return $this->conn->insert_id;
    }

    public function getTrashedProducts(): array
    {
        $sql = "
            SELECT s.id, s.name, s.product_code, s.category_id,
                   c.name AS category_name, sv.price, sv.market_price, sv.main_image, s.deleted_at
            FROM {$this->table} s
            LEFT JOIN categories c ON c.id = s.category_id
            LEFT JOIN shoe_variants sv ON sv.id = (
                SELECT MIN(id) FROM shoe_variants WHERE shoe_id = s.id LIMIT 1
            )
            WHERE s.deleted_at IS NOT NULL
            ORDER BY s.deleted_at DESC
        ";
        return $this->fetchAll($sql);
    }

    public function restoreProduct(int $id): bool
    {
        $sql = "UPDATE {$this->table} SET deleted_at = NULL WHERE id = ?";
        return $this->execute($sql, [$id]);
    }

    public function forceDeleteProduct(int $id): bool
    {
        $sqlGetVariants = "SELECT id FROM shoe_variants WHERE shoe_id = ?";
        $variants = $this->fetchAll($sqlGetVariants, [$id]);

        // Check if product is in any non-completed orders
        foreach ($variants as $variant) {
            // Check for orders that are NOT completed (status_id != 7)
            $sqlCheckPendingOrders = "
                SELECT COUNT(*) as count 
                FROM order_items oi
                JOIN orders o ON o.id = oi.order_id
                WHERE oi.shoe_variant_id = ? 
                AND o.current_status_id != 7
            ";
            $result = $this->fetchOne($sqlCheckPendingOrders, [$variant['id']]);
            
            if ($result && $result['count'] > 0) {
                // Product is in pending/processing orders, cannot delete
                return false;
            }
        }

        // All orders are completed, safe to delete
        foreach ($variants as $variant) {
            $sqlDeleteImages = "DELETE FROM shoe_images WHERE shoe_variant_id = ?";
            $this->execute($sqlDeleteImages, [$variant['id']]);

            $sqlDeleteAttrs = "DELETE FROM shoe_variant_attribute_map WHERE variant_id = ?";
            $this->execute($sqlDeleteAttrs, [$variant['id']]);
        }

        $sqlDeleteVariants = "DELETE FROM shoe_variants WHERE shoe_id = ?";
        $this->execute($sqlDeleteVariants, [$id]);

        $sqlDeleteReviews = "DELETE FROM reviews WHERE shoe_id = ?";
        $this->execute($sqlDeleteReviews, [$id]);

        $sql = "DELETE FROM {$this->table} WHERE id = ?";
        return $this->execute($sql, [$id]);
    }
}