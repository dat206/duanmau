<?php
class CategoryModel extends BaseModel
{
    protected string $table = 'categories';

    public function __construct(mysqli $conn)
    {
        parent::__construct($conn);
    }

    public function getAllCategories(): array
    {
        $sql = "SELECT * FROM {$this->table} WHERE deleted_at IS NULL ORDER BY id ASC";
        return $this->fetchAll($sql);
    }

    public function getCategoryById(int $id): ?array
    {
        $sql = "SELECT * FROM {$this->table} WHERE id = ? LIMIT 1";
        return $this->fetchOne($sql, [$id]);
    }

    public function createCategory(array $data): int
    {
        $sql = "INSERT INTO {$this->table} (name, description) VALUES (?, ?)";
        $this->execute($sql, [
            $data['name'],
            $data['description'] ?? ''
        ]);
        return $this->conn->insert_id;
    }

    public function updateCategory(int $id, array $data): bool
    {
        $sql = "UPDATE {$this->table} SET name = ?, description = ? WHERE id = ?";
        return $this->execute($sql, [
            $data['name'],
            $data['description'] ?? '',
            $id
        ]);
    }

    public function deleteCategory(int $id): bool
    {
        $sql = "UPDATE {$this->table} SET deleted_at = NOW() WHERE id = ?";
        return $this->execute($sql, [$id]);
    }

    public function getTrashedCategories(): array
    {
        $sql = "SELECT * FROM {$this->table} WHERE deleted_at IS NOT NULL ORDER BY deleted_at DESC";
        return $this->fetchAll($sql);
    }

    public function restoreCategory(int $id): bool
    {
        $sql = "UPDATE {$this->table} SET deleted_at = NULL WHERE id = ?";
        return $this->execute($sql, [$id]);
    }

    public function forceDeleteCategory(int $id): bool
    {
        $sqlCheck = "SELECT COUNT(*) AS total FROM shoes WHERE category_id = ? AND deleted_at IS NULL";
        $result = $this->fetchOne($sqlCheck, [$id]);

        if ($result && $result['total'] > 0) {
            return false;
        }

        $sql = "DELETE FROM {$this->table} WHERE id = ?";
        return $this->execute($sql, [$id]);
    }

    public function countCategories(): int
    {
        $sql = "SELECT COUNT(*) AS total FROM {$this->table} WHERE deleted_at IS NULL";
        $result = $this->fetchOne($sql);
        return (int)($result['total'] ?? 0);
    }

    public function getCategoryProductCount(int $categoryId): int
    {
        $sql = "SELECT COUNT(*) AS total FROM shoes WHERE category_id = ? AND deleted_at IS NULL";
        $result = $this->fetchOne($sql, [$categoryId]);
        return (int)($result['total'] ?? 0);
    }
}
