<?php
class ReviewModel extends BaseModel 
{
    public function getAllReviews() 
    {
        $sql = "SELECT r.*, u.name as user_name, s.name as product_name 
                FROM reviews r  
                JOIN users u ON r.user_id = u.id 
                JOIN shoes s ON r.shoe_id = s.id  
                ORDER BY r.created_at DESC";
        return $this->fetchAll($sql);
    }
 
    public function updateReviewStatus($id, $status)
    {
        $sql = "UPDATE reviews SET status = ? WHERE id = ?"; 
        return $this->execute($sql, [$status, $id]);
    } 

    public function createReview($userId, $productId, $rating, $comment)
    {
        $sql = "INSERT INTO reviews (user_id, shoe_id, rating, comment, created_at, status)  
                VALUES (?, ?, ?, ?, NOW(), 'approved')";
        return $this->execute($sql, [$userId, $productId, $rating, $comment]);
    }
 
    public function getAverageRating($productId)
    { 
        $sql = "SELECT AVG(rating) as avg_rating, COUNT(*) as total_reviews 
                FROM reviews 
                WHERE shoe_id = ? AND status = 'approved'";
        return $this->fetchOne($sql, [$productId]);
    }

    public function hasUserReviewedProduct($userId, $productId)
    {
        $sql = "SELECT COUNT(*) as count FROM reviews WHERE user_id = ? AND shoe_id = ?";
        $result = $this->fetchOne($sql, [$userId, $productId]);
        return ($result['count'] ?? 0) > 0;
    }
} 