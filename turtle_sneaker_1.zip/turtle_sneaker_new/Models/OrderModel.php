<?php
class OrderModel extends BaseModel
{
    protected string $table = 'orders';

    public function __construct(mysqli $conn)
    {
        parent::__construct($conn);
    }

    public function createAddress(int $userId, array $data): int
    {
        // Let MySQL AUTO_INCREMENT generate the ID automatically
        $sql = "INSERT INTO addresses (user_id, full_name, phone, address_line, city, district, ward, is_default) 
                VALUES (?, ?, ?, ?, ?, ?, ?, 1)";
        $this->execute($sql, [
            $userId,
            $data['name'],
            $data['phone'],
            $data['address'],
            $data['city'] ?? '',
            $data['district'] ?? '',
            $data['ward'] ?? ''
        ]);
        return $this->conn->insert_id; 
    } 


    public function createOrder($userId, $addressId, $subtotalPrice, $shippingFee, $tax, $totalAmount, $couponId = null, $shippingMethodId = 1, $paymentMethod = 'cod')
    {
     
        $sql = "INSERT INTO orders (user_id, address_id, coupon_id, current_status_id, subtotal_price, shipping_fee, tax, total_amount, shipping_method, payment_method, created_at) 
                VALUES (?, ?, ?, 1, ?, ?, ?, ?, ?, ?, NOW())"; 
        if (empty($couponId)) { 
            $couponId = NULL; 
        }
        $params = [$userId, $addressId, $couponId, $subtotalPrice, $shippingFee, $tax, $totalAmount, $shippingMethodId, $paymentMethod];
        if ($this->execute($sql, $params)) {
            return $this->conn->insert_id;
        } 
        return false; 
    }  

 
    public function createOrderItem(int $orderId, array $item): void 
    {
        $variantId = $this->getVariantId($item['product_id'], $item['color'], $item['size']);
        
        // Get product snapshot at time of order
        $snapshotSql = "SELECT sv.id, sv.sku, sv.main_image, sv.shoe_id, 
                               s.name as product_name, s.product_code
                        FROM shoe_variants sv
                        JOIN shoes s ON sv.shoe_id = s.id
                        WHERE sv.id = ?";
        $snapshotData = $this->fetchOne($snapshotSql, [$variantId]);
        
        // Create snapshot JSON to preserve product info at time of order
        $snapshot = json_encode([
            'shoe_id' => $snapshotData['shoe_id'] ?? null,
            'product_name' => $snapshotData['product_name'] ?? '',
            'product_code' => $snapshotData['product_code'] ?? '',
            'sku' => $snapshotData['sku'] ?? '',
            'main_image' => $snapshotData['main_image'] ?? ''
        ]);
        
        $orderItemId = $this->generateUniqueId('order_items');

        $sql = "INSERT INTO order_items (id, order_id, shoe_variant_id, quantity, price_each, selected_color, selected_size, variant_snapshot_json) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)"; 
        $this->execute($sql, [ 
            $orderItemId, 
            $orderId,
            $variantId,  
            $item['quantity'], 
            $item['price'], 
            $item['color'] ?? '', 
            $item['size'] ?? '',
            $snapshot 
        ]); 
    } 


    private function getVariantId($productId, $color, $size)
    {
        $sql = "SELECT id FROM shoe_variants WHERE shoe_id = ? LIMIT 1";
        $res = $this->fetchOne($sql, [$productId]);
        return $res['id'] ?? 0;
    }


    private function generateUniqueId(string $table): int
    {
        $maxAttempts = 5;
        for ($attempt = 0; $attempt < $maxAttempts; $attempt++) {
            $candidate = random_int(1, 2000000000);
            $exists = $this->fetchValue("SELECT 1 FROM {$table} WHERE id = ? LIMIT 1", [$candidate]);
            if (!$exists) {
                return $candidate;
            }
        }

        $row = $this->fetchOne("SELECT IFNULL(MAX(id), 0) + 1 AS next_id FROM {$table}");
        return (int)($row['next_id'] ?? 1);
    }


    public function getAllOrdersWithDetails()
    {
        $sql = "SELECT 
                    o.id, 
                    o.total_amount, 
                    o.created_at, 
                    os.name as status_name, 
                    os.id as status_id,
                    o.payment_method,
                    p.status as payment_status,
                    u.name as user_name, 
                    u.email as user_email,
                    GROUP_CONCAT(s.name SEPARATOR ', ') as product_names
                FROM orders o
                JOIN users u ON o.user_id = u.id
                JOIN order_statuses os ON o.current_status_id = os.id
                LEFT JOIN payments p ON p.order_id = o.id
                JOIN order_items oi ON o.id = oi.order_id
                JOIN shoe_variants sv ON oi.shoe_variant_id = sv.id
                JOIN shoes s ON sv.shoe_id = s.id
                GROUP BY o.id
                ORDER BY o.created_at DESC";
        return $this->fetchAll($sql);
    }

    public function getOrderPaymentInfo(int $orderId): ?array
    {
        $sql = "SELECT id, user_id, total_amount, payment_method, current_status_id 
                FROM orders 
                WHERE id = ?";
        return $this->fetchOne($sql, [$orderId]);
    }

    public function getOrdersByUserId(int $userId)
    {
        $sql = "SELECT 
                    o.id, 
                    o.total_amount, 
                    o.created_at, 
                    os.name as status_name, 
                    os.id as status_id,
                    o.payment_method,
                    p.status as payment_status,
                    GROUP_CONCAT(CONCAT(s.name, ' (', oi.quantity, 'x)') SEPARATOR ', ') as product_names
                FROM orders o
                JOIN order_statuses os ON o.current_status_id = os.id
                LEFT JOIN payments p ON p.order_id = o.id
                JOIN order_items oi ON o.id = oi.order_id
                JOIN shoe_variants sv ON oi.shoe_variant_id = sv.id
                JOIN shoes s ON sv.shoe_id = s.id
                WHERE o.user_id = ?
                GROUP BY o.id
                ORDER BY o.created_at DESC";
        return $this->fetchAll($sql, [$userId]);
    }

    public function getOrdersByUserIdPaginated(int $userId, int $limit, int $offset): array
    {
        $sql = "SELECT 
                    o.id, 
                    o.total_amount, 
                    o.created_at, 
                    os.name as status_name, 
                    os.id as status_id,
                    o.payment_method,
                    p.status as payment_status
                FROM orders o
                JOIN order_statuses os ON o.current_status_id = os.id
                LEFT JOIN payments p ON p.order_id = o.id
                WHERE o.user_id = ?
                GROUP BY o.id
                ORDER BY o.created_at DESC
                LIMIT ? OFFSET ?";
        return $this->fetchAll($sql, [$userId, $limit, $offset]);
    }

    public function countOrdersByUserId(int $userId): int
    {
        $sql = "SELECT COUNT(*) as count FROM orders WHERE user_id = ?";
        $result = $this->fetchOne($sql, [$userId]);
        return (int)($result['count'] ?? 0);
    }

    public function getAllOrdersWithDetailsPaginated(int $limit, int $offset): array
    {
        $sql = "SELECT 
                    o.id, 
                    o.total_amount, 
                    o.created_at, 
                    os.name as status_name, 
                    os.id as status_id,
                    o.payment_method,
                    p.status as payment_status,
                    u.name as user_name, 
                    u.email as user_email,
                    GROUP_CONCAT(s.name SEPARATOR ', ') as product_names
                FROM orders o
                JOIN users u ON o.user_id = u.id
                JOIN order_statuses os ON o.current_status_id = os.id
                LEFT JOIN payments p ON p.order_id = o.id
                JOIN order_items oi ON o.id = oi.order_id
                JOIN shoe_variants sv ON oi.shoe_variant_id = sv.id
                JOIN shoes s ON sv.shoe_id = s.id
                GROUP BY o.id
                ORDER BY o.created_at DESC
                LIMIT ? OFFSET ?";
        return $this->fetchAll($sql, [$limit, $offset]);
    }

    public function getOrderDetailById(int $orderId)
    {
        $sql = "SELECT 
                    o.id,
                    o.user_id,
                    o.address_id,
                    o.current_status_id,
                    o.subtotal_price,
                    o.shipping_fee,
                    o.shipping_method,
                    o.payment_method,
                    o.tax,
                    o.total_amount,
                    o.created_at,
                    o.coupon_id,
                    os.name as status_name,
                    u.name as user_name,
                    u.email as user_email,
                    u.phone as user_phone,
                    a.full_name as address_name,
                    a.phone as address_phone,
                    a.address_line,
                    c.code as coupon_code,
                    c.discount_amount as coupon_discount,
                    c.type as coupon_type
                FROM orders o
                JOIN users u ON o.user_id = u.id
                JOIN order_statuses os ON o.current_status_id = os.id
                LEFT JOIN addresses a ON o.address_id = a.id
                LEFT JOIN coupons c ON o.coupon_id = c.id
                WHERE o.id = ?";

        $order = $this->fetchOne($sql, [$orderId]);

        if ($order) {
            $order['items'] = $this->getOrderItems($orderId);

            if ($order['coupon_id']) {
                if ($order['coupon_type'] == 'shipping') {
                    $order['shipping_discount'] = $order['coupon_discount'];
                    $order['product_discount'] = 0;
                } else {
                    $order['shipping_discount'] = 0;
                    $order['product_discount'] = $order['coupon_discount'];
                }
            } else {
                $order['shipping_discount'] = 0;
                $order['product_discount'] = 0;
            }
        }

        return $order;
    }

    public function getOrderItems(int $orderId)
    {
        // First get the user_id from the order
        $orderSql = "SELECT user_id FROM orders WHERE id = ?";
        $orderData = $this->fetchOne($orderSql, [$orderId]);
        $userId = $orderData['user_id'] ?? null;

        $sql = "SELECT 
                    oi.id,
                    oi.quantity,
                    oi.price_each,
                    oi.selected_color as color_name,
                    oi.selected_size as size_name,
                    oi.variant_snapshot_json,
                    oi.shoe_variant_id
                FROM order_items oi
                WHERE oi.order_id = ?";

        $items = $this->fetchAll($sql, [$orderId]);
        
        // Extract product info from snapshot
        foreach ($items as &$item) {
            $snapshot = json_decode($item['variant_snapshot_json'], true);
            
            // Use snapshot data if available, otherwise fallback to live data
            if ($snapshot) {
                $item['product_id'] = $snapshot['shoe_id'] ?? null;
                $item['product_name'] = $snapshot['product_name'] ?? 'Sản phẩm';
                $item['product_code'] = $snapshot['product_code'] ?? '';
                $item['main_image'] = $snapshot['main_image'] ?? '';
                $item['sku'] = $snapshot['sku'] ?? '';
            } else {
                // Fallback: get live data if snapshot is missing
                $variantSql = "SELECT sv.sku, sv.main_image, s.id as shoe_id, s.name, s.product_code
                               FROM shoe_variants sv
                               JOIN shoes s ON sv.shoe_id = s.id
                               WHERE sv.id = ?";
                $variantData = $this->fetchOne($variantSql, [$item['shoe_variant_id']]);
                
                $item['product_id'] = $variantData['shoe_id'] ?? null;
                $item['product_name'] = $variantData['name'] ?? 'Sản phẩm';
                $item['product_code'] = $variantData['product_code'] ?? '';
                $item['main_image'] = $variantData['main_image'] ?? '';
                $item['sku'] = $variantData['sku'] ?? '';
            }
            
            // Check if user has reviewed this product
            if ($userId && $item['product_id']) {
                $reviewSql = "SELECT id FROM reviews WHERE shoe_id = ? AND user_id = ? LIMIT 1";
                $review = $this->fetchOne($reviewSql, [$item['product_id'], $userId]);
                $item['has_reviewed'] = $review ? 1 : 0;
            } else {
                $item['has_reviewed'] = 0;
            }
        }
        
        return $items;
    }


    public function validateStatusTransition(int $currentStatus, int $newStatus): bool
    {
        $allowedTransitions = [
            1 => [2, 8],
            2 => [3],
            3 => [4],
            4 => [5],
            5 => [6],
            6 => [7],
            7 => [],
            8 => []
        ];

        return in_array($newStatus, $allowedTransitions[$currentStatus] ?? []);
    }

    public function cancelOrder(int $orderId, int $userId): bool
    {
        $sql = "SELECT current_status_id FROM orders WHERE id = ? AND user_id = ?";
        $order = $this->fetchOne($sql, [$orderId, $userId]);

        if (!$order) {
            return false;
        }

        if ($order['current_status_id'] > 3) {
            return false;
        }

        $sql = "UPDATE orders SET current_status_id = 8 WHERE id = ?";
        return $this->execute($sql, [$orderId]);
    }

    public function updateOrderStatus(int $orderId, int $newStatusId): bool
    {
        $order = $this->fetchOne("SELECT current_status_id FROM orders WHERE id = ?", [$orderId]);

        if (!$order) {
            return false;
        }

        $currentStatus = $order['current_status_id'];

        if (!$this->validateStatusTransition($currentStatus, $newStatusId)) {
            return false;
        }

        $sql = "UPDATE orders SET current_status_id = ? WHERE id = ?";
        return $this->execute($sql, [$newStatusId, $orderId]);
    }

    public function canUserConfirmOrder(int $orderId, int $userId): bool
    {
        $sql = "SELECT user_id, current_status_id FROM orders WHERE id = ?";
        $order = $this->fetchOne($sql, [$orderId]);

        if (!$order) {
            return false;
        }

        return ($order['user_id'] == $userId && $order['current_status_id'] == 6);
    }


    public function confirmOrderReceipt(int $orderId, int $userId): bool
    {
        if (!$this->canUserConfirmOrder($orderId, $userId)) {
            return false;
        }
        $sql = "UPDATE orders SET current_status_id = 7 WHERE id = ? AND user_id = ?";
        $updated = $this->execute($sql, [$orderId, $userId]);

        if ($updated) {
            $order = $this->fetchOne("SELECT payment_method FROM orders WHERE id = ?", [$orderId]);
            if ($order && ($order['payment_method'] ?? '') === 'cod') {
                require_once __DIR__ . '/PaymentModel.php';
                $paymentModel = new PaymentModel($this->conn);
                $paymentModel->markPaid($orderId);
            }
        }
        return $updated;
    }

    public function countAllOrders(): int
    {
        $sql = "SELECT COUNT(*) as count FROM orders";
        $result = $this->fetchAll($sql);
        return (int)($result[0]['count'] ?? 0);
    }


    public function calculateTotalRevenue(): float
    {
        $sql = "SELECT SUM(total_amount) as total FROM orders WHERE current_status_id = 7";
        $result = $this->fetchAll($sql);
        return (float)($result[0]['total'] ?? 0);
    }

    public function countOrdersByStatus(int $statusId): int
    {
        $sql = "SELECT COUNT(*) as count FROM orders WHERE current_status_id = ?";
        $result = $this->fetchAll($sql, [$statusId]);
        return (int)($result[0]['count'] ?? 0);
    }

    public function hasPurchasedProduct(int $userId, int $productId): bool
    {
        $sql = "SELECT COUNT(*) as count 
                FROM orders o
                JOIN order_items oi ON o.id = oi.order_id
                JOIN shoe_variants sv ON oi.shoe_variant_id = sv.id
                WHERE o.user_id = ? 
                AND sv.shoe_id = ? 
                AND o.current_status_id = 7";

        $result = $this->fetchOne($sql, [$userId, $productId]);
        return ($result['count'] ?? 0) > 0;
    }

    public function getDailyRevenue(int $days = 30): array
    {
        $sql = "SELECT 
                    DATE(created_at) as date,
                    SUM(total_amount) as revenue
                FROM orders
                WHERE current_status_id = 7
                AND created_at >= DATE_SUB(CURDATE(), INTERVAL ? DAY)
                GROUP BY DATE(created_at)
                ORDER BY date ASC";

        return $this->fetchAll($sql, [$days]);
    }

    public function getTodayRevenue(): float
    {
        $sql = "SELECT SUM(total_amount) as total 
                FROM orders 
                WHERE current_status_id = 7 
                AND DATE(created_at) = CURDATE()";
        $result = $this->fetchAll($sql);
        return (float)($result[0]['total'] ?? 0);
    }

    public function getWeekRevenue(): float
    {
        $sql = "SELECT SUM(total_amount) as total 
                FROM orders 
                WHERE current_status_id = 7 
                AND YEARWEEK(created_at, 1) = YEARWEEK(CURDATE(), 1)";
        $result = $this->fetchAll($sql);
        return (float)($result[0]['total'] ?? 0);
    }

    public function getMonthRevenue(): float
    {
        $sql = "SELECT SUM(total_amount) as total 
                FROM orders 
                WHERE current_status_id = 7 
                AND YEAR(created_at) = YEAR(CURDATE()) 
                AND MONTH(created_at) = MONTH(CURDATE())";
        $result = $this->fetchAll($sql);
        return (float)($result[0]['total'] ?? 0);
    }

    public function getYearRevenue(): float
    {
        $sql = "SELECT SUM(total_amount) as total 
                FROM orders 
                WHERE current_status_id = 7 
                AND YEAR(created_at) = YEAR(CURDATE())";
        $result = $this->fetchAll($sql);
        return (float)($result[0]['total'] ?? 0);
    }

    public function getMonthlyRevenue(int $months = 12): array
    {
        $sql = "SELECT 
                    DATE_FORMAT(created_at, '%Y-%m') as month,
                    SUM(total_amount) as revenue
                FROM orders
                WHERE current_status_id = 7
                AND created_at >= DATE_SUB(CURDATE(), INTERVAL ? MONTH)
                GROUP BY DATE_FORMAT(created_at, '%Y-%m')
                ORDER BY month ASC";
        return $this->fetchAll($sql, [$months]);
    }

    public function getAllStatuses(): array
    {
        $sql = "SELECT id, name, description FROM order_statuses ORDER BY id ASC";
        return $this->fetchAll($sql);
    }

    public function getNextAllowedStatuses(int $currentStatusId): array
    {
        $allowedTransitions = [
            1 => [2],     // Pending -> Confirmed (removed Cancelled option for admin)
            2 => [3],     // Confirmed -> Preparing
            3 => [4],     // Preparing -> Ready to ship
            4 => [5],     // Ready to ship -> Shipping
            5 => [6],     // Shipping -> Delivered
            6 => [7],     // Delivered -> Completed
            7 => [],      // Completed (final)
            8 => []       // Cancelled (final) - only users can set this
        ];

        $nextStatusIds = $allowedTransitions[$currentStatusId] ?? [];
        
        if (empty($nextStatusIds)) {
            return [];
        }

        $placeholders = implode(',', array_fill(0, count($nextStatusIds), '?'));
        $sql = "SELECT id, name FROM order_statuses WHERE id IN ($placeholders) ORDER BY id ASC";
        return $this->fetchAll($sql, $nextStatusIds);
    }
}