<?php  
class ShippingModel extends BaseModel
{
    public function getActiveMethods()
    { 
        $sql = "SELECT * FROM shipping_methods WHERE is_active = 1 ORDER BY fee ASC"; 
        $result = $this->conn->query($sql);
        return $result->fetch_all(MYSQLI_ASSOC); 
    }
 
    public function getMethodById($id) 
    {
        $sql = "SELECT * FROM shipping_methods WHERE id = ?"; 
        $stmt = $this->conn->prepare($sql); 
        $stmt->bind_param("i", $id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    } 

    public function getMethodByName($name)
    {
        $sql = "SELECT * FROM shipping_methods WHERE name = ?";
        $stmt = $this->conn->prepare($sql); 
        $stmt->bind_param("s", $name);
        $stmt->execute(); 
        return $stmt->get_result()->fetch_assoc(); 
    }
}