<?php
class BaseModel
{
    protected mysqli $conn;

    public function __construct(mysqli $conn)
    {
        $this->conn = $conn;
    }

    protected function fetchAll(string $sql, array $params = []): array
    {
        $stmt = $this->prepare($sql, $params);
        if (!$stmt) {
            return [];
        }
        $stmt->execute();
        $result = $stmt->get_result();
        $records = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
        $stmt->close();
        return $records;
    }

    protected function fetchOne(string $sql, array $params = []): ?array
    {
        $stmt = $this->prepare($sql, $params);
        if (!$stmt) {
            return null;
        }
        $stmt->execute();
        $result = $stmt->get_result();
        $record = $result ? $result->fetch_assoc() : null;
        $stmt->close();
        return $record ?: null;
    }

    protected function fetchValue(string $sql, array $params = [])
    {
        $row = $this->fetchOne($sql, $params);
        if (!$row) {
            return null;
        }
        return array_shift($row);
    }

    protected function prepare(string $sql, array $params): ?mysqli_stmt
    {
        $stmt = $this->conn->prepare($sql);
        if (!$stmt) {
            error_log('MySQL prepare error: ' . $this->conn->error);
            return null;
        }
        if (!empty($params)) {
            $types = '';
            $values = [];
            foreach ($params as $param) {
                if (is_int($param)) {
                    $types .= 'i';
                } elseif (is_float($param)) {
                    $types .= 'd';
                } else {
                    $types .= 's';
                }
                $values[] = $param;
            }
            $stmt->bind_param($types, ...$values);
        }
        return $stmt;
    }

    protected function execute(string $sql, array $params = []): bool
    {
        $stmt = $this->prepare($sql, $params);
        if (!$stmt) {
            return false;
        }
        $result = $stmt->execute();
        if (!$result) {
            error_log('MySQL execute error: ' . $stmt->error);
        }
        $stmt->close();
        return $result;
    }
}
