<?php
class UserModel extends BaseModel
{

    protected $table = 'users';

    public function __construct(mysqli $conn)
    {
        parent::__construct($conn);
    }

    public function findByEmail($email)
    {
        $sql = "SELECT id, name, email, password, role, is_locked FROM " . $this->table . " WHERE email = ?";
        $users = $this->fetchAll($sql, [$email]);
        return $users[0] ?? null;
    } 

    public function create($name, $email, $hashed_password) 
    {
        $role = 'customer'; 
        $created_at = date('Y-m-d H:i:s');
        $next_id = $this->getNextId();
        $sql = "INSERT INTO " . $this->table . " (id, name, email, password, role, created_at) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $this->prepare($sql, [$next_id, $name, $email, $hashed_password, $role, $created_at]);
        if (!$stmt) {
            error_log('Failed to prepare statement: ' . $this->conn->error);
            return false;
        } 

        if ($stmt->execute()) {
            $new_id = $this->conn->insert_id ?: $next_id; 
            $stmt->close();
            return $new_id;
        } else {
            error_log('Failed to execute statement: ' . $stmt->error);
            $stmt->close(); 
            return false;
        }
    }

    private function getNextId()
    {
        $sql = "SELECT MAX(id) as max_id FROM " . $this->table; 
        $result = $this->conn->query($sql);
 
        if ($result && $row = $result->fetch_assoc()) { 
            return ($row['max_id'] ?? 0) + 1; 
        }

        return 1;
    }


    public function emailExists($email)
    {
        return $this->findByEmail($email) !== null; 
    }

    public function getUserById($userId)
    {
        $sql = "SELECT id, name, username, email, phone, gender, avatar, role, created_at FROM " . $this->table . " WHERE id = ?";
        $users = $this->fetchAll($sql, [$userId]);
        return $users[0] ?? null; 
    }

    public function updateProfile($userId, $data)
    {
        $fields = []; 
        $values = [];

        if (isset($data['name'])) {
            $fields[] = "name = ?";  
            $values[] = $data['name']; 
        } 
        if (isset($data['username'])) { 
            $fields[] = "username = ?";
            $values[] = $data['username'];
        }
        if (isset($data['email'])) {
            $fields[] = "email = ?";
            $values[] = $data['email'];
        }
        if (isset($data['phone'])) {
            $fields[] = "phone = ?";
            $values[] = $data['phone'];
        }
        if (isset($data['gender'])) {
            $fields[] = "gender = ?";
            $values[] = $data['gender'];
        }

        if (empty($fields)) {
            return false;
        }

        $values[] = $userId;
        $sql = "UPDATE " . $this->table . " SET " . implode(", ", $fields) . " WHERE id = ?";
        $stmt = $this->prepare($sql, $values);

        if ($stmt && $stmt->execute()) {
            $stmt->close();
            return true;
        }

        if ($stmt) {
            $stmt->close();
        }
        return false;
    }

    public function updateAvatar($userId, $avatarPath)
    {
        $sql = "UPDATE " . $this->table . " SET avatar = ? WHERE id = ?";
        $stmt = $this->prepare($sql, [$avatarPath, $userId]);

        if ($stmt && $stmt->execute()) {
            $stmt->close();
            return true;
        }

        if ($stmt) {
            $stmt->close();
        }
        return false;
    }

    public function usernameExists($username, $excludeUserId = null)
    {
        if (empty($username)) {
            return false;
        }

        if ($excludeUserId) {
            $sql = "SELECT id FROM " . $this->table . " WHERE username = ? AND id != ?";
            $users = $this->fetchAll($sql, [$username, $excludeUserId]);
        } else {
            $sql = "SELECT id FROM " . $this->table . " WHERE username = ?";
            $users = $this->fetchAll($sql, [$username]);
        }

        return !empty($users);
    }

    public function getUserAddresses($userId)
    {
        $sql = "SELECT * FROM addresses WHERE user_id = ? ORDER BY is_default DESC, id DESC";
        return $this->fetchAll($sql, [$userId]);
    }

    public function getDefaultAddress($userId)
    {
        $sql = "SELECT * FROM addresses WHERE user_id = ? AND is_default = 1 LIMIT 1";
        $addresses = $this->fetchAll($sql, [$userId]);
        return $addresses[0] ?? null;
    }

    public function saveAddress($userId, $addressData)
    {
        $existingDefault = $this->getDefaultAddress($userId);

        if ($existingDefault) {
            $sql = "UPDATE addresses SET 
                    full_name = ?, 
                    phone = ?, 
                    address_line = ?
                    WHERE id = ?";
            $this->execute($sql, [
                $addressData['name'],
                $addressData['phone'],
                $addressData['address'],
                $existingDefault['id']
            ]);
            return $existingDefault['id'];
        } else {
            $sql = "INSERT INTO addresses (user_id, full_name, phone, address_line, is_default) 
                    VALUES (?, ?, ?, ?, 1)";
            $this->execute($sql, [
                $userId,
                $addressData['name'],
                $addressData['phone'],
                $addressData['address']
            ]);
            return $this->conn->insert_id;
        }
    }

    public function setDefaultAddress($userId, $addressId)
    {
        $sql = "UPDATE addresses SET is_default = 0 WHERE user_id = ?";
        $this->execute($sql, [$userId]);

        $sql = "UPDATE addresses SET is_default = 1 WHERE id = ? AND user_id = ?";
        $this->execute($sql, [$addressId, $userId]);
    }

    public function updateUserPhoneIfEmpty(int $userId, string $phone): bool
    {
        if (empty($phone)) {
            return false;
        }

        $currentUser = $this->getUserById($userId);
        if ($currentUser && empty($currentUser['phone'])) {
            $sql = "UPDATE users SET phone = ? WHERE id = ?";
            return $this->execute($sql, [$phone, $userId]);
        }

        return false;
    }

    public function countAllUsers(): int
    {
        $sql = "SELECT COUNT(*) as count FROM users WHERE role != 'admin'";
        $result = $this->fetchAll($sql);
        return (int)($result[0]['count'] ?? 0);
    }

    public function getAllUsers()
    {
        $sql = "SELECT id, name, email, phone, gender, birthdate, role, is_locked, created_at FROM " . $this->table . " ORDER BY created_at DESC";
        return $this->fetchAll($sql);
    }

    public function toggleUserLock($userId, $status)
    {
        $sql = "UPDATE " . $this->table . " SET is_locked = ? WHERE id = ?";
        return $this->execute($sql, [$status, $userId]);
    }
}