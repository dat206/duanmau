<?php
class WishlistModel extends BaseModel
{
    protected string $table = 'wishlist';

    public function __construct(mysqli $conn)
    {
        parent::__construct($conn);
    }

    public function addToWishlist(int $userId, int $shoeId): bool
    { 
        $sql = "INSERT INTO {$this->table} (user_id, shoe_id, created_at) 
                VALUES (?, ?, NOW())
                ON DUPLICATE KEY UPDATE created_at = NOW()";
        return $this->execute($sql, [$userId, $shoeId]);
    } 

    public function removeFromWishlist(int $userId, int $shoeId): bool
    {  
        $sql = "DELETE FROM {$this->table} WHERE user_id = ? AND shoe_id = ?";
        return $this->execute($sql, [$userId, $shoeId]); 
    }

    public function isInWishlist(int $userId, int $shoeId): bool
    {
        $sql = "SELECT COUNT(*) as count FROM {$this->table} WHERE user_id = ? AND shoe_id = ?";
        $result = $this->fetchOne($sql, [$userId, $shoeId]);
        return ($result['count'] ?? 0) > 0;
    }

    public function getWishlistProducts(int $userId): array
    {
        $sql = " 
            SELECT s.id, s.name, s.product_code, s.category_id,
                   c.name AS category_name, sv.price, sv.main_image,
                   w.created_at as added_at
            FROM {$this->table} w
            JOIN shoes s ON s.id = w.shoe_id
            JOIN categories c ON c.id = s.category_id
            JOIN shoe_variants sv ON sv.shoe_id = s.id
            WHERE w.user_id = ?
            GROUP BY s.id
            ORDER BY w.created_at DESC
        ";
        return $this->fetchAll($sql, [$userId]);
    }

    public function getWishlistCount(int $userId): int
    {
        $sql = "SELECT COUNT(*) as count FROM {$this->table} WHERE user_id = ?";
        $result = $this->fetchOne($sql, [$userId]);
        return (int)($result['count'] ?? 0);
    }


    public function clearWishlist(int $userId): bool
    {
        $sql = "DELETE FROM {$this->table} WHERE user_id = ?";
        return $this->execute($sql, [$userId]);
    }

    public function getWishlistProductIds(int $userId): array
    {
        $sql = "SELECT shoe_id FROM {$this->table} WHERE user_id = ?";
        $results = $this->fetchAll($sql, [$userId]);
        return array_column($results, 'shoe_id');
    }
}