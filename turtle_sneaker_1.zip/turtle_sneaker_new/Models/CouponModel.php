<?php
class CouponModel extends BaseModel 
{
    public function getAllCoupons()
    {
        $sql = "SELECT * FROM coupons WHERE deleted_at IS NULL ORDER BY id DESC";  
        $result = $this->conn->query($sql); 
        return $result->fetch_all(MYSQLI_ASSOC);
    }
 
    public function getCouponById($id)
    {  
        $sql = "SELECT * FROM coupons WHERE id = ?";
        $stmt = $this->conn->prepare($sql); 
        $stmt->bind_param("i", $id);
        $stmt->execute(); 
        return $stmt->get_result()->fetch_assoc();   
    }
 
    public function createCoupon($data)
    {
        $sql = "INSERT INTO coupons (code, discount_amount, type, min_order_value, quantity, used_count, is_active, expiration_date) VALUES (?, ?, ?, ?, ?, 0, ?, ?)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param(
            "sdsdiis",
            $data['code'], 
            $data['discount_amount'],
            $data['type'],
            $data['min_order_value'],
            $data['quantity'], 
            $data['is_active'],
            $data['expiration_date']
        );
        return $stmt->execute(); 
    }

    public function updateCoupon($id, $data)
    {
        $sql = "UPDATE coupons SET code = ?, discount_amount = ?, type = ?, min_order_value = ?, quantity = ?, is_active = ?, expiration_date = ? WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param(
            "sdsdiisi", 
            $data['code'],
            $data['discount_amount'], 
            $data['type'], 
            $data['min_order_value'], 
            $data['quantity'], 
            $data['is_active'], 
            $data['expiration_date'], 
            $id
        );
        return $stmt->execute();
    }

    public function deleteCoupon($id)
    {
        $sql = "UPDATE coupons SET deleted_at = NOW() WHERE id = ?";
        $stmt = $this->conn->prepare($sql); 
        $stmt->bind_param("i", $id);
        return $stmt->execute();
    } 

    public function getTrashedCoupons()
    {
        $sql = "SELECT * FROM coupons WHERE deleted_at IS NOT NULL ORDER BY deleted_at DESC";
        $result = $this->conn->query($sql);
        return $result->fetch_all(MYSQLI_ASSOC);
    } 

    public function restoreCoupon($id)
    {
        $sql = "UPDATE coupons SET deleted_at = NULL WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $id); 
        return $stmt->execute();
    }

    public function forceDeleteCoupon($id) 
    {
        $sql = "DELETE FROM coupons WHERE id = ?";
        $stmt = $this->conn->prepare($sql); 
        $stmt->bind_param("i", $id);
        return $stmt->execute();
    }

    public function checkCouponCode($code)
    {
        $sql = "SELECT * FROM coupons WHERE code = ? AND deleted_at IS NULL";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("s", $code);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc(); 
    }

    public function getValidCoupons()
    {
        $now = date('Y-m-d H:i:s');
        $sql = "SELECT * FROM coupons WHERE is_active = 1 AND expiration_date > ? AND quantity > used_count AND deleted_at IS NULL";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("s", $now);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    public function codeExists($code, $excludeId = null)
    {
        if ($excludeId) {
            $sql = "SELECT COUNT(*) as count FROM coupons WHERE UPPER(code) = UPPER(?) AND id != ? AND deleted_at IS NULL";
            $stmt = $this->conn->prepare($sql);
            $stmt->bind_param("si", $code, $excludeId);
        } else {
            $sql = "SELECT COUNT(*) as count FROM coupons WHERE UPPER(code) = UPPER(?) AND deleted_at IS NULL";
            $stmt = $this->conn->prepare($sql);
            $stmt->bind_param("s", $code);
        }
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        return ($result['count'] ?? 0) > 0;
    }


    public function incrementUsedCount($code)
    {
        $sql = "UPDATE coupons SET used_count = used_count + 1 WHERE code = ? AND deleted_at IS NULL";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("s", $code);
        $result = $stmt->execute();
        
        // Log for debugging
        if ($result) {
            error_log("Coupon used_count incremented for code: " . $code);
        } else {
            error_log("Failed to increment used_count for code: " . $code . " - Error: " . $this->conn->error);
        }
        
        return $result;
    }
}