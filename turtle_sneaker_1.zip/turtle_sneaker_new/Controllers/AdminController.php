<?php
class AdminController
{
    private $productModel;
    private $orderModel;
    private $userModel;
    private $categoryModel;
    private $reviewModel;
    private $couponModel;

    public function __construct($productModel = null, $orderModel = null, $userModel = null, $categoryModel = null, $reviewModel = null, $couponModel = null)
    {
        $this->checkAdminAccess();
        $this->productModel = $productModel;
        $this->orderModel = $orderModel;
        $this->userModel = $userModel;
        $this->categoryModel = $categoryModel;
        $this->reviewModel = $reviewModel;
        $this->couponModel = $couponModel;
    }

    private function checkAdminAccess()
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
            header('Location: index.php?controller=auth&action=login');
            exit();
        }
    }

    public function dashboard()
    {
        $productCount = $this->productModel->countAllProducts();
        $orderCount = $this->orderModel->countAllOrders();
        $customerCount = $this->userModel ? $this->userModel->countAllUsers() : 0;
        $revenue = $this->orderModel->calculateTotalRevenue();

        $todayRevenue = $this->orderModel->getTodayRevenue();
        $weekRevenue = $this->orderModel->getWeekRevenue();
        $monthRevenue = $this->orderModel->getMonthRevenue();
        $yearRevenue = $this->orderModel->getYearRevenue();

        $pendingOrders = $this->orderModel->countOrdersByStatus(1);
        $shippingOrders = $this->orderModel->countOrdersByStatus(5);
        $completedOrders = $this->orderModel->countOrdersByStatus(7);

        $dailyRevenueData = $this->orderModel->getDailyRevenue(30);
        $chartLabels = [];
        $chartData = [];

        $startDate = date('Y-m-d', strtotime('-29 days'));
        $endDate = date('Y-m-d');
        $currentDate = $startDate;
        $revenueMap = [];

        foreach ($dailyRevenueData as $item) {
            $revenueMap[$item['date']] = (float)$item['revenue'];
        }

        while ($currentDate <= $endDate) {
            $chartLabels[] = date('d/m', strtotime($currentDate));
            $chartData[] = $revenueMap[$currentDate] ?? 0;
            $currentDate = date('Y-m-d', strtotime($currentDate . ' +1 day'));
        }

        $chartLabelsJson = json_encode($chartLabels);
        $chartDataJson = json_encode($chartData);

        $monthlyRevenueData = $this->orderModel->getMonthlyRevenue(12);
        $monthlyLabels = []; 
        $monthlyData = [];

        $monthlyMap = [];
        foreach ($monthlyRevenueData as $item) {
            $monthlyMap[$item['month']] = (float)$item['revenue'];
        }
 
        for ($i = 11; $i >= 0; $i--) {
            $month = date('Y-m', strtotime("-$i months"));
            $monthLabel = date('m/Y', strtotime("-$i months")); 
            $monthlyLabels[] = $monthLabel;
            $monthlyData[] = $monthlyMap[$month] ?? 0;
        } 

        $monthlyLabelsJson = json_encode($monthlyLabels); 
        $monthlyDataJson = json_encode($monthlyData);

        include __DIR__ . '/../views/admin/dashboard.php';
    }

    public function products()
    { 
        $products = $this->productModel->getAllProducts();
        include __DIR__ . '/../views/admin/products/index.php';
    } 

    public function createProduct() 
    {
        $categories = $this->productModel->getCategories();  
        $sizes = $this->productModel->getAllSizes(); 
        include __DIR__ . '/../views/admin/products/create.php';
    } 

    public function storeProduct()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $imagePath = '';
            if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
                $uploadDir = __DIR__ . '/../public/uploads/';
                if (!is_dir($uploadDir)) { 
                    mkdir($uploadDir, 0777, true);
                }
                $fileName = time() . '_' . basename($_FILES['image']['name']); 
                $targetPath = $uploadDir . $fileName;
                if (move_uploaded_file($_FILES['image']['tmp_name'], $targetPath)) {
                    $imagePath = 'public/uploads/' . $fileName;
                }
            }
  
            // Parse colors from comma-separated string 
            $colorsString = $_POST['colors'] ?? '';
            $colors = array_filter(array_map('trim', explode(',', $colorsString)));
            
            // Get sizes from checkboxes
            $sizes = $_POST['sizes'] ?? [];

            $data = [
                'name' => $_POST['name'],
                'product_code' => $_POST['product_code'],
                'category_id' => $_POST['category_id'],
                'description' => $_POST['description'], 
                'price' => $_POST['price'],
                'main_image' => $imagePath, 
                'colors' => $colors,
                'sizes' => $sizes
            ]; 
            
            $this->productModel->createProduct($data);
            
            $_SESSION['alert'] = [
                'type' => 'success',
                'message' => 'Thêm sản phẩm thành công!'
            ];
            
            header('Location: index.php?controller=admin&action=products');
            exit;
        }
    }

    public function editProduct($id = null)
    {
        $id = $id !== null ? (int)$id : (isset($_GET['id']) ? (int)$_GET['id'] : 0);
        $product = $this->productModel->getProductById($id);
        $categories = $this->productModel->getCategories();

        $sizes = $this->productModel->getAllSizes();

        $productColors = $this->productModel->getProductColors($id);
        $productSizesRaw = $this->productModel->getProductSizes($id);
        $productSizes = array_column($productSizesRaw, 'value');

        if (!$product) {
            header('Location: index.php?controller=admin&action=products');
            exit;
        }
        include __DIR__ . '/../views/admin/products/edit.php';
    }

    public function updateProduct($id = null)
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = $id !== null ? (int)$id : (isset($_GET['id']) ? (int)$_GET['id'] : 0);

            $imagePath = $_POST['current_image'] ?? '';
            if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
                $uploadDir = __DIR__ . '/../public/uploads/';
                if (!is_dir($uploadDir)) {
                    mkdir($uploadDir, 0777, true);
                }
                $fileName = time() . '_' . basename($_FILES['image']['name']);
                $targetPath = $uploadDir . $fileName;
                if (move_uploaded_file($_FILES['image']['tmp_name'], $targetPath)) {
                    $imagePath = 'public/uploads/' . $fileName;
                }
            }
            
            // Parse colors from comma-separated string
            $colorsString = $_POST['colors'] ?? '';
            $colors = array_filter(array_map('trim', explode(',', $colorsString)));
            
            // Get sizes from checkboxes
            $sizes = $_POST['sizes'] ?? [];
            
            $data = [
                'name' => $_POST['name'],
                'product_code' => $_POST['product_code'],
                'category_id' => $_POST['category_id'],
                'description' => $_POST['description'],
                'price' => $_POST['price'],
                'main_image' => $imagePath,
                'colors' => $colors,
                'sizes' => $sizes
            ];
            
            $this->productModel->updateProduct($id, $data);
            
            $_SESSION['alert'] = [
                'type' => 'success',
                'message' => 'Cập nhật sản phẩm thành công!'
            ];
            
            header('Location: index.php?controller=admin&action=products');
            exit;
        }
    }

    public function deleteProduct($id = null)
    {
        $id = $id !== null ? (int)$id : (isset($_GET['id']) ? (int)$_GET['id'] : 0);
        $result = $this->productModel->deleteProduct($id);

        if (!$result) {
            $_SESSION['alert'] = [
                'type' => 'error',
                'message' => 'Không thể xóa sản phẩm này vì đã có đơn hàng!'
            ];
        } else {
            $_SESSION['alert'] = [
                'type' => 'success',
                'message' => 'Xóa sản phẩm thành công!'
            ];
        }

        header('Location: index.php?controller=admin&action=products');
        exit;
    }

    public function orders()
    {
        $perPage = 10;
        $currentPage = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
        $totalOrders = $this->orderModel->countAllOrders();
        $totalPages = max(1, (int)ceil($totalOrders / $perPage));

        if ($currentPage > $totalPages) {
            $currentPage = $totalPages;
        }

        $offset = ($currentPage - 1) * $perPage;

        $orders = $this->orderModel->getAllOrdersWithDetailsPaginated($perPage, $offset);
        $allStatuses = $this->orderModel->getAllStatuses();
        $orderModel = $this->orderModel; // Pass to view

        include __DIR__ . '/../views/admin/orders/index.php';
    }

    public function orderDetail($id = null)
    {
        // Get ID from parameter (router) or GET (backward compatibility)
        $orderId = $id !== null ? (int)$id : (isset($_GET['id']) ? (int)$_GET['id'] : 0);
        $order = $this->orderModel->getOrderDetailById($orderId);

        if (!$order) {
            $_SESSION['alert'] = [
                'type' => 'error',
                'message' => 'Không tìm thấy đơn hàng!'
            ];
            header('Location: index.php?controller=admin&action=orders');
            exit;
        }

        include __DIR__ . '/../views/admin/orders/order_detail.php';
    }

    public function updateOrderStatus()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: index.php?controller=admin&action=orders');
            exit;
        }

        $orderId = $_POST['order_id'] ?? 0;
        $newStatusId = $_POST['status_id'] ?? 0;

        // Prevent admin from manually setting status to "Đã hoàn thành" (7)
        // Only user confirmation should trigger this status
        if ($newStatusId == 7) {
            $isAjax = isset($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false;
            
            if ($isAjax) {
                header('Content-Type: application/json');
                echo json_encode([
                    'success' => false,
                    'message' => 'Không thể thay đổi sang trạng thái "Đã hoàn thành". Chỉ khách hàng mới có thể xác nhận đã nhận hàng!'
                ]);
                exit;
            }
            
            $_SESSION['alert'] = [
                'type' => 'error',
                'message' => 'Không thể thay đổi sang trạng thái "Đã hoàn thành". Chỉ khách hàng mới có thể xác nhận đã nhận hàng!'
            ];
            
            header('Location: index.php?controller=admin&action=orderDetail&id=' . $orderId);
            exit;
        }

        // TEMPORARILY DISABLED FOR DEBUGGING
        /*
        // Check if order uses VNPay and payment is still pending
        $payment = null;
        try {
            require_once __DIR__ . '/../models/PaymentModel.php';
            $paymentModel = new PaymentModel($this->conn);
            $payment = $paymentModel->getByOrderId($orderId);
        } catch (Exception $e) {
            // If payment check fails, allow status update (for backward compatibility)
        }
        
        // Only block if payment exists, is VNPay, and is not paid
        if ($payment && isset($payment['method']) && $payment['method'] === 'vnpay' && $payment['status'] !== 'Paid') {
            // VNPay order not yet paid - admin cannot change status
            $isAjax = isset($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false;
            
            if ($isAjax) {
                header('Content-Type: application/json');
                echo json_encode([
                    'success' => false,
                    'message' => 'Không thể thay đổi trạng thái đơn hàng VNPay chưa thanh toán!'
                ]);
                exit;
            }
            
            $_SESSION['alert'] = [
                'type' => 'error',
                'message' => 'Không thể thay đổi trạng thái đơn hàng VNPay chưa thanh toán!'
            ];
            
            header('Location: index.php?controller=admin&action=orderDetail&id=' . $orderId);
            exit;
        }
        */

        $result = $this->orderModel->updateOrderStatus($orderId, $newStatusId);

        $isAjax = isset($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false;

        if ($isAjax) {
            header('Content-Type: application/json');
            echo json_encode([
                'success' => $result,
                'message' => $result ? 'Cập nhật trạng thái đơn hàng thành công!' : 'Không thể cập nhật trạng thái!'
            ]);
            exit;
        }

        $_SESSION['alert'] = [
            'type' => $result ? 'success' : 'error',
            'message' => $result ? 'Cập nhật trạng thái đơn hàng thành công!' : 'Không thể cập nhật trạng thái!'
        ];

        header('Location: index.php?controller=admin&action=orderDetail&id=' . $orderId);
        exit;
    }

    public function retryVnpayPayment()
    {
        $orderId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        if ($orderId <= 0) {
            $_SESSION['alert'] = ['type' => 'error', 'message' => 'Đơn hàng không hợp lệ!'];
            header('Location: index.php?controller=admin&action=orders');
            exit;
        }

        $order = $this->orderModel->getOrderPaymentInfo($orderId);
        if (!$order) {
            $_SESSION['alert'] = ['type' => 'error', 'message' => 'Không tìm thấy đơn hàng!'];
            header('Location: index.php?controller=admin&action=orders');
            exit;
        }

        if (($order['payment_method'] ?? '') !== 'vnpay') {
            $_SESSION['alert'] = ['type' => 'error', 'message' => 'Đơn hàng này không sử dụng VNPay!'];
            header('Location: index.php?controller=admin&action=orders');
            exit;
        }
        if ((int)($order['current_status_id'] ?? 0) === 8) {
            $_SESSION['alert'] = ['type' => 'error', 'message' => 'Đơn hàng đã bị hủy, không thể tiếp tục thanh toán!'];
            header('Location: index.php?controller=admin&action=orders');
            exit;
        }

        $reflection = new ReflectionClass($this->orderModel);
        $property = $reflection->getProperty('conn');
        $property->setAccessible(true);
        $conn = $property->getValue($this->orderModel);

        require_once __DIR__ . '/../models/PaymentModel.php';
        $paymentModel = new PaymentModel($conn);
        $payment = $paymentModel->getByOrderId($orderId);
        if ($payment && ($payment['status'] ?? '') === 'Paid') {
            $_SESSION['alert'] = ['type' => 'info', 'message' => 'Đơn hàng này đã được thanh toán.'];
            header('Location: index.php?controller=admin&action=orders');
            exit;
        }

        $amount = (float)($order['total_amount'] ?? 0);
        if ($amount <= 0) {
            $_SESSION['alert'] = ['type' => 'error', 'message' => 'Tổng tiền đơn hàng không hợp lệ!'];
            header('Location: index.php?controller=admin&action=orders');
            exit;
        }

        require_once __DIR__ . '/../models/PaymentModel.php';
        $paymentModel = new PaymentModel($conn);
        $paymentId = $paymentModel->createPayment($orderId, 'vnpay', 'Pending');
        if ($paymentId <= 0) {
            $_SESSION['alert'] = ['type' => 'error', 'message' => 'Không thể khởi tạo thanh toán VNPay.'];
            header('Location: index.php?controller=admin&action=orders');
            exit;
        }

        $vnpayUrl = $this->createVnpayPaymentUrl($paymentId, $amount, $orderId);
        header("Location: " . $vnpayUrl);
        exit;
    }

    private function createVnpayPaymentUrl(int $paymentId, float $amount, int $orderId): string
    {
        require_once __DIR__ . '/../vnpay_php/config.php';

        $vnp_TxnRef = $paymentId;
        $vnp_Amount = $amount * 100;
        $vnp_Locale = 'vn';
        $vnp_BankCode = '';
        $vnp_IpAddr = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';

        $protocol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http");
        $host = $_SERVER['HTTP_HOST'];
        $scriptPath = dirname($_SERVER['SCRIPT_NAME']);
        $basePath = rtrim($scriptPath, '/');
        $vnp_Returnurl = $protocol . "://" . $host . $basePath . "/vnpay_php/vnpay_return.php";

        $inputData = [
            "vnp_Version"   => "2.1.0",
            "vnp_TmnCode"   => $vnp_TmnCode,
            "vnp_Amount"    => $vnp_Amount,
            "vnp_Command"   => "pay",
            "vnp_CreateDate" => date('YmdHis'),
            "vnp_CurrCode"  => "VND",
            "vnp_IpAddr"    => $vnp_IpAddr,
            "vnp_Locale"    => $vnp_Locale,
            "vnp_OrderInfo" => "Thanh toan don hang #" . $orderId,
            "vnp_OrderType" => "other",
            "vnp_ReturnUrl" => $vnp_Returnurl,
            "vnp_TxnRef"    => $vnp_TxnRef,
            "vnp_ExpireDate" => date('YmdHis', strtotime('+15 minutes'))
        ];

        if (!empty($vnp_BankCode)) {
            $inputData['vnp_BankCode'] = $vnp_BankCode;
        }

        ksort($inputData);
        $query = "";
        $i = 0;
        $hashdata = "";
        foreach ($inputData as $key => $value) {
            if ($i == 1) {
                $hashdata .= '&' . urlencode($key) . "=" . urlencode($value);
            } else {
                $hashdata .= urlencode($key) . "=" . urlencode($value);
                $i = 1;
            }
            $query .= urlencode($key) . "=" . urlencode($value) . '&';
        }

        $vnp_Url = $vnp_Url . "?" . $query;
        if (isset($vnp_HashSecret)) {
            $vnpSecureHash = hash_hmac('sha512', $hashdata, $vnp_HashSecret);
            $vnp_Url .= 'vnp_SecureHash=' . $vnpSecureHash;
        }

        return $vnp_Url;
    }

    public function comments()
    {
        $reviews = $this->reviewModel->getAllReviews();
        include __DIR__ . '/../views/admin/comments/index.php';
    }

    public function updateCommentStatus($id = null)
    {
        $id = $id !== null ? (int)$id : (isset($_GET['id']) ? (int)$_GET['id'] : 0);
        $status = $_GET['status'] ?? 'pending';

        if ($this->reviewModel->updateReviewStatus($id, $status)) {
            $_SESSION['alert'] = [
                'type' => 'success',
                'message' => 'Cập nhật trạng thái bình luận thành công!'
            ];
        } else {
            $_SESSION['alert'] = [
                'type' => 'error',
                'message' => 'Có lỗi xảy ra!'
            ];
        }

        header('Location: index.php?controller=admin&action=comments');
        exit;
    }

    public function deleteComment($id = null)
    {
        $id = $id !== null ? (int)$id : (isset($_GET['id']) ? (int)$_GET['id'] : 0);

        if ($this->reviewModel->deleteReview($id)) {
            $_SESSION['alert'] = [
                'type' => 'success',
                'message' => 'Xóa bình luận thành công!'
            ];
        } else {
            $_SESSION['alert'] = [
                'type' => 'error',
                'message' => 'Có lỗi xảy ra!'
            ];
        }

        header('Location: index.php?controller=admin&action=comments');
        exit;
    }

    public function categories()
    {
        $categories = $this->categoryModel->getAllCategories();

        foreach ($categories as $key => $category) {
            $categories[$key]['product_count'] = $this->categoryModel->getCategoryProductCount($category['id']);
        }

        include __DIR__ . '/../views/admin/categories/index.php';
    }

    public function createCategory()
    {
        include __DIR__ . '/../views/admin/categories/create.php';
    }

    public function storeCategory()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = [
                'name' => $_POST['name'],
                'description' => $_POST['description'] ?? ''
            ];

            $this->categoryModel->createCategory($data);

            $_SESSION['alert'] = [
                'type' => 'success',
                'message' => 'Thêm danh mục thành công!'
            ];

            header('Location: index.php?controller=admin&action=categories');
            exit;
        }
    }

    public function editCategory($id = null)
    {
        $id = $id !== null ? (int)$id : (isset($_GET['id']) ? (int)$_GET['id'] : 0);
        $category = $this->categoryModel->getCategoryById($id);

        if (!$category) {
            header('Location: index.php?controller=admin&action=categories');
            exit;
        }

        include __DIR__ . '/../views/admin/categories/edit.php';
    }

    public function updateCategory($id = null)
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = $id !== null ? (int)$id : (isset($_GET['id']) ? (int)$_GET['id'] : 0);
            $data = [
                'name' => $_POST['name'],
                'description' => $_POST['description'] ?? ''
            ];

            $this->categoryModel->updateCategory($id, $data);

            $_SESSION['alert'] = [
                'type' => 'success',
                'message' => 'Cập nhật danh mục thành công!'
            ];

            header('Location: index.php?controller=admin&action=categories');
            exit;
        }
    }

    public function deleteCategory($id = null)
    {
        $id = $id !== null ? (int)$id : (isset($_GET['id']) ? (int)$_GET['id'] : 0);
        $result = $this->categoryModel->deleteCategory($id);

        if ($result) {
            $_SESSION['alert'] = [
                'type' => 'success',
                'message' => 'Xóa danh mục thành công!'
            ];
        } else {
            $_SESSION['alert'] = [
                'type' => 'error',
                'message' => 'Không thể xóa danh mục này vì còn sản phẩm đang sử dụng!'
            ];
        }

        header('Location: index.php?controller=admin&action=categories');
        exit;
    }

    public function coupons()
    {
        $coupons = $this->couponModel->getAllCoupons();
        include __DIR__ . '/../views/admin/coupons/index.php';
    }

    public function createCoupon()
    {
        include __DIR__ . '/../views/admin/coupons/create.php';
    }

    public function storeCoupon()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = [
                'code' => $_POST['code'],
                'discount_amount' => $_POST['discount_amount'],
                'type' => $_POST['type'],
                'min_order_value' => $_POST['min_order_value'],
                'quantity' => $_POST['quantity'],
                'is_active' => isset($_POST['is_active']) ? 1 : 0,
                'expiration_date' => $_POST['expiration_date']
            ];

            // Check if code already exists
            if ($this->couponModel->codeExists($data['code'])) {
                $_SESSION['alert'] = [
                    'type' => 'error',
                    'message' => 'Mã giảm giá "' . htmlspecialchars($data['code']) . '" đã tồn tại. Vui lòng chọn mã khác.'
                ];
                header('Location: index.php?controller=admin&action=createCoupon');
                exit;
            }

            if ($this->couponModel->createCoupon($data)) {
                $_SESSION['alert'] = ['type' => 'success', 'message' => 'Tạo mã giảm giá thành công!'];
            } else {
                $_SESSION['alert'] = ['type' => 'error', 'message' => 'Có lỗi xảy ra!'];
            }

            header('Location: index.php?controller=admin&action=coupons');
        }
    }

    public function editCoupon($id = null)
    {
        $id = $id !== null ? (int)$id : (isset($_GET['id']) ? (int)$_GET['id'] : 0);
        $coupon = $this->couponModel->getCouponById($id);

        if (!$coupon) {
            header('Location: index.php?controller=admin&action=coupons');
            exit;
        }

        include __DIR__ . '/../views/admin/coupons/edit.php';
    }

    public function updateCoupon($id = null)
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = $id !== null ? (int)$id : (isset($_GET['id']) ? (int)$_GET['id'] : 0);
            $data = [
                'code' => $_POST['code'],
                'discount_amount' => $_POST['discount_amount'],
                'type' => $_POST['type'],
                'min_order_value' => $_POST['min_order_value'],
                'quantity' => $_POST['quantity'],
                'is_active' => isset($_POST['is_active']) ? 1 : 0,
                'expiration_date' => $_POST['expiration_date']
            ];

            // Check if code already exists (excluding current coupon)
            if ($this->couponModel->codeExists($data['code'], $id)) {
                $_SESSION['alert'] = [
                    'type' => 'error',
                    'message' => 'Mã giảm giá "' . htmlspecialchars($data['code']) . '" đã tồn tại. Vui lòng chọn mã khác.'
                ];
                header('Location: index.php?controller=admin&action=editCoupon&id=' . $id);
                exit;
            }

            if ($this->couponModel->updateCoupon($id, $data)) {
                $_SESSION['alert'] = ['type' => 'success', 'message' => 'Cập nhật mã giảm giá thành công!'];
            } else {
                $_SESSION['alert'] = ['type' => 'error', 'message' => 'Có lỗi xảy ra!'];
            }

            header('Location: index.php?controller=admin&action=coupons');
        }
    }

    public function deleteCoupon($id = null)
    {
        $id = $id !== null ? (int)$id : (isset($_GET['id']) ? (int)$_GET['id'] : 0);

        if ($this->couponModel->deleteCoupon($id)) {
            $_SESSION['alert'] = ['type' => 'success', 'message' => 'Xóa mã giảm giá thành công!'];
        } else {
            $_SESSION['alert'] = ['type' => 'error', 'message' => 'Có lỗi xảy ra!'];
        }

        header('Location: index.php?controller=admin&action=coupons');
        exit;
    }

    public function users()
    {
        $users = $this->userModel->getAllUsers();
        include __DIR__ . '/../views/admin/users/index.php';
    }

    public function toggleUserLock($id = null)
    {
        // Get ID from parameter or GET
        $id = $id !== null ? (int)$id : (isset($_GET['id']) ? (int)$_GET['id'] : 0);
        $status = isset($_GET['status']) ? (int)$_GET['status'] : 0;

        if ($id == $_SESSION['user_id']) {
            $_SESSION['alert'] = ['type' => 'error', 'message' => 'Bạn không thể khóa chính mình!'];
            header('Location: ' . route('admin.users'));
            exit;
        }

        if ($this->userModel->toggleUserLock($id, $status)) {
            $msg = $status == 1 ? 'Đã khóa tài khoản thành công!' : 'Đã mở khóa tài khoản thành công!';
            $_SESSION['alert'] = ['type' => 'success', 'message' => $msg];
        } else {
            $_SESSION['alert'] = ['type' => 'error', 'message' => 'Có lỗi xảy ra!'];
        }

        header('Location: ' . route('admin.users'));
        exit;
    }

    public function trash()
    {
        $type = $_GET['type'] ?? 'products';

        $trashedProducts = $this->productModel->getTrashedProducts();
        $trashedCategories = $this->categoryModel->getTrashedCategories();
        $trashedCoupons = $this->couponModel->getTrashedCoupons();

        include __DIR__ . '/../views/admin/trash/index.php';
    }

    public function restoreProduct($id = null)
    {
        $id = $id !== null ? (int)$id : (isset($_GET['id']) ? (int)$_GET['id'] : 0);

        if ($this->productModel->restoreProduct($id)) {
            $_SESSION['alert'] = ['type' => 'success', 'message' => 'Khôi phục sản phẩm thành công!'];
        } else {
            $_SESSION['alert'] = ['type' => 'error', 'message' => 'Có lỗi xảy ra!'];
        }
        header('Location: index.php?controller=admin&action=trash&type=products');
        exit;
    }

    public function forceDeleteProduct($id = null)
    {
        $id = $id !== null ? (int)$id : (isset($_GET['id']) ? (int)$_GET['id'] : 0);
        if ($this->productModel->forceDeleteProduct($id)) {
            $_SESSION['alert'] = ['type' => 'success', 'message' => 'Xóa sản phẩm vĩnh viễn thành công!'];
        } else {
            $_SESSION['alert'] = ['type' => 'error', 'message' => 'Có lỗi xảy ra!'];
        }
        header('Location: index.php?controller=admin&action=trash&type=products');
        exit;
    }

    public function restoreCategory($id = null)
    {
        $id = $id !== null ? (int)$id : (isset($_GET['id']) ? (int)$_GET['id'] : 0);

        if ($this->categoryModel->restoreCategory($id)) {
            $_SESSION['alert'] = ['type' => 'success', 'message' => 'Khôi phục danh mục thành công!'];
        } else {
            $_SESSION['alert'] = ['type' => 'error', 'message' => 'Có lỗi xảy ra!'];
        }
        header('Location: index.php?controller=admin&action=trash&type=categories');
        exit;
    }

    public function forceDeleteCategory($id = null)
    {
        $id = $id !== null ? (int)$id : (isset($_GET['id']) ? (int)$_GET['id'] : 0);
        if ($this->categoryModel->forceDeleteCategory($id)) {
            $_SESSION['alert'] = ['type' => 'success', 'message' => 'Xóa danh mục vĩnh viễn thành công!'];
        } else {
            $_SESSION['alert'] = ['type' => 'error', 'message' => 'Có lỗi xảy ra!'];
        }
        header('Location: index.php?controller=admin&action=trash&type=categories');
        exit;
    }

    public function restoreCoupon($id = null)
    {
        $id = $id !== null ? (int)$id : (isset($_GET['id']) ? (int)$_GET['id'] : 0);

        if ($this->couponModel->restoreCoupon($id)) {
            $_SESSION['alert'] = ['type' => 'success', 'message' => 'Khôi phục mã giảm giá thành công!'];
        } else {
            $_SESSION['alert'] = ['type' => 'error', 'message' => 'Có lỗi xảy ra!'];
        }

        header('Location: index.php?controller=admin&action=trash&type=coupons');
        exit;
    }

    public function forceDeleteCoupon($id = null)
    {
        $id = $id !== null ? (int)$id : (isset($_GET['id']) ? (int)$_GET['id'] : 0);
        if ($this->couponModel->forceDeleteCoupon($id)) {
            $_SESSION['alert'] = ['type' => 'success', 'message' => 'Xóa mã giảm giá vĩnh viễn thành công!'];
        } else {
            $_SESSION['alert'] = ['type' => 'error', 'message' => 'Có lỗi xảy ra!'];
        }
        header('Location: index.php?controller=admin&action=trash&type=coupons');
        exit;
    }
}