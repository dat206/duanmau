<?php
class HomeController
{ 
    private ProductModel $productModel; 
    public function __construct(ProductModel $productModel) 
    {
        $this->productModel = $productModel; 
    } 

    public function index(): void 
    {
        $heroProducts = $this->productModel->getHeroProducts(4);
        $hotProducts = $this->productModel->getHotProducts(8);
        $sneakerProducts = $this->productModel->getProductsByCategoryName('Giày Sneaker', 8);
 

        $categories = $this->productModel->getCategories();
        $wishlistedProductIds = [];
        if (isset($_SESSION['user_id'])) { 
            require_once __DIR__ . '/../models/WishlistModel.php';
            global $conn;
            $wishlistModel = new WishlistModel($conn);
            $wishlistedProductIds = $wishlistModel->getWishlistProductIds($_SESSION['user_id']);
        }
        require_once __DIR__ . '/../views/layouts/header.php';
        require_once __DIR__ . '/../views/home/index.php';
        require_once __DIR__ . '/../views/layouts/footer.php'; 
    }
}