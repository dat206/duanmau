<?php
class UserController
{
    private $userModel;
    public $productModel;
    public $wishlistModel;
    public $reviewModel;

    public function __construct($userModel)
    {
        $this->userModel = $userModel;
    }

    public function profile()
    {
        if (!isset($_SESSION['user_id'])) {
            header('Location: index.php?controller=auth&action=login');
            exit();
        }

        $userId = $_SESSION['user_id'];
        $user = $this->userModel->getUserById($userId);
        $defaultAddress = $this->userModel->getDefaultAddress($userId);

        if (!$user) {
            $_SESSION['error_messages'] = ['Không tìm thấy thông tin người dùng. User ID: ' . $userId];
            $user = [
                'id' => $userId,
                'name' => $_SESSION['name'] ?? '',
                'email' => $_SESSION['email'] ?? '',
                'phone' => '',
                'gender' => '',
                'avatar' => '',
                'username' => ''
            ];
        }
        $categories = [];
        if (isset($this->productModel)) {
            $categories = $this->productModel->getCategories();
        }

        include __DIR__ . '/../views/user/profile.php';
    }

    public function edit()
    {
        if (!isset($_SESSION['user_id'])) {
            header('Location: index.php?controller=auth&action=login');
            exit();
        }

        $userId = $_SESSION['user_id'];
        $user = $this->userModel->getUserById($userId);

        if (!$user) {
            header('Location: index.php');
            exit();
        }

        $categories = [];
        if (isset($this->productModel)) {
            $categories = $this->productModel->getCategories();
        }

        include __DIR__ . '/../views/user/edit.php';
    }

    public function update()
    {
        if (!isset($_SESSION['user_id'])) {
            header('Location: index.php?controller=auth&action=login');
            exit();
        }

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: index.php?controller=user&action=edit');
            exit();
        }

        $userId = $_SESSION['user_id'];
        $errors = [];

        $data = [];

        if (isset($_POST['name']) && !empty(trim($_POST['name']))) {
            $data['name'] = trim($_POST['name']);
        }

        if (isset($_POST['username']) && !empty(trim($_POST['username']))) {
            $username = trim($_POST['username']);
            if ($this->userModel->usernameExists($username, $userId)) {
                $errors[] = "Tên đăng nhập đã tồn tại.";
            } else {
                $data['username'] = $username;
            }
        }

        if (isset($_POST['email']) && !empty(trim($_POST['email']))) {
            $email = trim($_POST['email']);
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $errors[] = "Email không hợp lệ.";
            } else {
                $existingUser = $this->userModel->findByEmail($email);
                if ($existingUser && $existingUser['id'] != $userId) {
                    $errors[] = "Email đã được sử dụng bởi tài khoản khác.";
                } else {
                    $data['email'] = $email;
                }
            }
        }

        if (isset($_POST['phone'])) {
            $data['phone'] = trim($_POST['phone']);
        }

        if (isset($_POST['gender']) && in_array($_POST['gender'], ['Nam', 'Nữ', 'Khác'])) {
            $data['gender'] = $_POST['gender'];
        }

        if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
            $uploadResult = $this->handleAvatarUpload($_FILES['avatar']);
            if ($uploadResult['success']) {
                $this->userModel->updateAvatar($userId, $uploadResult['path']);
            } else {
                $errors[] = $uploadResult['error'];
            }
        }

        if (empty($errors) && !empty($data)) {
            if ($this->userModel->updateProfile($userId, $data)) {
                if (isset($data['name'])) {
                    $_SESSION['name'] = $data['name'];
                }
                $_SESSION['success_message'] = "Cập nhật thông tin thành công!";
            } else {
                $errors[] = "Không thể cập nhật thông tin. Vui lòng thử lại.";
            }
        }

        if (!empty($errors)) {
            $_SESSION['error_messages'] = $errors;
        }

        header('Location: index.php?controller=user&action=profile');
        exit();
    }

    public function wishlist()
    {
        if (!isset($_SESSION['user_id'])) {
            header('Location: index.php?controller=auth&action=login');
            exit();
        }

        $userId = $_SESSION['user_id'];

        $wishlistProducts = [];
        if (isset($this->wishlistModel)) {
            $wishlistProducts = $this->wishlistModel->getWishlistProducts($userId);
            $_SESSION['wishlist_count'] = $this->wishlistModel->getWishlistCount($userId);
        }

        $categories = [];
        if (isset($this->productModel)) {
            $categories = $this->productModel->getCategories();
        }

        require_once __DIR__ . '/../views/layouts/header.php';
        require_once __DIR__ . '/../views/wishlist/index.php';
        require_once __DIR__ . '/../views/layouts/footer.php';
    }

    public function toggleWishlist()
    {
        header('Content-Type: application/json');

        if (!isset($_SESSION['user_id'])) {
            echo json_encode(['success' => false, 'message' => 'Vui lòng đăng nhập']);
            exit();
        }

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['success' => false, 'message' => 'Invalid request']);
            exit();
        }

        $userId = $_SESSION['user_id'];
        $productId = (int)($_POST['product_id'] ?? 0);

        if ($productId <= 0) {
            echo json_encode(['success' => false, 'message' => 'Invalid product ID']);
            exit();
        }

        if (!isset($this->wishlistModel)) {
            echo json_encode(['success' => false, 'message' => 'Wishlist not available']);
            exit();
        }

        $isInWishlist = $this->wishlistModel->isInWishlist($userId, $productId);

        if ($isInWishlist) {
            $result = $this->wishlistModel->removeFromWishlist($userId, $productId);
            $action = 'removed';
        } else {
            $result = $this->wishlistModel->addToWishlist($userId, $productId);
            $action = 'added';
        }

        if ($result) {
            $wishlistCount = $this->wishlistModel->getWishlistCount($userId);
            $_SESSION['wishlist_count'] = $wishlistCount;

            echo json_encode([
                'success' => true,
                'action' => $action,
                'wishlist_count' => $wishlistCount,
                'message' => $action === 'added' ? 'Đã thêm vào yêu thích' : 'Đã xóa khỏi yêu thích'
            ]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Có lỗi xảy ra']);
        }
        exit();
    }

    public function orders()
    {
        if (!isset($_SESSION['user_id'])) {
            header('Location: index.php?controller=auth&action=login');
            exit();
        }

        $userId = $_SESSION['user_id'];
        $user = $this->userModel->getUserById($userId);

        if (!$user) {
            header('Location: index.php');
            exit();
        }

        require_once __DIR__ . '/../models/OrderModel.php';
        global $conn;
        $orderModel = new OrderModel($conn);

        $page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
        $limit = 10;
        $offset = ($page - 1) * $limit;

        $totalOrders = $orderModel->countOrdersByUserId($userId);
        $totalPages = ceil($totalOrders / $limit);

        $orders = $orderModel->getOrdersByUserIdPaginated($userId, $limit, $offset);

        foreach ($orders as &$order) {
            $order['items'] = $orderModel->getOrderItems($order['id']);
        }

        $categories = [];
        if (isset($this->productModel)) {
            $categories = $this->productModel->getCategories();
        }

        include __DIR__ . '/../views/user/orders.php';
    }

    public function orderDetail($id = null)
    {
        if (!isset($_SESSION['user_id'])) {
            redirect('login');
            exit();
        }

        $userId = $_SESSION['user_id'];
        $orderId = $id ? (int)$id : 0;

        require_once __DIR__ . '/../models/OrderModel.php';
        global $conn;
        $orderModel = new OrderModel($conn);
        $order = $orderModel->getOrderDetailById($orderId);

        if (!$order || $order['user_id'] != $userId) {
            redirect('orders');
            exit();
        }

        $canConfirm = ($order['current_status_id'] == 2);

        if ($order['current_status_id'] == 3 && isset($this->reviewModel)) {
            foreach ($order['items'] as &$item) {

                $productId = $item['product_id'] ?? 0;
                $item['has_reviewed'] = $this->reviewModel->hasUserReviewedProduct($userId, $productId);
            }
        }

        $categories = [];
        if (isset($this->productModel)) {
            $categories = $this->productModel->getCategories();
        }

        include __DIR__ . '/../views/user/order_detail.php';
    }

    public function confirmReceived()
    {
        if (!isset($_SESSION['user_id'])) {
            header('Location: index.php?controller=auth&action=login');
            exit();
        }

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: index.php?controller=user&action=orders');
            exit();
        }

        $userId = $_SESSION['user_id'];
        $orderId = $_POST['order_id'] ?? 0;

        require_once __DIR__ . '/../models/OrderModel.php';
        global $conn;
        $orderModel = new OrderModel($conn);

        $result = $orderModel->confirmOrderReceipt($orderId, $userId);

        if ($result) {
            $_SESSION['success_message'] = 'Đã xác nhận nhận hàng thành công!';
        } else {
            $_SESSION['error_messages'] = ['Không thể xác nhận đơn hàng. Vui lòng thử lại.'];
        }

        header('Location: index.php?controller=user&action=orderDetail&id=' . $orderId);
        exit();
    }

    public function cancelOrder()
    {
        if (!isset($_SESSION['user_id'])) {
            header('Location: index.php?controller=auth&action=login');
            exit();
        }

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: index.php?controller=user&action=orders');
            exit();
        }

        $userId = $_SESSION['user_id'];
        $orderId = $_POST['order_id'] ?? 0;

        require_once __DIR__ . '/../models/OrderModel.php';
        global $conn;
        $orderModel = new OrderModel($conn);

        $result = $orderModel->cancelOrder($orderId, $userId);

        if ($result) {
            $_SESSION['success_message'] = 'Đã hủy đơn hàng thành công!';
        } else {
            $_SESSION['error_messages'] = ['Không thể hủy đơn hàng. Vui lòng kiểm tra lại trạng thái đơn hàng.'];
        }

        if (isset($_SERVER['HTTP_REFERER']) && strpos($_SERVER['HTTP_REFERER'], 'orderDetail') !== false) {
            header('Location: index.php?controller=user&action=orderDetail&id=' . $orderId);
        } else {
            header('Location: index.php?controller=user&action=orders');
        }
        exit();
    }

    public function submitReview()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: index.php?controller=user&action=orders');
            exit();
        }

        if (!isset($_SESSION['user_id'])) {
            header('Location: index.php?controller=auth&action=login');
            exit();
        }

        $userId = $_SESSION['user_id'];
        $productId = $_POST['product_id'] ?? 0;
        $orderId = $_POST['order_id'] ?? 0;
        $rating = $_POST['rating'] ?? 0;
        $comment = $_POST['comment'] ?? '';

        if ($productId <= 0 || $rating <= 0 || empty($comment)) {
            $_SESSION['error_messages'] = ['Vui lòng điền đầy đủ thông tin đánh giá.'];
            redirect("don-hang/$orderId");
            exit();
        }

        if ($this->reviewModel && $this->reviewModel->hasUserReviewedProduct($userId, $productId)) {
            $_SESSION['error_messages'] = ['Bạn đã đánh giá sản phẩm này rồi.'];
            redirect("don-hang/$orderId");
            exit();
        }

        if ($this->reviewModel && $this->reviewModel->createReview($userId, $productId, $rating, $comment)) {
            $_SESSION['success_message'] = 'Cảm ơn bạn đã đánh giá sản phẩm!';
        } else {
            $_SESSION['error_messages'] = ['Có lỗi xảy ra khi gửi đánh giá.'];
        }

        redirect("don-hang/$orderId");
        exit();
    }

    private function handleAvatarUpload($file)
    {
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        $maxSize = 5 * 1024 * 1024;

        if (!in_array($file['type'], $allowedTypes)) {
            return ['success' => false, 'error' => 'Chỉ chấp nhận file ảnh (JPG, PNG, GIF, WEBP).'];
        }

        if ($file['size'] > $maxSize) {
            return ['success' => false, 'error' => 'Kích thước file không được vượt quá 5MB.'];
        }

        $uploadDir = __DIR__ . '/../public/uploads/avatars/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }

        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = 'avatar_' . $_SESSION['user_id'] . '_' . time() . '.' . $extension;
        $uploadPath = $uploadDir . $filename;
        $relativePath = 'public/uploads/avatars/' . $filename;

        if (move_uploaded_file($file['tmp_name'], $uploadPath)) {
            return ['success' => true, 'path' => $relativePath];
        } else {
            return ['success' => false, 'error' => 'Không thể tải lên file. Vui lòng thử lại.'];
        }
    }

    public function retryVnpayPayment($id = null)
    {
        error_log("=== retryVnpayPayment CALLED ===");
        error_log("Session user_id: " . ($_SESSION['user_id'] ?? 'NOT SET'));
        error_log("Parameter id: " . ($id ?? 'NOT SET'));
        
        if (!isset($_SESSION['user_id'])) {
            error_log("retryVnpayPayment: No user_id in session");
            redirect('login');
            exit;
        }

        $userId = $_SESSION['user_id'];
        $orderId = $id ? (int)$id : 0;
        
        error_log("retryVnpayPayment: Processing order ID: $orderId for user ID: $userId");
        
        if ($orderId <= 0) {
            error_log("retryVnpayPayment: Invalid order ID");
            $_SESSION['error_messages'] = ['Đơn hàng không hợp lệ!'];
            redirect('orders');
            exit;
        }

        require_once __DIR__ . '/../models/OrderModel.php';
        global $conn;
        $orderModel = new OrderModel($conn);
        
        $order = $orderModel->getOrderPaymentInfo($orderId);
        if (!$order) {
            error_log("retryVnpayPayment: Order not found for ID: $orderId");
            $_SESSION['error_messages'] = ['Không tìm thấy đơn hàng!'];
            redirect('orders');
            exit;
        }
        
        error_log("retryVnpayPayment: Order data: " . json_encode($order));

        // Verify order belongs to user
        if ((int)$order['user_id'] !== $userId) {
            $_SESSION['error_messages'] = ['Bạn không có quyền truy cập đơn hàng này!'];
            redirect('orders');
            exit;
        }

        if (($order['payment_method'] ?? '') !== 'vnpay') {
            $_SESSION['error_messages'] = ['Đơn hàng này không sử dụng VNPay!'];
            redirect('orders');
            exit;
        }
        
        if ((int)($order['current_status_id'] ?? 0) === 8) {
            $_SESSION['error_messages'] = ['Đơn hàng đã bị hủy, không thể tiếp tục thanh toán!'];
            redirect('orders');
            exit;
        }

        require_once __DIR__ . '/../models/PaymentModel.php';
        $paymentModel = new PaymentModel($conn);
        $payment = $paymentModel->getByOrderId($orderId);
        if ($payment && ($payment['status'] ?? '') === 'Paid') {
            $_SESSION['success_message'] = 'Đơn hàng này đã được thanh toán.';
            redirect('orders');
            exit;
        }

        $amount = (float)($order['total_amount'] ?? 0);
        if ($amount <= 0) {
            $_SESSION['error_messages'] = ['Tổng tiền đơn hàng không hợp lệ!'];
            redirect('orders');
            exit;
        }

        // Use existing payment or create new one
        $paymentId = $payment ? $payment['id'] : $paymentModel->createPayment($orderId, 'vnpay', 'Pending');
        if ($paymentId <= 0) {
            $_SESSION['error_messages'] = ['Không thể khởi tạo thanh toán VNPay.'];
            redirect('orders');
            exit;
        }

        $vnpayUrl = $this->createVnpayPaymentUrl($paymentId, $amount, $orderId);
        header("Location: " . $vnpayUrl);
        exit;
    }

    private function createVnpayPaymentUrl(int $paymentId, float $amount, int $orderId): string
    {
        require_once __DIR__ . '/../vnpay_php/config.php';

        $vnp_TxnRef = $paymentId;
        $vnp_Amount = $amount * 100;
        $vnp_Locale = 'vn';
        $vnp_BankCode = '';
        $vnp_IpAddr = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';

        $protocol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http");
        $host = $_SERVER['HTTP_HOST'];
        $scriptPath = dirname($_SERVER['SCRIPT_NAME']);
        $basePath = rtrim($scriptPath, '/');
        $vnp_Returnurl = $protocol . "://" . $host . $basePath . "/vnpay_php/vnpay_return.php";

        $inputData = [
            "vnp_Version"   => "2.1.0",
            "vnp_TmnCode"   => $vnp_TmnCode,
            "vnp_Amount"    => $vnp_Amount,
            "vnp_Command"   => "pay",
            "vnp_CreateDate" => date('YmdHis'),
            "vnp_CurrCode"  => "VND",
            "vnp_IpAddr"    => $vnp_IpAddr,
            "vnp_Locale"    => $vnp_Locale,
            "vnp_OrderInfo" => "Thanh toan don hang #" . $orderId,
            "vnp_OrderType" => "other",
            "vnp_ReturnUrl" => $vnp_Returnurl,
            "vnp_TxnRef"    => $vnp_TxnRef,
            "vnp_ExpireDate" => date('YmdHis', strtotime('+15 minutes'))
        ];

        if (!empty($vnp_BankCode)) {
            $inputData['vnp_BankCode'] = $vnp_BankCode;
        }

        ksort($inputData);
        $query = "";
        $i = 0;
        $hashdata = "";
        foreach ($inputData as $key => $value) {
            if ($i == 1) {
                $hashdata .= '&' . urlencode($key) . "=" . urlencode($value);
            } else {
                $hashdata .= urlencode($key) . "=" . urlencode($value);
                $i = 1;
            }
            $query .= urlencode($key) . "=" . urlencode($value) . '&';
        }

        $vnp_Url = $vnp_Url . "?" . $query;
        if (isset($vnp_HashSecret)) {
            $vnpSecureHash = hash_hmac('sha512', $hashdata, $vnp_HashSecret);
            $vnp_Url .= 'vnp_SecureHash=' . $vnpSecureHash;
        }

        return $vnp_Url;
    }
}
