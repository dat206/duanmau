<?php
class AuthController
{
    private $userModel;
    public function __construct($userModel)
    {
        $this->userModel = $userModel;
    }

    // Show login page (for GET requests)
    public function showLogin()
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        $error = null;
        if (isset($_SESSION['flash_error'])) {
            $error = $_SESSION['flash_error'];
            unset($_SESSION['flash_error']);
        }
        include __DIR__ . '/../views/auth/login.php';
    }

    // Show register page (for GET requests)
    public function showRegister()
    {
        include __DIR__ . '/../views/auth/register.php';
    }

    // Legacy methods for backward compatibility
    public function showLoginView($error = null)
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        if ($error === null && isset($_SESSION['flash_error'])) {
            $error = $_SESSION['flash_error'];
            unset($_SESSION['flash_error']);
        }
        include __DIR__ . '/../views/auth/login.php';
    }

    public function showRegisterView($error = null)
    {
        include __DIR__ . '/../views/auth/register.php';
    }

    public function register()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = trim($_POST['name'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $password = $_POST['password'] ?? '';
            if (empty($name) || empty($email) || empty($password)) {
                $error = "Vui lòng điền đầy đủ các trường.";
                return $this->showRegisterView($error);
            }
            if ($this->userModel->emailExists($email)) {
                $error = "Email đã được đăng ký. Vui lòng đăng nhập.";
                return $this->showRegisterView($error);
            }
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $new_user_id = $this->userModel->create($name, $email, $hashed_password);
            if ($new_user_id) {
                if (session_status() === PHP_SESSION_NONE) {
                    session_start();
                }
                $_SESSION['user_id'] = $new_user_id;
                $_SESSION['name'] = $name;
                $_SESSION['role'] = 'customer';

                $_SESSION['cart_count'] = 0;
                $_SESSION['wishlist_count'] = 0;

                redirect('/');
                exit();
            } else {
                $error = "Đăng ký thất bại, vui lòng thử lại. Vui lòng kiểm tra lại thông tin và thử lại.";
                return $this->showRegisterView($error);
            }
        } else {
            $this->showRegisterView();
        }
    }

    public function login()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = trim($_POST['email'] ?? '');
            $password = $_POST['password'] ?? '';
            if (empty($email) || empty($password)) {
                $error = "Vui lòng nhập Email và Mật khẩu.";
                return $this->showLoginView($error);
            }
            $user = $this->userModel->findByEmail($email);
            if ($user && password_verify($password, $user['password'])) {
                if (isset($user['is_locked']) && $user['is_locked'] == 1) {
                    $error = "Tài khoản của bạn đã bị khóa do vi phạm cộng đồng";
                    return $this->showLoginView($error);
                }

                if (session_status() === PHP_SESSION_NONE) {
                    session_start();
                }
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['name'] = $user['name'];
                $_SESSION['role'] = $user['role'];

                require_once __DIR__ . '/../configs/Database.php';
                $database = new Database();
                $conn = $database->connect();

                if (isset($_SESSION['cart']) && is_array($_SESSION['cart']) && !empty($_SESSION['cart'])) {
                    require_once __DIR__ . '/../models/CartModel.php';
                    $cartModel = new CartModel($conn);
                    $cartModel->mergeSessionCart($user['id'], $_SESSION['cart']);
                    unset($_SESSION['cart']);
                }
                require_once __DIR__ . '/../models/CartModel.php';
                $cartModel = new CartModel($conn);
                $_SESSION['cart_count'] = $cartModel->getCartCount($user['id']);
                require_once __DIR__ . '/../models/WishlistModel.php';
                $wishlistModel = new WishlistModel($conn);
                $_SESSION['wishlist_count'] = $wishlistModel->getWishlistCount($user['id']);

                if ($user['role'] === 'admin') {
                    header('Location: index.php?controller=admin&action=dashboard');
                } else {
                    redirect('/');
                }
                exit();
            } else {
                $error = "Email hoặc Mật khẩu không đúng. Vui lòng kiểm tra lại.";
                return $this->showLoginView($error);
            }
        } else {
            $this->showLoginView();
        }
    }
    public function logout()
    {
        session_start();
        session_unset();
        session_destroy();
        redirect('/');
    }
}
