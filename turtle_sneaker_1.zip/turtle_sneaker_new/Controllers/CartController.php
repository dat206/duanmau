<?php
class CartController
{
    private ProductModel $productModel;
    private ?OrderModel $orderModel;
    private ?CartModel $cartModel;
    private ?CouponModel $couponModel;
    private ?ShippingModel $shippingModel;
    private mysqli $conn;

    public function __construct(ProductModel $productModel, ?OrderModel $orderModel = null, ?CartModel $cartModel = null, ?CouponModel $couponModel = null, ?ShippingModel $shippingModel = null)
    {
        $this->productModel = $productModel;
        $this->orderModel = $orderModel; 
        $this->cartModel = $cartModel; 
        $this->couponModel = $couponModel; 
        $this->shippingModel = $shippingModel; 
        $reflection = new ReflectionClass($productModel);
        $property = $reflection->getProperty('conn');
        $property->setAccessible(true); 
        $this->conn = $property->getValue($productModel);
    } 

    public function addToCart()
    {
        $this->ensureSession(); 
        header('Content-Type: application/json'); 
        if (!isset($_SESSION['user_id'])) {  
            http_response_code(401);
            echo json_encode([ 
                'success' => false,
                'message' => 'Vui lòng đăng nhập để thêm sản phẩm vào giỏ hàng.', 
                'redirect' => 'index.php?controller=auth&action=login' 
            ]);
            return;
        }

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            echo json_encode(['success' => false, 'message' => 'Method not allowed']);
            return;
        }

        $productId = isset($_POST['product_id']) ? (int)$_POST['product_id'] : 0;
        $quantity = isset($_POST['quantity']) ? max(1, (int)$_POST['quantity']) : 1;
        $color = isset($_POST['color']) ? trim($_POST['color']) : '';
        $size = isset($_POST['size']) ? trim($_POST['size']) : '';
        $variantPrice = isset($_POST['price']) ? (float)$_POST['price'] : null;
 
        if ($productId <= 0) {
            echo json_encode(['success' => false, 'message' => 'Sản phẩm không hợp lệ']); 
            return;
        }
 
        $product = $this->productModel->getProductDetail($productId);
        if (!$product) { 
            echo json_encode(['success' => false, 'message' => 'Không tìm thấy sản phẩm']);
            return; 
        }
 
        if ($variantPrice === null) {
            $variantPrice = $this->productModel->getVariantPriceByAttributes($productId, $color, $size);
        }

        $finalPrice = $variantPrice !== null ? $variantPrice : (float)($product['price'] ?? 0);

        if (isset($_SESSION['user_id'])) {
            $userId = (int)$_SESSION['user_id']; 
            $this->cartModel->addItem($userId, $productId, $quantity, $color, $size);
            $totalItems = $this->cartModel->getCartCount($userId);
        } else { 
            if (!isset($_SESSION['cart']) || !is_array($_SESSION['cart'])) {
                $_SESSION['cart'] = [];
            }

            $cartKey = $productId . '_' . md5($color . '_' . $size);

            if (isset($_SESSION['cart'][$cartKey])) {
                $_SESSION['cart'][$cartKey]['quantity'] += $quantity;
            } else {
                $_SESSION['cart'][$cartKey] = [
                    'product_id' => $productId,
                    'name' => $product['name'],
                    'category' => $product['category_name'] ?? '',
                    'price' => $finalPrice,
                    'image' => $product['main_image'],
                    'quantity' => $quantity,
                    'color' => $color,
                    'size' => $size
                ];
            }

            $totalItems = 0;
            foreach ($_SESSION['cart'] as $item) {
                $totalItems += $item['quantity'];
            }
        }

        $_SESSION['cart_count'] = $totalItems;

        echo json_encode([
            'success' => true,
            'message' => 'Thêm thành công',
            'cart_count' => $totalItems
        ]);
    }

    public function getCartCount()
    {
        $this->ensureSession();

        header('Content-Type: application/json');

        $totalItems = 0;
        if (isset($_SESSION['cart']) && is_array($_SESSION['cart'])) {
            foreach ($_SESSION['cart'] as $item) {
                $totalItems += $item['quantity'];
            }
        }

        echo json_encode(['count' => $totalItems]);
    }

    public function view(): void
    {
        $this->ensureSession();
        $this->requireLogin();

        if (isset($_SESSION['user_id'])) {
            $userId = (int)$_SESSION['user_id'];
            $dbItems = $this->cartModel->getCartItems($userId);
            $cartItems = $this->cartModel->toSessionFormat($dbItems);
        } else {
            $cartItems = $_SESSION['cart'] ?? [];
        }

        $totals = [
            'subtotal' => 0,
            'quantity' => 0,
        ];

        foreach ($cartItems as &$item) {
            // Check if product was deleted (from database is_deleted flag)
            $isDeleted = isset($item['is_deleted']) && $item['is_deleted'];
            
            if ($isDeleted) {
                // Product deleted - set line_total to 0, don't add to totals
                $item['line_total'] = 0;
            } else {
                // Product exists - calculate normally
                $color = $item['color'] ?? '';
                $size = $item['size'] ?? '';
                $variantPrice = $this->productModel->getVariantPriceByAttributes($item['product_id'], $color, $size);

                $product = $this->productModel->getProductById($item['product_id']);
                $itemPrice = $variantPrice !== null ? $variantPrice : ((float)($item['price'] ?? 0) ?: (float)($product['price'] ?? 0));
                $item['price'] = $itemPrice;
                $item['line_total'] = $itemPrice * (int)($item['quantity'] ?? 0);
                $totals['subtotal'] += $item['line_total'];
                $totals['quantity'] += (int)($item['quantity'] ?? 0);
            }
        }
        unset($item);

        $_SESSION['cart_count'] = $totals['quantity'];

        $categories = $this->productModel->getCategories();

        require_once __DIR__ . '/../views/layouts/header.php';
        require_once __DIR__ . '/../views/cart/view.php';
        require_once __DIR__ . '/../views/layouts/footer.php';
    }

    public function updateQuantity(): void
    {
        $this->ensureSession();
        $this->requireLogin();

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirectToCart();
        }

        $itemKey = $_POST['item_key'] ?? '';

        if (isset($_SESSION['user_id'])) {
            $parts = explode('_', $itemKey, 2);
            $productId = (int)$parts[0];

            $userId = (int)$_SESSION['user_id'];
            $dbItems = $this->cartModel->getCartItems($userId);
            $sessionItems = $this->cartModel->toSessionFormat($dbItems);

            if (!isset($sessionItems[$itemKey])) {
                $this->redirectToCart();
            }

            $item = $sessionItems[$itemKey];
            $color = $item['color'] ?? '';
            $size = $item['size'] ?? '';

            $change = $_POST['change'] ?? null;
            $newQuantity = $item['quantity'] ?? 1;

            if ($change === 'increment') {
                $newQuantity++;
            } elseif ($change === 'decrement') {
                $newQuantity = max(1, $newQuantity - 1);
            } elseif (isset($_POST['quantity'])) {
                $newQuantity = max(1, (int)$_POST['quantity']);
            }

            $this->cartModel->updateQuantity($userId, $productId, $color, $size, $newQuantity);

            $_SESSION['cart_count'] = $this->cartModel->getCartCount($userId);
        } else {
            if (!isset($_SESSION['cart'][$itemKey])) {
                $this->redirectToCart();
            }

            $change = $_POST['change'] ?? null;
            $newQuantity = $_SESSION['cart'][$itemKey]['quantity'] ?? 1;

            if ($change === 'increment') {
                $newQuantity++;
            } elseif ($change === 'decrement') {
                $newQuantity = max(1, $newQuantity - 1);
            } elseif (isset($_POST['quantity'])) {
                $newQuantity = max(1, (int)$_POST['quantity']);
            }

            $_SESSION['cart'][$itemKey]['quantity'] = $newQuantity;

            $totalItems = 0;
            foreach ($_SESSION['cart'] as $item) {
                $totalItems += $item['quantity'];
            }
            $_SESSION['cart_count'] = $totalItems;
        }

        $this->redirectToCart();
    }

    public function removeItem(): void
    {
        $this->ensureSession();
        $this->requireLogin();

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirectToCart();
        }

        $itemKey = $_POST['item_key'] ?? '';

        if (isset($_SESSION['user_id'])) {
            $parts = explode('_', $itemKey, 2);
            $productId = (int)$parts[0];

            $userId = (int)$_SESSION['user_id'];
            $dbItems = $this->cartModel->getCartItems($userId);
            $sessionItems = $this->cartModel->toSessionFormat($dbItems);

            if (isset($sessionItems[$itemKey])) {
                $item = $sessionItems[$itemKey];
                $this->cartModel->removeItem($userId, $productId, $item['color'] ?? '', $item['size'] ?? '');
            }

            $_SESSION['cart_count'] = $this->cartModel->getCartCount($userId);
        } else {
            if ($itemKey && isset($_SESSION['cart'][$itemKey])) {
                unset($_SESSION['cart'][$itemKey]);
            }

            $totalItems = 0;
            foreach ($_SESSION['cart'] as $item) {
                $totalItems += $item['quantity'];
            }
            $_SESSION['cart_count'] = $totalItems;
        }

        $this->redirectToCart();
    }

    public function removeMultipleItems(): void
    {
        $this->ensureSession();
        $this->requireLogin();

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirectToCart();
        }

        $itemKeys = $_POST['item_keys'] ?? [];
        error_log('removeMultipleItems called');
        error_log('POST data: ' . print_r($_POST, true));
        error_log('Item keys: ' . print_r($itemKeys, true));
        if (is_array($itemKeys)) {
            if (isset($_SESSION['user_id'])) {
                $userId = (int)$_SESSION['user_id'];
                $dbItems = $this->cartModel->getCartItems($userId);
                $sessionItems = $this->cartModel->toSessionFormat($dbItems);

                foreach ($itemKeys as $itemKey) {
                    if (isset($sessionItems[$itemKey])) {
                        $parts = explode('_', $itemKey, 2);
                        $productId = (int)$parts[0];
                        $item = $sessionItems[$itemKey];
                        $this->cartModel->removeItem($userId, $productId, $item['color'] ?? '', $item['size'] ?? '');
                    }
                }
            } else {
                foreach ($itemKeys as $itemKey) {
                    if (isset($_SESSION['cart'][$itemKey])) {
                        unset($_SESSION['cart'][$itemKey]);
                    }
                }
            }
        }

        $this->redirectToCart();
    }

    public function clear(): void
    {
        $this->ensureSession();
        $this->requireLogin();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $_SESSION['cart'] = [];
        }

        $this->redirectToCart();
    }

    private function ensureSession(): void
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
    }

    private function requireLogin(): void
    {
        if (!isset($_SESSION['user_id'])) {
            header('Location: index.php?controller=auth&action=login');
            exit;
        }
    }

    private function redirectToCart(): void
    {
        header('Location: ' . route('cart'));
        exit;
    }
    public function checkout(): void
    {
        $this->ensureSession();
        $this->requireLogin();

        $cartItems = [];
        $checkoutMode = 'cart';

        $isBuyNow = isset($_GET['mode']) && $_GET['mode'] === 'buy_now' && !empty($_SESSION['buy_now_cart']);
        if ($isBuyNow) {
            $cartItems = $_SESSION['buy_now_cart'];
            $checkoutMode = 'buy_now';
        } elseif (isset($_SESSION['user_id'])) {
            $userId = (int)$_SESSION['user_id'];
            $dbItems = $this->cartModel->getCartItems($userId);
            $allCartItems = $this->cartModel->toSessionFormat($dbItems);

            if (isset($_SESSION['selected_items']) && !empty($_SESSION['selected_items'])) {
                $selectedKeys = $_SESSION['selected_items'];
                $cartItems = array_filter($allCartItems, function ($key) use ($selectedKeys) {
                    return in_array($key, $selectedKeys);
                }, ARRAY_FILTER_USE_KEY);
            } else {
                $cartItems = $allCartItems;
            }
        } else {
            $cartItems = $_SESSION['cart'] ?? [];
        }

        if (empty($cartItems)) {
            $this->redirectToCart();
        }

        $totals = [
            'subtotal' => 0,
            'quantity' => 0,
        ];

        foreach ($cartItems as &$item) {
            $product = $this->productModel->getProductById($item['product_id']);
            if (!$product) {
                $item['out_of_stock'] = true;
                $item['line_total'] = 0;
                continue;
            }

            $item['out_of_stock'] = false;

            $color = $item['color'] ?? '';
            $size = $item['size'] ?? '';
            $variantPrice = $this->productModel->getVariantPriceByAttributes($item['product_id'], $color, $size);

            $itemPrice = $variantPrice !== null ? $variantPrice : ((float)($item['price'] ?? 0) ?: (float)($product['price'] ?? 0));
            $item['price'] = $itemPrice; // Cập nhật lại giá trong item
            $item['line_total'] = $itemPrice * (int)($item['quantity'] ?? 0);
            $totals['subtotal'] += $item['line_total'];
            $totals['quantity'] += (int)($item['quantity'] ?? 0);
        }
        unset($item);

        $userId = (int)$_SESSION['user_id'];
        require_once __DIR__ . '/../models/UserModel.php';
        $userModel = new UserModel($this->conn);

        $user = $userModel->getUserById($userId);
        $defaultAddress = $userModel->getDefaultAddress($userId);

        // Only set session data if not already set (preserve user's edits)
        if (!isset($_SESSION['name']) || empty($_SESSION['name'])) {
            $_SESSION['name'] = $user['name'] ?? '';
        }
        if (!isset($_SESSION['phone']) || empty($_SESSION['phone'])) {
            $_SESSION['phone'] = $user['phone'] ?? '';
        }
        if (!isset($_SESSION['address']) || empty($_SESSION['address'])) {
            $_SESSION['address'] = $defaultAddress['address_line'] ?? '';
        }

        $shippingMethods = $this->shippingModel->getActiveMethods();
        $selectedShippingId = $shippingMethods[0]['id'] ?? 0;
        $shippingFee = $shippingMethods[0]['fee'] ?? 0;

        $appliedVoucher = null;
        $voucherDiscount = 0;

        $coupons = $this->couponModel->getValidCoupons();
        $shippingCoupons = [];
        $discountCoupons = [];

        foreach ($coupons as $coupon) {
            if ($coupon['type'] === 'shipping') {
                $shippingCoupons[] = $coupon;
            } else {
                $discountCoupons[] = $coupon;
            }
        }


        $totals['total'] = $totals['subtotal'] + $shippingFee - $voucherDiscount;

        $categories = $this->productModel->getCategories();
        $checkoutModeValue = $checkoutMode;
        require_once __DIR__ . '/../views/layouts/header.php';
        require_once __DIR__ . '/../views/cart/checkout.php';
        require_once __DIR__ . '/../views/layouts/footer.php';
    }

    public function placeOrder(): void
    {
        $this->ensureSession();
        $this->requireLogin();

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirectToCart();
        }

        $checkoutMode = $_POST['checkout_mode'] ?? 'cart';

        if ($checkoutMode === 'buy_now') {
            $cartItems = $_SESSION['buy_now_cart'] ?? [];
        } elseif (isset($_SESSION['user_id'])) {
            $userId = (int)$_SESSION['user_id'];
            $dbItems = $this->cartModel->getCartItems($userId);
            $allCartItems = $this->cartModel->toSessionFormat($dbItems);
            if (isset($_SESSION['selected_items']) && !empty($_SESSION['selected_items'])) {
                $selectedKeys = $_SESSION['selected_items'];
                $cartItems = [];
                foreach ($allCartItems as $key => $item) {
                    if (in_array($key, $selectedKeys)) {
                        $cartItems[$key] = $item;
                    }
                }
            } else {
                $cartItems = $allCartItems;
            }
        } else {
            $cartItems = $_SESSION['cart'] ?? [];
        }
        if (empty($cartItems)) {
            $this->redirectToCart();
        }

        $subtotal = 0;
        foreach ($cartItems as $item) {
            $subtotal += (float)($item['price'] ?? 0) * (int)($item['quantity'] ?? 0);
        }
        $subtotal = 0;
        foreach ($cartItems as $item) {
            $subtotal += (float)($item['price'] ?? 0) * (int)($item['quantity'] ?? 0);
        }

        $shippingMethodId = $_POST['shipping_method'] ?? 0;
        $shippingMethod = $this->shippingModel->getMethodById($shippingMethodId);
        $shippingFee = $shippingMethod ? (float)$shippingMethod['fee'] : 0;

        $voucherCode = strtoupper(trim($_POST['voucher_code'] ?? ''));
        $voucher = $this->calculateVoucherDiscount($voucherCode, $subtotal, $shippingFee);
        $voucherDiscount = $voucher['amount'];
        $voucherCode = $voucher['code'];

        $total = $subtotal + $shippingFee - $voucherDiscount;

        $addressData = [
            'name' => trim($_POST['name'] ?? ''),
            'phone' => trim($_POST['phone'] ?? ''),
            'address' => trim($_POST['address'] ?? ''),
            'city' => $_POST['city'] ?? '',
            'district' => $_POST['district'] ?? '',
            'ward' => $_POST['ward'] ?? ''
        ];

        if (empty($addressData['name']) || empty($addressData['phone']) || empty($addressData['address'])) {
            $_SESSION['error_message'] = 'Vui lòng nhập đầy đủ thông tin: Họ tên, Số điện thoại và Địa chỉ nhận hàng!';
            header('Location: index.php?controller=cart&action=checkout');
            exit();
        }

        if (!preg_match('/^[0-9]{10,11}$/', $addressData['phone'])) {
            $_SESSION['error_message'] = 'Số điện thoại không hợp lệ! Vui lòng nhập 10-11 chữ số.';
            header('Location: index.php?controller=cart&action=checkout');
            exit();
        }

        require_once __DIR__ . '/../models/UserModel.php';
        $userModel = new UserModel($this->conn);
        if ($userModel->updateUserPhoneIfEmpty($_SESSION['user_id'], $addressData['phone'])) {
            $_SESSION['phone'] = $addressData['phone'];
        }

        $addressId = $this->orderModel->createAddress($_SESSION['user_id'], $addressData);

        $orderTotals = [
            'subtotal' => $subtotal,
            'shipping' => $shippingFee,
            'shipping_method' => $shippingMethod,
            'voucher_code' => $voucherCode,
            'discount' => $voucherDiscount,
            'total' => $total
        ];
        
        $orderId = $this->orderModel->createOrder(
            $_SESSION['user_id'],
            $addressId,
            $subtotal,
            $shippingFee,
            $total,
            $total,
            null,
            $shippingMethodId,
            $_POST['payment_method'] ?? 'cod'
        );

        foreach ($cartItems as $item) {
            $this->orderModel->createOrderItem($orderId, $item);
        }
        
        $paymentMethod = $_POST['payment_method'] ?? 'cod';
        require_once __DIR__ . '/../models/PaymentModel.php';
        $paymentModel = new PaymentModel($this->conn);
        $paymentId = $paymentModel->createPayment($orderId, $paymentMethod, 'Pending');

        if ($paymentMethod === 'vnpay') {
            if ($paymentId <= 0) {
                $_SESSION['error_message'] = 'Không thể khởi tạo thanh toán VNPay. Vui lòng thử lại.';
                redirect('thanh-toan');
                exit;
            }
            // DO NOT clear cart here for VNPay - will be cleared after successful payment in vnpay_return.php
            $vnpayUrl = $this->createVnpayPaymentUrl($paymentId, $total, $orderId);
            header("Location: $vnpayUrl");
            exit;
        }

        // Only clear cart for COD payment (immediate success)
        if ($checkoutMode === 'buy_now') {
            unset($_SESSION['buy_now_cart']);
        } else {
            $_SESSION['cart'] = [];
            $_SESSION['cart_count'] = 0;
        }

        // Clear selected items after successful order
        unset($_SESSION['selected_items']);

        redirect('cam-on');
        exit;
    }

    private function createVnpayPaymentUrl(int $paymentId, float $amount, int $orderId): string
    {
        require_once __DIR__ . '/../vnpay_php/config.php';

        $vnp_TxnRef = $paymentId;
        $vnp_Amount = $amount * 100;
        $vnp_Locale = 'vn';
        $vnp_BankCode = '';
        $vnp_IpAddr = $_SERVER['REMOTE_ADDR'];

        $protocol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http");
        $host = $_SERVER['HTTP_HOST'];
        $scriptPath = dirname($_SERVER['SCRIPT_NAME']);
        $basePath = rtrim($scriptPath, '/');
        $vnp_Returnurl = $protocol . "://" . $host . $basePath . "/vnpay_php/vnpay_return.php";

        $inputData = array(
            "vnp_Version" => "2.1.0",
            "vnp_TmnCode" => $vnp_TmnCode,
            "vnp_Amount" => $vnp_Amount,
            "vnp_Command" => "pay",
            "vnp_CreateDate" => date('YmdHis'),
            "vnp_CurrCode" => "VND",
            "vnp_IpAddr" => $vnp_IpAddr,
            "vnp_Locale" => $vnp_Locale,
            "vnp_OrderInfo" => "Thanh toan don hang #" . $orderId,
            "vnp_OrderType" => "other",
            "vnp_ReturnUrl" => $vnp_Returnurl,
            "vnp_TxnRef" => $vnp_TxnRef,
            "vnp_ExpireDate" => date('YmdHis', strtotime('+15 minutes'))
        );

        if (!empty($vnp_BankCode)) {
            $inputData['vnp_BankCode'] = $vnp_BankCode;
        }

        ksort($inputData);
        $query = "";
        $i = 0;
        $hashdata = "";
        foreach ($inputData as $key => $value) {
            if ($i == 1) {
                $hashdata .= '&' . urlencode($key) . "=" . urlencode($value);
            } else {
                $hashdata .= urlencode($key) . "=" . urlencode($value);
                $i = 1;
            }
            $query .= urlencode($key) . "=" . urlencode($value) . '&';
        }

        $vnp_Url = $vnp_Url . "?" . $query;
        if (isset($vnp_HashSecret)) {
            $vnpSecureHash = hash_hmac('sha512', $hashdata, $vnp_HashSecret);
            $vnp_Url .= 'vnp_SecureHash=' . $vnpSecureHash;
        }

        return $vnp_Url;
    }

    public function buyNow(): void
    {
        $this->ensureSession();
        header('Content-Type: application/json');
        if (!isset($_SESSION['user_id'])) {
            echo json_encode([
                'success' => false,
                'message' => 'Vui lòng đăng nhập để mua ngay.',
                'redirect' => 'index.php?controller=auth&action=login'
            ]);
            return;
        }
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            echo json_encode(['success' => false, 'message' => 'Method not allowed']);
            return;
        }
        $productId = isset($_POST['product_id']) ? (int)$_POST['product_id'] : 0;
        $quantity = isset($_POST['quantity']) ? max(1, (int)$_POST['quantity']) : 1;
        $color = trim($_POST['color'] ?? '');
        $size = trim($_POST['size'] ?? '');
        $variantPrice = isset($_POST['price']) ? (float)$_POST['price'] : null;
        if ($productId <= 0) {
            echo json_encode(['success' => false, 'message' => 'Sản phẩm không hợp lệ']);
            return;
        }
        $product = $this->productModel->getProductById($productId);
        if (!$product) {
            echo json_encode(['success' => false, 'message' => 'Không tìm thấy sản phẩm']);
            return;
        }
        if ($variantPrice === null) {
            $variantPrice = $this->productModel->getVariantPriceByAttributes($productId, $color, $size);
        }
        $finalPrice = $variantPrice !== null ? $variantPrice : (float)($product['price'] ?? 0);
        $itemKey = $productId . '_' . md5($color . '_' . $size);
        $itemData = [
            'product_id' => $productId,
            'name' => $product['name'] ?? '',
            'category' => $product['category_name'] ?? '',
            'price' => $finalPrice,
            'image' => $product['main_image'] ?? '',
            'quantity' => $quantity,
            'color' => $color,
            'size' => $size,
            'line_total' => $finalPrice * $quantity
        ];
        $_SESSION['buy_now_cart'] = [
            $itemKey => $itemData
        ];
        echo json_encode([
            'success' => true,
            'redirect' => route('checkout') . '?mode=buy_now'
        ]);
    }

    public function thankyou(): void
    {
        $this->ensureSession();
        $this->requireLogin();
        $categories = $this->productModel->getCategories();
        require_once __DIR__ . '/../views/layouts/header.php';
        require_once __DIR__ . '/../views/cart/thankyou.php';
        require_once __DIR__ . '/../views/layouts/footer.php';
    }

    private function calculateVoucherDiscount(string $code, float $subtotal, float $shippingFee = 0): array
    {
        if (empty($code)) {
            return ['code' => '', 'amount' => 0];
        }

        $coupon = $this->couponModel->checkCouponCode($code);

        if ($coupon && $coupon['is_active']) {
            $now = date('Y-m-d H:i:s');
            if ($coupon['expiration_date'] > $now && $coupon['quantity'] > $coupon['used_count']) {
                if ($subtotal >= $coupon['min_order_value']) {
                    $discountAmount = 0;
                    if ($coupon['type'] == 'amount') {
                        $discountAmount = (float)$coupon['discount_amount'];
                    } elseif ($coupon['type'] == 'percentage') {
                        $discountAmount = $subtotal * (float)$coupon['discount_amount'];
                    } elseif ($coupon['type'] == 'shipping') {
                        $discountAmount = (float)$coupon['discount_amount'];
                        if ($shippingFee > 0) {
                            $discountAmount = min($discountAmount, $shippingFee);
                        }
                    }
                    return [
                        'code' => $code,
                        'amount' => $discountAmount
                    ];
                }
            }
        }
        return [
            'code' => '',
            'amount' => 0
        ];
    }

    public function checkVoucher(): void
    {
        $this->ensureSession();
        header('Content-Type: application/json');

        $code = $_POST['code'] ?? '';
        $subtotal = (float)($_POST['subtotal'] ?? 0);
        $shippingFee = (float)($_POST['shipping_fee'] ?? 0);

        $result = $this->calculateVoucherDiscount($code, $subtotal, $shippingFee);

        if ($result['amount'] > 0) {
            echo json_encode(['success' => true, 'discount' => $result['amount'], 'code' => $result['code']]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Mã giảm giá không hợp lệ hoặc không đủ điều kiện']);
        }
    }

    public function setSelectedItems(): void
    {
        $this->ensureSession();
        header('Content-Type: application/json');

        if (!isset($_SESSION['user_id'])) {
            echo json_encode(['success' => false, 'message' => 'Vui lòng đăng nhập']);
            return;
        }

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['success' => false, 'message' => 'Invalid request method']);
            return;
        }

        $selectedItems = $_POST['selected_items'] ?? [];

        if (empty($selectedItems) || !is_array($selectedItems)) {
            echo json_encode(['success' => false, 'message' => 'Vui lòng chọn ít nhất một sản phẩm']);
            return;
        }
        $_SESSION['selected_items'] = $selectedItems;
        echo json_encode([
            'success' => true,
            'message' => 'Đã lưu sản phẩm đã chọn',
            'count' => count($selectedItems)
        ]);
    }

    public function saveAddress(): void
    {
        $this->ensureSession();
        header('Content-Type: application/json');

        if (!isset($_SESSION['user_id'])) {
            echo json_encode(['success' => false, 'message' => 'Vui lòng đăng nhập']);
            return;
        }

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['success' => false, 'message' => 'Invalid request method']);
            return;
        }

        $name = trim($_POST['name'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $address = trim($_POST['address'] ?? '');

        if (empty($name) || empty($phone) || empty($address)) {
            echo json_encode(['success' => false, 'message' => 'Vui lòng điền đầy đủ thông tin']);
            return;
        }

        // Validate phone number
        if (!preg_match('/^[0-9]{10,11}$/', $phone)) {
            echo json_encode(['success' => false, 'message' => 'Số điện thoại không hợp lệ']);
            return;
        }

        // Save to session
        $_SESSION['name'] = $name;
        $_SESSION['phone'] = $phone;
        $_SESSION['address'] = $address;

        // Optionally update user's phone if empty
        require_once __DIR__ . '/../models/UserModel.php';
        $userModel = new UserModel($this->conn);
        $userModel->updateUserPhoneIfEmpty($_SESSION['user_id'], $phone);

        echo json_encode([
            'success' => true,
            'message' => 'Lưu địa chỉ thành công'
        ]);
    }
}