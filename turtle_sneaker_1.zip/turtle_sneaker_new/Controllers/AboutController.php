<?php
class AboutController
{
    public function index()
    {
        require_once __DIR__ . '/../models/ProductModel.php';
        require_once __DIR__ . '/../configs/Database.php';
        $database = new Database();
        $conn = $database->connect();
        $productModel = new ProductModel($conn);
        $categories = $productModel->getCategories();
        require_once __DIR__ . '/../views/layouts/header.php';
        require_once __DIR__ . '/../views/about/index.php';
        require_once __DIR__ . '/../views/layouts/footer.php';
    }
}
