<?php
class ProductController
{
    private ProductModel $productModel;
    private ?OrderModel $orderModel;
    private ?ReviewModel $reviewModel;

    public function __construct(ProductModel $productModel, ?OrderModel $orderModel = null, ?ReviewModel $reviewModel = null)
    {
        $this->productModel = $productModel;
        $this->orderModel = $orderModel;
        $this->reviewModel = $reviewModel;
    }

    public function index(): void
    {
        $limit = 16;
        $currentPage = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
        $offset = ($currentPage - 1) * $limit;
        $categoryId = isset($_GET['category']) ? (int)$_GET['category'] : 0;

        $filterKeyword = trim($_GET['keyword'] ?? '');
        $filterCategories = isset($_GET['filter_category']) ? (array)$_GET['filter_category'] : [];
        $filterCategories = array_values(array_filter(array_map('intval', $filterCategories)));
        $selectedPriceRanges = isset($_GET['price_range']) ? array_filter((array)$_GET['price_range']) : [];

        $isFilterMode = !empty($filterKeyword) || !empty($filterCategories) || !empty($selectedPriceRanges);

        if ($isFilterMode) {
            $products = $this->productModel->searchProducts($filterKeyword, $filterCategories, $selectedPriceRanges, $limit, $offset);
            $totalProducts = $this->productModel->countSearchProducts($filterKeyword, $filterCategories, $selectedPriceRanges);
            $currentCategory = null;
        } elseif ($categoryId > 0) {
            $products = $this->productModel->getProductsByCategoryPaginated($categoryId, $limit, $offset);
            $totalProducts = $this->productModel->countProductsByCategory($categoryId);
            $currentCategory = $this->productModel->getCategoryById($categoryId);
        } else {
            $products = $this->productModel->getProductsPaginated($limit, $offset);
            $totalProducts = $this->productModel->countAllProducts();
            $currentCategory = null;
        }

        if (empty($products)) {
            if ($isFilterMode) {
                $products = $this->productModel->searchProducts($filterKeyword, $filterCategories, $selectedPriceRanges, $limit, 0);
            } elseif ($categoryId > 0) {
                $products = $this->productModel->getProductsByCategoryPaginated($categoryId, $limit, 0);
            } else {
                $products = $this->productModel->getProductsPaginated($limit, 0);
            }
        }

        $productImages = [];
        if (!empty($products)) {
            $productIds = array_column($products, 'id');
            $imageRows = $this->productModel->getImagesForProductIds($productIds);

            foreach ($imageRows as $row) {
                $productId = (int)$row['product_id'];
                if (!isset($productImages[$productId])) { 
                    $productImages[$productId] = [];
                }

                $productImages[$productId][] = $row['image_url'];
            } 
        }

        $totalPages = max(1, (int)ceil($totalProducts / $limit));  
        $categories = $this->productModel->getCategories(); 
        $selectedFilterCategories = $filterCategories; 
        $wishlistedProductIds = [];  
        if (isset($_SESSION['user_id'])) {   
            require_once __DIR__ . '/../models/WishlistModel.php';
            global $conn; 
            $wishlistModel = new WishlistModel($conn);
            $wishlistedProductIds = $wishlistModel->getWishlistProductIds($_SESSION['user_id']); 
        }

        require_once __DIR__ . '/../views/layouts/header.php'; 
        require_once __DIR__ . '/../views/product/index.php';
        require_once __DIR__ . '/../views/layouts/footer.php';  
    }

    public function detail($id = null): void
    {
        $id = $id !== null ? (int)$id : (isset($_GET['id']) ? (int)$_GET['id'] : 0);
        if ($id <= 0) {
            http_response_code(400);  
            echo 'Thiếu thông tin sản phẩm hợp lệ.'; 
            return;
        }
 
        $product = $this->productModel->getProductDetail($id); 
        if (!$product) { 
            http_response_code(404);
            echo 'Sản phẩm bạn tìm kiếm không tồn tại.'; 
            return;
        }

        $categories = $this->productModel->getCategories();
        $relatedProducts = $this->productModel->getRelatedProducts((int)$product['category_id'], $product['id'], 4);
        $additionalImages = $this->productModel->getProductImages($product['id']); 
        $thumbnails = array_column($additionalImages, 'image_url'); 
        $options = $this->productModel->getVariantOptions($product['id']); 

        $reviews = [];
        $avgRating = 0;
        $totalReviews = 0;
        $canReview = false;

        if ($this->reviewModel) { 
            $reviews = $this->productModel->getProductReviews($product['id']); 
            $ratingInfo = $this->reviewModel->getAverageRating($product['id']); 
            $avgRating = $ratingInfo['avg_rating'] ?? 0; 
            $totalReviews = $ratingInfo['total_reviews'] ?? 0;
        }

        if ($this->orderModel && isset($_SESSION['user_id'])) {
            $canReview = $this->orderModel->hasPurchasedProduct($_SESSION['user_id'], $product['id']);
        }

        if (empty($thumbnails)) {
            $thumbnails = [$product['main_image']];
        }

        $image = $product['main_image'] ?: 'https://placehold.co/600x600?text=No+Image';
        $name = $product['name'] ?? 'Sản phẩm';
        $basePriceRaw = (float)($product['price'] ?? 0);
        $price = number_format($basePriceRaw, 0, ',', '.');
        $categoryName = $product['category_name'] ?? 'Đang cập nhật';
        $product_code = $product['product_code'] ?? 'Đang cập nhật';
        $description = $product['description'] ?? '';
        $productId = $product['id'];
        $colors = $options['colors'] ?? [];
        $sizes = $options['sizes'] ?? [];
        $materialsList = $options['other'] ?? [];
        $materials = !empty($materialsList) ? implode(', ', $materialsList) : '';

        error_log("Product ID: $productId");
        error_log("Options from DB: " . print_r($options, true));
        error_log("Colors: " . print_r($colors, true));
        error_log("Sizes: " . print_r($sizes, true));

        require_once __DIR__ . '/../views/layouts/header.php';
        require_once __DIR__ . '/../views/product/detail.php';
        require_once __DIR__ . '/../views/layouts/footer.php';
    }
    public function search()
    {
        $keyword = $_GET['keyword'] ?? '';
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $limit = 12;
        $offset = ($page - 1) * $limit;

        $selectedCategories = isset($_GET['category']) ? $_GET['category'] : [];
        $selectedPriceRanges = isset($_GET['price_range']) ? $_GET['price_range'] : [];

        $selectedCategories = array_map('intval', $selectedCategories);
        $selectedCategories = array_filter($selectedCategories);

        $products = $this->productModel->searchProducts($keyword, $selectedCategories, $selectedPriceRanges, $limit, $offset);
        $totalProducts = $this->productModel->countSearchProducts($keyword, $selectedCategories, $selectedPriceRanges);
        $totalPages = ceil($totalProducts / $limit);
        $categories = $this->productModel->getCategories();

        require_once __DIR__ . '/../views/layouts/header.php';
        require_once __DIR__ . '/../views/product/search.php';
        require_once __DIR__ . '/../views/layouts/footer.php';
    }

    public function getPrice(): void
    {
        header('Content-Type: application/json');

        $productId = isset($_GET['product_id']) ? (int)$_GET['product_id'] : 0;
        $color = isset($_GET['color']) ? trim($_GET['color']) : '';
        $size = isset($_GET['size']) ? trim($_GET['size']) : '';

        if ($productId <= 0) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Sản phẩm không hợp lệ']);
            return;
        }

        $price = $this->productModel->getVariantPriceByAttributes($productId, $color, $size);

        // If variant price not found, use base product price
        if ($price === null) {
            $product = $this->productModel->getProductById($productId);
            $price = $product ? (float)($product['price'] ?? 0) : 0;
        }

        echo json_encode([
            'success' => true,
            'price' => $price,
            'formatted_price' => number_format($price, 0, ',', '.') . '₫'
        ]);
    }

    public function getByCategory(): void
    {
        header('Content-Type: application/json');

        $category = isset($_GET['category']) ? trim($_GET['category']) : '';

        if (empty($category)) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Danh mục không hợp lệ']);
            return;
        }

        $products = $this->productModel->getProductsByCategoryName($category, 12);

        if (empty($products)) {
            echo json_encode(['success' => true, 'products' => []]);
            return;
        }

        echo json_encode([
            'success' => true,
            'products' => $products
        ]);
    }

    public function submitReview()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: index.php');
            exit;
        }

        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        if (!isset($_SESSION['user_id'])) {
            $_SESSION['alert'] = ['type' => 'error', 'message' => 'Vui lòng đăng nhập để đánh giá!'];
            header('Location: index.php?controller=auth&action=login');
            exit;
        }

        $userId = $_SESSION['user_id'];
        $productId = $_POST['product_id'] ?? 0;
        $rating = $_POST['rating'] ?? 0;
        $comment = $_POST['comment'] ?? '';

        if ($productId <= 0 || $rating <= 0 || empty($comment)) {
            $_SESSION['alert'] = ['type' => 'error', 'message' => 'Vui lòng điền đầy đủ thông tin!'];
            header("Location: index.php?controller=product&action=detail&id=$productId");
            exit;
        }

        if ($this->orderModel && !$this->orderModel->hasPurchasedProduct($userId, $productId)) {
            $_SESSION['alert'] = ['type' => 'error', 'message' => 'Bạn cần mua sản phẩm này để đánh giá!'];
            header("Location: index.php?controller=product&action=detail&id=$productId");
            exit;
        }

        if ($this->reviewModel && $this->reviewModel->createReview($userId, $productId, $rating, $comment)) {
            $_SESSION['alert'] = ['type' => 'success', 'message' => 'Đánh giá của bạn đã được gửi và đang chờ duyệt!'];
        } else {
            $_SESSION['alert'] = ['type' => 'error', 'message' => 'Có lỗi xảy ra, vui lòng thử lại!'];
        }

        header("Location: index.php?controller=product&action=detail&id=$productId");
        exit;
    }
}