<?php
class Database {
    private $host = "127.0.0.1";
    private $user = "root"; 
    private $pass = "";     
    private $dbname = "turtle_sneaker"; 
    public $connection;
    public function connect() { 
        $this->connection = new mysqli($this->host, $this->user, $this->pass, $this->dbname);
        if ($this->connection->connect_error) {
            error_log("Kết nối CSDL thất bại: " . $this->connection->connect_error);
            return false;
        }
        $this->connection->set_charset("utf8mb4");
        return $this->connection;
    }
    public function getConnection(): ?mysqli {
        return $this->connection;
    }
}