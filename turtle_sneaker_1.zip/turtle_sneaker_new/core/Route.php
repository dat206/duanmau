<?php
/**
 * Route Class
 * Helper class for defining routes
 */
class Route
{
    protected static $routes = [];
    protected static $groupStack = [];
    protected static $namedRoutes = [];

    /**
     * Register a GET route
     * @param string $uri
     * @param string $action
     * @return RouteRegistrar
     */
    public static function get($uri, $action)
    {
        return self::addRoute('GET', $uri, $action);
    }

    /**
     * Register a POST route
     * @param string $uri
     * @param string $action
     * @return RouteRegistrar
     */
    public static function post($uri, $action)
    {
        return self::addRoute('POST', $uri, $action);
    }

    /**
     * Register a route for multiple methods
     * @param array $methods
     * @param string $uri
     * @param string $action
     * @return RouteRegistrar
     */
    public static function match($methods, $uri, $action)
    {
        $registrar = null;
        foreach ($methods as $method) {
            $registrar = self::addRoute($method, $uri, $action);
        }
        return $registrar;
    }

    /**
     * Add a route to the collection
     * @param string $method
     * @param string $uri
     * @param string $action
     * @return RouteRegistrar
     */
    protected static function addRoute($method, $uri, $action)
    {
        $uri = self::prefix($uri);
        
        $route = [
            'method' => $method,
            'uri' => $uri,
            'action' => $action,
            'middleware' => self::getGroupMiddleware(),
            'name' => null
        ];

        self::$routes[$method][] = $route;
        
        return new RouteRegistrar(count(self::$routes[$method]) - 1, $method);
    }

    /**
     * Create a route group
     * @param array $attributes
     * @param callable $callback
     */
    public static function group($attributes, $callback)
    {
        self::$groupStack[] = $attributes;
        
        call_user_func($callback);
        
        array_pop(self::$groupStack);
    }

    /**
     * Get prefix from group stack
     * @param string $uri
     * @return string
     */
    protected static function prefix($uri)
    {
        $prefix = '';
        foreach (self::$groupStack as $group) {
            if (isset($group['prefix'])) {
                $prefix .= '/' . trim($group['prefix'], '/');
            }
        }
        
        return trim($prefix . '/' . trim($uri, '/'), '/') ?: '/';
    }

    /**
     * Get middleware from group stack
     * @return array
     */
    protected static function getGroupMiddleware()
    {
        $middleware = [];
        foreach (self::$groupStack as $group) {
            if (isset($group['middleware'])) {
                $middleware[] = $group['middleware'];
            }
        }
        return $middleware;
    }

    /**
     * Get all routes
     * @return array
     */
    public static function getRoutes()
    {
        return self::$routes;
    }

    /**
     * Set route name
     * @param int $index
     * @param string $method
     * @param string $name
     */
    public static function setRouteName($index, $method, $name)
    {
        self::$routes[$method][$index]['name'] = $name;
        self::$namedRoutes[$name] = &self::$routes[$method][$index];
    }

    /**
     * Get route by name
     * @param string $name
     * @return array|null
     */
    public static function getRouteByName($name)
    {
        return self::$namedRoutes[$name] ?? null;
    }
}

/**
 * RouteRegistrar Class
 * Allows method chaining for route registration
 */
class RouteRegistrar
{
    protected $index;
    protected $method;

    public function __construct($index, $method)
    {
        $this->index = $index;
        $this->method = $method;
    }

    /**
     * Set route name
     * @param string $name
     * @return $this
     */
    public function name($name)
    {
        Route::setRouteName($this->index, $this->method, $name);
        return $this;
    }
}
