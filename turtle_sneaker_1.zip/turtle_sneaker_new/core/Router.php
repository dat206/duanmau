<?php
/**
 * Router Class
 * Main routing engine that matches requests to routes and executes controllers
 */
class Router
{
    protected $routes = [];
    protected $conn;

    public function __construct($conn = null)
    {
        $this->routes = Route::getRoutes();
        $this->conn = $conn;
    }

    /**
     * Dispatch the request to the appropriate controller
     */
    public function dispatch()
    {
        $uri = Request::uri();
        $method = Request::method();

        // Debug logging
        error_log("=== ROUTER DEBUG ===");
        error_log("URI: {$uri}");
        error_log("METHOD: {$method}");
        error_log("Available routes for {$method}: " . (isset($this->routes[$method]) ? count($this->routes[$method]) : 0));

        // Try to find matching route
        if (isset($this->routes[$method])) {
            foreach ($this->routes[$method] as $route) {
                $params = $this->matchRoute($uri, $route['uri']);
                
                if ($params !== false) {
                    // Check middleware
                    if (!empty($route['middleware'])) {
                        foreach ($route['middleware'] as $middleware) {
                            if (!$this->runMiddleware($middleware)) {
                                return;
                            }
                        }
                    }
                    
                    // Execute the route action
                    return $this->callAction($route['action'], $params);
                }
            }
        }

        // No route found - 404
        $this->notFound();
    }

    /**
     * Match URI against route pattern
     * @param string $uri
     * @param string $routeUri
     * @return array|false
     */
    protected function matchRoute($uri, $routeUri)
    {
        // Exact match
        if ($uri === $routeUri) {
            return [];
        }

        // Convert route pattern to regex
        $pattern = preg_replace('/\{([a-zA-Z0-9_]+)\?\}/', '?([^/]*)?', $routeUri);
        $pattern = preg_replace('/\{([a-zA-Z0-9_]+)\}/', '([^/]+)', $pattern);
        $pattern = '#^' . $pattern . '$#';

        if (preg_match($pattern, $uri, $matches)) {
            array_shift($matches); // Remove full match
            return $matches;
        }

        return false;
    }

    /**
     * Call the controller action
     * @param string $action
     * @param array $params
     */
    protected function callAction($action, $params = [])
    {
        list($controller, $method) = explode('@', $action);

        // Instantiate controller
        $controllerInstance = $this->instantiateController($controller);

        if (!method_exists($controllerInstance, $method)) {
            die("Method {$method} not found in {$controller}");
        }

        // Debug: Log what we're calling
        error_log("Router calling: {$controller}@{$method} with params: " . json_encode($params));
        
        // Call the method with parameters
        return call_user_func_array([$controllerInstance, $method], $params);
    }

    /**
     * Instantiate the controller
     * @param string $controller
     * @return object
     */
    protected function instantiateController($controller)
    {
        $controllerFile = __DIR__ . '/../controllers/' . $controller . '.php';
        
        if (!file_exists($controllerFile)) {
            die("Controller file not found: {$controllerFile}");
        }

        require_once $controllerFile;

        if (!class_exists($controller)) {
            die("Controller class not found: {$controller}");
        }

        // Check if controller needs database connection
        $reflection = new ReflectionClass($controller);
        $constructor = $reflection->getConstructor();

        if ($constructor && $constructor->getNumberOfParameters() > 0) {
            // Controller expects parameters (likely models)
            return $this->instantiateControllerWithDependencies($controller);
        }

        return new $controller();
    }

    /**
     * Instantiate controller with dependencies
     * @param string $controller
     * @return object
     */
    protected function instantiateControllerWithDependencies($controller)
    {
        // This is a simplified version - you may need to adjust based on your controllers
        switch ($controller) {
            case 'HomeController':
                require_once __DIR__ . '/../models/ProductModel.php';
                $productModel = new ProductModel($this->conn);
                return new HomeController($productModel);

            case 'ProductController':
                require_once __DIR__ . '/../models/ProductModel.php';
                require_once __DIR__ . '/../models/OrderModel.php';
                require_once __DIR__ . '/../models/ReviewModel.php';
                $productModel = new ProductModel($this->conn);
                $orderModel = new OrderModel($this->conn);
                $reviewModel = new ReviewModel($this->conn);
                return new ProductController($productModel, $orderModel, $reviewModel);

            case 'AuthController':
                require_once __DIR__ . '/../models/UserModel.php';
                $userModel = new UserModel($this->conn);
                return new AuthController($userModel);

            case 'AdminController':
                require_once __DIR__ . '/../models/ProductModel.php';
                require_once __DIR__ . '/../models/OrderModel.php';
                require_once __DIR__ . '/../models/UserModel.php';
                require_once __DIR__ . '/../models/CategoryModel.php';
                require_once __DIR__ . '/../models/ReviewModel.php';
                require_once __DIR__ . '/../models/CouponModel.php';
                $productModel = new ProductModel($this->conn);
                $orderModel = new OrderModel($this->conn);
                $userModel = new UserModel($this->conn);
                $categoryModel = new CategoryModel($this->conn);
                $reviewModel = new ReviewModel($this->conn);
                $couponModel = new CouponModel($this->conn);
                return new AdminController($productModel, $orderModel, $userModel, $categoryModel, $reviewModel, $couponModel);

            case 'CartController':
                require_once __DIR__ . '/../models/ProductModel.php';
                require_once __DIR__ . '/../models/OrderModel.php';
                require_once __DIR__ . '/../models/CartModel.php';
                require_once __DIR__ . '/../models/CouponModel.php';
                require_once __DIR__ . '/../models/ShippingModel.php';
                $productModel = new ProductModel($this->conn);
                $orderModel = new OrderModel($this->conn);
                $cartModel = new CartModel($this->conn);
                $couponModel = new CouponModel($this->conn);
                $shippingModel = new ShippingModel($this->conn);
                return new CartController($productModel, $orderModel, $cartModel, $couponModel, $shippingModel);

            case 'UserController':
                require_once __DIR__ . '/../models/UserModel.php';
                require_once __DIR__ . '/../models/ProductModel.php';
                require_once __DIR__ . '/../models/WishlistModel.php';
                require_once __DIR__ . '/../models/ReviewModel.php';
                $userModel = new UserModel($this->conn);
                $productModel = new ProductModel($this->conn);
                $wishlistModel = new WishlistModel($this->conn);
                $reviewModel = new ReviewModel($this->conn);
                $controller = new UserController($userModel);
                $controller->productModel = $productModel;
                $controller->wishlistModel = $wishlistModel;
                $controller->reviewModel = $reviewModel;
                return $controller;

            case 'AboutController':
                return new AboutController();

            default:
                return new $controller();
        }
    }

    /**
     * Run middleware
     * @param string $middleware
     * @return bool
     */
    protected function runMiddleware($middleware)
    {
        switch ($middleware) {
            case 'auth':
                if (!isset($_SESSION['user_id'])) {
                    redirect('/dang-nhap');
                    return false;
                }
                break;

            case 'admin':
                if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
                    redirect('/dang-nhap');
                    return false;
                }
                break;

            case 'guest':
                if (isset($_SESSION['user_id'])) {
                    redirect('/');
                    return false;
                }
                break;
        }

        return true;
    }

    /**
     * Handle 404 - Not Found
     */
    protected function notFound()
    {
        http_response_code(404);
        echo '<h1>404 - Không tìm thấy trang</h1>';
        echo '<p>Trang bạn đang tìm kiếm không tồn tại.</p>';
        echo '<a href="/">Quay về trang chủ</a>';
        exit;
    }
}
