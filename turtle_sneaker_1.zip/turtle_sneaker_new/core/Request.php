<?php
/**
 * Request Class
 * Handles HTTP request information
 */
class Request
{
    /**
     * Get the request URI
     * @return string
     */
    public static function uri()
    {
        $uri = trim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');
        
        // Remove base path if exists
        $basePath = trim(dirname($_SERVER['SCRIPT_NAME']), '/');
        if ($basePath && strpos($uri, $basePath) === 0) {
            $uri = substr($uri, strlen($basePath));
            $uri = trim($uri, '/');
        }
        
        return $uri ?: '/';
    }

    /**
     * Get the request method
     * @return string
     */
    public static function method()
    {
        return $_SERVER['REQUEST_METHOD'];
    }

    /**
     * Get all GET parameters
     * @return array
     */
    public static function get($key = null, $default = null)
    {
        if ($key === null) {
            return $_GET;
        }
        return $_GET[$key] ?? $default;
    }

    /**
     * Get all POST parameters
     * @return array
     */
    public static function post($key = null, $default = null)
    {
        if ($key === null) {
            return $_POST;
        }
        return $_POST[$key] ?? $default;
    }

    /**
     * Get request parameter (POST or GET)
     * @param string $key
     * @param mixed $default
     * @return mixed
     */
    public static function input($key, $default = null)
    {
        return $_POST[$key] ?? $_GET[$key] ?? $default;
    }

    /**
     * Check if request is POST
     * @return bool
     */
    public static function isPost()
    {
        return self::method() === 'POST';
    }

    /**
     * Check if request is GET
     * @return bool
     */
    public static function isGet()
    {
        return self::method() === 'GET';
    }

    /**
     * Check if request is AJAX
     * @return bool
     */
    public static function isAjax()
    {
        return !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
               strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
    }

    /**
     * Get previous URL
     * @return string
     */
    public static function previous()
    {
        return $_SERVER['HTTP_REFERER'] ?? '/';
    }
}
