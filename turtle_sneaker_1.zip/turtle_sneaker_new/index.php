<?php
/**
 * Turtle Sneaker - Entry Point
 * Modern routing system with Vietnamese URLs
 */

// Start session
session_start();

// Load core classes
require_once __DIR__ . '/core/Request.php';
require_once __DIR__ . '/core/Route.php';
require_once __DIR__ . '/core/Router.php';

// Load helpers
require_once __DIR__ . '/helpers/url_helper.php';

// Load database
require_once __DIR__ . '/configs/Database.php';

// Load base model
require_once __DIR__ . '/models/BaseModel.php';

// Connect to database
$database = new Database();
$conn = $database->connect(); 

if (!$conn) {
    http_response_code(500);
    echo 'Không thể kết nối cơ sở dữ liệu.';
    exit;
}

// Check if user is locked
if (isset($_SESSION['user_id'])) {
    $checkLockSql = "SELECT is_locked FROM users WHERE id = ?";
    $checkLockStmt = $conn->prepare($checkLockSql);
    if ($checkLockStmt) {
        $checkLockStmt->bind_param("i", $_SESSION['user_id']);
        $checkLockStmt->execute();
        $checkLockResult = $checkLockStmt->get_result();
        $checkLockUser = $checkLockResult->fetch_assoc();
        
        if ($checkLockUser && $checkLockUser['is_locked'] == 1) {
            session_unset();
            session_destroy();
            
            session_start();
            $_SESSION['flash_error'] = "Tài khoản của bạn đã bị khóa do vi phạm cộng đồng";
            redirect('/dang-nhap');
            exit;
        }
        $checkLockStmt->close();
    }
}

// Load route definitions
require_once __DIR__ . '/routes/web.php';

// Initialize router and dispatch request
$router = new Router($conn);
$router->dispatch();