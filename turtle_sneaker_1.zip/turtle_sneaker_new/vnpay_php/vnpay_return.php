<?php
session_start();

require_once "./config.php";
require_once __DIR__ . "/../configs/Database.php";
require_once __DIR__ . "/../models/BaseModel.php";
require_once __DIR__ . "/../models/PaymentModel.php";

// Thu thập dữ liệu trả về từ VNPay
$vnp_SecureHash = $_GET['vnp_SecureHash'] ?? '';
$inputData = [];
foreach ($_GET as $key => $value) {
    if (substr($key, 0, 4) == "vnp_") {
        $inputData[$key] = $value;
    }
}

unset($inputData['vnp_SecureHash']);
ksort($inputData);
$i = 0;
$hashData = "";
foreach ($inputData as $key => $value) {
    if ($i == 1) {
        $hashData = $hashData . '&' . urlencode($key) . "=" . urlencode($value);
    } else {
        $hashData = $hashData . urlencode($key) . "=" . urlencode($value);
        $i = 1;
    }
}

$secureHash = hash_hmac('sha512', $hashData, $vnp_HashSecret);
$paymentId = isset($_GET['vnp_TxnRef']) ? (int)$_GET['vnp_TxnRef'] : 0;
$responseCode = $_GET['vnp_ResponseCode'] ?? '';

// Xác định base URL để redirect về website
$protocol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http");
$host = $_SERVER['HTTP_HOST'];
$scriptPath = dirname(dirname($_SERVER['SCRIPT_NAME'])); // vnpay_php -> root
$basePath = rtrim($scriptPath, '/');
$baseUrl = $protocol . "://" . $host . $basePath;

// Kết nối CSDL và khởi tạo PaymentModel
$db = new Database();
$conn = $db->connect();
$paymentModel = new PaymentModel($conn);

if ($secureHash === $vnp_SecureHash) {
    if ($responseCode === '00') {
        // Thanh toán thành công -> tìm đơn hàng tương ứng và đánh dấu đã thanh toán
        if ($paymentId > 0) {
            $payment = $paymentModel->getById($paymentId);
            if ($payment && !empty($payment['order_id'])) {
                $orderId = (int)$payment['order_id'];
                $paymentModel->markPaid($orderId);
                
                // Clear cart after successful payment
                if (isset($_SESSION['buy_now_cart'])) {
                    unset($_SESSION['buy_now_cart']);
                } else {
                    $_SESSION['cart'] = [];
                    $_SESSION['cart_count'] = 0;
                }
                unset($_SESSION['selected_items']);
            }
        }
        $_SESSION['success_message'] = 'Thanh toán VNPay thành công! Đơn hàng của bạn đã được xác nhận.';
        header("Location: " . $baseUrl . "/cam-on");
        exit;
    } else {
        // Thanh toán thất bại hoặc người dùng hủy
        $_SESSION['error_message'] = 'Thanh toán VNPay không thành công hoặc đã bị hủy. Bạn có thể thử lại hoặc chọn phương thức khác.';
        header("Location: " . $baseUrl . "/thanh-toan");
        exit;
    }
} else {
    // Sai chữ ký
    $_SESSION['error_message'] = 'Có lỗi trong quá trình xác thực thanh toán VNPay. Vui lòng thử lại hoặc liên hệ hỗ trợ.';
    header("Location: " . $baseUrl . "/thanh-toan");
    exit;
}
