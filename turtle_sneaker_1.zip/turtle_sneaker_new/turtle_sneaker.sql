-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 09, 2025 at 09:38 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `turtle_sneaker`
--

-- --------------------------------------------------------

--
-- Table structure for table `addresses`
--

CREATE TABLE `addresses` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `address_line` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `district` varchar(255) DEFAULT NULL,
  `ward` varchar(255) DEFAULT NULL,
  `is_default` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `addresses`
--

INSERT INTO `addresses` (`id`, `user_id`, `full_name`, `phone`, `address_line`, `city`, `district`, `ward`, `is_default`) VALUES
(1, 1, 'Test User', '0123456789', 'Test Address', '', '', '', 1),
(2, 8, 'Phạm Văn Quân', '0978914708', 'Đông Lĩnh - Thanh Hóa', '', '', '', 1),
(3, 8, 'Phạm Văn Quân', '0978914708', 'Đông Lĩnh - Thanh Hóa', '', '', '', 1),
(4, 8, 'Phạm Văn Quân', '0978914708', 'Đông Lĩnh - Thanh Hóa', '', '', '', 1),
(5, 8, 'Phạm Văn Quân', '0978914708', 'Đông Lĩnh - Thanh Hóa', '', '', '', 1),
(6, 8, 'Phạm Văn Quân', '0978914708', 'Đông Lĩnh - Thanh Hóa', '', '', '', 1),
(7, 8, 'Phạm Văn Quân', '0978914708', 'Đông Lĩnh - Thanh Hóa', '', '', '', 1),
(8, 8, 'Phạm Văn Quân', '0978914708', 'Đông Lĩnh - Thanh Hóa', '', '', '', 1),
(9, 8, 'Phạm Văn Quân', '0978914708', 'Đông Lĩnh - Thanh Hóa', '', '', '', 1),
(10, 8, 'Phạm Văn Quân', '0978914708', 'Đông Lĩnh - Thanh Hóa', '', '', '', 1),
(11, 8, 'Phạm Văn Quân', '0978914708', 'Đông Lĩnh - Thanh Hóa', '', '', '', 1),
(12, 8, 'Phạm Văn Quân', '0978914708', 'Đông Lĩnh - Thanh Hóa', '', '', '', 1),
(13, 8, 'Phạm Văn Quân', '0978914708', 'Đông Lĩnh - Thanh Hóa', '', '', '', 1),
(14, 8, 'Phạm Văn Quân', '0978914708', 'Đông Lĩnh - Thanh Hóa', '', '', '', 1),
(15, 8, 'Phạm Văn Quân', '0978914708', 'Đông Lĩnh - Thanh Hóa', '', '', '', 1),
(16, 8, 'Phạm Văn Quân', '0978914708', 'Đông Lĩnh - Thanh Hóaasdasd', '', '', '', 1),
(17, 8, 'Phạm Văn Quân', '0978914708', 'Đông Lĩnh - Thanh Hóa', '', '', '', 1),
(18, 8, 'Phạm Văn Quân', '0978914708', 'Đông Lĩnh - Thanh Hóa', '', '', '', 1),
(19, 8, 'Phạm Văn Quân', '0978914708', 'Đông Lĩnh - Thanh Hóa', '', '', '', 1),
(20, 8, 'Phạm Văn Quân', '0978914708', 'Đông Lĩnh - Thanh Hóa', '', '', '', 1),
(21, 8, 'Phạm Văn Quân', '0978914708', 'Đông Lĩnh - Thanh Hóa', '', '', '', 1),
(22, 8, 'Phạm Văn Quân', '0978914708', 'Đông Lĩnh - Thanh Hóa', '', '', '', 1),
(23, 8, 'Phạm Văn Quân', '0978914708', 'Đông Lĩnh - Thanh Hóa', '', '', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `carts`
--

CREATE TABLE `carts` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `carts`
--

INSERT INTO `carts` (`id`, `user_id`, `created_at`) VALUES
(1, 2, '2025-11-10 09:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `cart_items`
--

CREATE TABLE `cart_items` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `variant_id` int(11) DEFAULT NULL,
  `color` varchar(50) DEFAULT NULL,
  `size` varchar(20) DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart_items`
--

INSERT INTO `cart_items` (`id`, `user_id`, `product_id`, `variant_id`, `color`, `size`, `quantity`, `created_at`, `updated_at`) VALUES
(2, 7, 8, NULL, '', '', 7, '2025-11-23 13:31:31', '2025-11-23 13:31:31'),
(3, 6, 4, NULL, '', '', 1, '2025-11-23 13:48:28', '2025-11-23 13:48:28'),
(4, 6, 8, NULL, '', '43', 5, '2025-11-23 17:43:13', '2025-11-23 17:43:13'),
(32, 8, 31, NULL, 'Trắng xanh lá', '38', 2, '2025-12-08 22:47:37', '2025-12-08 22:52:32'),
(33, 8, 7, NULL, 'Đen', '43', 1, '2025-12-08 22:52:55', '2025-12-08 22:52:55'),
(34, 8, 33, NULL, 'xanh rêu', '37', 1, '2025-12-08 23:18:30', '2025-12-08 23:18:30');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL COMMENT 'Thời điểm xóa mềm (NULL = chưa xóa)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `description`, `deleted_at`) VALUES
(1, 'Giày Sneaker', 'Thiết kế sneaker thời trang', NULL),
(2, 'Giày Boots', 'Boots thời trang mùa đông', NULL),
(3, 'Giày Chạy bộ', 'Giày chuyên dụng cho chạy bộ', NULL),
(4, 'Giày Bóng rổ', 'Hiệu năng dành cho bóng rổ', NULL),
(7, 'Giày Bóng đá', 'Hiệu năng dành cho bóng đá', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `coupons`
--

CREATE TABLE `coupons` (
  `id` int(11) NOT NULL,
  `code` varchar(255) DEFAULT NULL,
  `discount_amount` decimal(10,2) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `min_order_value` decimal(10,2) DEFAULT 0.00,
  `quantity` int(11) DEFAULT 0,
  `used_count` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT NULL,
  `expiration_date` datetime DEFAULT NULL COMMENT 'Ngày hết hạn của mã giảm giá',
  `deleted_at` datetime DEFAULT NULL COMMENT 'Thời điểm xóa mềm (NULL = chưa xóa)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `coupons`
--

INSERT INTO `coupons` (`id`, `code`, `discount_amount`, `type`, `min_order_value`, `quantity`, `used_count`, `is_active`, `expiration_date`, `deleted_at`) VALUES
(6, 'VUIXUANDONTET', 50000.00, 'amount', 150000.00, 10, 0, 1, '2026-01-03 10:16:00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `address_id` int(10) UNSIGNED NOT NULL,
  `coupon_id` int(11) DEFAULT NULL,
  `current_status_id` int(11) DEFAULT NULL COMMENT 'Khóa ngoại tới trạng thái hiện tại trong order_statuses',
  `subtotal_price` decimal(10,2) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `shipping_fee` decimal(10,2) DEFAULT NULL,
  `shipping_method` int(11) DEFAULT 1,
  `payment_method` varchar(50) DEFAULT 'cod' COMMENT 'Phương thức thanh toán: cod, vnpay',
  `tax` decimal(10,2) DEFAULT 0.00 COMMENT 'Thuế áp dụng cho đơn hàng',
  `total_amount` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `address_id`, `coupon_id`, `current_status_id`, `subtotal_price`, `created_at`, `shipping_fee`, `shipping_method`, `payment_method`, `tax`, `total_amount`) VALUES
(1, 8, 4, NULL, 6, 649000.00, '2025-12-06 10:00:17', 25000.00, 1, 'cod', 674000.00, 674000.00),
(2, 8, 5, NULL, 8, 649000.00, '2025-12-06 10:00:40', 25000.00, 1, 'cod', 674000.00, 674000.00),
(3, 8, 6, NULL, 7, 190000.00, '2025-12-06 10:03:34', 25000.00, 1, 'cod', 215000.00, 215000.00),
(4, 8, 7, NULL, 7, 999000.00, '2025-12-06 11:40:32', 25000.00, 1, 'cod', 1024000.00, 1024000.00),
(5, 8, 8, NULL, 7, 890000.00, '2025-12-06 11:48:40', 25000.00, 1, 'cod', 915000.00, 915000.00),
(6, 8, 9, NULL, 7, 299000.00, '2025-12-06 11:49:04', 25000.00, 1, 'cod', 324000.00, 324000.00),
(7, 8, 10, NULL, 7, 287560.00, '2025-12-06 12:01:15', 25000.00, 1, 'cod', 312560.00, 312560.00),
(8, 8, 11, NULL, 7, 312006.50, '2025-12-06 12:03:36', 25000.00, 1, 'vnpay', 337006.50, 337006.50),
(9, 8, 12, NULL, 7, 250000.00, '2025-12-07 16:30:19', 69000.00, 3, 'cod', 319000.00, 319000.00),
(10, 8, 13, NULL, 1, 327824.00, '2025-12-08 21:16:23', 25000.00, 1, 'cod', 352824.00, 352824.00),
(11, 8, 14, NULL, 8, 560000.00, '2025-12-08 21:16:27', 25000.00, 1, 'cod', 585000.00, 585000.00),
(12, 8, 15, NULL, 7, 409780.00, '2025-12-08 21:16:44', 25000.00, 1, 'cod', 434780.00, 434780.00),
(13, 8, 16, NULL, 8, 331800.00, '2025-12-08 21:20:43', 25000.00, 1, 'cod', 306800.00, 306800.00),
(14, 8, 17, NULL, 1, 950000.00, '2025-12-09 05:51:43', 25000.00, 1, 'vnpay', 975000.00, 975000.00),
(15, 8, 18, NULL, 1, 380000.00, '2025-12-09 05:52:43', 69000.00, 3, 'cod', 399000.00, 399000.00),
(16, 8, 19, NULL, 1, 299000.00, '2025-12-09 05:53:53', 25000.00, 1, 'vnpay', 274000.00, 274000.00),
(17, 8, 20, NULL, 6, 189335.00, '2025-12-09 05:54:45', 25000.00, 1, 'vnpay', 214335.00, 214335.00),
(18, 8, 21, NULL, 7, 221200.00, '2025-12-09 05:59:19', 69000.00, 3, 'vnpay', 240200.00, 240200.00),
(19, 8, 22, NULL, 7, 350000.00, '2025-12-09 06:18:50', 25000.00, 1, 'vnpay', 325000.00, 325000.00),
(20, 8, 23, NULL, 7, 330694.00, '2025-12-09 15:33:19', 25000.00, 1, 'cod', 305694.00, 305694.00);

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `shoe_variant_id` int(11) DEFAULT NULL,
  `variant_snapshot_json` text DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `price_each` decimal(10,0) DEFAULT NULL,
  `selected_color` varchar(100) DEFAULT NULL,
  `selected_size` varchar(50) DEFAULT NULL,
  `variant_map_id` int(11) DEFAULT NULL COMMENT 'Khóa ngoại tới shoe_variant_attribute_map'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `shoe_variant_id`, `variant_snapshot_json`, `quantity`, `price_each`, `selected_color`, `selected_size`, `variant_map_id`) VALUES
(13270298, 11, 599, '{\"shoe_id\":42,\"product_name\":\"Turtle Iron Defense\",\"product_code\":\"BD - 005\",\"sku\":\"BD - 005-01\",\"main_image\":\"public\\/uploads\\/1765127538_unnamed (13).jpg\"}', 1, 280000, 'Xanh dương', '43', NULL),
(38846649, 2, 92, NULL, 1, 350000, 'xanh rêu', '39', NULL),
(80403933, 6, 7, NULL, 1, 299000, 'Trắng', '43', NULL),
(110147775, 18, 479, '{\"shoe_id\":8,\"product_name\":\"Urban Shell\",\"product_code\":\"TS-008\",\"sku\":\"TS-008-01\",\"main_image\":\"public\\/uploads\\/1765125675_unnamed (9).jpg\"}', 1, 221200, 'Xanh dương', '41', NULL),
(193576936, 15, 96, '{\"shoe_id\":31,\"product_name\":\"Turtle Runasdasd\",\"product_code\":\"CB - 005\",\"sku\":\"CB - 005-01\",\"main_image\":\"public\\/uploads\\/1764984472_unnamed (3).jpg\"}', 2, 190000, 'Trắng xanh lá', '38', NULL),
(212303920, 17, 96, '{\"shoe_id\":31,\"product_name\":\"Turtle Runasdasd\",\"product_code\":\"CB - 005\",\"sku\":\"CB - 005-01\",\"main_image\":\"public\\/uploads\\/1764984472_unnamed (3).jpg\"}', 1, 189335, 'đen trắng', '40', NULL),
(215145708, 9, 24, '{\"shoe_id\":32,\"product_name\":\"Turtle Super\",\"product_code\":\"BR - 001\",\"sku\":\"\\u00e1dasdasdasd-01\",\"main_image\":\"public\\/uploads\\/1764984137_unnamed (4).jpg\"}', 1, 250000, 'tím', '42', NULL),
(222385775, 13, 614, '{\"shoe_id\":6,\"product_name\":\"Canvas Turtle\",\"product_code\":\"TS-006\",\"sku\":\"TS-006-01\",\"main_image\":\"public\\/uploads\\/1765127596_unnamed (11).jpg\"}', 1, 331800, 'Xanh dương', '41', NULL),
(265436057, 8, 7, NULL, 1, 312007, 'Đen', '42', NULL),
(573069361, 4, 92, NULL, 1, 350000, 'xanh rêu', '39', NULL),
(648231548, 5, 92, NULL, 2, 350000, 'xanh rêu', '39', NULL),
(653354137, 2, 7, NULL, 1, 299000, 'Trắng', '43', NULL),
(781895823, 16, 7, '{\"shoe_id\":7,\"product_name\":\"Hardback 90\",\"product_code\":\"TS-007\",\"sku\":\"TS-007-01\",\"main_image\":\"public\\/uploads\\/1765127631_unnamed (10).jpg\"}', 1, 299000, 'Đen', '43', NULL),
(869581169, 12, 689, '{\"shoe_id\":41,\"product_name\":\"Turtle Shield Goal\",\"product_code\":\"BD - 004\",\"sku\":\"BD - 004-01\",\"main_image\":\"public\\/uploads\\/1765127493_unnamed (14).jpg\"}', 1, 409780, 'Xanh dương', '43', NULL),
(968553974, 3, 96, NULL, 1, 190000, 'Xanh than', '43', NULL),
(1020557894, 19, 92, '{\"shoe_id\":33,\"product_name\":\"Turtle Best\",\"product_code\":\"TS - 015\",\"sku\":\"TS - 015-01\",\"main_image\":\"public\\/uploads\\/1764983968_unnamed (5).jpg\"}', 1, 350000, 'xanh rêu', '37', NULL),
(1404228283, 7, 5, NULL, 1, 287560, 'Xanh dương', '41', NULL),
(1492321406, 4, 7, NULL, 1, 299000, 'Trắng', '43', NULL),
(1494293355, 10, 599, '{\"shoe_id\":42,\"product_name\":\"Turtle Iron Defense\",\"product_code\":\"BD - 005\",\"sku\":\"BD - 005-01\",\"main_image\":\"public\\/uploads\\/1765127538_unnamed (13).jpg\"}', 1, 327824, 'Xanh dương', '43', NULL),
(1580913586, 5, 96, NULL, 1, 190000, 'Xanh than', '43', NULL),
(1588863810, 1, 7, NULL, 1, 299000, 'Trắng', '43', NULL),
(1694037118, 20, 7, '{\"shoe_id\":7,\"product_name\":\"Hardback 90\",\"product_code\":\"BS-002\",\"sku\":\"TS-007-01\",\"main_image\":\"public\\/uploads\\/1765127631_unnamed (10).jpg\"}', 1, 330694, 'Xanh dương', '41', NULL),
(1710214277, 4, 96, NULL, 1, 190000, 'Xanh than', '43', NULL),
(1819932695, 1, 92, NULL, 1, 350000, 'xanh rêu', '39', NULL),
(1840419007, 4, 223, NULL, 1, 160000, 'Xanh dương', '39', NULL),
(1840555373, 14, 96, '{\"shoe_id\":31,\"product_name\":\"Turtle Runasdasd\",\"product_code\":\"CB - 005\",\"sku\":\"CB - 005-01\",\"main_image\":\"public\\/uploads\\/1764984472_unnamed (3).jpg\"}', 5, 190000, 'Trắng xanh lá', '38', NULL),
(1846657506, 11, 599, '{\"shoe_id\":42,\"product_name\":\"Turtle Iron Defense\",\"product_code\":\"BD - 005\",\"sku\":\"BD - 005-01\",\"main_image\":\"public\\/uploads\\/1765127538_unnamed (13).jpg\"}', 1, 280000, 'Xanh dương', '41', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `order_statuses`
--

CREATE TABLE `order_statuses` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL COMMENT 'Tên trạng thái (VD: Chờ xác nhận, Đã giao)',
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_statuses`
--

INSERT INTO `order_statuses` (`id`, `name`, `description`, `is_active`) VALUES
(1, 'Chờ xử lí', 'Đơn hàng mới được tạo, đang chờ xử lí', 1),
(2, 'Đã xử lí', 'Đơn hàng đã được xác nhận và xử lí', 1),
(3, 'Đang chuẩn bị hàng', 'Đang đóng gói và chuẩn bị sản phẩm', 1),
(4, 'Đã giao cho đơn vị vận chuyển', 'Đã bàn giao hàng cho đơn vị vận chuyển', 1),
(5, 'Đang vận chuyển', 'Đơn hàng đang trên đường giao đến khách hàng', 1),
(6, 'Đã giao', 'Đơn vị vận chuyển đã giao hàng thành công, chờ khách hàng xác nhận', 1),
(7, 'Đã hoàn thành', 'Khách hàng đã xác nhận nhận hàng, đơn hàng hoàn tất', 1),
(8, 'Đã hủy', 'Đơn hàng đã bị hủy bởi khách hàng hoặc admin', 1);

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `method` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `paid_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `order_id`, `method`, `status`, `paid_at`) VALUES
(21949194, 7, 'cod', 'Paid', '2025-12-06 12:54:58'),
(142045364, 15, 'cod', 'Pending', NULL),
(331385561, 12, 'cod', 'Paid', '2025-12-08 22:01:19'),
(333128700, 4, 'cod', 'Paid', '2025-12-06 12:59:28'),
(557472465, 10, 'cod', 'Pending', NULL),
(677046426, 6, 'cod', 'Paid', '2025-12-06 12:57:59'),
(825488668, 19, 'vnpay', 'Paid', '2025-12-09 11:25:56'),
(860156272, 1, 'cod', 'Pending', NULL),
(879750094, 14, 'vnpay', 'Pending', NULL),
(930585130, 18, 'vnpay', 'Paid', '2025-12-09 06:01:54'),
(969606216, 2, 'cod', 'Paid', '2025-12-06 12:45:22'),
(1162272301, 8, 'vnpay', 'Paid', '2025-12-06 12:04:06'),
(1170265010, 16, 'vnpay', 'Pending', NULL),
(1269602546, 3, 'cod', 'Paid', '2025-12-06 12:59:31'),
(1435129914, 9, 'cod', 'Paid', '2025-12-07 16:37:36'),
(1608858259, 13, 'cod', 'Pending', NULL),
(1774268945, 17, 'vnpay', 'Paid', '2025-12-09 05:57:40'),
(1895859104, 11, 'cod', 'Pending', NULL),
(1944135372, 5, 'cod', 'Paid', '2025-12-06 12:59:25'),
(1970168004, 20, 'cod', 'Paid', '2025-12-09 15:34:19');

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `shoe_id` int(11) NOT NULL,
  `rating` int(1) NOT NULL CHECK (`rating` between 1 and 5),
  `comment` text DEFAULT NULL,
  `status` enum('pending','approved','hidden') DEFAULT 'pending',
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`id`, `user_id`, `shoe_id`, `rating`, `comment`, `status`, `created_at`) VALUES
(2, 1, 3, 5, 'áo đẹp ', 'approved', '2025-11-28 16:52:42'),
(3, 1, 1, 5, 'đẹp', 'approved', '2025-11-28 17:29:03'),
(4, 8, 5, 1, 'tệ rất tệ', 'hidden', '2025-12-03 10:22:09'),
(6, 8, 7, 5, 'Sản phẩm đẹp, đi rất là ôm chân', 'approved', '2025-12-06 12:58:15'),
(7, 8, 32, 5, 'Giày rất xịn, rẻ ko tưởng luôn á', 'approved', '2025-12-07 16:38:15'),
(8, 8, 41, 5, 'Sản phẩm đẹp', 'approved', '2025-12-08 22:09:38'),
(9, 8, 8, 5, 'Đi êm chân, ko bị bó sát quá, ưng quá chừng:>>', 'approved', '2025-12-09 14:51:48');

-- --------------------------------------------------------

--
-- Table structure for table `shipping_methods`
--

CREATE TABLE `shipping_methods` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `fee` decimal(10,2) NOT NULL DEFAULT 0.00,
  `is_active` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `shipping_methods`
--

INSERT INTO `shipping_methods` (`id`, `name`, `description`, `fee`, `is_active`) VALUES
(1, 'Tiêu chuẩn', 'Nhận hàng sau 4 - 5 ngày', 25000.00, 1),
(2, 'Nhanh', 'Nhận hàng sau 3 - 4 ngày', 37600.00, 1),
(3, 'Hỏa tốc', 'Nhận hàng sau 1 - 2 ngày', 69000.00, 1);

-- --------------------------------------------------------

--
-- Table structure for table `shoes`
--

CREATE TABLE `shoes` (
  `id` int(11) NOT NULL,
  `product_code` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL COMMENT 'Thời điểm xóa mềm (NULL = chưa xóa)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `shoes`
--

INSERT INTO `shoes` (`id`, `product_code`, `name`, `category_id`, `description`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'CB-001', 'Ocean Breeze', 3, 'Phiên bản giới hạn với phối màu Magnolia sang trọng.', '2025-08-01 10:00:00', '2025-12-09 15:28:00', NULL),
(3, 'CB-003', 'Endura Run', 3, 'Giày chạy bộ bền bỉ với công nghệ mới.', '2025-08-10 10:00:00', '2025-12-09 15:28:25', NULL),
(4, 'CB-004', 'Titan Terrain', 3, 'Độ bền cao, phù hợp mọi mặt sân.', '2025-08-12 10:00:00', '2025-12-09 05:17:49', NULL),
(5, 'TS-005', 'Snap Striker', 1, 'Phong cách kinh điển với phối màu đỏ xám.', '2025-08-14 10:00:00', '2025-12-09 05:16:40', NULL),
(6, 'BR - 002', 'Canvas Turtle', 4, 'Thiết kế dành cho bóng rổ với màu sắc nổi bật.', '2025-08-16 10:00:00', '2025-12-09 14:34:34', NULL),
(7, 'BS-002', 'Hardback 90', 2, 'Phong cách tối giản với sắc trắng bạc.', '2025-08-18 10:00:00', '2025-12-09 15:03:35', NULL),
(8, 'TS-008', 'Urban Shell', 1, 'Kiểu dáng classic với nhiều phối màu.', '2025-08-20 10:00:00', '2025-12-07 23:41:15', NULL),
(28, 'BS - 001', 'Turtle High', 2, '', '2025-12-06 06:31:29', '2025-12-06 08:32:53', NULL),
(31, 'CB - 005', 'Turtle Run', 3, '', '2025-12-06 06:44:58', '2025-12-09 14:53:36', NULL),
(32, 'BR - 001', 'Turtle Super', 4, '', '2025-12-06 06:50:18', '2025-12-07 16:30:48', NULL),
(33, 'TS - 015', 'Turtle Best', 1, 'Xu hướng giày hot hiện nay, phù hợp với giới trẻ', '2025-12-06 06:58:54', '2025-12-06 08:28:26', NULL),
(36, 'TS-018', 'Turtle Low', 1, '', '2025-12-06 10:47:59', '2025-12-06 10:47:59', NULL),
(38, 'BD - 002', 'Turtle Swamp Master', 7, '', '2025-12-08 00:08:23', '2025-12-08 00:08:23', NULL),
(39, 'BD - 001', 'Turtle Turbo Stud', 7, '', '2025-12-08 00:09:21', '2025-12-08 00:09:21', NULL),
(40, 'BD - 003', 'Tactical T', 7, '', '2025-12-08 00:10:30', '2025-12-08 00:10:30', NULL),
(41, 'BD - 004', 'Turtle Shield Goal', 7, '', '2025-12-08 00:11:33', '2025-12-08 16:23:13', NULL),
(42, 'BD - 005', 'Turtle Iron Defense', 7, '', '2025-12-08 00:12:18', '2025-12-08 00:12:18', NULL),
(46, 'TS - 022', 'Turtle One', 1, 'Giành cho những người yêu thích những đôi giày hầm hố', '2025-12-09 14:24:01', '2025-12-09 14:24:01', NULL),
(47, 'BR - 003', 'Hoop Shell', 4, '', '2025-12-09 14:33:15', '2025-12-09 14:33:15', NULL),
(48, 'BR - 004', 'Pivot Point', 4, '', '2025-12-09 14:34:03', '2025-12-09 14:34:03', NULL),
(49, 'BR - 005', 'Slam Dunk Turtle', 4, '', '2025-12-09 14:42:43', '2025-12-09 14:42:43', NULL),
(50, 'BS - 003', 'Heavy Duty T', 2, '', '2025-12-09 15:03:00', '2025-12-09 15:03:00', NULL),
(51, 'BS - 004', 'Solid Ground', 2, '', '2025-12-09 15:05:28', '2025-12-09 15:05:48', NULL),
(52, 'BS - 005', 'Armor Boot', 2, '', '2025-12-09 15:06:59', '2025-12-09 15:06:59', NULL),
(53, 'CB - 002', 'Aero Flow', 3, '', '2025-12-09 15:29:21', '2025-12-09 15:29:21', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `shoe_attributes`
--

CREATE TABLE `shoe_attributes` (
  `attribute_id` int(11) NOT NULL,
  `name` varchar(80) NOT NULL,
  `unit` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `shoe_attributes`
--

INSERT INTO `shoe_attributes` (`attribute_id`, `name`, `unit`) VALUES
(1, 'Kích cỡ', 'EU'),
(2, 'Màu sắc', NULL),
(3, 'color', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `shoe_attribute_values`
--

CREATE TABLE `shoe_attribute_values` (
  `value_id` int(11) NOT NULL,
  `attribute_id` int(11) NOT NULL,
  `value` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `shoe_attribute_values`
--

INSERT INTO `shoe_attribute_values` (`value_id`, `attribute_id`, `value`) VALUES
(1, 1, '39'),
(2, 1, '40'),
(3, 1, '41'),
(4, 1, '42'),
(5, 1, '43'),
(6, 2, 'Trắng'),
(7, 2, 'Đen'),
(8, 2, 'Xanh dương'),
(9, 2, 'Đỏ'),
(10, 1, '36'),
(11, 1, '37'),
(12, 1, '38'),
(13, 3, 'Trắng'),
(14, 3, 'Đen'),
(15, 3, 'Đỏ'),
(16, 3, 'hồng'),
(17, 3, 'tím'),
(18, 2, 'hồng'),
(19, 2, 'tím'),
(20, 2, 'Màu hường'),
(21, 2, 'xanh rêu'),
(22, 2, 'Xanh than'),
(23, 2, 'vàng'),
(24, 2, 'Trắng xanh lá'),
(25, 2, 'đen trắng'),
(26, 2, 'Xanh trắng'),
(27, 2, 'Hồng đen'),
(28, 2, 'Đen cam'),
(29, 2, 'Trắng đen'),
(30, 2, 'Nâu'),
(31, 2, 'Cam Xanh');

-- --------------------------------------------------------

--
-- Table structure for table `shoe_images`
--

CREATE TABLE `shoe_images` (
  `id` int(11) NOT NULL,
  `shoe_variant_id` int(11) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `shoe_variants`
--

CREATE TABLE `shoe_variants` (
  `id` int(11) NOT NULL,
  `shoe_id` int(11) DEFAULT NULL,
  `sku` varchar(255) DEFAULT NULL,
  `color` varchar(50) DEFAULT NULL,
  `size` varchar(20) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `market_price` decimal(10,2) DEFAULT NULL,
  `discount` decimal(10,2) DEFAULT NULL,
  `main_image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `shoe_variants`
--

INSERT INTO `shoe_variants` (`id`, `shoe_id`, `sku`, `color`, `size`, `price`, `market_price`, `discount`, `main_image`) VALUES
(5, 5, 'TS-005-01', NULL, NULL, 260000.00, 338000.00, NULL, 'public/uploads/1765232200_unnamed (6).jpg'),
(7, 7, 'TS-007-01', NULL, NULL, 299000.00, 388700.00, NULL, 'public/uploads/1765127631_unnamed (10).jpg'),
(24, 32, 'ádasdasdasd-01', NULL, NULL, 250000.00, NULL, NULL, 'public/uploads/1764984137_unnamed (4).jpg'),
(92, 33, 'TS - 015-01', NULL, NULL, 350000.00, NULL, NULL, 'public/uploads/1764983968_unnamed (5).jpg'),
(93, 33, 'TS - 015-02', NULL, NULL, 350000.00, NULL, NULL, 'public/uploads/1764983968_unnamed (5).jpg'),
(94, 33, 'TS - 015-03', NULL, NULL, 350000.00, NULL, NULL, 'public/uploads/1764983968_unnamed (5).jpg'),
(95, 33, 'TS - 015-04', NULL, NULL, 350000.00, NULL, NULL, 'public/uploads/1764983968_unnamed (5).jpg'),
(96, 31, 'CB - 005-01', NULL, NULL, 190000.00, NULL, NULL, 'public/uploads/1764984472_unnamed (3).jpg'),
(120, 28, 'BS - 001-01', NULL, NULL, 280000.00, NULL, NULL, 'public/uploads/1764984773_unnamed (1).jpg'),
(121, 28, 'BS - 001-02', NULL, NULL, 280000.00, NULL, NULL, 'public/uploads/1764984773_unnamed (1).jpg'),
(122, 28, 'BS - 001-03', NULL, NULL, 280000.00, NULL, NULL, 'public/uploads/1764984773_unnamed (1).jpg'),
(123, 28, 'BS - 001-04', NULL, NULL, 280000.00, NULL, NULL, 'public/uploads/1764984773_unnamed (1).jpg'),
(124, 28, 'BS - 001-05', NULL, NULL, 280000.00, NULL, NULL, 'public/uploads/1764984773_unnamed (1).jpg'),
(125, 28, 'BS - 001-06', NULL, NULL, 280000.00, NULL, NULL, 'public/uploads/1764984773_unnamed (1).jpg'),
(126, 28, 'BS - 001-07', NULL, NULL, 280000.00, NULL, NULL, 'public/uploads/1764984773_unnamed (1).jpg'),
(127, 28, 'BS - 001-08', NULL, NULL, 280000.00, NULL, NULL, 'public/uploads/1764984773_unnamed (1).jpg'),
(128, 28, 'BS - 001-09', NULL, NULL, 280000.00, NULL, NULL, 'public/uploads/1764984773_unnamed (1).jpg'),
(129, 28, 'BS - 001-10', NULL, NULL, 280000.00, NULL, NULL, 'public/uploads/1764984773_unnamed (1).jpg'),
(130, 28, 'BS - 001-11', NULL, NULL, 280000.00, NULL, NULL, 'public/uploads/1764984773_unnamed (1).jpg'),
(131, 28, 'BS - 001-12', NULL, NULL, 280000.00, NULL, NULL, 'public/uploads/1764984773_unnamed (1).jpg'),
(132, 28, 'BS - 001-13', NULL, NULL, 280000.00, NULL, NULL, 'public/uploads/1764984773_unnamed (1).jpg'),
(133, 28, 'BS - 001-14', NULL, NULL, 280000.00, NULL, NULL, 'public/uploads/1764984773_unnamed (1).jpg'),
(134, 28, 'BS - 001-15', NULL, NULL, 280000.00, NULL, NULL, 'public/uploads/1764984773_unnamed (1).jpg'),
(223, 36, 'TS-018-01', NULL, NULL, 160000.00, NULL, NULL, 'public/uploads/1764992879_unnamed (2).jpg'),
(224, 36, 'TS-018-02', NULL, NULL, 160000.00, NULL, NULL, 'public/uploads/1764992879_unnamed (2).jpg'),
(225, 36, 'TS-018-03', NULL, NULL, 160000.00, NULL, NULL, 'public/uploads/1764992879_unnamed (2).jpg'),
(226, 36, 'TS-018-04', NULL, NULL, 160000.00, NULL, NULL, 'public/uploads/1764992879_unnamed (2).jpg'),
(227, 36, 'TS-018-05', NULL, NULL, 160000.00, NULL, NULL, 'public/uploads/1764992879_unnamed (2).jpg'),
(228, 36, 'TS-018-06', NULL, NULL, 160000.00, NULL, NULL, 'public/uploads/1764992879_unnamed (2).jpg'),
(229, 36, 'TS-018-07', NULL, NULL, 160000.00, NULL, NULL, 'public/uploads/1764992879_unnamed (2).jpg'),
(230, 36, 'TS-018-08', NULL, NULL, 160000.00, NULL, NULL, 'public/uploads/1764992879_unnamed (2).jpg'),
(231, 36, 'TS-018-09', NULL, NULL, 160000.00, NULL, NULL, 'public/uploads/1764992879_unnamed (2).jpg'),
(232, 36, 'TS-018-10', NULL, NULL, 160000.00, NULL, NULL, 'public/uploads/1764992879_unnamed (2).jpg'),
(233, 36, 'TS-018-11', NULL, NULL, 160000.00, NULL, NULL, 'public/uploads/1764992879_unnamed (2).jpg'),
(234, 36, 'TS-018-12', NULL, NULL, 160000.00, NULL, NULL, 'public/uploads/1764992879_unnamed (2).jpg'),
(235, 36, 'TS-018-13', NULL, NULL, 160000.00, NULL, NULL, 'public/uploads/1764992879_unnamed (2).jpg'),
(236, 36, 'TS-018-14', NULL, NULL, 160000.00, NULL, NULL, 'public/uploads/1764992879_unnamed (2).jpg'),
(237, 36, 'TS-018-15', NULL, NULL, 160000.00, NULL, NULL, 'public/uploads/1764992879_unnamed (2).jpg'),
(238, 36, 'TS-018-16', NULL, NULL, 160000.00, NULL, NULL, 'public/uploads/1764992879_unnamed (2).jpg'),
(239, 36, 'TS-018-17', NULL, NULL, 160000.00, NULL, NULL, 'public/uploads/1764992879_unnamed (2).jpg'),
(240, 36, 'TS-018-18', NULL, NULL, 160000.00, NULL, NULL, 'public/uploads/1764992879_unnamed (2).jpg'),
(241, 36, 'TS-018-19', NULL, NULL, 160000.00, NULL, NULL, 'public/uploads/1764992879_unnamed (2).jpg'),
(242, 36, 'TS-018-20', NULL, NULL, 160000.00, NULL, NULL, 'public/uploads/1764992879_unnamed (2).jpg'),
(243, 36, 'TS-018-21', NULL, NULL, 160000.00, NULL, NULL, 'public/uploads/1764992879_unnamed (2).jpg'),
(244, 36, 'TS-018-22', NULL, NULL, 160000.00, NULL, NULL, 'public/uploads/1764992879_unnamed (2).jpg'),
(245, 36, 'TS-018-23', NULL, NULL, 160000.00, NULL, NULL, 'public/uploads/1764992879_unnamed (2).jpg'),
(246, 36, 'TS-018-24', NULL, NULL, 160000.00, NULL, NULL, 'public/uploads/1764992879_unnamed (2).jpg'),
(247, 36, 'TS-018-25', NULL, NULL, 160000.00, NULL, NULL, 'public/uploads/1764992879_unnamed (2).jpg'),
(248, 36, 'TS-018-26', NULL, NULL, 160000.00, NULL, NULL, 'public/uploads/1764992879_unnamed (2).jpg'),
(249, 36, 'TS-018-27', NULL, NULL, 160000.00, NULL, NULL, 'public/uploads/1764992879_unnamed (2).jpg'),
(250, 36, 'TS-018-28', NULL, NULL, 160000.00, NULL, NULL, 'public/uploads/1764992879_unnamed (2).jpg'),
(251, 36, 'TS-018-29', NULL, NULL, 160000.00, NULL, NULL, 'public/uploads/1764992879_unnamed (2).jpg'),
(252, 36, 'TS-018-30', NULL, NULL, 160000.00, NULL, NULL, 'public/uploads/1764992879_unnamed (2).jpg'),
(253, 36, 'TS-018-31', NULL, NULL, 160000.00, NULL, NULL, 'public/uploads/1764992879_unnamed (2).jpg'),
(254, 36, 'TS-018-32', NULL, NULL, 160000.00, NULL, NULL, 'public/uploads/1764992879_unnamed (2).jpg'),
(335, 32, 'BR - 001-01', NULL, NULL, 250000.00, NULL, NULL, 'public/uploads/1764984137_unnamed (4).jpg'),
(336, 32, 'BR - 001-02', NULL, NULL, 250000.00, NULL, NULL, 'public/uploads/1764984137_unnamed (4).jpg'),
(337, 32, 'BR - 001-03', NULL, NULL, 250000.00, NULL, NULL, 'public/uploads/1764984137_unnamed (4).jpg'),
(338, 32, 'BR - 001-04', NULL, NULL, 250000.00, NULL, NULL, 'public/uploads/1764984137_unnamed (4).jpg'),
(339, 32, 'BR - 001-05', NULL, NULL, 250000.00, NULL, NULL, 'public/uploads/1764984137_unnamed (4).jpg'),
(340, 32, 'BR - 001-06', NULL, NULL, 250000.00, NULL, NULL, 'public/uploads/1764984137_unnamed (4).jpg'),
(341, 32, 'BR - 001-07', NULL, NULL, 250000.00, NULL, NULL, 'public/uploads/1764984137_unnamed (4).jpg'),
(342, 32, 'BR - 001-08', NULL, NULL, 250000.00, NULL, NULL, 'public/uploads/1764984137_unnamed (4).jpg'),
(479, 8, 'TS-008-01', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765125675_unnamed (9).jpg'),
(480, 8, 'TS-008-02', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765125675_unnamed (9).jpg'),
(481, 8, 'TS-008-03', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765125675_unnamed (9).jpg'),
(482, 8, 'TS-008-04', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765125675_unnamed (9).jpg'),
(483, 8, 'TS-008-05', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765125675_unnamed (9).jpg'),
(484, 8, 'TS-008-06', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765125675_unnamed (9).jpg'),
(485, 8, 'TS-008-07', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765125675_unnamed (9).jpg'),
(486, 8, 'TS-008-08', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765125675_unnamed (9).jpg'),
(487, 8, 'TS-008-09', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765125675_unnamed (9).jpg'),
(488, 8, 'TS-008-10', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765125675_unnamed (9).jpg'),
(489, 8, 'TS-008-11', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765125675_unnamed (9).jpg'),
(490, 8, 'TS-008-12', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765125675_unnamed (9).jpg'),
(491, 8, 'TS-008-13', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765125675_unnamed (9).jpg'),
(492, 8, 'TS-008-14', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765125675_unnamed (9).jpg'),
(493, 8, 'TS-008-15', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765125675_unnamed (9).jpg'),
(494, 8, 'TS-008-16', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765125675_unnamed (9).jpg'),
(495, 8, 'TS-008-17', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765125675_unnamed (9).jpg'),
(496, 8, 'TS-008-18', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765125675_unnamed (9).jpg'),
(497, 8, 'TS-008-19', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765125675_unnamed (9).jpg'),
(498, 8, 'TS-008-20', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765125675_unnamed (9).jpg'),
(539, 38, 'BD - 002-01', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765127303_unnamed (17).jpg'),
(540, 38, 'BD - 002-02', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765127303_unnamed (17).jpg'),
(541, 38, 'BD - 002-03', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765127303_unnamed (17).jpg'),
(542, 38, 'BD - 002-04', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765127303_unnamed (17).jpg'),
(543, 38, 'BD - 002-05', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765127303_unnamed (17).jpg'),
(544, 38, 'BD - 002-06', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765127303_unnamed (17).jpg'),
(545, 38, 'BD - 002-07', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765127303_unnamed (17).jpg'),
(546, 38, 'BD - 002-08', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765127303_unnamed (17).jpg'),
(547, 38, 'BD - 002-09', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765127303_unnamed (17).jpg'),
(548, 38, 'BD - 002-10', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765127303_unnamed (17).jpg'),
(549, 39, 'BD - 001-01', NULL, NULL, 250000.00, NULL, NULL, 'public/uploads/1765127361_unnamed (16).jpg'),
(550, 39, 'BD - 001-02', NULL, NULL, 250000.00, NULL, NULL, 'public/uploads/1765127361_unnamed (16).jpg'),
(551, 39, 'BD - 001-03', NULL, NULL, 250000.00, NULL, NULL, 'public/uploads/1765127361_unnamed (16).jpg'),
(552, 39, 'BD - 001-04', NULL, NULL, 250000.00, NULL, NULL, 'public/uploads/1765127361_unnamed (16).jpg'),
(553, 39, 'BD - 001-05', NULL, NULL, 250000.00, NULL, NULL, 'public/uploads/1765127361_unnamed (16).jpg'),
(554, 39, 'BD - 001-06', NULL, NULL, 250000.00, NULL, NULL, 'public/uploads/1765127361_unnamed (16).jpg'),
(555, 39, 'BD - 001-07', NULL, NULL, 250000.00, NULL, NULL, 'public/uploads/1765127361_unnamed (16).jpg'),
(556, 39, 'BD - 001-08', NULL, NULL, 250000.00, NULL, NULL, 'public/uploads/1765127361_unnamed (16).jpg'),
(557, 39, 'BD - 001-09', NULL, NULL, 250000.00, NULL, NULL, 'public/uploads/1765127361_unnamed (16).jpg'),
(558, 39, 'BD - 001-10', NULL, NULL, 250000.00, NULL, NULL, 'public/uploads/1765127361_unnamed (16).jpg'),
(559, 39, 'BD - 001-11', NULL, NULL, 250000.00, NULL, NULL, 'public/uploads/1765127361_unnamed (16).jpg'),
(560, 39, 'BD - 001-12', NULL, NULL, 250000.00, NULL, NULL, 'public/uploads/1765127361_unnamed (16).jpg'),
(561, 39, 'BD - 001-13', NULL, NULL, 250000.00, NULL, NULL, 'public/uploads/1765127361_unnamed (16).jpg'),
(562, 39, 'BD - 001-14', NULL, NULL, 250000.00, NULL, NULL, 'public/uploads/1765127361_unnamed (16).jpg'),
(563, 39, 'BD - 001-15', NULL, NULL, 250000.00, NULL, NULL, 'public/uploads/1765127361_unnamed (16).jpg'),
(564, 40, 'BD - 003-01', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765127430_unnamed (15).jpg'),
(565, 40, 'BD - 003-02', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765127430_unnamed (15).jpg'),
(566, 40, 'BD - 003-03', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765127430_unnamed (15).jpg'),
(567, 40, 'BD - 003-04', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765127430_unnamed (15).jpg'),
(568, 40, 'BD - 003-05', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765127430_unnamed (15).jpg'),
(569, 40, 'BD - 003-06', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765127430_unnamed (15).jpg'),
(570, 40, 'BD - 003-07', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765127430_unnamed (15).jpg'),
(571, 40, 'BD - 003-08', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765127430_unnamed (15).jpg'),
(572, 40, 'BD - 003-09', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765127430_unnamed (15).jpg'),
(573, 40, 'BD - 003-10', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765127430_unnamed (15).jpg'),
(574, 40, 'BD - 003-11', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765127430_unnamed (15).jpg'),
(575, 40, 'BD - 003-12', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765127430_unnamed (15).jpg'),
(576, 40, 'BD - 003-13', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765127430_unnamed (15).jpg'),
(577, 40, 'BD - 003-14', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765127430_unnamed (15).jpg'),
(578, 40, 'BD - 003-15', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765127430_unnamed (15).jpg'),
(579, 40, 'BD - 003-16', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765127430_unnamed (15).jpg'),
(580, 40, 'BD - 003-17', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765127430_unnamed (15).jpg'),
(581, 40, 'BD - 003-18', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765127430_unnamed (15).jpg'),
(582, 40, 'BD - 003-19', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765127430_unnamed (15).jpg'),
(583, 40, 'BD - 003-20', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765127430_unnamed (15).jpg'),
(599, 42, 'BD - 005-01', NULL, NULL, 280000.00, NULL, NULL, 'public/uploads/1765127538_unnamed (13).jpg'),
(600, 42, 'BD - 005-02', NULL, NULL, 280000.00, NULL, NULL, 'public/uploads/1765127538_unnamed (13).jpg'),
(601, 42, 'BD - 005-03', NULL, NULL, 280000.00, NULL, NULL, 'public/uploads/1765127538_unnamed (13).jpg'),
(602, 42, 'BD - 005-04', NULL, NULL, 280000.00, NULL, NULL, 'public/uploads/1765127538_unnamed (13).jpg'),
(603, 42, 'BD - 005-05', NULL, NULL, 280000.00, NULL, NULL, 'public/uploads/1765127538_unnamed (13).jpg'),
(604, 42, 'BD - 005-06', NULL, NULL, 280000.00, NULL, NULL, 'public/uploads/1765127538_unnamed (13).jpg'),
(605, 42, 'BD - 005-07', NULL, NULL, 280000.00, NULL, NULL, 'public/uploads/1765127538_unnamed (13).jpg'),
(606, 42, 'BD - 005-08', NULL, NULL, 280000.00, NULL, NULL, 'public/uploads/1765127538_unnamed (13).jpg'),
(607, 42, 'BD - 005-09', NULL, NULL, 280000.00, NULL, NULL, 'public/uploads/1765127538_unnamed (13).jpg'),
(608, 42, 'BD - 005-10', NULL, NULL, 280000.00, NULL, NULL, 'public/uploads/1765127538_unnamed (13).jpg'),
(609, 42, 'BD - 005-11', NULL, NULL, 280000.00, NULL, NULL, 'public/uploads/1765127538_unnamed (13).jpg'),
(610, 42, 'BD - 005-12', NULL, NULL, 280000.00, NULL, NULL, 'public/uploads/1765127538_unnamed (13).jpg'),
(611, 42, 'BD - 005-13', NULL, NULL, 280000.00, NULL, NULL, 'public/uploads/1765127538_unnamed (13).jpg'),
(612, 42, 'BD - 005-14', NULL, NULL, 280000.00, NULL, NULL, 'public/uploads/1765127538_unnamed (13).jpg'),
(613, 42, 'BD - 005-15', NULL, NULL, 280000.00, NULL, NULL, 'public/uploads/1765127538_unnamed (13).jpg'),
(614, 6, 'TS-006-01', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765127596_unnamed (11).jpg'),
(689, 41, 'BD - 004-01', NULL, NULL, 350000.00, NULL, NULL, 'public/uploads/1765127493_unnamed (14).jpg'),
(690, 41, 'BD - 004-02', NULL, NULL, 350000.00, NULL, NULL, 'public/uploads/1765127493_unnamed (14).jpg'),
(691, 41, 'BD - 004-03', NULL, NULL, 350000.00, NULL, NULL, 'public/uploads/1765127493_unnamed (14).jpg'),
(692, 41, 'BD - 004-04', NULL, NULL, 350000.00, NULL, NULL, 'public/uploads/1765127493_unnamed (14).jpg'),
(693, 41, 'BD - 004-05', NULL, NULL, 350000.00, NULL, NULL, 'public/uploads/1765127493_unnamed (14).jpg'),
(694, 41, 'BD - 004-06', NULL, NULL, 350000.00, NULL, NULL, 'public/uploads/1765127493_unnamed (14).jpg'),
(695, 41, 'BD - 004-07', NULL, NULL, 350000.00, NULL, NULL, 'public/uploads/1765127493_unnamed (14).jpg'),
(696, 41, 'BD - 004-08', NULL, NULL, 350000.00, NULL, NULL, 'public/uploads/1765127493_unnamed (14).jpg'),
(697, 41, 'BD - 004-09', NULL, NULL, 350000.00, NULL, NULL, 'public/uploads/1765127493_unnamed (14).jpg'),
(698, 41, 'BD - 004-10', NULL, NULL, 350000.00, NULL, NULL, 'public/uploads/1765127493_unnamed (14).jpg'),
(699, 41, 'BD - 004-11', NULL, NULL, 350000.00, NULL, NULL, 'public/uploads/1765127493_unnamed (14).jpg'),
(700, 41, 'BD - 004-12', NULL, NULL, 350000.00, NULL, NULL, 'public/uploads/1765127493_unnamed (14).jpg'),
(701, 41, 'BD - 004-13', NULL, NULL, 350000.00, NULL, NULL, 'public/uploads/1765127493_unnamed (14).jpg'),
(702, 41, 'BD - 004-14', NULL, NULL, 350000.00, NULL, NULL, 'public/uploads/1765127493_unnamed (14).jpg'),
(703, 41, 'BD - 004-15', NULL, NULL, 350000.00, NULL, NULL, 'public/uploads/1765127493_unnamed (14).jpg'),
(840, 5, 'TS-005-01', NULL, NULL, 260000.00, NULL, NULL, 'public/uploads/1765232200_unnamed (6).jpg'),
(841, 5, 'TS-005-02', NULL, NULL, 260000.00, NULL, NULL, 'public/uploads/1765232200_unnamed (6).jpg'),
(842, 5, 'TS-005-03', NULL, NULL, 260000.00, NULL, NULL, 'public/uploads/1765232200_unnamed (6).jpg'),
(843, 5, 'TS-005-04', NULL, NULL, 260000.00, NULL, NULL, 'public/uploads/1765232200_unnamed (6).jpg'),
(844, 5, 'TS-005-05', NULL, NULL, 260000.00, NULL, NULL, 'public/uploads/1765232200_unnamed (6).jpg'),
(845, 5, 'TS-005-06', NULL, NULL, 260000.00, NULL, NULL, 'public/uploads/1765232200_unnamed (6).jpg'),
(846, 5, 'TS-005-07', NULL, NULL, 260000.00, NULL, NULL, 'public/uploads/1765232200_unnamed (6).jpg'),
(847, 5, 'TS-005-08', NULL, NULL, 260000.00, NULL, NULL, 'public/uploads/1765232200_unnamed (6).jpg'),
(848, 5, 'TS-005-09', NULL, NULL, 260000.00, NULL, NULL, 'public/uploads/1765232200_unnamed (6).jpg'),
(849, 5, 'TS-005-10', NULL, NULL, 260000.00, NULL, NULL, 'public/uploads/1765232200_unnamed (6).jpg'),
(850, 5, 'TS-005-11', NULL, NULL, 260000.00, NULL, NULL, 'public/uploads/1765232200_unnamed (6).jpg'),
(851, 5, 'TS-005-12', NULL, NULL, 260000.00, NULL, NULL, 'public/uploads/1765232200_unnamed (6).jpg'),
(852, 5, 'TS-005-13', NULL, NULL, 260000.00, NULL, NULL, 'public/uploads/1765232200_unnamed (6).jpg'),
(853, 5, 'TS-005-14', NULL, NULL, 260000.00, NULL, NULL, 'public/uploads/1765232200_unnamed (6).jpg'),
(854, 5, 'TS-005-15', NULL, NULL, 260000.00, NULL, NULL, 'public/uploads/1765232200_unnamed (6).jpg'),
(855, 5, 'TS-005-16', NULL, NULL, 260000.00, NULL, NULL, 'public/uploads/1765232200_unnamed (6).jpg'),
(856, 5, 'TS-005-17', NULL, NULL, 260000.00, NULL, NULL, 'public/uploads/1765232200_unnamed (6).jpg'),
(857, 5, 'TS-005-18', NULL, NULL, 260000.00, NULL, NULL, 'public/uploads/1765232200_unnamed (6).jpg'),
(858, 5, 'TS-005-19', NULL, NULL, 260000.00, NULL, NULL, 'public/uploads/1765232200_unnamed (6).jpg'),
(859, 5, 'TS-005-20', NULL, NULL, 260000.00, NULL, NULL, 'public/uploads/1765232200_unnamed (6).jpg'),
(860, 4, 'CB-004-01', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765232269_unnamed (12).jpg'),
(861, 4, 'CB-004-02', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765232269_unnamed (12).jpg'),
(862, 4, 'CB-004-03', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765232269_unnamed (12).jpg'),
(863, 4, 'CB-004-04', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765232269_unnamed (12).jpg'),
(864, 4, 'CB-004-05', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765232269_unnamed (12).jpg'),
(865, 4, 'CB-004-06', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765232269_unnamed (12).jpg'),
(866, 4, 'CB-004-07', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765232269_unnamed (12).jpg'),
(867, 4, 'CB-004-08', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765232269_unnamed (12).jpg'),
(868, 4, 'CB-004-09', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765232269_unnamed (12).jpg'),
(869, 4, 'CB-004-10', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765232269_unnamed (12).jpg'),
(870, 4, 'CB-004-11', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765232269_unnamed (12).jpg'),
(871, 4, 'CB-004-12', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765232269_unnamed (12).jpg'),
(872, 4, 'CB-004-13', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765232269_unnamed (12).jpg'),
(873, 4, 'CB-004-14', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765232269_unnamed (12).jpg'),
(874, 4, 'CB-004-15', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765232269_unnamed (12).jpg'),
(875, 4, 'CB-004-16', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765232269_unnamed (12).jpg'),
(876, 4, 'CB-004-17', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765232269_unnamed (12).jpg'),
(877, 4, 'CB-004-18', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765232269_unnamed (12).jpg'),
(878, 4, 'CB-004-19', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765232269_unnamed (12).jpg'),
(879, 4, 'CB-004-20', NULL, NULL, 200000.00, NULL, NULL, 'public/uploads/1765232269_unnamed (12).jpg'),
(880, 46, 'TS - 022-01', NULL, NULL, 230000.00, NULL, NULL, 'public/uploads/1765265041_unnamed (20).jpg'),
(881, 46, 'TS - 022-02', NULL, NULL, 230000.00, NULL, NULL, 'public/uploads/1765265041_unnamed (20).jpg'),
(882, 46, 'TS - 022-03', NULL, NULL, 230000.00, NULL, NULL, 'public/uploads/1765265041_unnamed (20).jpg'),
(883, 46, 'TS - 022-04', NULL, NULL, 230000.00, NULL, NULL, 'public/uploads/1765265041_unnamed (20).jpg'),
(884, 46, 'TS - 022-05', NULL, NULL, 230000.00, NULL, NULL, 'public/uploads/1765265041_unnamed (20).jpg'),
(885, 46, 'TS - 022-06', NULL, NULL, 230000.00, NULL, NULL, 'public/uploads/1765265041_unnamed (20).jpg'),
(886, 46, 'TS - 022-07', NULL, NULL, 230000.00, NULL, NULL, 'public/uploads/1765265041_unnamed (20).jpg'),
(887, 46, 'TS - 022-08', NULL, NULL, 230000.00, NULL, NULL, 'public/uploads/1765265041_unnamed (20).jpg'),
(888, 46, 'TS - 022-09', NULL, NULL, 230000.00, NULL, NULL, 'public/uploads/1765265041_unnamed (20).jpg'),
(889, 46, 'TS - 022-10', NULL, NULL, 230000.00, NULL, NULL, 'public/uploads/1765265041_unnamed (20).jpg'),
(890, 46, 'TS - 022-11', NULL, NULL, 230000.00, NULL, NULL, 'public/uploads/1765265041_unnamed (20).jpg'),
(891, 46, 'TS - 022-12', NULL, NULL, 230000.00, NULL, NULL, 'public/uploads/1765265041_unnamed (20).jpg'),
(892, 46, 'TS - 022-13', NULL, NULL, 230000.00, NULL, NULL, 'public/uploads/1765265041_unnamed (20).jpg'),
(893, 46, 'TS - 022-14', NULL, NULL, 230000.00, NULL, NULL, 'public/uploads/1765265041_unnamed (20).jpg'),
(894, 46, 'TS - 022-15', NULL, NULL, 230000.00, NULL, NULL, 'public/uploads/1765265041_unnamed (20).jpg'),
(895, 47, 'BR - 003-01', NULL, NULL, 250000.00, NULL, NULL, 'public/uploads/1765265595_unnamed (21).jpg'),
(896, 47, 'BR - 003-02', NULL, NULL, 250000.00, NULL, NULL, 'public/uploads/1765265595_unnamed (21).jpg'),
(897, 47, 'BR - 003-03', NULL, NULL, 250000.00, NULL, NULL, 'public/uploads/1765265595_unnamed (21).jpg'),
(898, 47, 'BR - 003-04', NULL, NULL, 250000.00, NULL, NULL, 'public/uploads/1765265595_unnamed (21).jpg'),
(899, 47, 'BR - 003-05', NULL, NULL, 250000.00, NULL, NULL, 'public/uploads/1765265595_unnamed (21).jpg'),
(900, 47, 'BR - 003-06', NULL, NULL, 250000.00, NULL, NULL, 'public/uploads/1765265595_unnamed (21).jpg'),
(901, 47, 'BR - 003-07', NULL, NULL, 250000.00, NULL, NULL, 'public/uploads/1765265595_unnamed (21).jpg'),
(902, 47, 'BR - 003-08', NULL, NULL, 250000.00, NULL, NULL, 'public/uploads/1765265595_unnamed (21).jpg'),
(903, 47, 'BR - 003-09', NULL, NULL, 250000.00, NULL, NULL, 'public/uploads/1765265595_unnamed (21).jpg'),
(904, 48, 'BR - 004-01', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765265643_unnamed (22).jpg'),
(905, 48, 'BR - 004-02', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765265643_unnamed (22).jpg'),
(906, 48, 'BR - 004-03', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765265643_unnamed (22).jpg'),
(907, 48, 'BR - 004-04', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765265643_unnamed (22).jpg'),
(908, 48, 'BR - 004-05', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765265643_unnamed (22).jpg'),
(909, 48, 'BR - 004-06', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765265643_unnamed (22).jpg'),
(910, 48, 'BR - 004-07', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765265643_unnamed (22).jpg'),
(911, 48, 'BR - 004-08', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765265643_unnamed (22).jpg'),
(912, 48, 'BR - 004-09', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765265643_unnamed (22).jpg'),
(913, 48, 'BR - 004-10', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765265643_unnamed (22).jpg'),
(914, 48, 'BR - 004-11', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765265643_unnamed (22).jpg'),
(915, 48, 'BR - 004-12', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765265643_unnamed (22).jpg'),
(916, 48, 'BR - 004-13', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765265643_unnamed (22).jpg'),
(917, 48, 'BR - 004-14', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765265643_unnamed (22).jpg'),
(918, 48, 'BR - 004-15', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765265643_unnamed (22).jpg'),
(919, 48, 'BR - 004-16', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765265643_unnamed (22).jpg'),
(920, 48, 'BR - 004-17', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765265643_unnamed (22).jpg'),
(921, 48, 'BR - 004-18', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765265643_unnamed (22).jpg'),
(922, 48, 'BR - 004-19', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765265643_unnamed (22).jpg'),
(923, 48, 'BR - 004-20', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765265643_unnamed (22).jpg'),
(924, 48, 'BR - 004-21', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765265643_unnamed (22).jpg'),
(925, 48, 'BR - 004-22', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765265643_unnamed (22).jpg'),
(926, 48, 'BR - 004-23', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765265643_unnamed (22).jpg'),
(927, 48, 'BR - 004-24', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765265643_unnamed (22).jpg'),
(928, 6, 'BR - 002-01', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765127596_unnamed (11).jpg'),
(929, 6, 'BR - 002-02', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765127596_unnamed (11).jpg'),
(930, 6, 'BR - 002-03', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765127596_unnamed (11).jpg'),
(931, 6, 'BR - 002-04', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765127596_unnamed (11).jpg'),
(932, 6, 'BR - 002-05', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765127596_unnamed (11).jpg'),
(933, 6, 'BR - 002-06', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765127596_unnamed (11).jpg'),
(934, 6, 'BR - 002-07', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765127596_unnamed (11).jpg'),
(935, 6, 'BR - 002-08', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765127596_unnamed (11).jpg'),
(936, 6, 'BR - 002-09', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765127596_unnamed (11).jpg'),
(937, 6, 'BR - 002-10', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765127596_unnamed (11).jpg'),
(938, 6, 'BR - 002-11', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765127596_unnamed (11).jpg'),
(939, 6, 'BR - 002-12', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765127596_unnamed (11).jpg'),
(940, 6, 'BR - 002-13', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765127596_unnamed (11).jpg'),
(941, 6, 'BR - 002-14', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765127596_unnamed (11).jpg'),
(942, 6, 'BR - 002-15', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765127596_unnamed (11).jpg'),
(943, 6, 'BR - 002-16', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765127596_unnamed (11).jpg'),
(944, 6, 'BR - 002-17', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765127596_unnamed (11).jpg'),
(945, 6, 'BR - 002-18', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765127596_unnamed (11).jpg'),
(946, 6, 'BR - 002-19', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765127596_unnamed (11).jpg'),
(947, 6, 'BR - 002-20', NULL, NULL, 300000.00, NULL, NULL, 'public/uploads/1765127596_unnamed (11).jpg'),
(948, 49, 'BR - 005-01', NULL, NULL, 320000.00, NULL, NULL, 'public/uploads/1765266163_unnamed (23).jpg'),
(949, 49, 'BR - 005-02', NULL, NULL, 320000.00, NULL, NULL, 'public/uploads/1765266163_unnamed (23).jpg'),
(950, 49, 'BR - 005-03', NULL, NULL, 320000.00, NULL, NULL, 'public/uploads/1765266163_unnamed (23).jpg'),
(951, 49, 'BR - 005-04', NULL, NULL, 320000.00, NULL, NULL, 'public/uploads/1765266163_unnamed (23).jpg'),
(952, 49, 'BR - 005-05', NULL, NULL, 320000.00, NULL, NULL, 'public/uploads/1765266163_unnamed (23).jpg'),
(953, 49, 'BR - 005-06', NULL, NULL, 320000.00, NULL, NULL, 'public/uploads/1765266163_unnamed (23).jpg'),
(954, 49, 'BR - 005-07', NULL, NULL, 320000.00, NULL, NULL, 'public/uploads/1765266163_unnamed (23).jpg'),
(955, 49, 'BR - 005-08', NULL, NULL, 320000.00, NULL, NULL, 'public/uploads/1765266163_unnamed (23).jpg'),
(956, 49, 'BR - 005-09', NULL, NULL, 320000.00, NULL, NULL, 'public/uploads/1765266163_unnamed (23).jpg'),
(957, 49, 'BR - 005-10', NULL, NULL, 320000.00, NULL, NULL, 'public/uploads/1765266163_unnamed (23).jpg'),
(958, 49, 'BR - 005-11', NULL, NULL, 320000.00, NULL, NULL, 'public/uploads/1765266163_unnamed (23).jpg'),
(959, 49, 'BR - 005-12', NULL, NULL, 320000.00, NULL, NULL, 'public/uploads/1765266163_unnamed (23).jpg'),
(960, 49, 'BR - 005-13', NULL, NULL, 320000.00, NULL, NULL, 'public/uploads/1765266163_unnamed (23).jpg'),
(961, 49, 'BR - 005-14', NULL, NULL, 320000.00, NULL, NULL, 'public/uploads/1765266163_unnamed (23).jpg'),
(962, 49, 'BR - 005-15', NULL, NULL, 320000.00, NULL, NULL, 'public/uploads/1765266163_unnamed (23).jpg'),
(963, 49, 'BR - 005-16', NULL, NULL, 320000.00, NULL, NULL, 'public/uploads/1765266163_unnamed (23).jpg'),
(964, 31, 'CB - 005-01', NULL, NULL, 190000.00, NULL, NULL, 'public/uploads/1764984472_unnamed (3).jpg'),
(965, 31, 'CB - 005-02', NULL, NULL, 190000.00, NULL, NULL, 'public/uploads/1764984472_unnamed (3).jpg'),
(966, 31, 'CB - 005-03', NULL, NULL, 190000.00, NULL, NULL, 'public/uploads/1764984472_unnamed (3).jpg'),
(967, 31, 'CB - 005-04', NULL, NULL, 190000.00, NULL, NULL, 'public/uploads/1764984472_unnamed (3).jpg'),
(968, 31, 'CB - 005-05', NULL, NULL, 190000.00, NULL, NULL, 'public/uploads/1764984472_unnamed (3).jpg'),
(969, 31, 'CB - 005-06', NULL, NULL, 190000.00, NULL, NULL, 'public/uploads/1764984472_unnamed (3).jpg'),
(970, 31, 'CB - 005-07', NULL, NULL, 190000.00, NULL, NULL, 'public/uploads/1764984472_unnamed (3).jpg'),
(971, 31, 'CB - 005-08', NULL, NULL, 190000.00, NULL, NULL, 'public/uploads/1764984472_unnamed (3).jpg'),
(972, 31, 'CB - 005-09', NULL, NULL, 190000.00, NULL, NULL, 'public/uploads/1764984472_unnamed (3).jpg'),
(973, 31, 'CB - 005-10', NULL, NULL, 190000.00, NULL, NULL, 'public/uploads/1764984472_unnamed (3).jpg'),
(974, 31, 'CB - 005-11', NULL, NULL, 190000.00, NULL, NULL, 'public/uploads/1764984472_unnamed (3).jpg'),
(975, 31, 'CB - 005-12', NULL, NULL, 190000.00, NULL, NULL, 'public/uploads/1764984472_unnamed (3).jpg'),
(976, 31, 'CB - 005-13', NULL, NULL, 190000.00, NULL, NULL, 'public/uploads/1764984472_unnamed (3).jpg'),
(977, 31, 'CB - 005-14', NULL, NULL, 190000.00, NULL, NULL, 'public/uploads/1764984472_unnamed (3).jpg'),
(978, 31, 'CB - 005-15', NULL, NULL, 190000.00, NULL, NULL, 'public/uploads/1764984472_unnamed (3).jpg'),
(979, 31, 'CB - 005-16', NULL, NULL, 190000.00, NULL, NULL, 'public/uploads/1764984472_unnamed (3).jpg'),
(980, 50, 'BS - 003-01', NULL, NULL, 260000.00, NULL, NULL, 'public/uploads/1765267380_unnamed (26).jpg'),
(981, 50, 'BS - 003-02', NULL, NULL, 260000.00, NULL, NULL, 'public/uploads/1765267380_unnamed (26).jpg'),
(982, 50, 'BS - 003-03', NULL, NULL, 260000.00, NULL, NULL, 'public/uploads/1765267380_unnamed (26).jpg'),
(983, 50, 'BS - 003-04', NULL, NULL, 260000.00, NULL, NULL, 'public/uploads/1765267380_unnamed (26).jpg'),
(984, 50, 'BS - 003-05', NULL, NULL, 260000.00, NULL, NULL, 'public/uploads/1765267380_unnamed (26).jpg'),
(985, 50, 'BS - 003-06', NULL, NULL, 260000.00, NULL, NULL, 'public/uploads/1765267380_unnamed (26).jpg'),
(986, 50, 'BS - 003-07', NULL, NULL, 260000.00, NULL, NULL, 'public/uploads/1765267380_unnamed (26).jpg'),
(987, 50, 'BS - 003-08', NULL, NULL, 260000.00, NULL, NULL, 'public/uploads/1765267380_unnamed (26).jpg'),
(988, 50, 'BS - 003-09', NULL, NULL, 260000.00, NULL, NULL, 'public/uploads/1765267380_unnamed (26).jpg'),
(989, 50, 'BS - 003-10', NULL, NULL, 260000.00, NULL, NULL, 'public/uploads/1765267380_unnamed (26).jpg'),
(990, 50, 'BS - 003-11', NULL, NULL, 260000.00, NULL, NULL, 'public/uploads/1765267380_unnamed (26).jpg'),
(991, 50, 'BS - 003-12', NULL, NULL, 260000.00, NULL, NULL, 'public/uploads/1765267380_unnamed (26).jpg'),
(992, 50, 'BS - 003-13', NULL, NULL, 260000.00, NULL, NULL, 'public/uploads/1765267380_unnamed (26).jpg'),
(993, 50, 'BS - 003-14', NULL, NULL, 260000.00, NULL, NULL, 'public/uploads/1765267380_unnamed (26).jpg'),
(994, 50, 'BS - 003-15', NULL, NULL, 260000.00, NULL, NULL, 'public/uploads/1765267380_unnamed (26).jpg'),
(995, 50, 'BS - 003-16', NULL, NULL, 260000.00, NULL, NULL, 'public/uploads/1765267380_unnamed (26).jpg'),
(996, 50, 'BS - 003-17', NULL, NULL, 260000.00, NULL, NULL, 'public/uploads/1765267380_unnamed (26).jpg'),
(997, 50, 'BS - 003-18', NULL, NULL, 260000.00, NULL, NULL, 'public/uploads/1765267380_unnamed (26).jpg'),
(998, 50, 'BS - 003-19', NULL, NULL, 260000.00, NULL, NULL, 'public/uploads/1765267380_unnamed (26).jpg'),
(999, 50, 'BS - 003-20', NULL, NULL, 260000.00, NULL, NULL, 'public/uploads/1765267380_unnamed (26).jpg'),
(1000, 7, 'BS-002-01', NULL, NULL, 299000.00, NULL, NULL, 'public/uploads/1765127631_unnamed (10).jpg'),
(1001, 7, 'BS-002-02', NULL, NULL, 299000.00, NULL, NULL, 'public/uploads/1765127631_unnamed (10).jpg'),
(1002, 7, 'BS-002-03', NULL, NULL, 299000.00, NULL, NULL, 'public/uploads/1765127631_unnamed (10).jpg'),
(1003, 7, 'BS-002-04', NULL, NULL, 299000.00, NULL, NULL, 'public/uploads/1765127631_unnamed (10).jpg'),
(1004, 7, 'BS-002-05', NULL, NULL, 299000.00, NULL, NULL, 'public/uploads/1765127631_unnamed (10).jpg'),
(1005, 7, 'BS-002-06', NULL, NULL, 299000.00, NULL, NULL, 'public/uploads/1765127631_unnamed (10).jpg'),
(1006, 7, 'BS-002-07', NULL, NULL, 299000.00, NULL, NULL, 'public/uploads/1765127631_unnamed (10).jpg'),
(1007, 7, 'BS-002-08', NULL, NULL, 299000.00, NULL, NULL, 'public/uploads/1765127631_unnamed (10).jpg'),
(1008, 7, 'BS-002-09', NULL, NULL, 299000.00, NULL, NULL, 'public/uploads/1765127631_unnamed (10).jpg'),
(1009, 7, 'BS-002-10', NULL, NULL, 299000.00, NULL, NULL, 'public/uploads/1765127631_unnamed (10).jpg'),
(1010, 7, 'BS-002-11', NULL, NULL, 299000.00, NULL, NULL, 'public/uploads/1765127631_unnamed (10).jpg'),
(1011, 7, 'BS-002-12', NULL, NULL, 299000.00, NULL, NULL, 'public/uploads/1765127631_unnamed (10).jpg'),
(1012, 7, 'BS-002-13', NULL, NULL, 299000.00, NULL, NULL, 'public/uploads/1765127631_unnamed (10).jpg'),
(1013, 7, 'BS-002-14', NULL, NULL, 299000.00, NULL, NULL, 'public/uploads/1765127631_unnamed (10).jpg'),
(1014, 7, 'BS-002-15', NULL, NULL, 299000.00, NULL, NULL, 'public/uploads/1765127631_unnamed (10).jpg'),
(1015, 7, 'BS-002-16', NULL, NULL, 299000.00, NULL, NULL, 'public/uploads/1765127631_unnamed (10).jpg'),
(1016, 7, 'BS-002-17', NULL, NULL, 299000.00, NULL, NULL, 'public/uploads/1765127631_unnamed (10).jpg'),
(1017, 7, 'BS-002-18', NULL, NULL, 299000.00, NULL, NULL, 'public/uploads/1765127631_unnamed (10).jpg'),
(1018, 7, 'BS-002-19', NULL, NULL, 299000.00, NULL, NULL, 'public/uploads/1765127631_unnamed (10).jpg'),
(1019, 7, 'BS-002-20', NULL, NULL, 299000.00, NULL, NULL, 'public/uploads/1765127631_unnamed (10).jpg'),
(1040, 51, 'BS - 004-01', NULL, NULL, 400000.00, NULL, NULL, 'public/uploads/1765267528_unnamed (25).jpg'),
(1041, 51, 'BS - 004-02', NULL, NULL, 400000.00, NULL, NULL, 'public/uploads/1765267528_unnamed (25).jpg'),
(1042, 51, 'BS - 004-03', NULL, NULL, 400000.00, NULL, NULL, 'public/uploads/1765267528_unnamed (25).jpg'),
(1043, 51, 'BS - 004-04', NULL, NULL, 400000.00, NULL, NULL, 'public/uploads/1765267528_unnamed (25).jpg'),
(1044, 51, 'BS - 004-05', NULL, NULL, 400000.00, NULL, NULL, 'public/uploads/1765267528_unnamed (25).jpg'),
(1045, 51, 'BS - 004-06', NULL, NULL, 400000.00, NULL, NULL, 'public/uploads/1765267528_unnamed (25).jpg'),
(1046, 51, 'BS - 004-07', NULL, NULL, 400000.00, NULL, NULL, 'public/uploads/1765267528_unnamed (25).jpg'),
(1047, 51, 'BS - 004-08', NULL, NULL, 400000.00, NULL, NULL, 'public/uploads/1765267528_unnamed (25).jpg'),
(1048, 51, 'BS - 004-09', NULL, NULL, 400000.00, NULL, NULL, 'public/uploads/1765267528_unnamed (25).jpg'),
(1049, 51, 'BS - 004-10', NULL, NULL, 400000.00, NULL, NULL, 'public/uploads/1765267528_unnamed (25).jpg'),
(1050, 51, 'BS - 004-11', NULL, NULL, 400000.00, NULL, NULL, 'public/uploads/1765267528_unnamed (25).jpg'),
(1051, 51, 'BS - 004-12', NULL, NULL, 400000.00, NULL, NULL, 'public/uploads/1765267528_unnamed (25).jpg'),
(1052, 51, 'BS - 004-13', NULL, NULL, 400000.00, NULL, NULL, 'public/uploads/1765267528_unnamed (25).jpg'),
(1053, 51, 'BS - 004-14', NULL, NULL, 400000.00, NULL, NULL, 'public/uploads/1765267528_unnamed (25).jpg'),
(1054, 51, 'BS - 004-15', NULL, NULL, 400000.00, NULL, NULL, 'public/uploads/1765267528_unnamed (25).jpg'),
(1055, 51, 'BS - 004-16', NULL, NULL, 400000.00, NULL, NULL, 'public/uploads/1765267528_unnamed (25).jpg'),
(1056, 51, 'BS - 004-17', NULL, NULL, 400000.00, NULL, NULL, 'public/uploads/1765267528_unnamed (25).jpg'),
(1057, 51, 'BS - 004-18', NULL, NULL, 400000.00, NULL, NULL, 'public/uploads/1765267528_unnamed (25).jpg'),
(1058, 51, 'BS - 004-19', NULL, NULL, 400000.00, NULL, NULL, 'public/uploads/1765267528_unnamed (25).jpg'),
(1059, 51, 'BS - 004-20', NULL, NULL, 400000.00, NULL, NULL, 'public/uploads/1765267528_unnamed (25).jpg'),
(1060, 52, 'BS - 005-01', NULL, NULL, 450000.00, NULL, NULL, 'public/uploads/1765267619_unnamed (24).jpg'),
(1061, 52, 'BS - 005-02', NULL, NULL, 450000.00, NULL, NULL, 'public/uploads/1765267619_unnamed (24).jpg'),
(1062, 52, 'BS - 005-03', NULL, NULL, 450000.00, NULL, NULL, 'public/uploads/1765267619_unnamed (24).jpg'),
(1063, 52, 'BS - 005-04', NULL, NULL, 450000.00, NULL, NULL, 'public/uploads/1765267619_unnamed (24).jpg'),
(1064, 52, 'BS - 005-05', NULL, NULL, 450000.00, NULL, NULL, 'public/uploads/1765267619_unnamed (24).jpg'),
(1065, 52, 'BS - 005-06', NULL, NULL, 450000.00, NULL, NULL, 'public/uploads/1765267619_unnamed (24).jpg'),
(1066, 52, 'BS - 005-07', NULL, NULL, 450000.00, NULL, NULL, 'public/uploads/1765267619_unnamed (24).jpg'),
(1067, 52, 'BS - 005-08', NULL, NULL, 450000.00, NULL, NULL, 'public/uploads/1765267619_unnamed (24).jpg'),
(1068, 52, 'BS - 005-09', NULL, NULL, 450000.00, NULL, NULL, 'public/uploads/1765267619_unnamed (24).jpg'),
(1069, 52, 'BS - 005-10', NULL, NULL, 450000.00, NULL, NULL, 'public/uploads/1765267619_unnamed (24).jpg'),
(1070, 52, 'BS - 005-11', NULL, NULL, 450000.00, NULL, NULL, 'public/uploads/1765267619_unnamed (24).jpg'),
(1071, 52, 'BS - 005-12', NULL, NULL, 450000.00, NULL, NULL, 'public/uploads/1765267619_unnamed (24).jpg'),
(1072, 1, 'CB-001-01', NULL, NULL, 120000.00, NULL, NULL, 'public/uploads/1765197447_unnamed.jpg'),
(1073, 1, 'CB-001-02', NULL, NULL, 120000.00, NULL, NULL, 'public/uploads/1765197447_unnamed.jpg'),
(1074, 1, 'CB-001-03', NULL, NULL, 120000.00, NULL, NULL, 'public/uploads/1765197447_unnamed.jpg'),
(1075, 1, 'CB-001-04', NULL, NULL, 120000.00, NULL, NULL, 'public/uploads/1765197447_unnamed.jpg'),
(1076, 1, 'CB-001-05', NULL, NULL, 120000.00, NULL, NULL, 'public/uploads/1765197447_unnamed.jpg'),
(1077, 1, 'CB-001-06', NULL, NULL, 120000.00, NULL, NULL, 'public/uploads/1765197447_unnamed.jpg'),
(1078, 1, 'CB-001-07', NULL, NULL, 120000.00, NULL, NULL, 'public/uploads/1765197447_unnamed.jpg'),
(1079, 1, 'CB-001-08', NULL, NULL, 120000.00, NULL, NULL, 'public/uploads/1765197447_unnamed.jpg'),
(1080, 1, 'CB-001-09', NULL, NULL, 120000.00, NULL, NULL, 'public/uploads/1765197447_unnamed.jpg'),
(1081, 1, 'CB-001-10', NULL, NULL, 120000.00, NULL, NULL, 'public/uploads/1765197447_unnamed.jpg'),
(1082, 1, 'CB-001-11', NULL, NULL, 120000.00, NULL, NULL, 'public/uploads/1765197447_unnamed.jpg'),
(1083, 1, 'CB-001-12', NULL, NULL, 120000.00, NULL, NULL, 'public/uploads/1765197447_unnamed.jpg'),
(1084, 1, 'CB-001-13', NULL, NULL, 120000.00, NULL, NULL, 'public/uploads/1765197447_unnamed.jpg'),
(1085, 1, 'CB-001-14', NULL, NULL, 120000.00, NULL, NULL, 'public/uploads/1765197447_unnamed.jpg'),
(1086, 1, 'CB-001-15', NULL, NULL, 120000.00, NULL, NULL, 'public/uploads/1765197447_unnamed.jpg'),
(1087, 1, 'CB-001-16', NULL, NULL, 120000.00, NULL, NULL, 'public/uploads/1765197447_unnamed.jpg'),
(1088, 1, 'CB-001-17', NULL, NULL, 120000.00, NULL, NULL, 'public/uploads/1765197447_unnamed.jpg'),
(1089, 1, 'CB-001-18', NULL, NULL, 120000.00, NULL, NULL, 'public/uploads/1765197447_unnamed.jpg'),
(1090, 1, 'CB-001-19', NULL, NULL, 120000.00, NULL, NULL, 'public/uploads/1765197447_unnamed.jpg'),
(1091, 1, 'CB-001-20', NULL, NULL, 120000.00, NULL, NULL, 'public/uploads/1765197447_unnamed.jpg'),
(1092, 3, 'CB-003-01', NULL, NULL, 180000.00, NULL, NULL, 'public/uploads/1765127832_unnamed (18).jpg'),
(1093, 3, 'CB-003-02', NULL, NULL, 180000.00, NULL, NULL, 'public/uploads/1765127832_unnamed (18).jpg'),
(1094, 3, 'CB-003-03', NULL, NULL, 180000.00, NULL, NULL, 'public/uploads/1765127832_unnamed (18).jpg'),
(1095, 3, 'CB-003-04', NULL, NULL, 180000.00, NULL, NULL, 'public/uploads/1765127832_unnamed (18).jpg'),
(1096, 3, 'CB-003-05', NULL, NULL, 180000.00, NULL, NULL, 'public/uploads/1765127832_unnamed (18).jpg'),
(1097, 3, 'CB-003-06', NULL, NULL, 180000.00, NULL, NULL, 'public/uploads/1765127832_unnamed (18).jpg'),
(1098, 3, 'CB-003-07', NULL, NULL, 180000.00, NULL, NULL, 'public/uploads/1765127832_unnamed (18).jpg'),
(1099, 3, 'CB-003-08', NULL, NULL, 180000.00, NULL, NULL, 'public/uploads/1765127832_unnamed (18).jpg'),
(1100, 3, 'CB-003-09', NULL, NULL, 180000.00, NULL, NULL, 'public/uploads/1765127832_unnamed (18).jpg'),
(1101, 3, 'CB-003-10', NULL, NULL, 180000.00, NULL, NULL, 'public/uploads/1765127832_unnamed (18).jpg'),
(1102, 3, 'CB-003-11', NULL, NULL, 180000.00, NULL, NULL, 'public/uploads/1765127832_unnamed (18).jpg'),
(1103, 3, 'CB-003-12', NULL, NULL, 180000.00, NULL, NULL, 'public/uploads/1765127832_unnamed (18).jpg'),
(1104, 3, 'CB-003-13', NULL, NULL, 180000.00, NULL, NULL, 'public/uploads/1765127832_unnamed (18).jpg'),
(1105, 3, 'CB-003-14', NULL, NULL, 180000.00, NULL, NULL, 'public/uploads/1765127832_unnamed (18).jpg'),
(1106, 3, 'CB-003-15', NULL, NULL, 180000.00, NULL, NULL, 'public/uploads/1765127832_unnamed (18).jpg'),
(1107, 3, 'CB-003-16', NULL, NULL, 180000.00, NULL, NULL, 'public/uploads/1765127832_unnamed (18).jpg'),
(1108, 3, 'CB-003-17', NULL, NULL, 180000.00, NULL, NULL, 'public/uploads/1765127832_unnamed (18).jpg'),
(1109, 3, 'CB-003-18', NULL, NULL, 180000.00, NULL, NULL, 'public/uploads/1765127832_unnamed (18).jpg'),
(1110, 3, 'CB-003-19', NULL, NULL, 180000.00, NULL, NULL, 'public/uploads/1765127832_unnamed (18).jpg'),
(1111, 3, 'CB-003-20', NULL, NULL, 180000.00, NULL, NULL, 'public/uploads/1765127832_unnamed (18).jpg'),
(1112, 53, 'CB - 002-01', NULL, NULL, 500000.00, NULL, NULL, 'public/uploads/1765268961_unnamed (27).jpg'),
(1113, 53, 'CB - 002-02', NULL, NULL, 500000.00, NULL, NULL, 'public/uploads/1765268961_unnamed (27).jpg'),
(1114, 53, 'CB - 002-03', NULL, NULL, 500000.00, NULL, NULL, 'public/uploads/1765268961_unnamed (27).jpg'),
(1115, 53, 'CB - 002-04', NULL, NULL, 500000.00, NULL, NULL, 'public/uploads/1765268961_unnamed (27).jpg'),
(1116, 53, 'CB - 002-05', NULL, NULL, 500000.00, NULL, NULL, 'public/uploads/1765268961_unnamed (27).jpg'),
(1117, 53, 'CB - 002-06', NULL, NULL, 500000.00, NULL, NULL, 'public/uploads/1765268961_unnamed (27).jpg'),
(1118, 53, 'CB - 002-07', NULL, NULL, 500000.00, NULL, NULL, 'public/uploads/1765268961_unnamed (27).jpg'),
(1119, 53, 'CB - 002-08', NULL, NULL, 500000.00, NULL, NULL, 'public/uploads/1765268961_unnamed (27).jpg'),
(1120, 53, 'CB - 002-09', NULL, NULL, 500000.00, NULL, NULL, 'public/uploads/1765268961_unnamed (27).jpg'),
(1121, 53, 'CB - 002-10', NULL, NULL, 500000.00, NULL, NULL, 'public/uploads/1765268961_unnamed (27).jpg'),
(1122, 53, 'CB - 002-11', NULL, NULL, 500000.00, NULL, NULL, 'public/uploads/1765268961_unnamed (27).jpg'),
(1123, 53, 'CB - 002-12', NULL, NULL, 500000.00, NULL, NULL, 'public/uploads/1765268961_unnamed (27).jpg'),
(1124, 53, 'CB - 002-13', NULL, NULL, 500000.00, NULL, NULL, 'public/uploads/1765268961_unnamed (27).jpg'),
(1125, 53, 'CB - 002-14', NULL, NULL, 500000.00, NULL, NULL, 'public/uploads/1765268961_unnamed (27).jpg'),
(1126, 53, 'CB - 002-15', NULL, NULL, 500000.00, NULL, NULL, 'public/uploads/1765268961_unnamed (27).jpg'),
(1127, 53, 'CB - 002-16', NULL, NULL, 500000.00, NULL, NULL, 'public/uploads/1765268961_unnamed (27).jpg'),
(1128, 53, 'CB - 002-17', NULL, NULL, 500000.00, NULL, NULL, 'public/uploads/1765268961_unnamed (27).jpg'),
(1129, 53, 'CB - 002-18', NULL, NULL, 500000.00, NULL, NULL, 'public/uploads/1765268961_unnamed (27).jpg'),
(1130, 53, 'CB - 002-19', NULL, NULL, 500000.00, NULL, NULL, 'public/uploads/1765268961_unnamed (27).jpg'),
(1131, 53, 'CB - 002-20', NULL, NULL, 500000.00, NULL, NULL, 'public/uploads/1765268961_unnamed (27).jpg'),
(1132, 53, 'CB - 002-21', NULL, NULL, 500000.00, NULL, NULL, 'public/uploads/1765268961_unnamed (27).jpg'),
(1133, 53, 'CB - 002-22', NULL, NULL, 500000.00, NULL, NULL, 'public/uploads/1765268961_unnamed (27).jpg'),
(1134, 53, 'CB - 002-23', NULL, NULL, 500000.00, NULL, NULL, 'public/uploads/1765268961_unnamed (27).jpg'),
(1135, 53, 'CB - 002-24', NULL, NULL, 500000.00, NULL, NULL, 'public/uploads/1765268961_unnamed (27).jpg'),
(1136, 53, 'CB - 002-25', NULL, NULL, 500000.00, NULL, NULL, 'public/uploads/1765268961_unnamed (27).jpg'),
(1137, 53, 'CB - 002-26', NULL, NULL, 500000.00, NULL, NULL, 'public/uploads/1765268961_unnamed (27).jpg'),
(1138, 53, 'CB - 002-27', NULL, NULL, 500000.00, NULL, NULL, 'public/uploads/1765268961_unnamed (27).jpg'),
(1139, 53, 'CB - 002-28', NULL, NULL, 500000.00, NULL, NULL, 'public/uploads/1765268961_unnamed (27).jpg'),
(1140, 53, 'CB - 002-29', NULL, NULL, 500000.00, NULL, NULL, 'public/uploads/1765268961_unnamed (27).jpg'),
(1141, 53, 'CB - 002-30', NULL, NULL, 500000.00, NULL, NULL, 'public/uploads/1765268961_unnamed (27).jpg'),
(1142, 53, 'CB - 002-31', NULL, NULL, 500000.00, NULL, NULL, 'public/uploads/1765268961_unnamed (27).jpg'),
(1143, 53, 'CB - 002-32', NULL, NULL, 500000.00, NULL, NULL, 'public/uploads/1765268961_unnamed (27).jpg');

-- --------------------------------------------------------

--
-- Table structure for table `shoe_variant_attribute_map`
--

CREATE TABLE `shoe_variant_attribute_map` (
  `map_id` int(11) NOT NULL,
  `variant_id` int(11) NOT NULL COMMENT 'Khóa ngoại tới biến thể',
  `value_id` int(11) NOT NULL COMMENT 'Khóa ngoại tới giá trị thuộc tính',
  `stock` int(11) NOT NULL DEFAULT 0 COMMENT 'Số lượng tồn kho cho sự kết hợp thuộc tính này'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `shoe_variant_attribute_map`
--

INSERT INTO `shoe_variant_attribute_map` (`map_id`, `variant_id`, `value_id`, `stock`) VALUES
(118, 5, 1, 15),
(119, 5, 2, 15),
(120, 5, 3, 15),
(121, 5, 4, 15),
(122, 5, 5, 15),
(123, 5, 6, 10),
(124, 5, 7, 10),
(125, 5, 8, 10),
(126, 5, 9, 10),
(136, 7, 1, 15),
(137, 7, 2, 15),
(138, 7, 3, 15),
(139, 7, 4, 15),
(140, 7, 5, 15),
(141, 7, 6, 10),
(142, 7, 7, 10),
(143, 7, 8, 10),
(144, 7, 9, 10),
(215, 24, 18, 0),
(216, 24, 2, 0),
(351, 92, 21, 0),
(352, 92, 10, 0),
(353, 93, 21, 0),
(354, 93, 11, 0),
(355, 94, 21, 0),
(356, 94, 12, 0),
(357, 95, 21, 0),
(358, 95, 1, 0),
(407, 120, 22, 0),
(408, 120, 1, 0),
(409, 121, 22, 0),
(410, 121, 2, 0),
(411, 122, 22, 0),
(412, 122, 3, 0),
(413, 123, 22, 0),
(414, 123, 4, 0),
(415, 124, 22, 0),
(416, 124, 5, 0),
(417, 125, 6, 0),
(418, 125, 1, 0),
(419, 126, 6, 0),
(420, 126, 2, 0),
(421, 127, 6, 0),
(422, 127, 3, 0),
(423, 128, 6, 0),
(424, 128, 4, 0),
(425, 129, 6, 0),
(426, 129, 5, 0),
(427, 130, 7, 0),
(428, 130, 1, 0),
(429, 131, 7, 0),
(430, 131, 2, 0),
(431, 132, 7, 0),
(432, 132, 3, 0),
(433, 133, 7, 0),
(434, 133, 4, 0),
(435, 134, 7, 0),
(436, 134, 5, 0),
(613, 223, 6, 0),
(614, 223, 10, 0),
(615, 224, 6, 0),
(616, 224, 11, 0),
(617, 225, 6, 0),
(618, 225, 12, 0),
(619, 226, 6, 0),
(620, 226, 1, 0),
(621, 227, 6, 0),
(622, 227, 2, 0),
(623, 228, 6, 0),
(624, 228, 3, 0),
(625, 229, 6, 0),
(626, 229, 4, 0),
(627, 230, 6, 0),
(628, 230, 5, 0),
(629, 231, 7, 0),
(630, 231, 10, 0),
(631, 232, 7, 0),
(632, 232, 11, 0),
(633, 233, 7, 0),
(634, 233, 12, 0),
(635, 234, 7, 0),
(636, 234, 1, 0),
(637, 235, 7, 0),
(638, 235, 2, 0),
(639, 236, 7, 0),
(640, 236, 3, 0),
(641, 237, 7, 0),
(642, 237, 4, 0),
(643, 238, 7, 0),
(644, 238, 5, 0),
(645, 239, 8, 0),
(646, 239, 10, 0),
(647, 240, 8, 0),
(648, 240, 11, 0),
(649, 241, 8, 0),
(650, 241, 12, 0),
(651, 242, 8, 0),
(652, 242, 1, 0),
(653, 243, 8, 0),
(654, 243, 2, 0),
(655, 244, 8, 0),
(656, 244, 3, 0),
(657, 245, 8, 0),
(658, 245, 4, 0),
(659, 246, 8, 0),
(660, 246, 5, 0),
(661, 247, 9, 0),
(662, 247, 10, 0),
(663, 248, 9, 0),
(664, 248, 11, 0),
(665, 249, 9, 0),
(666, 249, 12, 0),
(667, 250, 9, 0),
(668, 250, 1, 0),
(669, 251, 9, 0),
(670, 251, 2, 0),
(671, 252, 9, 0),
(672, 252, 3, 0),
(673, 253, 9, 0),
(674, 253, 4, 0),
(675, 254, 9, 0),
(676, 254, 5, 0),
(837, 335, 18, 0),
(838, 335, 2, 0),
(839, 336, 18, 0),
(840, 336, 3, 0),
(841, 337, 18, 0),
(842, 337, 4, 0),
(843, 338, 18, 0),
(844, 338, 5, 0),
(845, 339, 19, 0),
(846, 339, 2, 0),
(847, 340, 19, 0),
(848, 340, 3, 0),
(849, 341, 19, 0),
(850, 341, 4, 0),
(851, 342, 19, 0),
(852, 342, 5, 0),
(1125, 479, 6, 0),
(1126, 479, 1, 0),
(1127, 480, 6, 0),
(1128, 480, 2, 0),
(1129, 481, 6, 0),
(1130, 481, 3, 0),
(1131, 482, 6, 0),
(1132, 482, 4, 0),
(1133, 483, 6, 0),
(1134, 483, 5, 0),
(1135, 484, 8, 0),
(1136, 484, 1, 0),
(1137, 485, 8, 0),
(1138, 485, 2, 0),
(1139, 486, 8, 0),
(1140, 486, 3, 0),
(1141, 487, 8, 0),
(1142, 487, 4, 0),
(1143, 488, 8, 0),
(1144, 488, 5, 0),
(1145, 489, 7, 0),
(1146, 489, 1, 0),
(1147, 490, 7, 0),
(1148, 490, 2, 0),
(1149, 491, 7, 0),
(1150, 491, 3, 0),
(1151, 492, 7, 0),
(1152, 492, 4, 0),
(1153, 493, 7, 0),
(1154, 493, 5, 0),
(1155, 494, 9, 0),
(1156, 494, 1, 0),
(1157, 495, 9, 0),
(1158, 495, 2, 0),
(1159, 496, 9, 0),
(1160, 496, 3, 0),
(1161, 497, 9, 0),
(1162, 497, 4, 0),
(1163, 498, 9, 0),
(1164, 498, 5, 0),
(1245, 539, 8, 0),
(1246, 539, 1, 0),
(1247, 540, 8, 0),
(1248, 540, 2, 0),
(1249, 541, 8, 0),
(1250, 541, 3, 0),
(1251, 542, 8, 0),
(1252, 542, 4, 0),
(1253, 543, 8, 0),
(1254, 543, 5, 0),
(1255, 544, 9, 0),
(1256, 544, 1, 0),
(1257, 545, 9, 0),
(1258, 545, 2, 0),
(1259, 546, 9, 0),
(1260, 546, 3, 0),
(1261, 547, 9, 0),
(1262, 547, 4, 0),
(1263, 548, 9, 0),
(1264, 548, 5, 0),
(1265, 549, 6, 0),
(1266, 549, 1, 0),
(1267, 550, 6, 0),
(1268, 550, 2, 0),
(1269, 551, 6, 0),
(1270, 551, 3, 0),
(1271, 552, 6, 0),
(1272, 552, 4, 0),
(1273, 553, 6, 0),
(1274, 553, 5, 0),
(1275, 554, 8, 0),
(1276, 554, 1, 0),
(1277, 555, 8, 0),
(1278, 555, 2, 0),
(1279, 556, 8, 0),
(1280, 556, 3, 0),
(1281, 557, 8, 0),
(1282, 557, 4, 0),
(1283, 558, 8, 0),
(1284, 558, 5, 0),
(1285, 559, 9, 0),
(1286, 559, 1, 0),
(1287, 560, 9, 0),
(1288, 560, 2, 0),
(1289, 561, 9, 0),
(1290, 561, 3, 0),
(1291, 562, 9, 0),
(1292, 562, 4, 0),
(1293, 563, 9, 0),
(1294, 563, 5, 0),
(1295, 564, 7, 0),
(1296, 564, 1, 0),
(1297, 565, 7, 0),
(1298, 565, 2, 0),
(1299, 566, 7, 0),
(1300, 566, 3, 0),
(1301, 567, 7, 0),
(1302, 567, 4, 0),
(1303, 568, 7, 0),
(1304, 568, 5, 0),
(1305, 569, 8, 0),
(1306, 569, 1, 0),
(1307, 570, 8, 0),
(1308, 570, 2, 0),
(1309, 571, 8, 0),
(1310, 571, 3, 0),
(1311, 572, 8, 0),
(1312, 572, 4, 0),
(1313, 573, 8, 0),
(1314, 573, 5, 0),
(1315, 574, 9, 0),
(1316, 574, 1, 0),
(1317, 575, 9, 0),
(1318, 575, 2, 0),
(1319, 576, 9, 0),
(1320, 576, 3, 0),
(1321, 577, 9, 0),
(1322, 577, 4, 0),
(1323, 578, 9, 0),
(1324, 578, 5, 0),
(1325, 579, 26, 0),
(1326, 579, 1, 0),
(1327, 580, 26, 0),
(1328, 580, 2, 0),
(1329, 581, 26, 0),
(1330, 581, 3, 0),
(1331, 582, 26, 0),
(1332, 582, 4, 0),
(1333, 583, 26, 0),
(1334, 583, 5, 0),
(1365, 599, 6, 0),
(1366, 599, 1, 0),
(1367, 600, 6, 0),
(1368, 600, 2, 0),
(1369, 601, 6, 0),
(1370, 601, 3, 0),
(1371, 602, 6, 0),
(1372, 602, 4, 0),
(1373, 603, 6, 0),
(1374, 603, 5, 0),
(1375, 604, 7, 0),
(1376, 604, 1, 0),
(1377, 605, 7, 0),
(1378, 605, 2, 0),
(1379, 606, 7, 0),
(1380, 606, 3, 0),
(1381, 607, 7, 0),
(1382, 607, 4, 0),
(1383, 608, 7, 0),
(1384, 608, 5, 0),
(1385, 609, 8, 0),
(1386, 609, 1, 0),
(1387, 610, 8, 0),
(1388, 610, 2, 0),
(1389, 611, 8, 0),
(1390, 611, 3, 0),
(1391, 612, 8, 0),
(1392, 612, 4, 0),
(1393, 613, 8, 0),
(1394, 613, 5, 0),
(1395, 614, 6, 0),
(1396, 614, 1, 0),
(1545, 689, 27, 0),
(1546, 689, 1, 0),
(1547, 690, 27, 0),
(1548, 690, 2, 0),
(1549, 691, 27, 0),
(1550, 691, 3, 0),
(1551, 692, 27, 0),
(1552, 692, 4, 0),
(1553, 693, 27, 0),
(1554, 693, 5, 0),
(1555, 694, 6, 0),
(1556, 694, 1, 0),
(1557, 695, 6, 0),
(1558, 695, 2, 0),
(1559, 696, 6, 0),
(1560, 696, 3, 0),
(1561, 697, 6, 0),
(1562, 697, 4, 0),
(1563, 698, 6, 0),
(1564, 698, 5, 0),
(1565, 699, 8, 0),
(1566, 699, 1, 0),
(1567, 700, 8, 0),
(1568, 700, 2, 0),
(1569, 701, 8, 0),
(1570, 701, 3, 0),
(1571, 702, 8, 0),
(1572, 702, 4, 0),
(1573, 703, 8, 0),
(1574, 703, 5, 0),
(1847, 840, 6, 0),
(1848, 840, 1, 0),
(1849, 841, 6, 0),
(1850, 841, 2, 0),
(1851, 842, 6, 0),
(1852, 842, 3, 0),
(1853, 843, 6, 0),
(1854, 843, 4, 0),
(1855, 844, 6, 0),
(1856, 844, 5, 0),
(1857, 845, 8, 0),
(1858, 845, 1, 0),
(1859, 846, 8, 0),
(1860, 846, 2, 0),
(1861, 847, 8, 0),
(1862, 847, 3, 0),
(1863, 848, 8, 0),
(1864, 848, 4, 0),
(1865, 849, 8, 0),
(1866, 849, 5, 0),
(1867, 850, 7, 0),
(1868, 850, 1, 0),
(1869, 851, 7, 0),
(1870, 851, 2, 0),
(1871, 852, 7, 0),
(1872, 852, 3, 0),
(1873, 853, 7, 0),
(1874, 853, 4, 0),
(1875, 854, 7, 0),
(1876, 854, 5, 0),
(1877, 855, 9, 0),
(1878, 855, 1, 0),
(1879, 856, 9, 0),
(1880, 856, 2, 0),
(1881, 857, 9, 0),
(1882, 857, 3, 0),
(1883, 858, 9, 0),
(1884, 858, 4, 0),
(1885, 859, 9, 0),
(1886, 859, 5, 0),
(1887, 860, 6, 0),
(1888, 860, 1, 0),
(1889, 861, 6, 0),
(1890, 861, 2, 0),
(1891, 862, 6, 0),
(1892, 862, 3, 0),
(1893, 863, 6, 0),
(1894, 863, 4, 0),
(1895, 864, 6, 0),
(1896, 864, 5, 0),
(1897, 865, 8, 0),
(1898, 865, 1, 0),
(1899, 866, 8, 0),
(1900, 866, 2, 0),
(1901, 867, 8, 0),
(1902, 867, 3, 0),
(1903, 868, 8, 0),
(1904, 868, 4, 0),
(1905, 869, 8, 0),
(1906, 869, 5, 0),
(1907, 870, 7, 0),
(1908, 870, 1, 0),
(1909, 871, 7, 0),
(1910, 871, 2, 0),
(1911, 872, 7, 0),
(1912, 872, 3, 0),
(1913, 873, 7, 0),
(1914, 873, 4, 0),
(1915, 874, 7, 0),
(1916, 874, 5, 0),
(1917, 875, 9, 0),
(1918, 875, 1, 0),
(1919, 876, 9, 0),
(1920, 876, 2, 0),
(1921, 877, 9, 0),
(1922, 877, 3, 0),
(1923, 878, 9, 0),
(1924, 878, 4, 0),
(1925, 879, 9, 0),
(1926, 879, 5, 0),
(1927, 880, 28, 0),
(1928, 880, 1, 0),
(1929, 881, 28, 0),
(1930, 881, 2, 0),
(1931, 882, 28, 0),
(1932, 882, 3, 0),
(1933, 883, 28, 0),
(1934, 883, 4, 0),
(1935, 884, 28, 0),
(1936, 884, 5, 0),
(1937, 885, 29, 0),
(1938, 885, 1, 0),
(1939, 886, 29, 0),
(1940, 886, 2, 0),
(1941, 887, 29, 0),
(1942, 887, 3, 0),
(1943, 888, 29, 0),
(1944, 888, 4, 0),
(1945, 889, 29, 0),
(1946, 889, 5, 0),
(1947, 890, 26, 0),
(1948, 890, 1, 0),
(1949, 891, 26, 0),
(1950, 891, 2, 0),
(1951, 892, 26, 0),
(1952, 892, 3, 0),
(1953, 893, 26, 0),
(1954, 893, 4, 0),
(1955, 894, 26, 0),
(1956, 894, 5, 0),
(1957, 895, 6, 0),
(1958, 895, 3, 0),
(1959, 896, 6, 0),
(1960, 896, 4, 0),
(1961, 897, 6, 0),
(1962, 897, 5, 0),
(1963, 898, 7, 0),
(1964, 898, 3, 0),
(1965, 899, 7, 0),
(1966, 899, 4, 0),
(1967, 900, 7, 0),
(1968, 900, 5, 0),
(1969, 901, 30, 0),
(1970, 901, 3, 0),
(1971, 902, 30, 0),
(1972, 902, 4, 0),
(1973, 903, 30, 0),
(1974, 903, 5, 0),
(1975, 904, 6, 0),
(1976, 904, 10, 0),
(1977, 905, 6, 0),
(1978, 905, 11, 0),
(1979, 906, 6, 0),
(1980, 906, 12, 0),
(1981, 907, 6, 0),
(1982, 907, 1, 0),
(1983, 908, 6, 0),
(1984, 908, 2, 0),
(1985, 909, 6, 0),
(1986, 909, 3, 0),
(1987, 910, 6, 0),
(1988, 910, 4, 0),
(1989, 911, 6, 0),
(1990, 911, 5, 0),
(1991, 912, 7, 0),
(1992, 912, 10, 0),
(1993, 913, 7, 0),
(1994, 913, 11, 0),
(1995, 914, 7, 0),
(1996, 914, 12, 0),
(1997, 915, 7, 0),
(1998, 915, 1, 0),
(1999, 916, 7, 0),
(2000, 916, 2, 0),
(2001, 917, 7, 0),
(2002, 917, 3, 0),
(2003, 918, 7, 0),
(2004, 918, 4, 0),
(2005, 919, 7, 0),
(2006, 919, 5, 0),
(2007, 920, 31, 0),
(2008, 920, 10, 0),
(2009, 921, 31, 0),
(2010, 921, 11, 0),
(2011, 922, 31, 0),
(2012, 922, 12, 0),
(2013, 923, 31, 0),
(2014, 923, 1, 0),
(2015, 924, 31, 0),
(2016, 924, 2, 0),
(2017, 925, 31, 0),
(2018, 925, 3, 0),
(2019, 926, 31, 0),
(2020, 926, 4, 0),
(2021, 927, 31, 0),
(2022, 927, 5, 0),
(2023, 928, 6, 0),
(2024, 928, 1, 0),
(2025, 929, 6, 0),
(2026, 929, 2, 0),
(2027, 930, 6, 0),
(2028, 930, 3, 0),
(2029, 931, 6, 0),
(2030, 931, 4, 0),
(2031, 932, 6, 0),
(2032, 932, 5, 0),
(2033, 933, 8, 0),
(2034, 933, 1, 0),
(2035, 934, 8, 0),
(2036, 934, 2, 0),
(2037, 935, 8, 0),
(2038, 935, 3, 0),
(2039, 936, 8, 0),
(2040, 936, 4, 0),
(2041, 937, 8, 0),
(2042, 937, 5, 0),
(2043, 938, 7, 0),
(2044, 938, 1, 0),
(2045, 939, 7, 0),
(2046, 939, 2, 0),
(2047, 940, 7, 0),
(2048, 940, 3, 0),
(2049, 941, 7, 0),
(2050, 941, 4, 0),
(2051, 942, 7, 0),
(2052, 942, 5, 0),
(2053, 943, 9, 0),
(2054, 943, 1, 0),
(2055, 944, 9, 0),
(2056, 944, 2, 0),
(2057, 945, 9, 0),
(2058, 945, 3, 0),
(2059, 946, 9, 0),
(2060, 946, 4, 0),
(2061, 947, 9, 0),
(2062, 947, 5, 0),
(2063, 948, 6, 0),
(2064, 948, 2, 0),
(2065, 949, 6, 0),
(2066, 949, 3, 0),
(2067, 950, 6, 0),
(2068, 950, 4, 0),
(2069, 951, 6, 0),
(2070, 951, 5, 0),
(2071, 952, 7, 0),
(2072, 952, 2, 0),
(2073, 953, 7, 0),
(2074, 953, 3, 0),
(2075, 954, 7, 0),
(2076, 954, 4, 0),
(2077, 955, 7, 0),
(2078, 955, 5, 0),
(2079, 956, 8, 0),
(2080, 956, 2, 0),
(2081, 957, 8, 0),
(2082, 957, 3, 0),
(2083, 958, 8, 0),
(2084, 958, 4, 0),
(2085, 959, 8, 0),
(2086, 959, 5, 0),
(2087, 960, 9, 0),
(2088, 960, 2, 0),
(2089, 961, 9, 0),
(2090, 961, 3, 0),
(2091, 962, 9, 0),
(2092, 962, 4, 0),
(2093, 963, 9, 0),
(2094, 963, 5, 0),
(2095, 964, 24, 0),
(2096, 964, 10, 0),
(2097, 965, 24, 0),
(2098, 965, 11, 0),
(2099, 966, 24, 0),
(2100, 966, 12, 0),
(2101, 967, 24, 0),
(2102, 967, 1, 0),
(2103, 968, 24, 0),
(2104, 968, 2, 0),
(2105, 969, 24, 0),
(2106, 969, 3, 0),
(2107, 970, 24, 0),
(2108, 970, 4, 0),
(2109, 971, 24, 0),
(2110, 971, 5, 0),
(2111, 972, 25, 0),
(2112, 972, 10, 0),
(2113, 973, 25, 0),
(2114, 973, 11, 0),
(2115, 974, 25, 0),
(2116, 974, 12, 0),
(2117, 975, 25, 0),
(2118, 975, 1, 0),
(2119, 976, 25, 0),
(2120, 976, 2, 0),
(2121, 977, 25, 0),
(2122, 977, 3, 0),
(2123, 978, 25, 0),
(2124, 978, 4, 0),
(2125, 979, 25, 0),
(2126, 979, 5, 0),
(2127, 980, 6, 0),
(2128, 980, 1, 0),
(2129, 981, 6, 0),
(2130, 981, 2, 0),
(2131, 982, 6, 0),
(2132, 982, 3, 0),
(2133, 983, 6, 0),
(2134, 983, 4, 0),
(2135, 984, 6, 0),
(2136, 984, 5, 0),
(2137, 985, 7, 0),
(2138, 985, 1, 0),
(2139, 986, 7, 0),
(2140, 986, 2, 0),
(2141, 987, 7, 0),
(2142, 987, 3, 0),
(2143, 988, 7, 0),
(2144, 988, 4, 0),
(2145, 989, 7, 0),
(2146, 989, 5, 0),
(2147, 990, 8, 0),
(2148, 990, 1, 0),
(2149, 991, 8, 0),
(2150, 991, 2, 0),
(2151, 992, 8, 0),
(2152, 992, 3, 0),
(2153, 993, 8, 0),
(2154, 993, 4, 0),
(2155, 994, 8, 0),
(2156, 994, 5, 0),
(2157, 995, 9, 0),
(2158, 995, 1, 0),
(2159, 996, 9, 0),
(2160, 996, 2, 0),
(2161, 997, 9, 0),
(2162, 997, 3, 0),
(2163, 998, 9, 0),
(2164, 998, 4, 0),
(2165, 999, 9, 0),
(2166, 999, 5, 0),
(2167, 1000, 6, 0),
(2168, 1000, 1, 0),
(2169, 1001, 6, 0),
(2170, 1001, 2, 0),
(2171, 1002, 6, 0),
(2172, 1002, 3, 0),
(2173, 1003, 6, 0),
(2174, 1003, 4, 0),
(2175, 1004, 6, 0),
(2176, 1004, 5, 0),
(2177, 1005, 8, 0),
(2178, 1005, 1, 0),
(2179, 1006, 8, 0),
(2180, 1006, 2, 0),
(2181, 1007, 8, 0),
(2182, 1007, 3, 0),
(2183, 1008, 8, 0),
(2184, 1008, 4, 0),
(2185, 1009, 8, 0),
(2186, 1009, 5, 0),
(2187, 1010, 7, 0),
(2188, 1010, 1, 0),
(2189, 1011, 7, 0),
(2190, 1011, 2, 0),
(2191, 1012, 7, 0),
(2192, 1012, 3, 0),
(2193, 1013, 7, 0),
(2194, 1013, 4, 0),
(2195, 1014, 7, 0),
(2196, 1014, 5, 0),
(2197, 1015, 9, 0),
(2198, 1015, 1, 0),
(2199, 1016, 9, 0),
(2200, 1016, 2, 0),
(2201, 1017, 9, 0),
(2202, 1017, 3, 0),
(2203, 1018, 9, 0),
(2204, 1018, 4, 0),
(2205, 1019, 9, 0),
(2206, 1019, 5, 0),
(2247, 1040, 6, 0),
(2248, 1040, 1, 0),
(2249, 1041, 6, 0),
(2250, 1041, 2, 0),
(2251, 1042, 6, 0),
(2252, 1042, 3, 0),
(2253, 1043, 6, 0),
(2254, 1043, 4, 0),
(2255, 1044, 6, 0),
(2256, 1044, 5, 0),
(2257, 1045, 8, 0),
(2258, 1045, 1, 0),
(2259, 1046, 8, 0),
(2260, 1046, 2, 0),
(2261, 1047, 8, 0),
(2262, 1047, 3, 0),
(2263, 1048, 8, 0),
(2264, 1048, 4, 0),
(2265, 1049, 8, 0),
(2266, 1049, 5, 0),
(2267, 1050, 7, 0),
(2268, 1050, 1, 0),
(2269, 1051, 7, 0),
(2270, 1051, 2, 0),
(2271, 1052, 7, 0),
(2272, 1052, 3, 0),
(2273, 1053, 7, 0),
(2274, 1053, 4, 0),
(2275, 1054, 7, 0),
(2276, 1054, 5, 0),
(2277, 1055, 9, 0),
(2278, 1055, 1, 0),
(2279, 1056, 9, 0),
(2280, 1056, 2, 0),
(2281, 1057, 9, 0),
(2282, 1057, 3, 0),
(2283, 1058, 9, 0),
(2284, 1058, 4, 0),
(2285, 1059, 9, 0),
(2286, 1059, 5, 0),
(2287, 1060, 7, 0),
(2288, 1060, 2, 0),
(2289, 1061, 7, 0),
(2290, 1061, 3, 0),
(2291, 1062, 7, 0),
(2292, 1062, 4, 0),
(2293, 1063, 7, 0),
(2294, 1063, 5, 0),
(2295, 1064, 8, 0),
(2296, 1064, 2, 0),
(2297, 1065, 8, 0),
(2298, 1065, 3, 0),
(2299, 1066, 8, 0),
(2300, 1066, 4, 0),
(2301, 1067, 8, 0),
(2302, 1067, 5, 0),
(2303, 1068, 9, 0),
(2304, 1068, 2, 0),
(2305, 1069, 9, 0),
(2306, 1069, 3, 0),
(2307, 1070, 9, 0),
(2308, 1070, 4, 0),
(2309, 1071, 9, 0),
(2310, 1071, 5, 0),
(2311, 1072, 6, 0),
(2312, 1072, 1, 0),
(2313, 1073, 6, 0),
(2314, 1073, 2, 0),
(2315, 1074, 6, 0),
(2316, 1074, 3, 0),
(2317, 1075, 6, 0),
(2318, 1075, 4, 0),
(2319, 1076, 6, 0),
(2320, 1076, 5, 0),
(2321, 1077, 8, 0),
(2322, 1077, 1, 0),
(2323, 1078, 8, 0),
(2324, 1078, 2, 0),
(2325, 1079, 8, 0),
(2326, 1079, 3, 0),
(2327, 1080, 8, 0),
(2328, 1080, 4, 0),
(2329, 1081, 8, 0),
(2330, 1081, 5, 0),
(2331, 1082, 7, 0),
(2332, 1082, 1, 0),
(2333, 1083, 7, 0),
(2334, 1083, 2, 0),
(2335, 1084, 7, 0),
(2336, 1084, 3, 0),
(2337, 1085, 7, 0),
(2338, 1085, 4, 0),
(2339, 1086, 7, 0),
(2340, 1086, 5, 0),
(2341, 1087, 9, 0),
(2342, 1087, 1, 0),
(2343, 1088, 9, 0),
(2344, 1088, 2, 0),
(2345, 1089, 9, 0),
(2346, 1089, 3, 0),
(2347, 1090, 9, 0),
(2348, 1090, 4, 0),
(2349, 1091, 9, 0),
(2350, 1091, 5, 0),
(2351, 1092, 6, 0),
(2352, 1092, 1, 0),
(2353, 1093, 6, 0),
(2354, 1093, 2, 0),
(2355, 1094, 6, 0),
(2356, 1094, 3, 0),
(2357, 1095, 6, 0),
(2358, 1095, 4, 0),
(2359, 1096, 6, 0),
(2360, 1096, 5, 0),
(2361, 1097, 8, 0),
(2362, 1097, 1, 0),
(2363, 1098, 8, 0),
(2364, 1098, 2, 0),
(2365, 1099, 8, 0),
(2366, 1099, 3, 0),
(2367, 1100, 8, 0),
(2368, 1100, 4, 0),
(2369, 1101, 8, 0),
(2370, 1101, 5, 0),
(2371, 1102, 7, 0),
(2372, 1102, 1, 0),
(2373, 1103, 7, 0),
(2374, 1103, 2, 0),
(2375, 1104, 7, 0),
(2376, 1104, 3, 0),
(2377, 1105, 7, 0),
(2378, 1105, 4, 0),
(2379, 1106, 7, 0),
(2380, 1106, 5, 0),
(2381, 1107, 9, 0),
(2382, 1107, 1, 0),
(2383, 1108, 9, 0),
(2384, 1108, 2, 0),
(2385, 1109, 9, 0),
(2386, 1109, 3, 0),
(2387, 1110, 9, 0),
(2388, 1110, 4, 0),
(2389, 1111, 9, 0),
(2390, 1111, 5, 0),
(2391, 1112, 6, 0),
(2392, 1112, 10, 0),
(2393, 1113, 6, 0),
(2394, 1113, 11, 0),
(2395, 1114, 6, 0),
(2396, 1114, 12, 0),
(2397, 1115, 6, 0),
(2398, 1115, 1, 0),
(2399, 1116, 6, 0),
(2400, 1116, 2, 0),
(2401, 1117, 6, 0),
(2402, 1117, 3, 0),
(2403, 1118, 6, 0),
(2404, 1118, 4, 0),
(2405, 1119, 6, 0),
(2406, 1119, 5, 0),
(2407, 1120, 7, 0),
(2408, 1120, 10, 0),
(2409, 1121, 7, 0),
(2410, 1121, 11, 0),
(2411, 1122, 7, 0),
(2412, 1122, 12, 0),
(2413, 1123, 7, 0),
(2414, 1123, 1, 0),
(2415, 1124, 7, 0),
(2416, 1124, 2, 0),
(2417, 1125, 7, 0),
(2418, 1125, 3, 0),
(2419, 1126, 7, 0),
(2420, 1126, 4, 0),
(2421, 1127, 7, 0),
(2422, 1127, 5, 0),
(2423, 1128, 8, 0),
(2424, 1128, 10, 0),
(2425, 1129, 8, 0),
(2426, 1129, 11, 0),
(2427, 1130, 8, 0),
(2428, 1130, 12, 0),
(2429, 1131, 8, 0),
(2430, 1131, 1, 0),
(2431, 1132, 8, 0),
(2432, 1132, 2, 0),
(2433, 1133, 8, 0),
(2434, 1133, 3, 0),
(2435, 1134, 8, 0),
(2436, 1134, 4, 0),
(2437, 1135, 8, 0),
(2438, 1135, 5, 0),
(2439, 1136, 9, 0),
(2440, 1136, 10, 0),
(2441, 1137, 9, 0),
(2442, 1137, 11, 0),
(2443, 1138, 9, 0),
(2444, 1138, 12, 0),
(2445, 1139, 9, 0),
(2446, 1139, 1, 0),
(2447, 1140, 9, 0),
(2448, 1140, 2, 0),
(2449, 1141, 9, 0),
(2450, 1141, 3, 0),
(2451, 1142, 9, 0),
(2452, 1142, 4, 0),
(2453, 1143, 9, 0),
(2454, 1143, 5, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL COMMENT 'Tên đăng nhập',
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `gender` enum('Nam','Nữ','Khác') DEFAULT NULL COMMENT 'Giới tính',
  `birthdate` date DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL COMMENT 'Đường dẫn ảnh đại diện',
  `role` varchar(255) DEFAULT NULL,
  `is_locked` tinyint(1) DEFAULT 0,
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `email`, `password`, `phone`, `gender`, `birthdate`, `avatar`, `role`, `is_locked`, `created_at`) VALUES
(1, 'Chung Văn Đặt', 'dat', 'user22@gmail.com', '$2y$10$.fO7v2kh6iu.wTs6nH9XLeYrYnQnHq9CQOlfEX80cMYuJBSy4FFdi', '0987654321', 'Nam', NULL, 'public/uploads/avatars/avatar_1_1764057385.jpg', 'customer', 0, '2025-11-19 05:26:58'),
(2, 'Phạm Quân', NULL, 'phamquan@gmail.com', '1234', '0978914708', NULL, NULL, NULL, 'customer', 0, '2025-02-01 09:30:00'),
(3, 'Mai Trang', NULL, 'maitrang@gmail.com', '', '0965001234', NULL, NULL, NULL, 'customer', 0, '2025-03-12 10:00:00'),
(4, 'fhdfi', NULL, 'nguoidung@gmail.com', '$2y$10$aKlVB/yEzO80Jyf.Q6EXLen6E.QDWgWESHhwaHo/ZuI5HJMR/jFEe', NULL, NULL, NULL, NULL, 'customer', 0, '2025-11-19 05:52:38'),
(5, 'admin', NULL, 'vanquan2006k@gmail.com', '123456', '0978914708', NULL, NULL, NULL, 'admin', 0, NULL),
(6, 'Administrator', NULL, 'admin@example.com', '$2y$10$sDBoNg5V5OO/IYuf67zvLe4cax1GxMeXFMycmFnD5mE6hvhtNUKe2', NULL, NULL, NULL, NULL, 'admin', 0, '2025-11-23 18:44:10'),
(7, 'quan', NULL, 'van@gmail.com', '$2y$10$Q40xJSg16VKa6V7aPJLndOSzqDHPYmFRYeVMNKo/Xk06fR.OwayNa', NULL, NULL, NULL, NULL, 'customer', 0, '2025-11-23 14:31:25'),
(8, 'Phạm Văn Quân', NULL, 'vanq26800@gmail.com', '$2y$10$W1dNNdblqm62hUE5JWsQ.OfBcmLIrt/28qafPeldIEbSLpukfiHtG', '0978914708', 'Nam', NULL, 'public/uploads/avatars/avatar_8_1764235485.jpg', 'customer', 0, '2025-11-27 09:57:47');

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `shoe_id` int(11) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `wishlist`
--

INSERT INTO `wishlist` (`id`, `user_id`, `shoe_id`, `created_at`) VALUES
(2, 1, 4, '2025-11-28 09:42:38'),
(4, 1, 7, '2025-11-28 15:08:19'),
(43, 6, 7, '2025-12-04 17:26:36'),
(49, 8, 41, '2025-12-08 12:50:58'),
(52, 8, 5, '2025-12-09 11:12:05');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addresses`
--
ALTER TABLE `addresses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `addresses_ibfk_1` (`user_id`);

--
-- Indexes for table `carts`
--
ALTER TABLE `carts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `carts_ibfk_1` (`user_id`);

--
-- Indexes for table `cart_items`
--
ALTER TABLE `cart_items`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_cart_item` (`user_id`,`product_id`,`color`,`size`),
  ADD KEY `idx_user_cart` (`user_id`),
  ADD KEY `idx_product_cart` (`product_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coupons`
--
ALTER TABLE `coupons`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orders_ibfk_1` (`user_id`),
  ADD KEY `orders_ibfk_2` (`address_id`),
  ADD KEY `orders_ibfk_3` (`coupon_id`),
  ADD KEY `fk_orders_current_status` (`current_status_id`),
  ADD KEY `idx_shipping_method` (`shipping_method`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_order_items_variant_map` (`variant_map_id`),
  ADD KEY `order_items_ibfk_1` (`order_id`),
  ADD KEY `order_items_ibfk_2` (`shoe_variant_id`);

--
-- Indexes for table `order_statuses`
--
ALTER TABLE `order_statuses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `payments_ibfk_1` (`order_id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`),
  ADD KEY `reviews_ibfk_1` (`user_id`),
  ADD KEY `reviews_ibfk_2` (`shoe_id`);

--
-- Indexes for table `shipping_methods`
--
ALTER TABLE `shipping_methods`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shoes`
--
ALTER TABLE `shoes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `shoes_ibfk_2` (`category_id`);

--
-- Indexes for table `shoe_attributes`
--
ALTER TABLE `shoe_attributes`
  ADD PRIMARY KEY (`attribute_id`);

--
-- Indexes for table `shoe_attribute_values`
--
ALTER TABLE `shoe_attribute_values`
  ADD PRIMARY KEY (`value_id`),
  ADD KEY `fk_attribute_value_attribute` (`attribute_id`);

--
-- Indexes for table `shoe_images`
--
ALTER TABLE `shoe_images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_shoe_images_variant` (`shoe_variant_id`);

--
-- Indexes for table `shoe_variants`
--
ALTER TABLE `shoe_variants`
  ADD PRIMARY KEY (`id`),
  ADD KEY `shoe_variants_ibfk_1` (`shoe_id`);

--
-- Indexes for table `shoe_variant_attribute_map`
--
ALTER TABLE `shoe_variant_attribute_map`
  ADD PRIMARY KEY (`map_id`),
  ADD KEY `fk_variant_map_value` (`value_id`),
  ADD KEY `fk_variant_map_variant` (`variant_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_username` (`username`);

--
-- Indexes for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_shoe` (`user_id`,`shoe_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `shoe_id` (`shoe_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addresses`
--
ALTER TABLE `addresses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `cart_items`
--
ALTER TABLE `cart_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `coupons`
--
ALTER TABLE `coupons`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `order_statuses`
--
ALTER TABLE `order_statuses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `shipping_methods`
--
ALTER TABLE `shipping_methods`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `shoes`
--
ALTER TABLE `shoes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `shoe_attributes`
--
ALTER TABLE `shoe_attributes`
  MODIFY `attribute_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `shoe_attribute_values`
--
ALTER TABLE `shoe_attribute_values`
  MODIFY `value_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `shoe_variants`
--
ALTER TABLE `shoe_variants`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1144;

--
-- AUTO_INCREMENT for table `shoe_variant_attribute_map`
--
ALTER TABLE `shoe_variant_attribute_map`
  MODIFY `map_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2455;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `wishlist`
--
ALTER TABLE `wishlist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `addresses`
--
ALTER TABLE `addresses`
  ADD CONSTRAINT `addresses_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `carts`
--
ALTER TABLE `carts`
  ADD CONSTRAINT `carts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `cart_items`
--
ALTER TABLE `cart_items`
  ADD CONSTRAINT `fk_cart_product` FOREIGN KEY (`product_id`) REFERENCES `shoes` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_cart_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `fk_orders_current_status` FOREIGN KEY (`current_status_id`) REFERENCES `order_statuses` (`id`),
  ADD CONSTRAINT `fk_orders_shipping_method` FOREIGN KEY (`shipping_method`) REFERENCES `shipping_methods` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `orders_ibfk_3` FOREIGN KEY (`coupon_id`) REFERENCES `coupons` (`id`);

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `fk_order_items_variant_map` FOREIGN KEY (`variant_map_id`) REFERENCES `shoe_variant_attribute_map` (`map_id`),
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`),
  ADD CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`shoe_variant_id`) REFERENCES `shoe_variants` (`id`);

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`);

--
-- Constraints for table `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `reviews_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `reviews_ibfk_2` FOREIGN KEY (`shoe_id`) REFERENCES `shoes` (`id`);

--
-- Constraints for table `shoes`
--
ALTER TABLE `shoes`
  ADD CONSTRAINT `shoes_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`);

--
-- Constraints for table `shoe_attribute_values`
--
ALTER TABLE `shoe_attribute_values`
  ADD CONSTRAINT `fk_attribute_value_attribute` FOREIGN KEY (`attribute_id`) REFERENCES `shoe_attributes` (`attribute_id`);

--
-- Constraints for table `shoe_images`
--
ALTER TABLE `shoe_images`
  ADD CONSTRAINT `fk_shoe_images_variant` FOREIGN KEY (`shoe_variant_id`) REFERENCES `shoe_variants` (`id`);

--
-- Constraints for table `shoe_variants`
--
ALTER TABLE `shoe_variants`
  ADD CONSTRAINT `shoe_variants_ibfk_1` FOREIGN KEY (`shoe_id`) REFERENCES `shoes` (`id`);

--
-- Constraints for table `shoe_variant_attribute_map`
--
ALTER TABLE `shoe_variant_attribute_map`
  ADD CONSTRAINT `fk_variant_map_value` FOREIGN KEY (`value_id`) REFERENCES `shoe_attribute_values` (`value_id`),
  ADD CONSTRAINT `fk_variant_map_variant` FOREIGN KEY (`variant_id`) REFERENCES `shoe_variants` (`id`);

--
-- Constraints for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD CONSTRAINT `fk_wishlist_shoe` FOREIGN KEY (`shoe_id`) REFERENCES `shoes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_wishlist_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
