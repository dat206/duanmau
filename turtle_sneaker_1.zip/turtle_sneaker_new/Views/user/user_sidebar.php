<?php
$currentPage = $_GET['action'] ?? 'profile';
?>
<div class="user-sidebar">
    <div class="user-sidebar-header">
        <h3>Tài khoản của tôi</h3>
    </div>
    <nav class="user-sidebar-nav">
        <ul>
            <li class="<?php echo ($currentPage === 'profile' || $currentPage === 'edit') ? 'active' : ''; ?>">
                <a href="index.php?controller=user&action=profile">
                    <i class="fas fa-user"></i>
                    <span>Hồ sơ của tôi</span>
                </a>
            </li>
            <li class="<?php echo $currentPage === 'orders' ? 'active' : ''; ?>">
                <a href="index.php?controller=user&action=orders">
                    <i class="fas fa-shopping-bag"></i>
                    <span>Lịch sử đơn hàng</span>
                </a>
            </li>
        </ul>
    </nav>
</div>
