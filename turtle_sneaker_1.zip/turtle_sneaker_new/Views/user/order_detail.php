<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chi tiết đơn hàng - Turtle Sneaker</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<?= asset('css/style.css?v=' . time()) ?>">
    <link rel="stylesheet" href="<?= asset('css/user.css?v=' . time()) ?>">
    <link rel="stylesheet" href="<?= asset('css/order-detail.css?v=' . time()) ?>">
</head>
<body>
    <?php include __DIR__ . '/../layouts/header.php'; ?>

    <div class="profile-container-new">
        <div class="profile-header-new">
            <h1>Chi tiết đơn hàng #<?php echo $order['id']; ?></h1>
            <a href="<?= route('orders') ?>" class="btn-back">
                <i class="fas fa-arrow-left"></i> Quay lại
            </a>
        </div>

        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success">
                <?php echo htmlspecialchars($_SESSION['success_message']); unset($_SESSION['success_message']); ?>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['error_messages'])): ?>
            <div class="alert alert-error">
                <?php foreach ($_SESSION['error_messages'] as $error) {
                    echo '<p>' . htmlspecialchars($error) . '</p>';
                }
                unset($_SESSION['error_messages']); ?>
            </div>
        <?php endif; ?>

        <div class="user-profile-layout">
            <?php include __DIR__ . '/user_sidebar.php'; ?>
            <div class="order-detail-content">
                <div class="order-status-card">
                    <div class="status-header">
                        <h3>Trạng thái đơn hàng</h3>
                        <span class="status-badge status-<?php echo $order['current_status_id']; ?>">
                            <?php echo htmlspecialchars($order['status_name']); ?>
                        </span>
                    </div>
                    <div class="status-timeline">
                        <?php if ($order['current_status_id'] == 8): ?>
                            <div class="timeline-item completed">
                                <div class="timeline-icon"><i class="fas fa-check"></i></div>
                                <div class="timeline-content">
                                    <strong>Đơn hàng đã đặt</strong>
                                    <p><?php echo date('d/m/Y H:i', strtotime($order['created_at'])); ?></p>
                                </div>
                            </div>
                            <div class="timeline-item completed cancelled">
                                <div class="timeline-icon"><i class="fas fa-times"></i></div>
                                <div class="timeline-content">
                                    <strong>Đã hủy</strong>
                                    <p>Đơn hàng đã bị hủy</p>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="timeline-item <?php echo $order['current_status_id'] >= 1 ? 'completed' : ''; ?>">
                                <div class="timeline-icon"><i class="fas fa-check"></i></div>
                                <div class="timeline-content">
                                    <strong>Chờ xử lí</strong>
                                    <?php if ($order['current_status_id'] == 1): ?>
                                        <p><?php echo date('d/m/Y H:i', strtotime($order['created_at'])); ?></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="timeline-item <?php echo $order['current_status_id'] >= 2 ? 'completed' : ''; ?>">
                                <div class="timeline-icon"><i class="fas fa-clipboard-check"></i></div>
                                <div class="timeline-content">
                                    <strong>Đã xử lí</strong>
                                    <?php if ($order['current_status_id'] == 2): ?>
                                        <p>Đơn hàng đã được xác nhận</p>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="timeline-item <?php echo $order['current_status_id'] >= 3 ? 'completed' : ''; ?>">
                                <div class="timeline-icon"><i class="fas fa-box"></i></div>
                                <div class="timeline-content">
                                    <strong>Đang chuẩn bị hàng</strong>
                                    <?php if ($order['current_status_id'] == 3): ?>
                                        <p>Đang đóng gói sản phẩm</p>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="timeline-item <?php echo $order['current_status_id'] >= 4 ? 'completed' : ''; ?>">
                                <div class="timeline-icon"><i class="fas fa-people-carry"></i></div>
                                <div class="timeline-content">
                                    <strong>Đã giao cho đơn vị vận chuyển</strong>
                                    <?php if ($order['current_status_id'] == 4): ?>
                                        <p>Đã bàn giao cho shipper</p>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="timeline-item <?php echo $order['current_status_id'] >= 5 ? 'completed' : ''; ?>">
                                <div class="timeline-icon"><i class="fas fa-truck"></i></div>
                                <div class="timeline-content">
                                    <strong>Đang vận chuyển</strong>
                                    <?php if ($order['current_status_id'] == 5): ?>
                                        <p>Đơn hàng đang trên đường giao đến bạn</p>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="timeline-item <?php echo $order['current_status_id'] >= 6 ? 'completed' : ''; ?>">
                                <div class="timeline-icon"><i class="fas fa-shipping-fast"></i></div>
                                <div class="timeline-content">
                                    <strong>Đã giao</strong>
                                    <?php if ($order['current_status_id'] == 6): ?>
                                        <p>Vui lòng xác nhận đã nhận hàng</p>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="timeline-item <?php echo $order['current_status_id'] >= 7 ? 'completed' : ''; ?>">
                                <div class="timeline-icon"><i class="fas fa-check-circle"></i></div>
                                <div class="timeline-content">
                                    <strong>Đã hoàn thành</strong>
                                    <?php if ($order['current_status_id'] == 7): ?>
                                        <p>Bạn đã xác nhận nhận hàng</p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                    <?php if ($order['current_status_id'] <= 3): ?>
                        <form action="<?= route('order.cancel', ['id' => $order['id']]) ?>" method="POST" class="confirm-form" onsubmit="return confirm('Bạn có chắc chắn muốn hủy đơn hàng này không?');">
                            <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                            <button type="submit" class="btn-cancel-detail">
                                <i class="fas fa-times-circle"></i> Hủy đơn hàng
                            </button>
                        </form><br>
                    <?php endif; ?>
                </div>
                <div class="order-info-card">
                    <h3>Thông tin đơn hàng</h3>
                    <div class="info-row">
                        <span class="label">Mã đơn hàng:</span>
                        <span class="value">#AYENLEA<?php echo str_pad($order['id'], 4, '0', STR_PAD_LEFT); ?></span>
                    </div>
                    <div class="info-row">
                        <span class="label">Ngày đặt:</span>
                        <span class="value"><?php echo date('d/m/Y H:i', strtotime($order['created_at'])); ?></span>
                    </div>
                    <div class="info-row">
                        <span class="label">Tổng tiền:</span>
                        <span class="value total"><?php echo number_format($order['total_amount'], 0, ',', '.'); ?>đ</span>
                    </div>
                </div>
                <div class="order-info-card">
                    <h3>Địa chỉ nhận hàng</h3>
                    <div class="address-box">
                        <p><strong><?php echo htmlspecialchars($order['address_name']); ?></strong></p>
                        <p><?php echo htmlspecialchars($order['address_phone']); ?></p>
                        <p><?php echo htmlspecialchars($order['address_line']); ?></p>
                        <?php 
                        $city = $order['city'] ?? '';
                        $district = $order['district'] ?? '';
                        $ward = $order['ward'] ?? '';
                        $hasErrors = (strpos($city, '<b>Warning</b>') !== false) || 
                                     (strpos($district, '<b>Warning</b>') !== false) || 
                                     (strpos($ward, '<b>Warning</b>') !== false);
                        if (!$hasErrors && !empty(trim($city . $district . $ward))): 
                        ?>
                            <p><?php echo htmlspecialchars(trim($ward . ', ' . $district . ', ' . $city), ENT_QUOTES, 'UTF-8'); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="order-info-card">
                    <h3>Sản phẩm</h3>
                    <div class="items-list">
                        <?php foreach ($order['items'] as $item): ?>
                            <div class="item-row">
                                <div class="item-image">
                                    <?php if (!empty($item['main_image'])): ?>
                                        <img src="<?= url($item['main_image']) ?>" alt="Product">
                                    <?php else: ?>
                                        <div class="no-image"><i class="fas fa-image"></i></div>
                                    <?php endif; ?>
                                </div>
                                <div class="item-info">
                                    <h4><?php echo htmlspecialchars($item['product_name']); ?></h4>
                                    <p class="item-sku">SKU: <?php echo htmlspecialchars($item['sku']); ?></p>
                                    <p class="item-quantity">Số lượng: <?php echo $item['quantity']; ?></p>
                                </div>
                                <div class="item-price">
                                    <p class="price"><?php echo number_format($item['price_each'], 0, ',', '.'); ?>đ</p>
                                    <p class="subtotal">Tổng: <?php echo number_format($item['price_each'] * $item['quantity'], 0, ',', '.'); ?>đ</p>
                                    
                                    <?php ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <div class="order-summary">
                        <div class="summary-row">
                            <span>Tạm tính:</span>
                            <span><?php echo number_format($order['subtotal_price'], 0, ',', '.'); ?>đ</span>
                        </div>
                        <?php if ($order['product_discount'] > 0): ?>
                        <div class="summary-row discount-row">
                            <span>
                                Giảm giá sản phẩm:
                                <?php if ($order['coupon_code']): ?>
                                    <small>(<?php echo htmlspecialchars($order['coupon_code']); ?>)</small>
                                <?php endif; ?>
                            </span>
                            <span class="discount-amount">-<?php echo number_format($order['product_discount'], 0, ',', '.'); ?>đ</span>
                        </div>
                        <?php endif; ?>
                        <div class="summary-row">
                            <span>Phí vận chuyển:</span>
                            <span><?php echo number_format($order['shipping_fee'], 0, ',', '.'); ?>đ</span>
                        </div>
                        <?php if ($order['shipping_discount'] > 0): ?>
                        <div class="summary-row discount-row">
                            <span>
                                Giảm phí vận chuyển:
                                <?php if ($order['coupon_code']): ?>
                                    <small>(<?php echo htmlspecialchars($order['coupon_code']); ?>)</small>
                                <?php endif; ?>
                            </span>
                            <span class="discount-amount">-<?php echo number_format($order['shipping_discount'], 0, ',', '.'); ?>đ</span>
                        </div>
                        <?php endif; ?>
                        <div class="summary-row total-row">
                            <span>Tổng cộng:</span>
                            <span><?php echo number_format($order['total_amount'], 0, ',', '.'); ?>đ</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include __DIR__ . '/../layouts/footer.php'; ?>

    <div id="reviewModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeReviewModal()">&times;</span>
            <h3>Đánh giá sản phẩm</h3>
            <p id="modalProductName" style="margin-bottom: 15px; color: #666;"></p>
            
            <form action="<?= route('review.add') ?>" method="POST">
                <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                <input type="hidden" name="product_id" id="modalProductId">
                
                <div class="form-group" style="margin-bottom: 15px;">
                    <label>Đánh giá:</label>
                    <div class="rating-container">
                        <div class="rating-input">
                            <?php for($i=5; $i>=1; $i--): ?>
                                <input type="radio" id="star<?= $i ?>" name="rating" value="<?= $i ?>" required>
                                <label for="star<?= $i ?>" title="<?= $i ?> sao">★</label>
                            <?php endfor; ?>
                        </div>
                    </div>
                </div>
                
                <div class="form-group" style="margin-bottom: 15px;">
                    <label for="comment">Nội dung:</label>
                    <textarea name="comment" id="comment" rows="4" class="form-control" style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px;" required placeholder="Chia sẻ cảm nhận của bạn về sản phẩm..."></textarea>
                </div>
                
                <button type="submit" class="btn-submit-review">Gửi đánh giá</button>
            </form>
        </div>
    </div>

    <script src="<?= asset('js/user-order-detail.js?v=' . time()) ?>"></script>
</body>
</html>


