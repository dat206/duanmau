<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lịch Sử Đơn Hàng - Turtle Sneaker</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="public/css/style.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="public/css/user.css?v=<?php echo time(); ?>">
</head>
<body>
    <?php include __DIR__ . '/../layouts/header.php'; ?>

    <?php
    require_once __DIR__ . '/../components/breadcrumb.php';
    $breadcrumbItems = [
        ['label' => 'Lịch sử đơn hàng']
    ];
    renderBreadcrumb($breadcrumbItems);
    ?>
    <div class="profile-container-new">
        <div class="profile-header-new">
            <h1>Lịch sử đơn hàng</h1>
            <a href="index.php?controller=auth&action=logout" class="btn-logout">Đăng xuất</a>
        </div>
        <div class="user-profile-layout">
            <?php include __DIR__ . '/user_sidebar.php'; ?>
            <div class="orders-content">
                <?php if (empty($orders)): ?>
                    <div class="no-orders">
                        <i class="fas fa-shopping-bag"></i>
                        <h3>Chưa có đơn hàng nào</h3>
                        <p>Bạn chưa có đơn hàng nào. Hãy bắt đầu mua sắm ngay!</p>
                        <a href="index.php?controller=product" class="btn-primary">Mua sắm ngay</a>
                    </div>
                <?php else: ?>
                    <div class="orders-list">
                        <?php foreach ($orders as $order): ?>
                            <div class="order-card" data-order-id="<?php echo $order['id']; ?>">
                                <div class="order-header">
                                    <div class="order-info">
                                        <span class="order-id">Đơn hàng #<?php echo htmlspecialchars($order['id']); ?></span>
                                        <span class="order-date"><?php echo date('d/m/Y H:i', strtotime($order['created_at'])); ?></span>
                                    </div>
                                    <div class="order-status-group">
                                        <div class="order-status status-<?php echo $order['status_id']; ?>">
                                            <?php echo htmlspecialchars($order['status_name']); ?>
                                        </div>
                                        <?php
                                            $paymentMethod = $order['payment_method'] ?? 'cod';
                                            $paymentStatus = $order['payment_status'] ?? null;
                                        ?>
                                        <div class="payment-status-badge">
                                            <?php if ($paymentStatus === 'Paid'): ?>
                                                <span class="badge-paid"><i class="fas fa-check-circle"></i> Đã thanh toán</span>
                                            <?php else: ?>
                                                <?php if ($paymentMethod === 'vnpay'): ?>
                                                    <span class="badge-unpaid"><i class="fas fa-credit-card"></i> Chưa thanh toán (VNPAY)</span>
                                                <?php else: ?>
                                                    <span class="badge-unpaid"><i class="fas fa-money-bill-wave"></i> Chưa thanh toán (COD)</span>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="order-body">
                                    <div class="order-products-grid">
                                        <?php if (isset($order['items']) && !empty($order['items'])): ?>
                                            <?php foreach ($order['items'] as $item): ?>
                                                <div class="order-product-item">
                                                    <img src="<?php echo htmlspecialchars($item['main_image'] ?? 'https://placehold.co/60x60?text=No+Image'); ?>" alt="<?php echo htmlspecialchars($item['product_name']); ?>">
                                                    <div class="order-product-info">
                                                        <div class="product-name"><?php echo htmlspecialchars($item['product_name']); ?></div>
                                                        <div class="product-variants">
                                                            <?php if (!empty($item['size_name'])): ?>
                                                                <span class="variant-badge">Size: <?php echo htmlspecialchars($item['size_name']); ?></span>
                                                            <?php endif; ?>
                                                            <?php if (!empty($item['color_name'])): ?>
                                                                <span class="variant-badge">Màu: <?php echo htmlspecialchars($item['color_name']); ?></span>
                                                            <?php endif; ?>
                                                        </div>
                                                        <div class="product-quantity">x<?php echo $item['quantity']; ?></div>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </div>
                                    <div class="order-total">
                                        <span class="total-label">Tổng tiền:</span>
                                        <span class="total-amount"><?php echo number_format($order['total_amount'], 0, ',', '.'); ?>đ</span>
                                    </div>
                                </div>
                                <div class="order-actions">
                                    <?php if ($order['status_id'] <= 3): ?>
                                        <form action="<?= route('order.cancel', ['id' => $order['id']]) ?>" method="POST" style="display: inline-block;" onsubmit="return confirm('Bạn có chắc chắn muốn hủy đơn hàng này không?');">
                                            <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                                            <button type="submit" class="btn-cancel">
                                                <i class="fas fa-times-circle"></i> Hủy đơn hàng
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                    
                                    <?php if ($order['status_id'] == 6): ?>
                                        <button class="btn-confirm" onclick="confirmReceived(<?php echo $order['id']; ?>, this)">
                                            <i class="fas fa-check-circle"></i> Đã nhận hàng
                                        </button>
                                    <?php endif; ?>

                                    <?php if (($order['payment_method'] ?? 'cod') === 'vnpay' && ($order['payment_status'] ?? null) !== 'Paid' && $order['status_id'] != 8): ?>
                                        <a href="<?= route('order.retry-payment', ['id' => $order['id']]) ?>" 
                                           class="btn-confirm btn-retry-payment">
                                            <i class="fas fa-redo"></i> Tiếp tục thanh toán
                                        </a>
                                    <?php endif; ?>
                                    
                                    <?php if ($order['status_id'] == 7): ?>
                                        <?php 
                                        $unreviewedItems = [];
                                        if (isset($order['items'])) {
                                            foreach ($order['items'] as $item) {
                                                if (isset($item['has_reviewed']) && !$item['has_reviewed']) {
                                                    $unreviewedItems[] = $item;
                                                }
                                            }
                                        }
                                        ?>
                                        <?php if (!empty($unreviewedItems)): ?>
                                            <button class="btn-review" onclick="showReviewOptions(<?php echo $order['id']; ?>)">
                                                <i class="fas fa-star"></i> Đánh giá (<?php echo count($unreviewedItems); ?>)
                                            </button>
                                        <?php else: ?>
                                            <span class="btn-reviewed">
                                                <i class="fas fa-check-circle"></i> Đã đánh giá
                                            </span>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    
                                    <a href="<?= route('order.detail', ['id' => $order['id']]) ?>" class="btn-view-detail">
                                        <i class="fas fa-eye"></i> Xem chi tiết
                                    </a>
                                </div>
                                
                                <?php if ($order['status_id'] == 7 && isset($order['items'])): ?>
                                    <div class="review-items-data" data-order-id="<?php echo $order['id']; ?>" style="display: none;">
                                        <?php echo htmlspecialchars(json_encode($order['items']), ENT_QUOTES, 'UTF-8'); ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <?php if ($totalPages > 1): ?>
                        <div class="pagination-container">
                            <div class="pagination">
                                <?php if ($page > 1): ?>
                                    <a href="?controller=user&action=orders&page=<?php echo $page - 1; ?>" class="pagination-btn">
                                        <i class="fas fa-chevron-left"></i> Trước
                                    </a>
                                <?php endif; ?>
                                
                                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                                    <?php if ($i == $page): ?>
                                        <span class="pagination-number active"><?php echo $i; ?></span>
                                    <?php else: ?>
                                        <a href="?controller=user&action=orders&page=<?php echo $i; ?>" class="pagination-number"><?php echo $i; ?></a>
                                    <?php endif; ?>
                                <?php endfor; ?>
                                
                                <?php if ($page < $totalPages): ?>
                                    <a href="?controller=user&action=orders&page=<?php echo $page + 1; ?>" class="pagination-btn">
                                        Sau <i class="fas fa-chevron-right"></i>
                                    </a>
                                <?php endif; ?>
                            </div>
                            <div class="pagination-info">
                                Trang <?php echo $page; ?> / <?php echo $totalPages; ?> (<?php echo $totalOrders; ?> đơn hàng)
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <?php include __DIR__ . '/../layouts/footer.php'; ?>
    
    <script>
        const BASE_URL = '<?= url('') ?>';
    </script>
    <script src="public/js/user-orders.js?v=<?php echo time(); ?>"></script>
    

    
    <div id="productSelectionModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeProductSelection()">&times;</span>
            <h3>Chọn sản phẩm để đánh giá</h3>
            <div id="productSelectionList" class="product-selection-list"></div>
        </div>
    </div>
    <div id="reviewModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeReviewModal()">&times;</span>
            <h3>Đánh giá sản phẩm</h3>
            <p id="modalProductName" style="margin-bottom: 15px; color: #666;"></p>
            
            <form action="<?= route('review.add') ?>" method="POST">
                <input type="hidden" name="order_id" id="modalOrderId">
                <input type="hidden" name="product_id" id="modalProductId">
                
                <div class="form-group" style="margin-bottom: 15px;">
                    <label>Đánh giá:</label>
                    <div class="rating-container">
                        <div class="rating-input">
                            <?php for($i=5; $i>=1; $i--): ?>
                                <input type="radio" id="star<?= $i ?>" name="rating" value="<?= $i ?>" required>
                                <label for="star<?= $i ?>" title="<?= $i ?> sao">★</label>
                            <?php endfor; ?>
                        </div>
                    </div>
                </div>
                
                <div class="form-group" style="margin-bottom: 15px;">
                    <label for="comment">Nội dung:</label>
                    <textarea name="comment" id="comment" rows="4" class="form-control" style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px;" required placeholder="Chia sẻ cảm nhận của bạn về sản phẩm..."></textarea>
                </div>
                
                <button type="submit" class="btn-submit-review">Gửi đánh giá</button>
            </form>
        </div>
    </div>
    
    <script>
    function confirmReceived(orderId, button) {
        if (!confirm('Bạn đã nhận được hàng?')) {
            return;
        }
        button.disabled = true;
        button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Đang xử lý...';
        fetch(BASE_URL + `don-hang/${orderId}/da-nhan`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'order_id=' + orderId
        })
        .then(response => response.text())
        .then(data => {
            location.reload();
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Có lỗi xảy ra. Vui lòng thử lại.');
            button.disabled = false;
            button.innerHTML = '<i class="fas fa-check-circle"></i> Đã nhận hàng';
        });
    }
    
    function showReviewOptions(orderId) {
        const dataDiv = document.querySelector(`.review-items-data[data-order-id="${orderId}"]`);
        if (!dataDiv) {
            console.error('Review data not found for order:', orderId);
            return;
        }
        
        try {
            const items = JSON.parse(dataDiv.textContent);
            console.log('Order items:', items);
            
            const unreviewedItems = items.filter(item => !item.has_reviewed || item.has_reviewed == 0);
            console.log('Unreviewed items:', unreviewedItems);
            
            if (unreviewedItems.length === 0) {
                alert('Bạn đã đánh giá tất cả sản phẩm trong đơn hàng này!');
                return;
            }
            
            if (unreviewedItems.length === 1) {
                openReviewModal(unreviewedItems[0].product_id, unreviewedItems[0].product_name, orderId);
            } else {
                showProductSelection(unreviewedItems, orderId);
            }
        } catch (error) {
            console.error('Error parsing review data:', error);
            alert('Có lỗi xảy ra khi tải dữ liệu đánh giá.');
        }
    }
    
    function showProductSelection(items, orderId) {
        const modal = document.getElementById('productSelectionModal');
        const list = document.getElementById('productSelectionList');
        
        list.innerHTML = '';
        items.forEach(item => {
            const div = document.createElement('div');
            div.className = 'product-selection-item';
            div.innerHTML = `
                <img src="${item.main_image}" alt="${item.product_name}">
                <div class="product-selection-info">
                    <h4>${item.product_name}</h4>
                    <p>SKU: ${item.sku}</p>
                </div>
                <button onclick="openReviewModal(${item.product_id}, '${item.product_name.replace(/'/g, "\\'")}', ${orderId}); closeProductSelection();" class="btn-review-sm">
                    Đánh giá
                </button>
            `;
            list.appendChild(div);
        });
        modal.style.display = 'block';
    }
    
    function closeProductSelection() {
        document.getElementById('productSelectionModal').style.display = 'none';
    }
    
    function openReviewModal(productId, productName, orderId) {
        document.getElementById('modalProductId').value = productId;
        document.getElementById('modalOrderId').value = orderId;
        document.getElementById('modalProductName').textContent = productName;
        document.getElementById('reviewModal').style.display = "block";
    }

    function closeReviewModal() {
        document.getElementById('reviewModal').style.display = "none";
    }

    window.onclick = function(event) {
        const reviewModal = document.getElementById('reviewModal');
        const selectionModal = document.getElementById('productSelectionModal');
        
        if (event.target == reviewModal) {
            reviewModal.style.display = "none";
        }
        if (event.target == selectionModal) {
            selectionModal.style.display = "none";
        }
    }
    </script>
    
    <link rel="stylesheet" href="public/css/user-orders.css?v=<?php echo time(); ?>">
</body>
</html>
