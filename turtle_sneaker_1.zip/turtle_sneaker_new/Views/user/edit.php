<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chỉnh Sửa Thông Tin - Turtle Sneaker</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="public/css/style.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="public/css/user.css?v=<?php echo time(); ?>">
</head>
<body>
    <?php include __DIR__ . '/../layouts/header.php'; ?>

    <div class="profile-container">
        <div class="profile-header">
            <h1>Chỉnh Sửa Thông Tin Cá Nhân</h1>
        </div>
        <div class="user-profile-layout">
            <?php include __DIR__ . '/user_sidebar.php'; ?>
            <div class="profile-content">
                <form action="index.php?controller=user&action=update" method="POST" enctype="multipart/form-data" class="profile-edit-form">
                    <div class="form-section avatar-upload-section">
                        <label>Ảnh đại diện</label>
                        <div class="avatar-upload-wrapper">
                            <div class="avatar-preview">
                                <?php if (!empty($user['avatar'])): ?>
                                    <img src="<?php echo htmlspecialchars($user['avatar']); ?>" alt="Avatar" id="avatar-preview-img">
                                <?php else: ?>
                                    <div class="default-avatar-preview" id="default-avatar-preview">
                                        <span><?php echo strtoupper(substr($user['name'], 0, 1)); ?></span>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="avatar-upload-controls">
                                <input type="file" name="avatar" id="avatar-input" accept="image/*" style="display: none;">
                                <button type="button" class="btn btn-secondary" onclick="document.getElementById('avatar-input').click();">
                                    Chọn ảnh
                                </button>
                                <p class="help-text">JPG, PNG, GIF hoặc WEBP. Tối đa 5MB.</p>
                            </div>
                        </div>
                    </div>

                    <div class="form-section">
                        <h3>Thông tin cá nhân</h3>
                        <div class="form-group">
                            <label for="name">Tên đầy đủ <span class="required">*</span></label>
                            <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($user['name']); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="username">Tên đăng nhập</label>
                            <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($user['username'] ?? ''); ?>" placeholder="Nhập tên đăng nhập">
                            <p class="help-text">Tên đăng nhập phải là duy nhất</p>
                        </div>
                        <div class="form-group">
                            <label for="email">Email <span class="required">*</span></label>
                            <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="phone">Số điện thoại</label>
                            <input type="tel" id="phone" name="phone" value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>" placeholder="Nhập số điện thoại">
                        </div>
                        <div class="form-group">
                            <label for="gender">Giới tính</label>
                            <select id="gender" name="gender">
                                <option value="">-- Chọn giới tính --</option>
                                <option value="Nam" <?php echo (isset($user['gender']) && $user['gender'] === 'Nam') ? 'selected' : ''; ?>>Nam</option>
                                <option value="Nữ" <?php echo (isset($user['gender']) && $user['gender'] === 'Nữ') ? 'selected' : ''; ?>>Nữ</option>
                                <option value="Khác" <?php echo (isset($user['gender']) && $user['gender'] === 'Khác') ? 'selected' : ''; ?>>Khác</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-section">
                        <h3>Địa chỉ</h3>
                        <p class="info-text">Để quản lý địa chỉ của bạn, vui lòng thực hiện khi đặt hàng hoặc trong giỏ hàng.</p>
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">Lưu thay đổi</button>
                        <a href="index.php?controller=user&action=profile" class="btn btn-secondary">Hủy</a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php include __DIR__ . '/../layouts/footer.php'; ?>

    <script src="public/js/user-edit.js?v=<?php echo time(); ?>"></script>
    <script style="display:none">
        /*
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const previewImg = document.getElementById('avatar-preview-img');
                    const defaultAvatar = document.getElementById('default-avatar-preview');
                    if (previewImg) {
                        previewImg.src = e.target.result;
                    } else if (defaultAvatar) {
                        defaultAvatar.outerHTML = '<img src="' + e.target.result + '" alt="Avatar" id="avatar-preview-img">';
                    }
                };
                reader.readAsDataURL(file);
            }
        });

        document.querySelector('.profile-edit-form').addEventListener('submit', function(e) {
            const email = document.getElementById('email').value;
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

            if (!emailRegex.test(email)) {
                e.preventDefault();
                alert('Vui lòng nhập email hợp lệ.');
                return false;
            }
        */
    </script>
</body>

</html>