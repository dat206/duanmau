<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hồ Sơ Của Tôi - Turtle Sneaker</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="public/css/style.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="public/css/user.css?v=<?php echo time(); ?>">
</head>
<body>
    <?php include __DIR__ . '/../layouts/header.php'; ?>

    <?php
    require_once __DIR__ . '/../components/breadcrumb.php';
    $breadcrumbItems = [
        ['label' => 'Hồ sơ của tôi']
    ];
    renderBreadcrumb($breadcrumbItems);
    ?>

    <div class="profile-container-new">
        <div class="profile-header-new">
            <h1>Hồ sơ của tôi</h1>
            <a href="index.php?controller=auth&action=logout" class="btn-logout">Đăng xuất</a>
        </div>

        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success">
                <?php 
                echo htmlspecialchars($_SESSION['success_message']); 
                unset($_SESSION['success_message']);
                ?>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['error_messages'])): ?>
            <div class="alert alert-error">
                <?php 
                foreach ($_SESSION['error_messages'] as $error) {
                    echo '<p>' . htmlspecialchars($error) . '</p>';
                }
                unset($_SESSION['error_messages']);
                ?>
            </div>
        <?php endif; ?>

        <div class="user-profile-layout">
            <?php include __DIR__ . '/user_sidebar.php'; ?>
            <div class="profile-content-new">
                <div class="profile-form-column">
                    <form action="index.php?controller=user&action=update" method="POST" enctype="multipart/form-data" class="profile-edit-form-new">
                        
                        <div class="form-group-new">
                            <label for="name">Họ Và Tên:</label>
                            <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($user['name']); ?>" required>
                        </div>

                        <div class="form-group-new">
                            <label for="phone">Số điện thoại:</label>
                            <input type="tel" id="phone" name="phone" value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>" placeholder="Nhập số điện thoại">
                        </div>

                        <div class="form-group-new">
                            <label for="email">Email:</label>
                            <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                        </div>
                        <div class="form-group-new">
                            <label for="birthdate">Ngày sinh:</label>
                            <input type="date" id="birthdate" name="birthdate" value="">
                        </div>

                        <div class="form-group-new">
                            <label>Giới tính:</label>
                            <div class="gender-options">
                                <label class="radio-label">
                                    <input type="radio" name="gender" value="Nam" <?php echo (isset($user['gender']) && $user['gender'] === 'Nam') ? 'checked' : ''; ?>>
                                    Nam
                                </label>
                                <label class="radio-label">
                                    <input type="radio" name="gender" value="Nữ" <?php echo (isset($user['gender']) && $user['gender'] === 'Nữ') ? 'checked' : ''; ?>>
                                    Nữ
                                </label>
                                <label class="radio-label">
                                    <input type="radio" name="gender" value="Khác" <?php echo (isset($user['gender']) && $user['gender'] === 'Khác') ? 'checked' : ''; ?>>
                                    Khác
                                </label>
                            </div>
                        </div>

                        <div class="form-actions-new">
                            <button type="submit" class="btn-save">Lưu</button>
                        </div>
                    </form>
                </div>
                <div class="profile-avatar-column">
                    <div class="avatar-upload-section-new">
                        <div class="avatar-preview-new">
                            <?php if (!empty($user['avatar'])): ?>
                                <img src="<?php echo htmlspecialchars($user['avatar']); ?>" alt="Avatar" id="avatar-preview-img-new">
                            <?php else: ?>
                                <div class="default-avatar-new" id="default-avatar-preview-new">
                                    <span><?php echo strtoupper(substr($user['name'], 0, 1)); ?></span>
                                </div>
                            <?php endif; ?>
                        </div>
                        <form action="index.php?controller=user&action=update" method="POST" enctype="multipart/form-data" id="avatar-form">
                            <input type="file" name="avatar" id="avatar-input-new" accept="image/*" style="display: none;">
                            <button type="button" class="btn-choose-avatar" onclick="document.getElementById('avatar-input-new').click();">
                                Chọn ảnh
                            </button>
                        </form>
                        <p class="avatar-note">Dung lượng file tối đa 5MB<br>Định dạng: .JPEG, .PNG, .GIF, .WEBP</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include __DIR__ . '/../layouts/footer.php'; ?>

    <script src="public/js/user-profile.js?v=<?php echo time(); ?>"></script>
</body>
</html>
