<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Turtle Sneaker</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700&display=swap">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="<?= asset('css/style.css?v=' . time()) ?>">
</head>
<body>
    <header class="site-header">
        <div class="top-bar">
            <div class="logo">
                <a href="<?= url('/') ?>">
                    <img width="90px" height="40px" object-fit="cover" src="<?= url('logonew.png') ?>" alt="Turtle Sneaker">
                </a>
            </div>
            <nav class="header-nav">
                <a href="<?= route('products') ?>">Sản phẩm</a>
                <div class="nav-dropdown">
                    <a href="#" class="dropdown-toggle">Danh mục<span class="arrow">▼</span></a>
                    <div class="dropdown-menu">
                        <?php if (isset($categories) && is_array($categories)): ?>
                            <?php foreach ($categories as $cat): ?>
                                <a href="<?= route('products') ?>?category=<?= $cat['id'] ?>"><?= htmlspecialchars($cat['name']) ?></a>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
                <a href="<?= route('about') ?>">Giới thiệu</a>
                <a href="#">Liên hệ</a>
            </nav>
            <form class="search-box" action="<?= route('products') ?>" method="GET">
                <input type="text" name="keyword" placeholder="Tìm kiếm sản phẩm..." value="<?php echo htmlspecialchars($_GET['keyword'] ?? ''); ?>">
                <button type="submit" class="search-btn">
                    <i class='bx bx-search'></i>
                </button>
            </form>
            <div class="header-actions">
                <?php $isLoggedIn = isset($_SESSION['user_id']); ?>
                <?php $isAdmin = isset($_SESSION['role']) && $_SESSION['role'] === 'admin'; ?>
                
                <?php if ($isAdmin): ?>
                    <a href="<?= route('admin.dashboard') ?>" class="admin-return-btn" title="Quay lại trang quản trị">
                        <i class='bx bx-arrow-back'></i> Admin
                    </a>
                <?php endif; ?>
                
                <div class="user-account-wrapper">
                    <?php if ($isLoggedIn): ?>
                        <a href="<?= route('profile') ?>" class="icon-btn-with-label" title="Tài khoản của tôi">
                            <i class='bx bxs-user-circle'></i>
                            <span class="user-name"><?php echo htmlspecialchars($_SESSION['name'] ?? 'Tài khoản'); ?></span>
                        </a>
                    <?php else: ?>
                        <a href="<?= route('login') ?>" class="icon-btn" title="Đăng nhập">
                            <i class='bx bxs-user-circle'></i>
                        </a>
                    <?php endif; ?>
                </div>
                
                <a href="<?php echo $isLoggedIn ? route('wishlist') : route('login'); ?>" 
                   class="icon-btn wishlist-icon" title="Sản phẩm yêu thích">
                    <i class='bx bxs-heart'></i>
                    <?php if ($isLoggedIn && isset($_SESSION['wishlist_count']) && $_SESSION['wishlist_count'] > 0): ?>
                        <span class="wishlist-badge"><?php echo $_SESSION['wishlist_count']; ?></span>
                    <?php endif; ?>
                </a>
                
                <a href="<?php echo $isLoggedIn ? route('cart') : route('login'); ?>" 
                   class="icon-btn cart-icon" title="Giỏ hàng">
                    <i class='bx bxs-cart'></i>
                    <?php if ($isLoggedIn && isset($_SESSION['cart_count']) && $_SESSION['cart_count'] > 0): ?>
                        <span class="cart-badge"><?php echo $_SESSION['cart_count']; ?></span>
                    <?php endif; ?>
                </a>
            </div>
        </div>
    </header>
    <?php
    // Check if we're on homepage by checking current URI
    $currentUri = Request::uri();
    $isHomePage = ($currentUri === '/' || $currentUri === 'trang-chu');
    if (!$isHomePage):
    ?>
    <main class="site-main">
    <?php endif; ?>