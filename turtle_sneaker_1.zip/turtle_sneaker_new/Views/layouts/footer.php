</main>
<footer class="site-footer">
    <div class="footer-brand">
        <img width="200px" src="logonew.png" alt="Turtle Sneaker Logo">
    </div>
    <div class="footer-columns">
        <div>
            <h4>Khách hàng</h4>
            <ul>
                <li><a href="#">Hướng dẫn mua hàng</a></li>
                <li><a href="#">Chính sách đổi trả</a></li>
                <li><a href="#">Chính sách bảo hành</a></li>
                <li><a href="#">Khách hàng thân thiết</a></li>
            </ul>
        </div>
        <div>
            <h4>Về chúng tôi</h4>
            <ul>
                <li><a href="#">Giới thiệu</a></li>
                <li><a href="#">Điều khoản sử dụng</a></li>
                <li><a href="#">Tin tức / Blog</a></li>
            </ul>
        </div>
        <div>
            <h4>Liên hệ</h4>
            <ul>
                <li><a href="#">Facebook</a></li>
                <li><a href="#">Instagram</a></li>
                <li><a href="#">YouTube</a></li>
                <li><a href="#">Thread</a></li>
            </ul>
        </div>
    </div>
    <div class="footer-map">
        <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d212.27328305888304!2d105.70778721100514!3d19.835136559700835!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e1!3m2!1svi!2s!4v1763478774480!5m2!1svi!2s" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>
</footer>
</body>
</html>

