<div class="product-page-wrapper">
    <div class="filter-sidebar">
        <div class="filter-group">
            <h3>BỘ LỌC SẢN PHẨM</h3>
            
            <form action="<?= route('products') ?>" method="GET" id="filterForm">
                <?php if (!empty($currentCategory)): ?>
                    <input type="hidden" name="category" value="<?= $currentCategory['id']; ?>">
                <?php endif; ?>
                <?php 
                $keyword = trim($_GET['keyword'] ?? '');
                if (!empty($keyword)): 
                ?>
                    <input type="hidden" name="keyword" value="<?= htmlspecialchars($keyword); ?>">
                <?php endif; ?>

                <div class="filter-section">
                    <h4>Theo Danh Mục</h4>
                    <?php 
                    $selectedFilterCategories = isset($_GET['filter_category']) ? (array)$_GET['filter_category'] : [];
                    $selectedFilterCategories = array_map('intval', $selectedFilterCategories);
                    ?>
                    <?php foreach ($categories as $cat): ?>
                        <label class="checkbox-container">
                            <input type="checkbox" name="filter_category[]" value="<?= $cat['id']; ?>" 
                                <?= in_array($cat['id'], $selectedFilterCategories) ? 'checked' : '' ?>>
                            <span class="checkmark"></span>
                            <?= htmlspecialchars($cat['name']); ?>
                        </label>
                    <?php endforeach; ?>
                </div>

                <div class="filter-section">
                    <h4>Khoảng Giá</h4>
                    <?php
                    $priceRanges = [
                        '0-150000' => 'Dưới 150.000đ',
                        '150000-200000' => '150.000đ - 200.000đ',
                        '200000-300000' => '300.000đ - 400.000đ',
                        '400000-500000' => '400.000đ - 500.000đ',
                        '500000-99999999' => 'Trên 500.000đ'
                    ];
                    $selectedPriceRange = $_GET['price_range'] ?? '';
                    ?>
                    <?php foreach ($priceRanges as $value => $label): ?>
                        <label class="radio-container">
                            <input type="radio" name="price_range" value="<?= $value ?>"
                                <?= $selectedPriceRange === $value ? 'checked' : '' ?>>
                            <span class="radiomark"></span>
                            <?= $label ?>
                        </label>
                    <?php endforeach; ?>
                </div>
                
                <button type="submit" class="btn-filter">Áp dụng</button>
                <?php if (!empty($selectedPriceRange) || !empty($selectedFilterCategories)): ?>
                    <?php 
                    $clearUrl = route('products');
                    $params = [];
                    if (!empty($currentCategory)) {
                        $params['category'] = $currentCategory['id'];
                    }
                    if (!empty($keyword)) {
                        $params['keyword'] = $keyword;
                    }
                    if (!empty($params)) {
                        $clearUrl .= '?' . http_build_query($params);
                    }
                    ?>
                    <a href="<?= $clearUrl ?>" class="btn-clear-filter">Xóa bộ lọc</a>
                <?php endif; ?>
            </form>
        </div>
    </div>

    <div class="product-content">
        <h2 class="product-page-title">
            <?php 
            $keyword = trim($_GET['keyword'] ?? '');
            if (!empty($keyword)): 
            ?>
                Kết quả tìm kiếm: "<?= htmlspecialchars($keyword); ?>"
            <?php elseif (!empty($currentCategory)): ?>
                <?= htmlspecialchars($currentCategory['name']); ?>
            <?php else: ?>
                Tất cả sản phẩm
            <?php endif; ?>
        </h2>
        <?php $productImages = $productImages ?? []; ?>
        <div class="product-grid-container">
            <?php if (!empty($products)): ?>
                <?php foreach ($products as $product): ?>
                    <?php
                    $image = $product['main_image'] ?? 'https://placehold.co/400x400?text=No+Image';
                    $name = htmlspecialchars($product['name'] ?? 'Sản phẩm');
                    $price = number_format((float)($product['price'] ?? 0), 0, ',', '.');
                    $gallery = $productImages[$product['id']] ?? [];
                    ?>
                    <a class="product-card-link" href="<?= route('product.detail', ['id' => $product['id']]) ?>">
                        <div class="product-card-v2">
                            <div class="product-card-image">
                                <img src="<?= url($image) ?>" alt="<?= $name; ?>">
                                <button class="product-wishlist-btn <?= in_array($product['id'], $wishlistedProductIds ?? []) ? 'active' : ''; ?>" onclick="toggleWishlist(event, <?= $product['id']; ?>)" title="Thêm vào yêu thích">
                                    <i class='bx <?= in_array($product['id'], $wishlistedProductIds ?? []) ? 'bxs-heart' : 'bx-heart'; ?>'></i>
                                </button>
                            </div>
                            <div class="product-card-body">
                                <div class="product-card-meta">
                                    <span class="product-chip"><?php echo htmlspecialchars($product['category_name'] ?? 'Sản phẩm'); ?></span>
                                </div>
                                <h3><?= $name; ?></h3>
                                <p class="price"><?= $price; ?>đ</p>
                            </div>
                        </div>
                    </a>
                <?php endforeach; ?>
            <?php else: ?>
                <p>Hiện chưa có sản phẩm nào để hiển thị.</p>
            <?php endif; ?>
        </div>

        <div class="pagination">
            <?php
            $baseUrl = route('products');
            $params = [];
            if (!empty($currentCategory)) {
                $params['category'] = $currentCategory['id'];
            }
            if (!empty($selectedPriceRange)) {
                $params['price_range'] = $selectedPriceRange;
            }
            if (!empty($params)) {
                $baseUrl .= '?' . http_build_query($params);
            }
            ?>
            <?php if ($currentPage > 1): ?>
                <a href="<?= $baseUrl ?><?= !empty($params) ? '&' : '?' ?>page=<?= $currentPage - 1; ?>">&lt;</a>
            <?php else: ?>
                <span class="disabled">&lt;</span>
            <?php endif; ?>

            <?php for ($page = 1; $page <= $totalPages; $page++): ?>
                <?php if ($page == $currentPage): ?>
                    <span class="current"><?= $page; ?></span>
                <?php else: ?>
                    <a href="<?= $baseUrl ?><?= !empty($params) ? '&' : '?' ?>page=<?= $page; ?>"><?= $page; ?></a>
                <?php endif; ?>
            <?php endfor; ?>

            <?php if ($currentPage < $totalPages): ?>
                <a href="<?= $baseUrl ?><?= !empty($params) ? '&' : '?' ?>page=<?= $currentPage + 1; ?>">&gt;</a>
            <?php else: ?>
                <span class="disabled">&gt;</span>
            <?php endif; ?>
        </div>
    </div>
</div>

<link rel="stylesheet" href="<?= url('public/css/product-card.css?v=' . time()) ?>">
<link rel="stylesheet" href="<?= url('public/css/product.css?v=' . time()) ?>">

<script src="<?= url('public/js/product-list.js?v=' . time()) ?>"></script>
