<?php
require_once __DIR__ . '/../components/breadcrumb.php';
$breadcrumbItems = [
    ['label' => 'Sản phẩm', 'url' => route('products')],
    ['label' => $name ?? 'Chi tiết sản phẩm']
];
renderBreadcrumb($breadcrumbItems);
?>
<link rel="stylesheet" href="<?= url('public/css/rating-stars.css?v=' . time()) ?>">

<div class="detail-container">
    <div class="product-main-info">
        <div class="product-gallery">
            <div class="main-image-wrapper">
                <img src="<?= url($image) ?>" alt="<?= htmlspecialchars($name); ?>" style="width: 400px; height: 400px; object-fit: cover;">
            </div>
        </div>

        <div class="product-details">
            <h2><?= htmlspecialchars($name); ?></h2>
            <div class="detail-price" id="product-price"><?= $price; ?>₫</div>
            
            <div class="product-rating-summary" style="margin-bottom: 15px;">
                <span class="text-warning">
                    <?php 
                    $stars = round($avgRating ?? 0); 
                    for($i=1; $i<=5; $i++) {
                        echo $i <= $stars ? '★' : '☆';
                    }
                    ?>
                </span>
                <span class="text-muted">(<?= $totalReviews ?? 0 ?> đánh giá)</span>
            </div>

            <div class="detail-option-group">
                <span>Màu sắc:</span>
                <?php if (!empty($colors)): ?>
                    <?php foreach ($colors as $color): ?>
                        <button type="button" class="option-btn" data-option="color" data-value="<?= htmlspecialchars($color); ?>"><?= htmlspecialchars($color); ?></button>
                    <?php endforeach; ?>
                <?php else: ?>
                    <span style="color: #999; font-size: 0.9em;">Đang cập nhật</span>
                <?php endif; ?>
            </div>

            <div class="detail-option-group">
                <span>Size:</span>
                <?php if (!empty($sizes)): ?>
                    <?php foreach ($sizes as $size): ?>
                        <button type="button" class="option-btn" data-option="size" data-value="<?= htmlspecialchars($size); ?>"><?= htmlspecialchars($size); ?></button>
                    <?php endforeach; ?>
                <?php else: ?>
                    <span style="color: #999; font-size: 0.9em;">Đang cập nhật</span>
                <?php endif; ?>
                <p class="text-muted small" style="margin-top: 5px;"><u>Hướng dẫn chọn size</u></p>
            </div>

            <div class="detail-option-group">
                <span>Số lượng</span>
                <div class="quantity-control">
                    <button type="button" data-action="decrease">-</button>
                    <input type="number" id="quantity-input" value="1" min="1" max="999">
                    <button type="button" data-action="increase">+</button>
                </div>
                <span class="stock-status">Còn hàng</span>
            </div>

            <div class="action-buttons">
                <a href="#" class="buy-now-btn" id="buy-now-btn" data-product-id="<?= htmlspecialchars($productId ?? ''); ?>">Mua ngay</a>
                <a href="#" class="add-to-cart-btn" id="add-to-cart-btn" data-product-id="<?= htmlspecialchars($productId ?? ''); ?>">Thêm vào giỏ hàng</a>
            </div>
        </div>
    </div>

    <div style="display: flex; gap: 80px; margin-top: 50px; flex-wrap: wrap;">
        <div style="flex: 1 1 300px;">
            <h3 class="detail-section-header">CHI TIẾT SẢN PHẨM</h3>
            <div class="detail-section-content product-meta">
                <p><strong>Danh mục:</strong> <?= htmlspecialchars($categoryName); ?></p>
                <p><strong>Mã sản phẩm:</strong> <?= htmlspecialchars($product_code); ?></p>
                <p><strong>Gửi từ:</strong> Thanh Hóa</p>
            </div>
        </div>
    <?php

$product_id = null;
if (isset($result_details) && is_array($result_details) && !empty($result_details['productId'])) {
    $product_id = (int)$result_details['productId'];
}

$rating = 4; 
if (isset($result_details) && is_array($result_details)) {
    if (isset($result_details['rating'])) {
        $rating = (int)$result_details['rating'];
    } elseif (isset($result_details['avg_rating'])) {
        $rating = (int)$result_details['avg_rating'];
    }
}

if (!isset($productId) && isset($_GET['id'])) {
    $productId = (int)$_GET['id'];
}

if (!isset($productId) || !$productId) {
    echo '<p>Sản phẩm không xác định. Vui lòng kiểm tra controller hoặc nguồn dữ liệu.</p>';
    return;
}
?>
        <div style="flex: 1 1 300px;">
            <h3 class="detail-section-header">MÔ TẢ SẢN PHẨM</h3>
            <div class="detail-section-content">
                <p><?= nl2br(htmlspecialchars($description ?: '')); ?></p>
            </div>
        </div>
    </div>

    <h3 class="detail-section-header" style="margin-top: 60px;">ĐÁNH GIÁ TỪ KHÁCH HÀNG ĐÃ MUA</h3>
    
    <?php if (isset($_SESSION['alert'])): ?>
        <div class="alert alert-<?= $_SESSION['alert']['type'] ?>" style="padding: 15px; margin-bottom: 20px; border-radius: 4px; <?= $_SESSION['alert']['type'] == 'success' ? 'background-color: #d4edda; color: #155724;' : 'background-color: #f8d7da; color: #721c24;' ?>">
            <?= $_SESSION['alert']['message'] ?>
        </div>
        <?php unset($_SESSION['alert']); ?>
    <?php endif; ?>

    <?php if (!empty($reviews)): ?>
        <div class="review-list">
            <?php foreach ($reviews as $review): ?>
                <div class="review-item">
                    <div class="review-header">
                        <div class="reviewer-avatar"><?= strtoupper(substr($review['user_name'] ?? 'U', 0, 1)); ?></div>
                        <div>
                            <span class="reviewer-name"><?= htmlspecialchars($review['user_name'] ?? 'Người dùng'); ?></span>
                            <span class="review-meta">| <?= date('d-m-Y H:i', strtotime($review['created_at'])); ?></span>
                        </div>
                    </div>
                    <div class="star-rating">
                        <?= str_repeat('⭐', (int)($review['rating'] ?? 0)); ?>
                    </div>
                    <div class="review-content">
                        <?= nl2br(htmlspecialchars($review['comment'] ?? '')); ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <p>Chưa có đánh giá cho sản phẩm này.</p>
    <?php endif; ?>

    <?php if (!empty($relatedProducts)): ?>
        <h3 class="detail-section-header" style="margin-top: 60px;">SẢN PHẨM CÙNG DANH MỤC</h3>
        <div class="product-grid">
            <?php foreach ($relatedProducts as $related): ?>
                <?php
                $relatedImage = $related['main_image'] ?? 'https://placehold.co/400x400?text=No+Image';
                $relatedName = htmlspecialchars($related['name'] ?? 'Sản phẩm');
                $relatedPrice = number_format((float)($related['price'] ?? 0), 0, ',', '.');
                $relatedLink = route('product.detail', ['id' => $related['id']]);
                ?>
                <a href="<?= $relatedLink; ?>" style="text-decoration: none; color: inherit; display: block;">
                    <article class="product-card">
                        <img src="<?= url($relatedImage) ?>" alt="<?= $relatedName; ?>">
                        <h3><?= $relatedName; ?></h3>
                        <p class="price"><?= $relatedPrice; ?>₫</p>
                    </article>
                </a>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<div id="notification" style="display: none; position: fixed; top: 20px; right: 20px; background: #4CAF50; color: white; padding: 15px 20px; border-radius: 5px; z-index: 10000; box-shadow: 0 2px 10px rgba(0,0,0,0.2);">
    <span id="notification-text"></span>
</div>


<script>
window.productDetailData = {
    basePriceRaw: <?= isset($basePriceRaw) ? $basePriceRaw : (float)($product['price'] ?? 0); ?>,
    productId: <?= (int)($productId ?? 0); ?>
};
const BASE_URL = '<?= url('') ?>';
</script>
<script src="<?= url('public/js/product-detail.js?v=' . time()) ?>"></script>