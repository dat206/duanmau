<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng Nhập - Turtle Sneaker</title>
    <link rel="stylesheet" href="public/css/auth.css?v=<?php echo time(); ?>">

</head>
<body>

    <div class="login-container">
        <h2 class="login-title">Đăng Nhập</h2>

        <?php if (isset($error)): ?>
<p class="error-message"><?php echo $error; ?></p>
        <?php endif; ?>

        <form action="<?= route('login.post') ?>" method="POST">
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" placeholder="username@gmail.com" required>
            </div>

            <div class="form-group">
                <label for="password">Mật khẩu:</label>
                <div class="password-input-wrapper">
                    <input type="password" id="password" name="password" placeholder="Password" required>
                    <span>👀</span> 
                </div>
            </div>
            
            <div class="remember-me">
                <input type="checkbox" id="remember_me" name="remember_me">
                <label for="remember_me">Ghi nhớ mật khẩu</label>
            </div>

            <button type="submit" class="btn-login">Đăng nhập</button>
        </form>

        <p class="register-link">
            Bạn chưa có tài khoản? <a href="<?= route('register') ?>">Đăng kí ngay</a>
        </p>
        
        <p class="back-home-link">
            <a href="<?= url('/') ?>">← Quay lại trang chủ</a>
        </p>
    </div>

</body>
</html>