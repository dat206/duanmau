<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng Ký - Turtle Sneaker</title>
    <link rel="stylesheet" href="public/css/auth.css?v=<?php echo time(); ?>">
</head>
<body>

    <div class="register-container">
        <h2 class="register-title">Đăng Ký</h2>

        <?php if (isset($error)): ?>
<p class="error-message"><?php echo $error; ?></p>
        <?php endif; ?>

        <form action="<?= route('register.post') ?>" method="POST">
            <div class="form-group">
                <label for="name">Tên đăng ký:</label>
                <input type="text" id="name" name="name" placeholder="Name" required>
            </div>

            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" placeholder="username@gmail.com" required>
            </div>

            <div class="form-group">
                <label for="password">Nhập mật khẩu:</label>
                <input type="password" id="password" name="password" placeholder="Password" required>
            </div>

            <button type="submit" class="btn-register">Đăng Ký</button>
        </form>

        <p class="login-link">
            Bạn đã có tài khoản? <a href="<?= route('login') ?>">Đăng nhập ngay</a>
        </p>
        
        <p class="back-home-link">
            <a href="<?= url('/') ?>">← Quay lại trang chủ</a>
        </p>
    </div>

</body>
</html>
