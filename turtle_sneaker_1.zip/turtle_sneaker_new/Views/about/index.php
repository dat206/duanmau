<?php
require_once __DIR__ . '/../components/breadcrumb.php';

$breadcrumbItems = [
    ['label' => 'Giới thiệu']
];

renderBreadcrumb($breadcrumbItems);
?>

<div class="about-container" style="max-width: 1200px; margin: 40px auto; padding: 0 20px;">
    <div class="about-hero" style="text-align: center; margin-bottom: 60px;">
        <h1 style="font-size: 2.5em; color: #333; margin-bottom: 20px;">Về Turtle Sneaker</h1>
        <p style="font-size: 1.2em; color: #666; max-width: 800px; margin: 0 auto; line-height: 1.6;">
            Chào mừng bạn đến với Turtle Sneaker - điểm đến tin cậy cho những đôi giày thể thao chất lượng cao, 
            phong cách và đẳng cấp.
        </p>
    </div>

    <div class="about-section" style="margin-bottom: 60px;">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 40px; align-items: center;">
            <div>
                <h2 style="font-size: 2em; color: #333; margin-bottom: 20px;">Câu Chuyện Của Chúng Tôi</h2>
                <p style="color: #666; line-height: 1.8; margin-bottom: 15px;">
                    Turtle Sneaker được thành lập với niềm đam mê mãnh liệt về giày thể thao và mong muốn 
                    mang đến cho khách hàng Việt Nam những sản phẩm chính hãng, chất lượng cao với giá cả hợp lý.
                </p>
                <p style="color: #666; line-height: 1.8; margin-bottom: 15px;">
                    Chúng tôi tin rằng mỗi đôi giày không chỉ là phụ kiện thời trang, mà còn là người bạn đồng hành 
                    trong mọi hành trình của bạn - từ những buổi tập luyện thể thao đến những chuyến phiêu lưu 
                    khám phá cuộc sống.
                </p>
            </div>
            <div style="background:linear-gradient(135deg, #667eea 0%, #764ba2 100%); height: 300px; border-radius: 10px; display: flex; align-items: center; justify-content: center; color: white; font-size: 3em;">    
            </div>
        </div>
</div>
    <div class="about-section" style="margin-bottom: 60px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 60px; border-radius: 10px; color: white;">
        <h2 style="font-size: 2em; margin-bottom: 20px; text-align: center;">Sứ Mệnh Của Chúng Tôi</h2>
        <p style="font-size: 1.1em; line-height: 1.8; text-align: center; max-width: 800px; margin: 0 auto;">
            Mang đến cho mọi người cơ hội sở hữu những đôi giày thể thao chất lượng cao, 
            giúp họ tự tin thể hiện phong cách và chinh phục mọi mục tiêu trong cuộc sống.
        </p>
    </div>


    <div class="about-section" style="margin-bottom: 60px;">
        <h2 style="font-size: 2em; color: #333; margin-bottom: 40px; text-align: center;">Tại Sao Chọn Turtle Sneaker?</h2>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px;">
            <div style="display: flex; gap: 20px; padding: 20px; background: #f8f9fa; border-radius: 10px;">
                <div style="font-size: 2em; color: #667eea;">🚚</div>
                <div>
                    <h3 style="color: #333; margin-bottom: 10px;">Giao Hàng Nhanh Chóng</h3>
                    <p style="color: #666; line-height: 1.6;">
                        Giao hàng toàn quốc trong 1-3 ngày, miễn phí ship cho đơn hàng trên 500K.
                    </p>
                </div>
            </div>
            
            <div style="display: flex; gap: 20px; padding: 20px; background: #f8f9fa; border-radius: 10px;">
                <div style="font-size: 2em; color: #667eea;">🔄</div>
                <div>
                    <h3 style="color: #333; margin-bottom: 10px;">Đổi Trả Dễ Dàng</h3>
                    <p style="color: #666; line-height: 1.6;">
                        Chính sách đổi trả trong 7 ngày, không cần lý do, hoàn tiền 100%.
                    </p>
                </div>
            </div>
            
            <div style="display: flex; gap: 20px; padding: 20px; background: #f8f9fa; border-radius: 10px;">
                <div style="font-size: 2em; color: #667eea;">💳</div>
                <div>
                    <h3 style="color: #333; margin-bottom: 10px;">Thanh Toán An Toàn</h3>
                    <p style="color: #666; line-height: 1.6;">
                        Hỗ trợ nhiều hình thức thanh toán: COD, chuyển khoản, ví điện tử.
                    </p>
                </div>
            </div>
            
            <div style="display: flex; gap: 20px; padding: 20px; background: #f8f9fa; border-radius: 10px;">
                <div style="font-size: 2em; color: #667eea;">🎁</div>
                <div>
                    <h3 style="color: #333; margin-bottom: 10px;">Ưu Đãi Hấp Dẫn</h3>
                    <p style="color: #666; line-height: 1.6;">
                        Chương trình khuyến mãi thường xuyên, tích điểm đổi quà cho khách hàng thân thiết.
                    </p>
                </div>
            </div>
        </div>
    </div>

    <div class="about-section" style="text-align: center; padding: 60px 20px; background: #f8f9fa; border-radius: 10px;">
        <h2 style="font-size: 2em; color: #333; margin-bottom: 20px;">Sẵn Sàng Khám Phá?</h2>
        <p style="color: #666; font-size: 1.1em; margin-bottom: 30px;">
            Hãy để Turtle Sneaker đồng hành cùng bạn trên mọi hành trình!
        </p>
        <div style="display: flex; gap: 20px; justify-content: center;">
            <a href="index.php?controller=product" style="display: inline-block; padding: 15px 40px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; text-decoration: none; border-radius: 5px; font-weight: 600;">
                Mua Sắm Ngay
            </a>
            <a href="index.php" style="display: inline-block; padding: 15px 40px; background: white; color: #667eea; text-decoration: none; border-radius: 5px; font-weight: 600; border: 2px solid #667eea;">
                Về Trang Chủ
            </a>
        </div>
    </div>
</div>

<link rel="stylesheet" href="public/css/about.css?v=<?php echo time(); ?>">
