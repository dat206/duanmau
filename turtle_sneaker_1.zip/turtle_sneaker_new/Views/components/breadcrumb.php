<?php
function renderBreadcrumb($items) {
    if (empty($items)) {
        return;
    }
    ?>
    <nav class="breadcrumb-container" aria-label="Breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?= url('/') ?>" class="breadcrumb-link">
                    <i class='bx bx-home-alt'></i>
                    <span>Trang chủ</span>
                </a>
            </li>
            
            <?php foreach ($items as $index => $item): ?>
                <?php $isLast = ($index === count($items) - 1); ?>
                
                <li class="breadcrumb-separator">
                    <i class='bx bx-chevron-right'></i>
                </li>
                
                <li class="breadcrumb-item <?php echo $isLast ? 'active' : ''; ?>">
                    <?php if ($isLast || empty($item['url'])): ?>
                        <span class="breadcrumb-current"><?php echo htmlspecialchars($item['label']); ?></span>
                    <?php else: ?>
                        <a href="<?php echo htmlspecialchars($item['url']); ?>" class="breadcrumb-link">
                            <?php echo htmlspecialchars($item['label']); ?>
                        </a>
                    <?php endif; ?>
                </li>
            <?php endforeach; ?>
        </ol>
    </nav>
    
    <link rel="stylesheet" href="<?= asset('css/breadcrumb.css?v=' . time()) ?>">
    <?php
}
?>
