<?php
require_once __DIR__ . '/../components/breadcrumb.php';

$breadcrumbItems = [
    ['label' => 'Giỏ hàng', 'url' => 'index.php?controller=cart&action=view'],
    ['label' => 'Thanh toán', 'url' => 'index.php?controller=cart&action=checkout'],
    ['label' => 'Cảm ơn']
];

renderBreadcrumb($breadcrumbItems);
?>

<section class="thankyou-page">
    <div class="thankyou-card">
        <div class="thankyou-icon">✅</div>
        <h1>Cảm ơn bạn đã đặt hàng!</h1>
        <p>Đơn hàng của bạn đang được xử lý. Turtle Sneaker sẽ liên hệ và giao hàng trong thời gian sớm nhất.</p>
        <div class="thankyou-actions">
            <a href="<?= url('/') ?>" class="btn-home">Quay về trang chủ</a>
        </div>
    </div>
</section>

<link rel="stylesheet" href="<?= url('public/css/cart.css?v=' . time()) ?>">

