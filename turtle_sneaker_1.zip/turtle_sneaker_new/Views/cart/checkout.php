<?php
$recipientName = $_SESSION['name'] ?? '';
$recipientPhone = $_SESSION['phone'] ?? '';
$addressLine = $_SESSION['address'] ?? '';

if (!function_exists('formatCurrencyVN')) {
    function formatCurrencyVN(float $value): string {
        return number_format($value, 0, ',', '.') . 'đ';
    }
}

$subtotal = $totals['subtotal'] ?? 0;
$shippingFee = $shippingFee ?? 0;
$voucherDiscount = $voucherDiscount ?? 0;
$totalPayable = $totals['total'] ?? ($subtotal + $shippingFee - $voucherDiscount);
$fullAddress = trim($addressLine);
$checkoutModeValue = $checkoutModeValue ?? 'cart';
?>

<?php
require_once __DIR__ . '/../components/breadcrumb.php';

$breadcrumbItems = [
    ['label' => 'Giỏ hàng', 'url' => 'index.php?controller=cart&action=view'],
    ['label' => 'Thanh toán']
];

renderBreadcrumb($breadcrumbItems);
?>
<link rel="stylesheet" href="public/css/toast.css?v=<?php echo time(); ?>">
<script src="public/js/toast.js?v=<?php echo time(); ?>"></script>
<div class="checkout-page">
    <div class="checkout-layout">
        <div class="checkout-main">
            <section class="card address-card">
                <div class="card-title">
                    <h3>Địa chỉ nhận hàng</h3>
                    <button type="button" class="link-button" id="toggleAddressEdit">Thay đổi</button>
                </div>
                <div class="address-display">
                    <div>
                        <strong id="displayRecipient"><?= htmlspecialchars($recipientName) ?></strong>
                        <span id="displayPhone"><?= htmlspecialchars($recipientPhone) ?></span>
                    </div>
                    <p id="displayAddress"><?= htmlspecialchars($fullAddress) ?></p>
                </div>
                <div class="address-edit" id="addressEditPanel">
                    <div class="form-grid">
                        <label>Họ và tên <span style="color: red;">*</span>
                            <input type="text" name="name" id="inputName" form="checkoutForm" value="<?= htmlspecialchars($recipientName) ?>">
                        </label>
                        <label>Số điện thoại <span style="color: red;">*</span>
                            <input type="tel" name="phone" id="inputPhone" form="checkoutForm" value="<?= htmlspecialchars($recipientPhone) ?>" pattern="[0-9]{10,11}" title="Vui lòng nhập số điện thoại hợp lệ (10-11 số)">
                        </label>
                        <label>Địa chỉ <span style="color: red;">*</span>
                            <input type="text" name="address" id="inputAddress" form="checkoutForm" value="<?= htmlspecialchars($addressLine) ?>">
                        </label>
                    </div>
                    <div class="address-actions">
                        <button type="button" class="btn-secondary" id="cancelAddressEdit">Hủy</button>
                        <button type="button" class="btn-primary" id="saveAddressBtn">Lưu</button>
                </div>
            </div>
            </section>

            <section class="card order-card">
                <table class="order-table">
                    <thead>
                        <tr>
                            <th>Sản phẩm</th>
                            <th>Giá</th>
                            <th>Số lượng</th>
                            <th>Thành tiền</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($cartItems as $item): ?>
                            <tr>
                                <td class="product-info">
                                    <img src="<?= htmlspecialchars($item['image']) ?>" alt="<?= htmlspecialchars($item['name']) ?>">
                                    <div>
                                        <p class="product-name"><?= htmlspecialchars($item['name']) ?></p>
                                        <p class="product-meta">Loại: <?= htmlspecialchars($item['category'] ?? 'Giày Sneaker') ?> | Màu sắc: <?= htmlspecialchars($item['color'] ?? 'Đen') ?> | Size: <?= htmlspecialchars($item['size'] ?? '42') ?></p>
                                    </div>
                                </td>
                                <td><?= formatCurrencyVN((float)$item['price']) ?></td>
                                <td>x<?= (int)$item['quantity'] ?></td>
                                <td><?= formatCurrencyVN((float)$item['line_total']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </section>

            <section class="card shipping-card">
                <div class="shipping-row">
                    <div>
                        <p>Phương thức vận chuyển: <strong id="shippingLabel"><?= htmlspecialchars($shippingMethods[0]['name'] ?? 'Chưa chọn') ?></strong></p>
                        <span id="shippingDesc" class="shipping-desc"><?= htmlspecialchars($shippingMethods[0]['description'] ?? '') ?></span>
                    </div>
                    <div class="shipping-actions">
                        <span id="shippingFeeText" class="shipping-fee"><?= formatCurrencyVN((float)$shippingFee) ?></span>
                        <button type="button" class="link-button" id="changeShippingBtn">Thay đổi</button>
                                </div>
                                </div>
                <div class="shipping-options" id="shippingOptionList">
                    <?php foreach ($shippingMethods as $method): ?>
                        <label class="shipping-option <?= $method['id'] == $selectedShippingId ? 'active' : '' ?>">
                            <input type="radio" name="shipping_option_temp" value="<?= $method['id'] ?>" <?= $method['id'] == $selectedShippingId ? 'checked' : '' ?>
                                   data-label="<?= htmlspecialchars($method['name']) ?>" data-desc="<?= htmlspecialchars($method['description']) ?>" data-fee="<?= (float)$method['fee'] ?>">
                            <div>
                                <strong><?= htmlspecialchars($method['name']) ?></strong>
                                <p><?= htmlspecialchars($method['description']) ?></p>
                                <span><?= formatCurrencyVN((float)$method['fee']) ?></span>
                            </div>
                        </label>
                    <?php endforeach; ?>
                    <div style="width: 100%; text-align: right; margin-top: 10px;">
                        <button type="button" class="btn-primary" id="applyShippingBtn">Áp dụng</button>
                    </div>
                </div>
            </section>

            <section class="card voucher-card">
                <div class="voucher-row">
                    <div>
                        <strong>Turtle Sneaker Voucher</strong>
                        <p>Chọn voucher để áp dụng ưu đãi</p>
                    </div>
                    <button type="button" class="btn-secondary" id="openVoucherBtn">Chọn Voucher</button>
                </div>
                <div class="voucher-selected" id="voucherSelected" <?= $voucherDiscount > 0 ? '' : 'style="display:none;"' ?>>
                    <span id="voucherSelectedLabel">Đã áp dụng mã <?= htmlspecialchars($appliedVoucher['code'] ?? '') ?> (-<?= formatCurrencyVN((float)$voucherDiscount) ?>)</span>
                    <button type="button" class="link-button" id="removeVoucherBtn">Xóa</button>
                </div>
            </section>
                <div class="voucher-selected" id="voucherSelected" <?= $voucherDiscount > 0 ? '' : 'style="display:none;"' ?>>
                    <span id="voucherSelectedLabel">Đã áp dụng mã <?= htmlspecialchars($appliedVoucher['code'] ?? '') ?> (-<?= formatCurrencyVN((float)$voucherDiscount) ?>)</span>
                    <button type="button" class="link-button" id="removeVoucherBtn">Xóa</button>
                </div>
            </section>
                    </div>

        <div class="checkout-summary">
            <form action="<?= route('checkout.process') ?>" method="POST" id="checkoutForm" class="summary-card payment-summary-card">
                <div class="payment-header">
                    <h3>Phương thức thanh toán</h3>
                    <div class="payment-tabs" id="paymentTabs">
                        <button type="button" class="payment-tab active" data-method="cod">Thanh toán khi nhận hàng</button>
                        <button type="button" class="payment-tab" data-method="vnpay">Thanh toán ví VNPAY</button>
                    </div>
                </div>

                <div class="payment-body">
                    <div class="payment-info-container">
                        <div class="payment-info" id="paymentInfo">
                            <p data-method="cod" class="active">Bạn sẽ thanh toán trực tiếp cho shipper khi nhận hàng.</p>
                            <p data-method="banking">Chuyển khoản vào tài khoản Turtle Sneaker theo hướng dẫn sau khi đặt.</p>
                            <p data-method="vnpay">Thanh toán nhanh qua VNPAY với nhiều ưu đãi dành riêng.</p>
                        </div>
                    </div>

                    <div class="order-summary-container">
                        <div class="summary-line">
                            <span>Tổng tiền hàng:</span>
                            <strong id="subtotalValue"><?= formatCurrencyVN((float)$subtotal) ?></strong>
                        </div>
                        <div class="summary-line">
                            <span>Tổng phí vận chuyển:</span>
                            <strong id="shippingSummaryValue"><?= formatCurrencyVN((float)$shippingFee) ?></strong>
                        </div>
                        <div class="summary-line">
                            <span>Tổng cộng mã giảm giá:</span>
                            <strong id="voucherSummaryValue">-<?= formatCurrencyVN((float)$voucherDiscount) ?></strong>
                        </div>
                        <div class="summary-total">
                            <span>Tổng thanh toán</span>
                            <strong id="grandTotalValue"><?= formatCurrencyVN((float)$totalPayable) ?></strong>
                        </div>
                        <div style="text-align: right; margin-top: 20px;">
                            <button type="submit" class="btn-order">Đặt hàng</button>
                        </div>
                    </div>
                </div>

                <input type="hidden" name="shipping_method" id="shippingMethodInput" value="<?= htmlspecialchars($selectedShippingId) ?>">
                <input type="hidden" name="shipping_fee" id="shippingFeeInput" value="<?= (float)$shippingFee ?>">
                <input type="hidden" name="voucher_code" id="voucherCodeInput" value="<?= htmlspecialchars($appliedVoucher['code'] ?? '') ?>">
                <input type="hidden" name="voucher_discount" id="voucherDiscountInput" value="<?= (float)$voucherDiscount ?>">
                <input type="hidden" name="payment_method" id="paymentMethodInput" value="cod">
                <input type="hidden" name="name" value="<?= htmlspecialchars($recipientName) ?>" id="hiddenName">
                <input type="hidden" name="phone" value="<?= htmlspecialchars($recipientPhone) ?>" id="hiddenPhone">
                <input type="hidden" name="address" value="<?= htmlspecialchars($addressLine) ?>" id="hiddenAddress">
                <input type="hidden" name="checkout_mode" value="<?= htmlspecialchars($checkoutModeValue ?? 'cart') ?>">
            </form>
        </div>
        </div>
    </div>

    <div class="voucher-modal" id="voucherModal">
        <div class="voucher-dialog">
            <div class="voucher-dialog__header">
                <h4>Chọn voucher</h4>
                <button type="button" class="close-modal" id="closeVoucherModal">&times;</button>
            </div>
            <div class="voucher-columns">
                 <div class="voucher-column">
                    <h5>Miễn phí vận chuyển</h5>
                    <div class="voucher-list">
                        <?php foreach ($shippingCoupons as $coupon): ?>
                            <div class="voucher-item" data-code="<?= $coupon['code'] ?>" data-discount="<?= (float)$coupon['discount_amount'] ?>" data-min="<?= (float)$coupon['min_order_value'] ?>" data-type="<?= $coupon['type'] ?>">
                                <div>
                                    <strong><?= htmlspecialchars($coupon['code']) ?></strong>
                                    <p>Giảm <?= formatCurrencyVN((float)$coupon['discount_amount']) ?> phí vận chuyển</p>
                                    <small>Đơn tối thiểu: <?= formatCurrencyVN((float)$coupon['min_order_value']) ?></small>
                                </div>
                                <button type="button" class="btn-primary btn-apply-voucher">Áp dụng</button>
                            </div>
                        <?php endforeach; ?>
                        <?php if (empty($shippingCoupons)): ?>
                            <p style="color: #888; font-style: italic;">Không có mã miễn phí vận chuyển nào.</p>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="voucher-column">
                    <h5 class="discount-header">Mã giảm giá</h5>
                    <div class="voucher-list">
                        <?php foreach ($discountCoupons as $coupon): ?>
                            <div class="voucher-item" data-code="<?= $coupon['code'] ?>" data-discount="<?= (float)$coupon['discount_amount'] ?>" data-min="<?= (float)$coupon['min_order_value'] ?>" data-type="<?= $coupon['type'] ?>">
                                <div>
                                    <strong><?= htmlspecialchars($coupon['code']) ?></strong>
                                    <p>
                                        <?php if ($coupon['type'] == 'percentage'): ?>
                                            Giảm <?= (float)$coupon['discount_amount'] * 100 ?>%
                                        <?php else: ?>
                                            Giảm <?= formatCurrencyVN((float)$coupon['discount_amount']) ?>
                                        <?php endif; ?>
                                    </p>
                                    <small>Đơn tối thiểu: <?= formatCurrencyVN((float)$coupon['min_order_value']) ?></small>
                                </div>
                                <button type="button" class="btn-primary btn-apply-voucher">Áp dụng</button>
                            </div>
                        <?php endforeach; ?>
                        <?php if (empty($discountCoupons)): ?>
                            <p style="color: #888; font-style: italic;">Không có mã giảm giá nào.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<link rel="stylesheet" href="public/css/checkout.css?v=<?php echo time(); ?>">


<script>
// PHP variables for checkout
window.checkoutData = {
    shippingMethods: <?= json_encode($shippingMethods, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP) ?>,
    subtotal: parseFloat(<?= (float)$subtotal ?>),
    shippingFee: parseFloat(<?= (float)$shippingFee ?>),
    voucherDiscount: parseFloat(<?= (float)$voucherDiscount ?>)
};
</script>

<script>
    const BASE_URL = '<?= url('') ?>';
</script>
<script src="<?= url('public/js/checkout.js?v=' . time()) ?>"></script>
