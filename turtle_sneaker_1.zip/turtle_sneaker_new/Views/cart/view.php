<?php
$cartItems = $cartItems ?? [];
$totals = $totals ?? ['quantity' => 0, 'subtotal' => 0];
$itemCount = count($cartItems);
require_once __DIR__ . '/../components/breadcrumb.php';
$breadcrumbItems = [
    ['label' => 'Giỏ hàng']
];
renderBreadcrumb($breadcrumbItems);
?>

<section class="cart-page">
    <header class="cart-page__head">
        <p class="cart-page__path">
            <span>Turtle Sneaker</span> | Giỏ hàng
        </p>
        <h1>Giỏ hàng của bạn</h1>
        <p class="cart-page__meta">
            <?php if ($itemCount === 0): ?>
                Chưa có sản phẩm nào được thêm vào giỏ hàng.
            <?php else: ?>
                Có <strong><?php echo $totals['quantity']; ?></strong> sản phẩm đang chờ bạn thanh toán.
            <?php endif; ?>
        </p>
    </header>

    <?php if ($itemCount === 0): ?>
        <div class="cart-empty">
            <div class="cart-empty-icon">🛍️</div>
            <p>Giỏ hàng của bạn đang trống.</p>
            <a href="<?= route('products') ?>" class="btn btn-primary">Tiếp tục mua sắm</a>
        </div>
    <?php else: ?>
        <div class="cart-items-wrapper">
            <div class="cart-table-card">
                <table class="cart-table-v2">
                    <thead>
                        <tr>
                            <th class="col-select">
                            </th>
                            <th class="col-product">Sản phẩm</th>
                            <th class="col-price">Giá</th>
                            <th class="col-qty">Số lượng</th>
                            <th class="col-total">Tổng tiền</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($cartItems as $key => $item): ?>
                            <?php
                            $image = $item['image'] ?? '';
                            if (!$image) {
                                $image = 'https://placehold.co/120x120?text=No+Image';
                            }
                            $lineTotal = $item['line_total'] ?? 0;
                            $isDeleted = $item['is_deleted'] ?? false;
                            ?>
                            <tr class="cart-item-row <?php echo $isDeleted ? 'out-of-stock' : ''; ?>" data-item-key="<?php echo htmlspecialchars($key); ?>" data-price="<?php echo (float)$item['price']; ?>">
                                <td class="col-select">
                                    <label class="checkbox">
                                        <input type="checkbox" class="item-checkbox" <?php echo $isDeleted ? 'disabled' : 'checked'; ?> data-item-key="<?php echo htmlspecialchars($key); ?>">
                                        <span></span>
                                    </label>
                                </td>
                                <td class="col-product">
                                    <div class="cart-product-cell">
                                        <img src="<?php echo htmlspecialchars($image); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>" style="<?php echo $isDeleted ? 'opacity: 0.5;' : ''; ?>">
                                        <div class="product-details">
                                            <h3><?php echo htmlspecialchars($item['name']); ?></h3>
                                            <?php if ($isDeleted): ?>
                                                <span class="out-of-stock-badge" style="display: inline-block; background: #ff4444; color: white; padding: 2px 8px; border-radius: 4px; font-size: 12px; margin-top: 4px;">Sản phẩm đã hết hàng</span>
                                            <?php endif; ?>
                                            <p>
                                                <?php if (!empty($item['color'])): ?>
                                                    Màu: <strong><?php echo htmlspecialchars($item['color']); ?></strong>
                                                <?php endif; ?>
                                                <?php if (!empty($item['size'])): ?>
                                                    <span class="dot-separator"></span>
                                                    Size: <strong><?php echo htmlspecialchars($item['size']); ?></strong>
                                                <?php endif; ?>
                                            </p>
                                        </div>
                                    </div>
                                </td>
                                <td class="col-price">
                                    <span class="item-price"><?php echo number_format((float)$item['price'], 0, ',', '.'); ?>đ</span>
                                </td>
                                <td class="col-qty">
                                    <div class="quantity-stepper">
                                        <button type="button" class="qty-decrement" aria-label="Giảm" data-item-key="<?php echo htmlspecialchars($key); ?>" <?php echo $isDeleted ? 'disabled' : ''; ?>>-</button>
                                        <input type="text" class="qty-input" value="<?php echo (int)$item['quantity']; ?>" readonly data-item-key="<?php echo htmlspecialchars($key); ?>">
                                        <button type="button" class="qty-increment" aria-label="Tăng" data-item-key="<?php echo htmlspecialchars($key); ?>" <?php echo $isDeleted ? 'disabled' : ''; ?>>+</button>
                                    </div>
                                </td>
                                <td class="col-total">
                                    <?php if ($isDeleted): ?>
                                        <strong class="item-total" style="color: #999;">-</strong>
                                    <?php else: ?>
                                        <strong class="item-total"><?php echo number_format($lineTotal, 0, ',', '.'); ?>đ</strong>
                                    <?php endif; ?>
                                </td>

                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="cart-footer-actions">
            <label class="checkbox">
                <input type="checkbox" id="select-all-footer" checked>
                <span></span>
                Chọn tất cả
            </label>
            <button type="button" class="btn-link" id="remove-selected-btn" onclick="handleRemoveSelected()">Xóa đã chọn</button>
            <div class="cart-footer-total">
                <span>Tổng cộng (<span id="footer-selected-count"><?php echo $itemCount; ?></span> sản phẩm):</span>
                <strong id="footer-selected-total"><?php echo number_format($totals['subtotal'], 0, ',', '.'); ?>đ</strong>
            </div>
            <button class="btn btn-primary" id="checkout-footer-btn" type="button">Mua hàng</button>
        </div>
    <?php endif; ?>
</section>

<script>
    // Base URL for AJAX requests
    const BASE_URL = '<?= url('') ?>';
</script>
<script src="<?= url('public/js/cart.js?v=' . time()) ?>"></script>

<link rel="stylesheet" href="<?= url('public/css/cart.css?v=' . time()) ?>">

