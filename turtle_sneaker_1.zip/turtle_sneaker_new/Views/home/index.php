<section class="hero-slider-section">
    <div class="hero-slider-container">
        <div class="slider-wrapper">
            <div class="slide active">
                <img src="<?= url('public/images/slider/banner11.jpg') ?>" alt="Slide 1">
            </div>
            <div class="slide">
                <img src="<?= url('public/images/slider/banner22.jpg') ?>" alt="Slide 2">
            </div>
            <div class="slide">
                <img src="<?= url('public/images/slider/banner33.jpg') ?>" alt="Slide 3">
            </div>
        </div>
        <div class="hero-overlay-content">
            <div class="hero-overlay-inner">
                <p class="hero-badge">Turtle Sneaker</p>
                <h1>Hơi thở Sneaker mới, đánh thức chất riêng của bạn</h1>
                <p class="hero-subtitle">
                    Chọn ngay những đôi sneaker độc bản với công nghệ đệm êm, chất liệu bền bỉ và bảng màu đầy cảm hứng
                    dành riêng cho những cú đạp tự tin.
                </p>
                <div class="hero-cta-group">
                    <a href="<?= route('products') ?>" class="hero-cta primary">Mua ngay</a>
                </div>
            </div>
        </div>
        <button class="slider-btn prev" onclick="moveSlide(-1)">&#10094;</button>
        <button class="slider-btn next" onclick="moveSlide(1)">&#10095;</button>
        <div class="slider-dots">
            <span class="dot active" onclick="currentSlide(1)"></span>
            <span class="dot" onclick="currentSlide(2)"></span>
            <span class="dot" onclick="currentSlide(3)"></span>
        </div>
    </div>
</section>

<div class="home-container">
    <section class="product-section">
        <div class="section-heading">
            <div class="heading-content">
                <h2>GIÀY HOT</h2>
                <p>Những đôi sneaker dẫn đầu xu hướng 2025</p>
            </div>
            <a class="btn-view-more" href="<?= route('products') ?>">Xem thêm <i class='bx bx-right-arrow-alt'></i></a>
        </div>
        <div class="product-slider-wrapper">
            <button class="slider-nav-btn prev" onclick="navigateSlider('hot-products-slider', -1)">
                <i class='bx bx-chevron-left'></i>
            </button>
            <div class="product-slider" id="hot-products-slider">
                <div class="product-slider-track">
                <?php foreach ($hotProducts ?? [] as $product): ?>
                    <?php
                    $image = $product['main_image'] ?? '';
                    if (!$image) {
                        $image = 'https://placehold.co/400x400?text=No+Image';
                    }
                    $category_name = $product['category_name'] ?? 'Chưa rõ'; 
                    ?>
                    <a class="product-card-link slider-item" href="<?= route('product.detail', ['id' => $product['id']]) ?>">
                        <div class="product-card-v2">
                            <div class="product-card-image">
                                <img src="<?= url($image) ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
                                <button class="product-wishlist-btn <?= in_array($product['id'], $wishlistedProductIds ?? []) ? 'active' : ''; ?>" onclick="toggleWishlist(event, <?= $product['id']; ?>)" title="Thêm vào yêu thích">
                                    <i class='bx <?= in_array($product['id'], $wishlistedProductIds ?? []) ? 'bxs-heart' : 'bx-heart'; ?>'></i>
                                </button>
                            </div>
                            <div class="product-card-body">
                                <div class="product-card-meta">
                                    <span class="product-chip"><?php echo htmlspecialchars($category_name); ?></span>
                                </div>
                                <h3><?php echo htmlspecialchars($product['name']); ?></h3>
                                <p class="price"><?php echo number_format((float) $product['price'], 0, ',', '.'); ?>đ</p>
                            </div>
                        </div>
                    </a>
                <?php endforeach; ?>
                </div>
            </div>
            <button class="slider-nav-btn next" onclick="navigateSlider('hot-products-slider', 1)">
                <i class='bx bx-chevron-right'></i>
            </button>
        </div>
    </section>

    <section class="product-section">
        <div class="section-heading">
            <div class="heading-content">
                <h2>SNEAKER</h2>
                <p>Các mẫu sneaker mới nhất</p>
            </div>
        </div>
        <div class="category-filter-buttons">
            <?php 
            $displayCategories = array_slice($categories ?? [], 0, 5);
            $isFirst = true;
            foreach ($displayCategories as $category): 
            ?>
                <button class="category-btn <?php echo $isFirst ? 'active' : ''; ?>" 
                        data-category="<?php echo htmlspecialchars($category['name']); ?>" 
                        onclick="filterByCategory('<?php echo htmlspecialchars($category['name'], ENT_QUOTES); ?>')">
                    <?php echo htmlspecialchars($category['name']); ?>
                </button>
            <?php 
                $isFirst = false;
            endforeach; 
            ?>
        </div>
        <div class="product-slider-wrapper">
            <button class="slider-nav-btn prev" onclick="navigateSlider('sneaker-products-slider', -1)">
                <i class='bx bx-chevron-left'></i>
            </button>
            <div class="product-slider" id="sneaker-products-slider">
                <div class="product-slider-track">
                <?php foreach ($sneakerProducts ?? [] as $product): ?>
                    <?php
                    $image = $product['main_image'] ?? '';
                    if (!$image) {
                        $image = 'https://placehold.co/400x400?text=No+Image';
                    }
                    $category_name = $product['category_name'] ?? 'Chưa rõ';
                    ?>
                    <a class="product-card-link slider-item" href="<?= route('product.detail', ['id' => $product['id']]) ?>">
                        <div class="product-card-v2">
                            <div class="product-card-image">
                                <img src="<?= url($image) ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
                                <button class="product-wishlist-btn <?= in_array($product['id'], $wishlistedProductIds ?? []) ? 'active' : ''; ?>" onclick="toggleWishlist(event, <?= $product['id']; ?>)" title="Thêm vào yêu thích">
                                    <i class='bx <?= in_array($product['id'], $wishlistedProductIds ?? []) ? 'bxs-heart' : 'bx-heart'; ?>'></i>
                                </button>
                            </div>
                            <div class="product-card-body">
                                <div class="product-card-meta">
                                    <span class="product-chip"><?php echo htmlspecialchars($category_name); ?></span>
                                </div>
                                <h3><?php echo htmlspecialchars($product['name']); ?></h3>
                                <p class="price"><?php echo number_format((float) $product['price'], 0, ',', '.'); ?>đ</p>
                            </div>
                        </div>
                    </a>
                <?php endforeach; ?>
                </div>
            </div>
            <button class="slider-nav-btn next" onclick="navigateSlider('sneaker-products-slider', 1)">
                <i class='bx bx-chevron-right'></i>
            </button>
        </div>
    </section>
</div>

<link rel="stylesheet" href="public/css/home.css?v=<?php echo time(); ?>">

<script src="public/js/home.js?v=<?php echo time(); ?>"></script>

<script>
function toggleWishlist(event, productId) {
    event.preventDefault();
    event.stopPropagation();
    
    const button = event.currentTarget;
    const icon = button.querySelector('i');
    
    <?php if (!isset($_SESSION['user_id'])): ?>
        alert('Vui lòng đăng nhập để sử dụng tính năng yêu thích!');
        window.location.href = '<?= route('login') ?>';
        return;
    <?php endif; ?>
    
    const formData = new FormData();
    formData.append('product_id', productId);
    
    fetch('<?= url('/yeu-thich/them') ?>', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            button.classList.toggle('active');
            
            if (data.action === 'added') {
                icon.className = 'bx bxs-heart';
            } else {
                icon.className = 'bx bx-heart';
            }
            
            const wishlistBadge = document.querySelector('.wishlist-badge');
            if (wishlistBadge) {
                if (data.wishlist_count > 0) {
                    wishlistBadge.textContent = data.wishlist_count;
                    wishlistBadge.style.display = 'flex';
                } else {
                    wishlistBadge.style.display = 'none';
                }
            }
        } else {
            alert(data.message || 'Có lỗi xảy ra');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Có lỗi xảy ra khi thêm vào yêu thích');
    });
}
</script>
