<?php
require_once __DIR__ . '/../components/breadcrumb.php';
$breadcrumbItems = [
    ['label' => 'Sản phẩm yêu thích']
];
renderBreadcrumb($breadcrumbItems);
?>

<div class="wishlist-container">
    <h1 class="wishlist-title">Sản phẩm yêu thích của tôi</h1>
    
    <?php if (empty($wishlistProducts)): ?>
        <div class="empty-wishlist">
            <i class='bx bx-heart-circle' style="font-size: 5rem; color: #ccc;"></i>
            <h2>Chưa có sản phẩm yêu thích</h2>
            <p>Hãy thêm sản phẩm yêu thích để dễ dàng tìm lại sau này!</p>
            <a href="index.php?controller=product" class="btn-browse">Khám phá sản phẩm</a>
        </div>
    <?php else: ?>
        <div class="wishlist-grid">
            <?php foreach ($wishlistProducts as $product): ?>
                <?php
                $image = $product['main_image'] ?? 'https://placehold.co/400x400?text=No+Image';
                $name = htmlspecialchars($product['name'] ?? 'Sản phẩm');
                $price = number_format((float)($product['price'] ?? 0), 0, ',', '.');
                ?>
                <div class="wishlist-item">
                    <a class="product-card-link" href="index.php?controller=product&action=detail&id=<?= $product['id']; ?>">
                        <div class="product-card-v2">
                            <div class="product-card-image">
                                <img src="<?= htmlspecialchars($image); ?>" alt="<?= $name; ?>">
                                <button class="product-wishlist-btn active" onclick="removeFromWishlist(event, <?= $product['id']; ?>)" title="Xóa khỏi yêu thích">
                                    <i class='bx bxs-heart'></i>
                                </button>
                            </div>
                            <div class="product-card-body">
                                <div class="product-card-meta">
                                    <span class="product-chip"><?php echo htmlspecialchars($product['category_name'] ?? 'Sản phẩm'); ?></span>
                                </div>
                                <h3><?= $name; ?></h3>
                                <p class="price"><?= $price; ?>đ</p>
                            </div>
                        </div>
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<link rel="stylesheet" href="public/css/product-card.css?v=<?php echo time(); ?>">
<link rel="stylesheet" href="public/css/wishlist.css?v=<?php echo time(); ?>">


<script>
    const BASE_URL = '<?= url('') ?>';
</script>
<script src="public/js/wishlist.js?v=<?php echo time(); ?>"></script>
