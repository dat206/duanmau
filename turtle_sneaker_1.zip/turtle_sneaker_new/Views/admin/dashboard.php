<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Turtle Sneaker</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="public/css/admin.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="admin-layout">
        <?php include __DIR__ . '/sidebar.php'; ?>
        <div class="admin-content">
            <div class="admin-header">
                <h1>Báo cáo thống kê</h1>
                <div class="role">Vai trò: Admin</div>
            </div>
            
            <div class="revenue-stats-row">
                <div class="revenue-stat-card">
                    <div class="revenue-stat-content">
                        <h3>Doanh thu hôm nay</h3>
                        <div class="revenue-stat-value"><?php echo number_format($todayRevenue ?? 0, 0, ',', '.'); ?> VNĐ</div>
                        <div class="revenue-stat-meta">Hôm nay / <?php echo number_format($todayRevenue ?? 0, 0, ',', '.'); ?> VNĐ</div>
                    </div>
                </div>

                <div class="revenue-stat-card">
                    <div class="revenue-stat-content">
                        <h3>Doanh thu tuần này</h3>
                        <div class="revenue-stat-value"><?php echo number_format($weekRevenue ?? 0, 0, ',', '.'); ?> VNĐ</div>
                        <div class="revenue-stat-meta">Tuần này / <?php echo number_format($weekRevenue ?? 0, 0, ',', '.'); ?> VNĐ</div>
                    </div>
                </div>

                <div class="revenue-stat-card">
                    <div class="revenue-stat-content">
                        <h3>Doanh thu tháng này</h3>
                        <div class="revenue-stat-value"><?php echo number_format($monthRevenue ?? 0, 0, ',', '.'); ?> VNĐ</div>
                        <div class="revenue-stat-meta">Tháng này / <?php echo number_format($monthRevenue ?? 0, 0, ',', '.'); ?> VNĐ</div>
                    </div>
                </div>

                <div class="revenue-stat-card">
                    <div class="revenue-stat-content">
                        <h3>Doanh thu năm nay</h3>
                        <div class="revenue-stat-value"><?php echo number_format($yearRevenue ?? 0, 0, ',', '.'); ?> VNĐ</div>
                        <div class="revenue-stat-meta">Năm nay / <?php echo number_format($yearRevenue ?? 0, 0, ',', '.'); ?> VNĐ</div>
                    </div>
                </div>
            </div>

            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-content">
                        <h3>Tổng số đơn hàng</h3>
                        <div class="stat-value"><?php echo $orderCount ?? 0; ?></div>
                        <div class="stat-meta">Tháng này / <?php echo $orderCount ?? 0; ?> đơn</div>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-content">
                        <h3>Tổng số sản phẩm</h3>
                        <div class="stat-value"><?php echo $productCount ?? 0; ?></div>
                        <div class="stat-meta">Sản phẩm hiện có</div>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-content">
                        <h3>Tổng số người dùng</h3>
                        <div class="stat-value"><?php echo $customerCount ?? 0; ?></div>
                        <div class="stat-meta">Người dùng đã đăng ký</div>
                    </div>
                </div>
            </div>
            <div class="section-header" style="margin-top: 40px;">
                <h2>Biểu đồ doanh thu</h2>
            </div>
            
            <div class="charts-grid">
                <div class="chart-container">
                    <h3 class="chart-title">Doanh thu theo ngày (30 ngày gần nhất)</h3>
                    <div class="chart-wrapper">
                        <canvas id="dailyRevenueChart"></canvas>
                    </div>
                </div>
                
                <div class="chart-container">
                    <h3 class="chart-title">Doanh thu theo tháng (12 tháng gần nhất)</h3>
                    <div class="chart-wrapper">
                        <canvas id="monthlyRevenueChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        const dailyCtx = document.getElementById('dailyRevenueChart');
        if (dailyCtx) {
            new Chart(dailyCtx.getContext('2d'), {
                type: 'line',
                data: {
                    labels: <?php echo $chartLabelsJson ?? '[]'; ?>,
                    datasets: [{
                        label: 'Doanh thu (VNĐ)',
                        data: <?php echo $chartDataJson ?? '[]'; ?>,
                        borderColor: '#00bf00ff',
                        backgroundColor: 'rgba(0, 191, 0, 0.1)',
                        borderWidth: 3,
                        fill: true,
                        tension: 0.4,
                        pointRadius: 4,
                        pointBackgroundColor: '#00bf00ff',
                        pointBorderColor: '#fff',
                        pointBorderWidth: 2,
                        pointHoverRadius: 6
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { display: false },
                        tooltip: {
                            backgroundColor: 'rgba(0, 0, 0, 0.8)',
                            padding: 12,
                            callbacks: {
                                label: function(context) {
                                    return 'Doanh thu: ' + new Intl.NumberFormat('vi-VN').format(context.parsed.y) + ' VNĐ';
                                }
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: { color: 'rgba(0, 0, 0, 0.05)' },
                            ticks: {
                                callback: function(value) {
                                    return new Intl.NumberFormat('vi-VN', { notation: 'compact' }).format(value);
                                }
                            }
                        },
                        x: {
                            grid: { display: false },
                            ticks: { maxRotation: 0, autoSkip: true, maxTicksLimit: 15 }
                        }
                    }
                }
            });
        }

        const monthlyCtx = document.getElementById('monthlyRevenueChart');
        if (monthlyCtx) {
            new Chart(monthlyCtx.getContext('2d'), {
                type: 'bar',
                data: {
                    labels: <?php echo $monthlyLabelsJson ?? '[]'; ?>,
                    datasets: [{
                        label: 'Doanh thu (VNĐ)',
                        data: <?php echo $monthlyDataJson ?? '[]'; ?>,
                        backgroundColor: '#00bf00ff',
                        borderColor: '#00bf00ff',
                        borderWidth: 2,
                        borderRadius: 8,
                        barThickness: 40
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { display: false },
                        tooltip: {
                            backgroundColor: 'rgba(0, 0, 0, 0.8)',
                            padding: 12,
                            callbacks: {
                                label: function(context) {
                                    return 'Doanh thu: ' + new Intl.NumberFormat('vi-VN').format(context.parsed.y) + ' VNĐ';
                                }
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: { color: 'rgba(0, 0, 0, 0.05)' },
                            ticks: {
                                callback: function(value) {
                                    return new Intl.NumberFormat('vi-VN', { notation: 'compact' }).format(value);
                                }
                            }
                        },
                        x: {
                            grid: { display: false },
                            ticks: { maxRotation: 45 }
                        }
                    }
                }
            });
        }
    </script>
    
    <link rel="stylesheet" href="public/css/admin-dashboard.css?v=<?php echo time(); ?>">
</body>
</html>
