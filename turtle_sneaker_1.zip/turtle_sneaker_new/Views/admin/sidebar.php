<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý - Turtle Sneaker</title>
    <link rel="stylesheet" href="<?= url('public/css/admin.css') ?>">
    <link rel="stylesheet" href="<?= url('public/css/admin-rating.css') ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <div class="admin-sidebar">
        <div class="logo">
            <img style="width: 200px;" src="<?= url('logonew.png') ?>" alt="Turtle Sneaker">        </div>
        <nav>
            <ul>
                <li><a href="<?= route('admin.dashboard') ?>"><i class="fas fa-chart-bar"></i> Thống kê</a></li>
                <li><a href="<?= route('admin.products') ?>"><i class="fas fa-box"></i> Quản lí sản phẩm</a></li>
                <li><a href="<?= route('admin.categories') ?>"><i class="fas fa-list"></i> Quản lí danh mục</a></li>
                <li><a href="<?= route('admin.comments') ?>"><i class="fas fa-comments"></i> Quản lí bình luận</a></li>
                <li><a href="<?= route('admin.orders') ?>"><i class="fas fa-shopping-cart"></i> Quản lí đơn hàng</a></li>
                <li><a href="<?= route('admin.coupons') ?>"><i class="fas fa-ticket-alt"></i> Quản lí mã giảm giá</a></li>
                <li><a href="<?= route('admin.users') ?>"><i class="fas fa-users"></i> Quản lí người dùng</a></li>
                <li><a href="<?= route('admin.trash') ?>"><i class="fas fa-trash-alt"></i> Thùng rác</a></li>
                <li><a href="<?= url('/') ?>"><i class="fas fa-eye"></i> Xem website</a></li>
                <li><a href="<?= route('logout') ?>"><i class="fas fa-sign-out-alt"></i> Đăng xuất</a></li>
            </ul>
        </nav>
    </div>
