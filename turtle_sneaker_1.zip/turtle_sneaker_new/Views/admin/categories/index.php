<?php include __DIR__ . '/../sidebar.php'; ?>
<?php
    $categoryCount = count($categories ?? []);
    $totalProducts = 0;
    if (!empty($categories)) {
        foreach ($categories as $category) {
            $totalProducts += (int)($category['product_count'] ?? 0);
        }
    }
    $avgProducts = $categoryCount > 0 ? $totalProducts / $categoryCount : 0;
?>
<div class="admin-content">
    <div class="page-header">
        <div>
            <p class="page-subtitle">Hệ thống danh mục</p>
            <h1>Quản lý danh mục</h1>
            <div class="page-meta">
                <span><i class="fas fa-layer-group"></i> <?php echo $categoryCount; ?> danh mục</span>
                <span><i class="fas fa-boxes"></i> <?php echo $totalProducts; ?> sản phẩm đang gắn</span>
            </div>
        </div>
        <div class="page-actions">
            <a href="<?= route('admin.category.create') ?>" class="btn-primary">
                <i class="fas fa-plus"></i> Thêm danh mục
            </a>
        </div>
    </div>

    <?php if (isset($_SESSION['alert'])): ?>
        <div class="alert alert-<?php echo $_SESSION['alert']['type']; ?>">
            <?php echo htmlspecialchars($_SESSION['alert']['message']); ?>
        </div>
        <?php unset($_SESSION['alert']); ?>
    <?php endif; ?>

    <div class="insight-cards">
        <div class="insight-card">
            <span class="insight-label">Tổng danh mục</span>
            <div class="insight-value"><?php echo $categoryCount; ?></div>
            <span class="insight-meta">Nhóm sản phẩm đang hoạt động</span>
        </div>
        <div class="insight-card">
            <span class="insight-label">Tổng sản phẩm</span>
            <div class="insight-value"><?php echo $totalProducts; ?></div>
            <span class="insight-meta">Đang được phân loại</span>
        </div>
    </div>

    <?php if (!empty($categories)): ?>
        <div class="table-container table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Tên danh mục</th>
                        <th>Mô tả</th>
                        <th>Số sản phẩm</th>
                        <th>Thao tác</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($categories as $category): ?>
                        <tr>
                            <td>#<?php echo str_pad($category['id'], 3, '0', STR_PAD_LEFT); ?></td>
                            <td class="table-cell-title"><?php echo htmlspecialchars($category['name']); ?></td>
                            <td>
                                <div class="table-cell-meta" style="max-width: 420px;"><?php echo htmlspecialchars($category['description'] ?? 'Chưa cập nhật mô tả'); ?></div>
                            </td>
                            <td>
                                <span class="chip chip-neutral"><i class="fas fa-boxes"></i> <?php echo $category['product_count'] ?? 0; ?> sản phẩm</span>
                            </td>
                            <td class="table-actions">
                                <a href="<?= route('admin.category.edit', ['id' => $category['id']]) ?>" class="action-btn btn-edit" title="Chỉnh sửa">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <a href="<?= route('admin.category.delete', ['id' => $category['id']]) ?>" class="action-btn btn-delete" onclick="return confirm('Bạn có chắc chắn muốn xóa danh mục này?');" title="Xóa danh mục">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="empty-state">
            <i class="fas fa-layer-group"></i>
            <h3>Chưa có danh mục nào</h3>
            <p>Tạo danh mục để sắp xếp sản phẩm khoa học và dễ tìm kiếm hơn.</p>
            <a href="index.php?controller=admin&action=createCategory" class="btn-primary">
                <i class="fas fa-plus"></i> Thêm danh mục mới
            </a>
        </div>
    <?php endif; ?>
</div>
</body>
</html>





