<?php include __DIR__ . '/../sidebar.php'; ?>
    <div class="admin-content">
        <div class="admin-header">
            <h1>Sửa danh mục</h1>
            <div class="role">Vai trò: Admin</div>
        </div>

        <div class="table-container" style="padding: 20px;">
            <form action="<?= route('admin.category.update', ['id' => $category['id']]) ?>" method="POST">
                <div class="form-group">
                    <label for="name">Tên danh mục</label>
                    <input type="text" id="name" name="name" class="form-control" value="<?php echo htmlspecialchars($category['name']); ?>" required>
                </div>

                <div class="form-group">
                    <label for="description">Mô tả</label>
                    <textarea id="description" name="description" class="form-control" rows="5"><?php echo htmlspecialchars($category['description'] ?? ''); ?></textarea>
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn-primary">Cập nhật</button>
                    <a href="<?= route('admin.categories') ?>" class="btn-primary" style="background-color: #6c757d;">Hủy</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>

