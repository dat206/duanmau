<?php include __DIR__ . '/../sidebar.php'; ?>

<div class="main-content">
    <div class="header-actions">
        <h1>Chỉnh sửa mã giảm giá</h1>
        <a href="<?= route('admin.coupons') ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Quay lại
        </a>
    </div>

    <?php if (isset($_SESSION['alert'])): ?>
        <div class="alert alert-<?php echo $_SESSION['alert']['type']; ?>">
            <i class="fas fa-<?php echo $_SESSION['alert']['type'] === 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
            <?php echo $_SESSION['alert']['message']; ?>
        </div>
        <?php unset($_SESSION['alert']); ?>
    <?php endif; ?>

    <div class="coupon-create-wrapper">
        <div class="form-section">
            <div class="card">
                <form action="<?= route('admin.coupon.update', ['id' => $coupon['id']]) ?>" method="POST" id="couponForm">
                    <div class="form-group">
                        <label><i class="fas fa-tag"></i> Mã giảm giá *</label>
                        <input type="text" name="code" id="couponCode" class="form-control" required placeholder="VD: SUMMER2025" maxlength="20" value="<?php echo htmlspecialchars($coupon['code']); ?>">
                        <small class="text-muted">
                            <span id="codeCounter"><?php echo strlen($coupon['code']); ?></span>/20 ký tự | Chỉ sử dụng chữ cái, số và gạch dưới
                        </small>
                        <div id="codeValidation" class="validation-message"></div>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label><i class="fas fa-percentage"></i> Loại giảm giá *</label>
                            <select name="type" class="form-control" required id="discountType">
                                <option value="amount" <?php echo $coupon['type'] == 'amount' ? 'selected' : ''; ?>>Số tiền cố định (VNĐ)</option>
                                <option value="percentage" <?php echo $coupon['type'] == 'percentage' ? 'selected' : ''; ?>>Phần trăm (%)</option>
                                <option value="shipping" <?php echo $coupon['type'] == 'shipping' ? 'selected' : ''; ?>>Miễn phí vận chuyển</option>
                            </select>
                        </div>
                        <div class="form-group col-md-6">
                            <label><i class="fas fa-money-bill-wave"></i> Giá trị giảm *</label>
                            <input type="number" name="discount_amount" id="discountAmount" class="form-control" required min="0" step="0.01" value="<?php echo $coupon['discount_amount']; ?>">
                            <small class="text-muted" id="discountHint">
                                <?php echo $coupon['type'] == 'percentage' ? 'Nhập phần trăm (VD: 10 cho 10%)' : 'Nhập số tiền (VNĐ)'; ?>
                            </small>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label><i class="fas fa-shopping-cart"></i> Đơn hàng tối thiểu</label>
                            <input type="number" name="min_order_value" id="minOrderValue" class="form-control" value="<?php echo $coupon['min_order_value']; ?>" min="0">
                            <small class="text-muted">Giá trị đơn hàng tối thiểu để áp dụng mã</small>
                        </div>
                        <div class="form-group col-md-6">
                            <label><i class="fas fa-sort-numeric-up"></i> Số lượng mã *</label>
                            <input type="number" name="quantity" id="quantity" class="form-control" value="<?php echo $coupon['quantity']; ?>" required min="1">
                            <small class="text-muted">Số lần mã có thể được sử dụng</small>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label><i class="fas fa-calendar-alt"></i> Ngày hết hạn *</label>
                            <input type="datetime-local" name="expiration_date" id="expirationDate" class="form-control" required value="<?php echo date('Y-m-d\TH:i', strtotime($coupon['expiration_date'])); ?>">
                            <small class="text-muted">Mã sẽ không thể sử dụng sau thời gian này</small>
                        </div>
                        <div class="form-group col-md-6">
                            <label><i class="fas fa-toggle-on"></i> Trạng thái</label>
                            <div class="custom-control custom-switch mt-2">
                                <input type="checkbox" name="is_active" class="custom-control-input" id="isActive" <?php echo $coupon['is_active'] ? 'checked' : ''; ?>>
                                <label class="custom-control-label" for="isActive">Kích hoạt ngay</label>
                            </div>
                            <small class="text-muted">Mã sẽ có thể sử dụng ngay sau khi cập nhật</small>
                        </div>
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Cập nhật mã giảm giá
                        </button>
                        <a href="<?= route('admin.coupons') ?>" class="btn btn-secondary">
                            <i class="fas fa-times"></i> Hủy
                        </a>
                    </div>
                </form>
            </div>
        </div>

        <div class="preview-section">
            <div class="preview-card">
                <h3><i class="fas fa-eye"></i> Xem trước mã giảm giá</h3>
                <div class="coupon-preview">
                    <div class="coupon-preview-header">
                        <div class="coupon-code" id="previewCode"><?php echo htmlspecialchars($coupon['code']); ?></div>
                        <div class="coupon-badge" id="previewBadge"><?php echo $coupon['is_active'] ? 'Đang hoạt động' : 'Tạm dừng'; ?></div>
                    </div>
                    <div class="coupon-preview-body">
                        <div class="discount-value" id="previewDiscount">
                            <?php 
                            if ($coupon['type'] == 'percentage') {
                                echo '<span class="value">' . ($coupon['discount_amount'] * 100) . '</span>';
                                echo '<span class="unit">%</span>';
                            } elseif ($coupon['type'] == 'shipping') {
                                echo '<span class="value" style="font-size: 1.5rem;">Miễn phí vận chuyển</span>';
                            } else {
                                echo '<span class="value">' . number_format($coupon['discount_amount'], 0, ',', '.') . '</span>';
                                echo '<span class="unit">₫</span>';
                            }
                            ?>
                        </div>
                        <div class="coupon-details">
                            <div class="detail-item">
                                <i class="fas fa-shopping-cart"></i>
                                <span>Đơn tối thiểu: <strong id="previewMinOrder"><?php echo number_format($coupon['min_order_value'], 0, ',', '.'); ?>₫</strong></span>
                            </div>
                            <div class="detail-item">
                                <i class="fas fa-sort-numeric-up"></i>
                                <span>Còn lại: <strong id="previewQuantity"><?php echo $coupon['quantity']; ?></strong> mã</span>
                            </div>
                            <div class="detail-item">
                                <i class="fas fa-calendar-alt"></i>
                                <span>Hết hạn: <strong id="previewExpiry"><?php echo date('d/m/Y H:i', strtotime($coupon['expiration_date'])); ?></strong></span>
                            </div>
                        </div>
                    </div>
                    <div class="coupon-preview-footer">
                        <span class="status-indicator <?php echo $coupon['is_active'] ? 'active' : 'inactive'; ?>" id="previewStatus">
                            <i class="fas fa-<?php echo $coupon['is_active'] ? 'check-circle' : 'times-circle'; ?>"></i> 
                            <?php echo $coupon['is_active'] ? 'Đang hoạt động' : 'Tạm dừng'; ?>
                        </span>
                    </div>
                </div>
                
                <div class="preview-tips">
                    <h4><i class="fas fa-lightbulb"></i> Gợi ý</h4>
                    <ul>
                        <li>Mã giảm giá nên ngắn gọn và dễ nhớ</li>
                        <li>Sử dụng chữ in hoa để dễ đọc</li>
                        <li>Tránh tạo mã trùng với mã đã có</li>
                        <li>Đặt thời hạn phù hợp với chiến dịch</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<link rel="stylesheet" href="<?= url('public/css/admin-coupons-create.css?v=' . time()) ?>">
<script src="<?= url('public/js/admin-coupons-create.js?v=' . time()) ?>"></script>

</body>
</html>
