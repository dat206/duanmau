<?php include __DIR__ . '/../sidebar.php'; ?>

<div class="main-content">
    <div class="header-actions">
        <h1>Thêm mã giảm giá mới</h1>
        <a href="<?= route('admin.coupons') ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Quay lại
        </a>
    </div>

    <?php if (isset($_SESSION['alert'])): ?>
        <div class="alert alert-<?php echo $_SESSION['alert']['type']; ?>">
            <i class="fas fa-<?php echo $_SESSION['alert']['type'] === 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
            <?php echo $_SESSION['alert']['message']; ?>
        </div>
        <?php unset($_SESSION['alert']); ?>
    <?php endif; ?>

    <div class="coupon-create-wrapper">
        <div class="form-section">
            <div class="card">
                <form action="<?= route('admin.coupon.store') ?>" method="POST" id="couponForm">
                    <div class="form-group">
                        <label><i class="fas fa-tag"></i> Mã giảm giá</label>
                        <input type="text" name="code" id="couponCode" class="form-control" required placeholder="VD: VUIXUANDONTET" maxlength="20">
                        <div id="codeValidation" class="validation-message"></div>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label><i class="fas fa-percentage"></i> Loại giảm giá *</label>
                            <select name="type" class="form-control" required id="discountType">
                                <option value="amount">Số tiền cố định (VNĐ)</option>
                                <option value="percentage">Phần trăm (%)</option>
                                <option value="shipping">Miễn phí vận chuyển</option>
                            </select>
                        </div>
                        <div class="form-group col-md-6">
                            <label><i class="fas fa-money-bill-wave"></i> Giá trị giảm *</label>
                            <input type="number" name="discount_amount" id="discountAmount" class="form-control" required min="0" step="0.01" value="0">
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label><i class="fas fa-shopping-cart"></i> Đơn hàng tối thiểu</label>
                            <input type="number" name="min_order_value" id="minOrderValue" class="form-control" value="0" min="0">
                        </div>
                        <div class="form-group col-md-6">
                            <label><i class="fas fa-sort-numeric-up"></i> Số lượng mã *</label>
                            <input type="number" name="quantity" id="quantity" class="form-control" value="100" required min="1">
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label><i class="fas fa-calendar-alt"></i> Ngày hết hạn *</label>
                            <input type="datetime-local" name="expiration_date" id="expirationDate" class="form-control" required>
                        </div>
                        <div class="form-group col-md-6">
                            <label><i class="fas fa-toggle-on"></i> Trạng thái</label>
                            <div class="custom-control custom-switch mt-2">
                                <input type="checkbox" name="is_active" class="custom-control-input" id="isActive" checked>
                                <label class="custom-control-label" for="isActive">Kích hoạt ngay</label>
                            </div>
                        </div>
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">Tạo mã giảm giá</button>
                        <a href="<?= route('admin.coupons') ?>" class="btn btn-secondary">Hủy</a>
                    </div>
                </form>
            </div>
        </div>

        <div class="preview-section">
            <div class="preview-card">
                <h3>Xem trước mã giảm giá</h3>
                <div class="coupon-preview">
                    <div class="coupon-preview-header">
                        <div class="coupon-code" id="previewCode">VUIXUANDONTET</div>
                        <div class="coupon-badge" id="previewBadge">Mới</div>
                    </div>
                    <div class="coupon-preview-body">
                        <div class="discount-value" id="previewDiscount">
                            <span class="value">0</span>
                            <span class="unit">₫</span>
                        </div>
                        <div class="coupon-details">
                            <div class="detail-item">
                                <i class="fas fa-shopping-cart"></i>
                                <span>Đơn tối thiểu: <strong id="previewMinOrder">0₫</strong></span>
                            </div>
                            <div class="detail-item">
                                <i class="fas fa-sort-numeric-up"></i>
                                <span>Còn lại: <strong id="previewQuantity">100</strong> mã</span>
                            </div>
                            <div class="detail-item">
                                <i class="fas fa-calendar-alt"></i>
                                <span>Hết hạn: <strong id="previewExpiry">--/--/----</strong></span>
                            </div>
                        </div>
                    </div>
                    <div class="coupon-preview-footer">
                        <span class="status-indicator active" id="previewStatus">
                            <i class="fas fa-check-circle"></i> Đang hoạt động
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<link rel="stylesheet" href="<?= url('public/css/admin-coupons-create.css?v=' . time()) ?>">
<script src="<?= url('public/js/admin-coupons-create.js?v=' . time()) ?>"></script>

</body>
</html>
