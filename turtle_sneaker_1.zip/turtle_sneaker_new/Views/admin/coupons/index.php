<?php include __DIR__ . '/../sidebar.php'; ?>
<?php
    $couponCount = count($coupons ?? []);
    $activeCoupons = 0;
    $shippingCoupons = 0;
    $expiredCoupons = 0;
    $now = time();
    if (!empty($coupons)) {
        foreach ($coupons as $coupon) {
            if (!empty($coupon['is_active'])) {
                $activeCoupons++;
            }
            if (($coupon['type'] ?? '') === 'shipping') {
                $shippingCoupons++;
            }
            if (!empty($coupon['expiration_date']) && strtotime($coupon['expiration_date']) < $now) {
                $expiredCoupons++;
            }
        }
    }
?>
<div class="admin-content">
    <div class="page-header">
        <div>
            <p class="page-subtitle">Chương trình ưu đãi</p>
            <h1>Quản lý mã giảm giá</h1>
            <div class="page-meta">
                <span><i class="fas fa-ticket-alt"></i> <?php echo $couponCount; ?> mã</span>
                <span><i class="fas fa-bolt"></i> <?php echo $activeCoupons; ?> đang hoạt động</span>
            </div>
        </div>
        <div class="page-actions">
            <a href="<?= route('admin.coupon.create') ?>" class="btn-primary">
                <i class="fas fa-plus"></i> Tạo mã mới
            </a>
        </div>
    </div>

    <?php if (isset($_SESSION['alert'])): ?>
        <div class="alert alert-<?php echo $_SESSION['alert']['type']; ?>">
            <?php echo htmlspecialchars($_SESSION['alert']['message']); ?>
        </div>
        <?php unset($_SESSION['alert']); ?>
    <?php endif; ?>

    <div class="insight-cards">
        <div class="insight-card">
            <span class="insight-label">Mã đang chạy</span>
            <div class="insight-value"><?php echo $activeCoupons; ?></div>
            <span class="insight-meta">Có thể áp dụng ngay</span>
        </div>
        <div class="insight-card">
            <span class="insight-label">Mã miễn phí ship</span>
            <div class="insight-value"><?php echo $shippingCoupons; ?></div>
            <span class="insight-meta">Tập trung giữ chân khách hàng</span>
        </div>
        <div class="insight-card">
            <span class="insight-label">Mã hết hạn</span>
            <div class="insight-value"><?php echo $expiredCoupons; ?></div>
            <span class="insight-meta">Cần gia hạn hoặc xóa</span>
        </div>
    </div>

    <?php if (!empty($coupons)): ?>
        <div class="table-container table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Mã</th>
                        <th>Loại</th>
                        <th>Giá trị</th>
                        <th>Đơn tối thiểu</th>
                        <th>Số lượng</th>
                        <th>Đã dùng</th>
                        <th>Hết hạn</th>
                        <th>Trạng thái</th>
                        <th>Thao tác</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($coupons as $coupon): ?>
                        <?php
                            $isActive = !empty($coupon['is_active']);
                            $isExpired = !empty($coupon['expiration_date']) && strtotime($coupon['expiration_date']) < $now;
                            $typeLabel = '';
                            switch ($coupon['type']) {
                                case 'shipping':
                                    $typeLabel = 'Miễn phí vận chuyển';
                                    break;
                                case 'percentage':
                                    $typeLabel = 'Phần trăm';
                                    break;
                                case 'amount':
                                    $typeLabel = 'Giảm theo số tiền';
                                    break;
                                default:
                                    $typeLabel = htmlspecialchars($coupon['type']);
                            }
                        ?>
                        <tr>
                            <td>
                                <div class="table-cell-title"><?php echo htmlspecialchars($coupon['code']); ?></div>
                                <div class="table-cell-meta">Tối đa <?php echo $coupon['quantity']; ?> lượt dùng</div>
                            </td>
                            <td><?php echo $typeLabel; ?></td>
                            <td>
                                <?php if (($coupon['type'] ?? '') === 'percentage'): ?>
                                    <?php echo ($coupon['discount_amount'] * 100); ?>%
                                <?php else: ?>
                                    <?php echo number_format($coupon['discount_amount'], 0, ',', '.'); ?>đ
                                <?php endif; ?>
                            </td>
                            <td><?php echo number_format($coupon['min_order_value'], 0, ',', '.'); ?>đ</td>
                            <td><?php echo (int)($coupon['quantity'] ?? 0); ?></td>
                            <td><?php echo (int)($coupon['used_count'] ?? 0); ?></td>
                            <td><?php echo date('d/m/Y H:i', strtotime($coupon['expiration_date'])); ?></td>
                            <td>
                                <?php if ($isExpired): ?>
                                    <span class="status-pill pill-danger"><i class="fas fa-exclamation-triangle"></i> Hết hạn</span>
                                <?php else: ?>
                                    <span class="status-pill <?php echo $isActive ? 'pill-success' : 'pill-warning'; ?>">
                                        <i class="fas fa-circle"></i> <?php echo $isActive ? 'Hoạt động' : 'Tạm khóa'; ?>
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td class="table-actions">
                                <a href="<?= route('admin.coupon.edit', ['id' => $coupon['id']]) ?>" class="action-btn btn-edit" title="Chỉnh sửa">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <a href="<?= route('admin.coupon.delete', ['id' => $coupon['id']]) ?>" class="action-btn btn-delete" onclick="return confirm('Bạn có chắc chắn muốn xóa mã này?');" title="Xóa mã">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="empty-state">
            <i class="fas fa-ticket-alt"></i>
            <h3>Chưa có mã giảm giá</h3>
            <p>Tạo những chương trình ưu đãi hấp dẫn để thu hút khách hàng quay lại.</p>
            <a href="index.php?controller=admin&action=createCoupon" class="btn-primary">
                <i class="fas fa-plus"></i> Tạo mã đầu tiên
            </a>
        </div>
    <?php endif; ?>
</div>
</body>
</html>





