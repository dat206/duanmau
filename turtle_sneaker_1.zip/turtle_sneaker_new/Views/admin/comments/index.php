<?php include __DIR__ . '/../sidebar.php'; ?>
<?php
    $reviewTotal = count($reviews ?? []);
    $approvedCount = 0;
    $pendingCount = 0;
    $hiddenCount = 0;
    if (!empty($reviews)) {
        foreach ($reviews as $review) {
            switch ($review['status']) {
                case 'approved':
                    $approvedCount++;
                    break;
                case 'hidden':
                    $hiddenCount++;
                    break;
                default:
                    $pendingCount++;
            }
        }
    }
?>
<div class="admin-content">
    <div class="page-header">
        <div>
            <p class="page-subtitle">Phản hồi sản phẩm</p>
            <h1>Quản lý bình luận</h1>
            <div class="page-meta">
                <span><i class="fas fa-comment"></i> <?php echo $reviewTotal; ?> bình luận</span>
                <span><i class="fas fa-star"></i> <?php echo $approvedCount; ?> hiển thị</span>
            </div>
        </div>
    </div>

    <?php if (isset($_SESSION['alert'])): ?>
        <div class="alert alert-<?php echo $_SESSION['alert']['type']; ?>">
            <?php echo htmlspecialchars($_SESSION['alert']['message']); ?>
        </div>
        <?php unset($_SESSION['alert']); ?>
    <?php endif; ?>

    <div class="insight-cards">
        <div class="insight-card">
            <span class="insight-label">Đã duyệt</span>
            <div class="insight-value"><?php echo $approvedCount; ?></div>
            <span class="insight-meta">Hiển thị trên trang sản phẩm</span>
        </div>
        <div class="insight-card">
            <span class="insight-label">Chờ duyệt</span>
            <div class="insight-value"><?php echo $pendingCount; ?></div>
            <span class="insight-meta">Cần kiểm duyệt nội dung</span>
        </div>
        <div class="insight-card">
            <span class="insight-label">Đã ẩn</span>
            <div class="insight-value"><?php echo $hiddenCount; ?></div>
            <span class="insight-meta">Không hiển thị với khách</span>
        </div>
    </div>

    <?php if (!empty($reviews)): ?>
        <div class="table-container table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Người dùng</th>
                        <th>Sản phẩm</th>
                        <th>Nội dung</th>
                        <th>Đánh giá</th>
                        <th>Ngày tạo</th>
                        <th>Trạng thái</th>
                        <th>Thao tác</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($reviews as $review): ?>
                        <tr>
                            <td>#<?php echo $review['id']; ?></td>
                            <td class="table-cell-title"><?php echo htmlspecialchars($review['user_name']); ?></td>
                            <td><?php echo htmlspecialchars($review['product_name']); ?></td>
                            <td style="max-width: 360px;">
                                <div class="table-cell-meta"><?php echo htmlspecialchars($review['comment']); ?></div>
                            </td>
                            <td>
                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                    <i class="fas fa-star <?php echo $i <= $review['rating'] ? 'text-warning' : 'text-muted'; ?>"></i>
                                <?php endfor; ?>
                            </td>
                            <td><?php echo date('d/m/Y H:i', strtotime($review['created_at'])); ?></td>
                            <td>
                                <?php
                                    $statusClass = 'pill-warning';
                                    $statusText = 'Chờ duyệt';
                                    if ($review['status'] === 'approved') {
                                        $statusClass = 'pill-success';
                                        $statusText = 'Đã duyệt';
                                    } elseif ($review['status'] === 'hidden') {
                                        $statusClass = 'pill-danger';
                                        $statusText = 'Đã ẩn';
                                    }
                                ?>
                                <span class="status-pill <?php echo $statusClass; ?>"><?php echo $statusText; ?></span>
                            </td>
                            <td class="table-actions">
                                <?php if($review['status'] !== 'approved'): ?>
                                    <a href="<?= route('admin.comment.approve', ['id' => $review['id']]) ?>?status=approved" 
                                       class="action-btn btn-view" title="Duyệt">
                                        <i class="fas fa-check"></i>
                                    </a>
                                <?php endif; ?>
                                
                                <?php if($review['status'] !== 'hidden'): ?>
                                    <a href="<?= route('admin.comment.hide', ['id' => $review['id']]) ?>?status=hidden" 
                                       class="action-btn btn-edit" title="Ẩn bình luận">
                                        <i class="fas fa-eye-slash"></i>
                                    </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="empty-state">
            <i class="fas fa-comment-slash"></i>
            <h3>Chưa có bình luận</h3>
            <p>Khi khách hàng đánh giá sản phẩm, bình luận sẽ xuất hiện tại đây.</p>
        </div>
    <?php endif; ?>
</div>
</body>
</html>





