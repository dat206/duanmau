<?php include __DIR__ . '/../sidebar.php'; ?>
    <div class="admin-content">
        <div class="admin-header">
            <h1>Sửa sản phẩm</h1>
            <div class="role">Vai trò: Admin</div>
        </div>

        <div class="table-container" style="padding: 20px;">
            <form action="<?= route('admin.product.update', ['id' => $product['id']]) ?>" method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="name">Tên sản phẩm</label>
                    <input type="text" id="name" name="name" class="form-control" value="<?php echo htmlspecialchars($product['name']); ?>" required>
                </div>

                <div class="form-group">
                    <label for="product_code">Mã sản phẩm</label>
                    <input type="text" id="product_code" name="product_code" class="form-control" value="<?php echo htmlspecialchars($product['product_code'] ?? ''); ?>" required>
                </div>

                <div class="form-group">
                    <label for="category_id">Danh mục</label>
                    <select id="category_id" name="category_id" class="form-control" required>
                        <?php foreach ($categories as $category): ?>
                            <option value="<?php echo $category['id']; ?>" <?php echo ($category['id'] == $product['category_id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($category['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="price">Giá</label>
                    <input type="number" id="price" name="price" class="form-control" value="<?php echo $product['price'] ?? 0; ?>" required>
                </div>

                <div class="form-group">
                    <label for="image">Ảnh đại diện</label>
                    <?php if (!empty($product['main_image'])): ?>
                        <div style="margin-bottom: 10px;">
                            <img src="<?= url($product['main_image']) ?>" alt="Current Image" style="width: 100px; height: auto;">
                        </div>
                    <?php endif; ?>
                    <input type="hidden" name="current_image" value="<?php echo htmlspecialchars($product['main_image'] ?? ''); ?>">
                    <input type="file" id="image" name="image" class="form-control" accept="image/*">
                    <small>Để trống nếu không muốn thay đổi ảnh.</small>
                </div>

                <div class="form-group">
                    <label for="description">Mô tả</label>
                    <textarea id="description" name="description" class="form-control" rows="5"><?php echo htmlspecialchars($product['description'] ?? ''); ?></textarea>
                </div>

                <div class="form-group">
                    <label for="colors">Màu sắc (cách nhau bằng dấu phẩy)</label>
                    <input type="text" id="colors" name="colors" class="form-control" placeholder="VD: Trắng, Đen, Xanh dương, Đỏ" value="<?php echo htmlspecialchars(implode(', ', $productColors)); ?>">
                    <small>Nhập các màu sắc, cách nhau bằng dấu phẩy</small>
                </div>

                <div class="form-group">
                    <label>Kích cỡ</label>
                    <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                        <?php foreach ($sizes as $size): ?>
                            <label style="display: flex; align-items: center; gap: 5px;">
                                <input type="checkbox" name="sizes[]" value="<?php echo $size['value']; ?>" 
                                    <?php echo in_array($size['value'], $productSizes) ? 'checked' : ''; ?>>
                                <span><?php echo $size['value']; ?></span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn-primary">Cập nhật</button>
                    <a href="<?= route('admin.products') ?>" class="btn-primary" style="background-color: #6c757d;">Hủy</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
