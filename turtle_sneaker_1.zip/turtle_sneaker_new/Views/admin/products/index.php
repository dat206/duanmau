<?php include __DIR__ . '/../sidebar.php'; ?>
<?php
    $productCount = count($products ?? []);
    $inventoryValue = 0;
    $maxPrice = 0;
    if (!empty($products)) {
        foreach ($products as $item) {
            $price = (float)($item['price'] ?? 0);
            $inventoryValue += $price;
            if ($price > $maxPrice) {
                $maxPrice = $price;
            }
        }
    }
    $averagePrice = $productCount > 0 ? $inventoryValue / $productCount : 0;
?>
<div class="admin-content">
    <div class="page-header">
        <div>
            <p class="page-subtitle">Kho sản phẩm</p>
            <h1>Quản lý sản phẩm</h1>
            <div class="page-meta">
                <span><i class="fas fa-box"></i> <?php echo $productCount; ?> sản phẩm</span>
                <span><i class="fas fa-clock"></i> Cập nhật <?php echo date('d/m/Y'); ?></span>
            </div>
        </div>
        <div class="page-actions">
            <a href="<?= route('admin.product.create') ?>" class="btn-primary">
                <i class="fas fa-plus"></i> Thêm sản phẩm
            </a>
        </div>
    </div>

    <?php if (isset($_SESSION['alert'])): ?>
        <div class="alert alert-<?php echo $_SESSION['alert']['type']; ?>">
            <?php echo htmlspecialchars($_SESSION['alert']['message']); ?>
        </div>
        <?php unset($_SESSION['alert']); ?>
    <?php endif; ?>

    <div class="insight-cards">
        <div class="insight-card">
            <span class="insight-label">Tổng sản phẩm</span>
            <div class="insight-value"><?php echo $productCount; ?></div>
            <span class="insight-meta">Đang hiển thị trong cửa hàng</span>
        </div>
        <div class="insight-card">
            <span class="insight-label">Giá cao nhất</span>
            <div class="insight-value"><?php echo number_format($maxPrice, 0, ',', '.'); ?>đ</div>
            <span class="insight-meta">Sản phẩm có giá trị lớn nhất</span>
        </div>
    </div>

    <?php if (!empty($products)): ?>
        <div class="table-container table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Ảnh</th>
                        <th>Sản phẩm</th>
                        <th>Danh mục</th>
                        <th>Giá bán</th>
                        <th>Thao tác</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($products as $product): ?>
                        <tr>
                            <td>#<?php echo str_pad($product['id'], 4, '0', STR_PAD_LEFT); ?></td>
                            <td>
                                <img src="<?= url($product['main_image'] ?? 'public/images/no-image.jpg') ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" class="product-img">
                            </td>
                            <td>
                                <div class="table-cell-title"><?php echo htmlspecialchars($product['name']); ?></div>
                                <div class="table-cell-meta"><?php echo htmlspecialchars($product['product_code'] ?? ''); ?></div>
                            </td>
                            <td><?php echo htmlspecialchars($product['category_name'] ?? 'N/A'); ?></td>
                            <td class="table-cell-title"><?php echo number_format($product['price'] ?? 0, 0, ',', '.'); ?>đ</td>
                            <td class="table-actions">
                                <a href="<?= route('admin.product.edit', ['id' => $product['id']]) ?>" class="action-btn btn-edit" title="Chỉnh sửa">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <a href="<?= route('admin.product.delete', ['id' => $product['id']]) ?>" class="action-btn btn-delete" onclick="return confirm('Bạn có chắc chắn muốn xóa sản phẩm này?');" title="Xóa sản phẩm">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="empty-state">
            <i class="fas fa-box-open"></i>
            <h3>Chưa có sản phẩm nào</h3>
            <p>Danh sách đang trống. Hãy thêm sản phẩm đầu tiên để bắt đầu kinh doanh.</p>
            <a href="index.php?controller=admin&action=createProduct" class="btn-primary">
                <i class="fas fa-plus"></i> Thêm sản phẩm mới
            </a>
        </div>
    <?php endif; ?>
</div>
</body>
</html>





