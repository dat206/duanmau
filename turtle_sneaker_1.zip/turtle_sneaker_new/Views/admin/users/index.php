<?php include __DIR__ . '/../sidebar.php'; ?>
<?php
    $userTotal = count($users ?? []);
    $adminCount = 0;
    $lockedCount = 0;
    if (!empty($users)) {
        foreach ($users as $user) {
            if (($user['role'] ?? '') === 'admin') {
                $adminCount++;
            }
            if (!empty($user['is_locked'])) {
                $lockedCount++;
            }
        }
    }
?>
<div class="admin-content">
    <div class="page-header">
        <div>
            <p class="page-subtitle">Cộng đồng khách hàng</p>
            <h1>Quản lý người dùng</h1>
            <div class="page-meta">
                <span><i class="fas fa-users"></i> <?php echo $userTotal; ?> tài khoản</span>
                <span><i class="fas fa-user-shield"></i> <?php echo $adminCount; ?> quản trị viên</span>
            </div>
        </div>
    </div>

    <?php if (isset($_SESSION['alert'])): ?>
        <div class="alert alert-<?php echo $_SESSION['alert']['type']; ?>">
            <?php echo htmlspecialchars($_SESSION['alert']['message']); ?>
        </div>
        <?php unset($_SESSION['alert']); ?>
    <?php endif; ?>

    <div class="insight-cards">
        <div class="insight-card">
            <span class="insight-label">Tổng người dùng</span>
            <div class="insight-value"><?php echo $userTotal; ?></div>
            <span class="insight-meta">Đã đăng ký hệ thống</span>
        </div>
        <div class="insight-card">
            <span class="insight-label">Tài khoản admin</span>
            <div class="insight-value"><?php echo $adminCount; ?></div>
            <span class="insight-meta">Có quyền quản trị</span>
        </div>
        <div class="insight-card">
            <span class="insight-label">Đang bị khóa</span>
            <div class="insight-value"><?php echo $lockedCount; ?></div>
            <span class="insight-meta">Cần xem xét mở lại</span>
        </div>
    </div>

    <?php if (!empty($users)): ?>
        <div class="table-container table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Thông tin</th>
                        <th>Liên hệ</th>
                        <th>Ngày sinh</th>
                        <th>Vai trò</th>
                        <th>Trạng thái</th>
                        <th>Hành động</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                        <tr>
                            <td>#<?php echo $user['id']; ?></td>
                            <td>
                                <div class="table-cell-title"><?php echo htmlspecialchars($user['name']); ?></div>
                                <div class="table-cell-meta"><?php echo htmlspecialchars($user['gender'] ?? '---'); ?></div>
                            </td>
                            <td>
                                <div class="table-cell-meta"><i class="fas fa-envelope"></i> <?php echo htmlspecialchars($user['email']); ?></div>
                                <div class="table-cell-meta"><i class="fas fa-phone"></i> <?php echo htmlspecialchars($user['phone'] ?? '---'); ?></div>
                            </td>
                            <td><?php echo $user['birthdate'] ? date('d/m/Y', strtotime($user['birthdate'])) : '---'; ?></td>
                            <td>
                                <span class="status-pill <?php echo ($user['role'] === 'admin') ? 'pill-info' : 'pill-neutral'; ?>">
                                    <?php echo ucfirst($user['role']); ?>
                                </span>
                            </td>
                            <td>
                                <?php if (!empty($user['is_locked'])): ?>
                                    <span class="status-pill pill-danger">Đã khóa</span>
                                <?php else: ?>
                                    <span class="status-pill pill-success">Hoạt động</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($user['role'] !== 'admin'): ?>
                                    <?php if (!empty($user['is_locked'])): ?>
                                        <a href="<?= route('admin.user.toggle') ?>?id=<?php echo $user['id']; ?>&status=0"
                                           class="btn btn-sm btn-success"
                                           onclick="return confirm('Bạn có chắc muốn mở khóa tài khoản này?')">
                                            Mở khóa
                                        </a>
                                    <?php else: ?>
                                        <a href="<?= route('admin.user.toggle') ?>?id=<?php echo $user['id']; ?>&status=1"
                                           class="btn btn-sm btn-danger"
                                           onclick="return confirm('Bạn có chắc muốn khóa tài khoản này?')">
                                            Khóa
                                        </a>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="empty-state">
            <i class="fas fa-users"></i>
            <h3>Chưa có người dùng</h3>
            <p>Người dùng sẽ xuất hiện tại đây khi họ đăng ký hoặc được tạo tài khoản.</p>
        </div>
    <?php endif; ?>
</div>
</body>
</html>





