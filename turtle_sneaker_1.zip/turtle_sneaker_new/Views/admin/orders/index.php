<?php include __DIR__ . '/../sidebar.php'; ?>
<?php
    $orderTotal = count($orders ?? []);
    $pendingTotal = 0;
    $shippingTotal = 0;
    $completedTotal = 0;
    if (!empty($orders)) {
        foreach ($orders as $order) {
            switch ((int)$order['status_id']) {
                case 1:
                    $pendingTotal++;
                    break;
                case 5:
                    $shippingTotal++;
                    break;
                case 6:
                case 7:
                    $completedTotal++;
                    break;
            }
        }
    }

    $allStatuses = [
        1 => 'Chờ xử lí',
        2 => 'Đã xử lí',
        3 => 'Đang chuẩn bị hàng',
        4 => 'Đã giao cho đơn vị vận chuyển',
        5 => 'Đang vận chuyển',
        6 => 'Đã giao',
        7 => 'Đã hoàn thành',
        8 => 'Đã hủy'
    ];

    $statusColors = [
        1 => '#fde68a',
        2 => '#bae6fd',
        3 => '#c7d2fe',
        4 => '#ddd6fe',
        5 => '#bfdbfe',
        6 => '#bbf7d0',
        7 => '#86efac',
        8 => '#fecdd3'
    ];
?>
<div class="admin-content">
    <div class="page-header">
        <div>
            <h1>Quản lý đơn hàng</h1>
            <div class="page-meta">
                <span><i class="fas fa-receipt"></i> <?php echo $orderTotal; ?> đơn hàng</span>
                <span><i class="fas fa-sync-alt"></i> Cập nhật <?php echo date('d/m/Y H:i'); ?></span>
            </div>
        </div>
    </div>

    <div class="insight-cards">
        <div class="insight-card">
            <span class="insight-label">Đang xử lí</span>
            <div class="insight-value"><?php echo $pendingTotal; ?></div>
            <span class="insight-meta">Chờ duyệt & phân công</span>
        </div>
        <div class="insight-card">
            <span class="insight-label">Đang giao</span>
            <div class="insight-value"><?php echo $shippingTotal; ?></div>
            <span class="insight-meta">Đơn ở trạng thái vận chuyển</span>
        </div>
        <div class="insight-card">
            <span class="insight-label">Hoàn thành</span>
            <div class="insight-value"><?php echo $completedTotal; ?></div>
            <span class="insight-meta">Khách đã nhận hàng</span>
        </div>
    </div>

    <div class="table-toolbar">
        <div class="toolbar-meta">
            <span class="chip chip-warning"><i class="fas fa-hourglass-half"></i> <?php echo $pendingTotal; ?> chờ xử lí</span>
            <span class="chip chip-neutral"><i class="fas fa-truck"></i> <?php echo $shippingTotal; ?> đang giao</span>
            <span class="chip chip-success"><i class="fas fa-check-circle"></i> <?php echo $completedTotal; ?> hoàn tất</span>
        </div>
        <span class="muted-text">Hiển thị <?php echo $orderTotal; ?> đơn hàng</span>
    </div>

    <?php if (!empty($orders)): ?>
        <div class="table-container table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Khách hàng</th>
                        <th>Sản phẩm</th>
                        <th>Tổng tiền</th>
                        <th>Ngày đặt</th>
                        <th>Trạng thái đơn</th>
                        <th>Trạng thái thanh toán</th>
                        <th>Thao tác</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($orders as $order): ?>
                        <?php
                            $productNames = explode(', ', $order['product_names']);
                            $firstProduct = $productNames[0] ?? '';
                            $extraCount = max(count($productNames) - 1, 0);
                            
                            // Get next allowed statuses from database
                            $nextStatusesArray = $orderModel->getNextAllowedStatuses((int)$order['status_id']);
                            
                            // Convert to associative array for compatibility
                            $nextStatuses = [];
                            foreach ($nextStatusesArray as $status) {
                                $nextStatuses[$status['id']] = $status['name'];
                            }
                            
                            $canEdit = !empty($nextStatuses);
                        ?>
                        <tr>
                            <td>
                                <div class="table-cell-title"><?php echo htmlspecialchars($order['user_name']); ?></div>
                                <div class="table-cell-meta"><?php echo htmlspecialchars($order['user_email']); ?></div>
                            </td>
                            <td>
                                <div class="table-cell-title"><?php echo htmlspecialchars($firstProduct); ?></div>
                                <?php if ($extraCount > 0): ?>
                                    <div class="table-cell-meta">+<?php echo $extraCount; ?> sản phẩm khác</div>
                                <?php endif; ?>
                            </td>
                            <td class="table-cell-title"><?php echo number_format($order['total_amount'], 0, ',', '.'); ?>đ</td>
                            <td><?php echo date('d/m/Y', strtotime($order['created_at'])); ?></td>
                            <td>
                                <?php if ($canEdit && !empty($nextStatuses)): ?>
                                    <select class="status-select" data-order-id="<?php echo $order['id']; ?>" style="background-color: <?php echo $statusColors[$order['status_id']] ?? '#e2e8f0'; ?>;">
                                        <option value="<?php echo $order['status_id']; ?>" selected><?php echo $allStatuses[$order['status_id']] ?? 'Không xác định'; ?></option>
                                        <?php foreach ($nextStatuses as $statusId => $statusName): ?>
                                            <option value="<?php echo $statusId; ?>"><?php echo $statusName; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                <?php else: ?>
                                    <span class="status-badge" style="background-color: <?php echo $statusColors[$order['status_id']] ?? '#e2e8f0'; ?>;">
                                        <?php echo htmlspecialchars($order['status_name']); ?>
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php
                                    $paymentMethod = $order['payment_method'] ?? 'cod';
                                    $paymentStatus = $order['payment_status'] ?? null;
                                ?>
                                <?php if ($paymentStatus === 'Paid'): ?>
                                    <span class="status-pill pill-success">
                                        <i class="fas fa-check-circle"></i> Đã thanh toán
                                    </span>
                                <?php else: ?>
                                    <?php if ($paymentMethod === 'vnpay'): ?>
                                        <span class="status-pill pill-warning">
                                            <i class="fas fa-credit-card"></i> Chưa thanh toán (VNPAY)
                                        </span>
                                    <?php else: ?>
                                        <span class="status-pill pill-warning">
                                            <i class="fas fa-money-bill-wave"></i> Chưa thanh toán (COD)
                                        </span>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </td>
                            <td class="table-actions">
                                <a href="<?= route('admin.order.detail', ['id' => $order['id']]) ?>" class="action-btn btn-view" title="Xem chi tiết">
                                    <i class="fas fa-eye"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <?php
            $currentPage = $currentPage ?? 1;
            $totalPages = $totalPages ?? 1;
        ?>
        <?php if ($totalPages > 1): ?>
            <div class="pagination">
                <?php if ($currentPage > 1): ?>
                    <a class="page-link" href="index.php?controller=admin&action=orders&page=<?php echo $currentPage - 1; ?>">&laquo;</a>
                <?php endif; ?>

                <?php for ($p = 1; $p <= $totalPages; $p++): ?>
                    <a class="page-link <?php echo $p === $currentPage ? 'active' : ''; ?>" 
                       href="index.php?controller=admin&action=orders&page=<?php echo $p; ?>">
                        <?php echo $p; ?>
                    </a>
                <?php endfor; ?>

                <?php if ($currentPage < $totalPages): ?>
                    <a class="page-link" href="index.php?controller=admin&action=orders&page=<?php echo $currentPage + 1; ?>">&raquo;</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    <?php else: ?>
        <div class="empty-state">
            <i class="fas fa-receipt"></i>
            <h3>Chưa có đơn hàng</h3>
            <p>Khi khách hàng đặt mua sản phẩm, bạn sẽ theo dõi và xử lí tại đây.</p>
        </div>
    <?php endif; ?>
</div>

<link rel="stylesheet" href="<?= url('public/css/admin-orders.css?v=' . time()) ?>">


<script>
    const BASE_URL = '<?= url('') ?>';
</script>
<script src="<?= url('public/js/admin-orders.js?v=' . time()) ?>"></script>
</body>
</html>

