<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chi tiết đơn hàng #<?php echo $order['id']; ?> - Turtle Sneaker</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<?= url('public/css/admin.css') ?>">
    <link rel="stylesheet" href="<?= url('public/css/admin-orders.css?v=' . time()) ?>">
    <link rel="stylesheet" href="<?= url('public/css/admin-order-detail.css?v=' . time()) ?>">
</head>
<body>
    <div class="admin-layout">
        <?php include __DIR__ . '/../sidebar.php'; ?>
        <div class="admin-content">
            <div class="admin-header">
                <h1>Chi tiết đơn hàng #AYENLEA<?php echo str_pad($order['id'], 4, '0', STR_PAD_LEFT); ?></h1>
                <a href="<?= route('admin.orders') ?>" class="btn-back">
                    <i class="fas fa-arrow-left"></i> Quay lại
                </a>
            </div>

        <?php if (isset($_SESSION['alert'])): ?>
            <div class="alert alert-<?php echo $_SESSION['alert']['type']; ?>">
                <?php echo htmlspecialchars($_SESSION['alert']['message']); ?>
            </div>
            <?php unset($_SESSION['alert']); ?>
        <?php endif; ?>

        <div class="order-detail-content">
            <div class="order-status-card">
                <div class="status-header">
                    <h3>Trạng thái đơn hàng</h3>
                    <span class="status-badge status-<?php echo $order['current_status_id']; ?>">
                        <?php echo htmlspecialchars($order['status_name']); ?>
                    </span>
                </div>
                <div class="status-timeline">
                    <?php if ($order['current_status_id'] == 8): ?>
                        <div class="timeline-item completed">
                            <div class="timeline-icon"><i class="fas fa-check"></i></div>
                            <div class="timeline-content">
                                <strong>Đơn hàng đã đặt</strong>
                                <p><?php echo date('d/m/Y H:i', strtotime($order['created_at'])); ?></p>
                            </div>
                        </div>
                        <div class="timeline-item completed cancelled">
                            <div class="timeline-icon"><i class="fas fa-times"></i></div>
                            <div class="timeline-content">
                                <strong>Đã hủy</strong>
                                <p>Đơn hàng đã bị hủy</p>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="timeline-item <?php echo $order['current_status_id'] >= 1 ? 'completed' : ''; ?>">
                            <div class="timeline-icon"><i class="fas fa-check"></i></div>
                            <div class="timeline-content">
                                <strong>Chờ xử lí</strong>
                                <?php if ($order['current_status_id'] == 1): ?>
                                    <p><?php echo date('d/m/Y H:i', strtotime($order['created_at'])); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="timeline-item <?php echo $order['current_status_id'] >= 2 ? 'completed' : ''; ?>">
                            <div class="timeline-icon"><i class="fas fa-clipboard-check"></i></div>
                            <div class="timeline-content">
                                <strong>Đã xử lí</strong>
                                <?php if ($order['current_status_id'] == 2): ?>
                                    <p>Đơn hàng đã được xác nhận</p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="timeline-item <?php echo $order['current_status_id'] >= 3 ? 'completed' : ''; ?>">
                            <div class="timeline-icon"><i class="fas fa-box"></i></div>
                            <div class="timeline-content">
                                <strong>Đang chuẩn bị hàng</strong>
                                <?php if ($order['current_status_id'] == 3): ?>
                                    <p>Đang đóng gói sản phẩm</p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="timeline-item <?php echo $order['current_status_id'] >= 4 ? 'completed' : ''; ?>">
                            <div class="timeline-icon"><i class="fas fa-people-carry"></i></div>
                            <div class="timeline-content">
                                <strong>Đã giao cho đơn vị vận chuyển</strong>
                                <?php if ($order['current_status_id'] == 4): ?>
                                    <p>Đã bàn giao cho shipper</p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="timeline-item <?php echo $order['current_status_id'] >= 5 ? 'completed' : ''; ?>">
                            <div class="timeline-icon"><i class="fas fa-truck"></i></div>
                            <div class="timeline-content">
                                <strong>Đang vận chuyển</strong>
                                <?php if ($order['current_status_id'] == 5): ?>
                                    <p>Đơn hàng đang trên đường giao đến khách hàng</p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="timeline-item <?php echo $order['current_status_id'] >= 6 ? 'completed' : ''; ?>">
                            <div class="timeline-icon"><i class="fas fa-shipping-fast"></i></div>
                            <div class="timeline-content">
                                <strong>Đã giao</strong>
                                <?php if ($order['current_status_id'] == 6): ?>
                                    <p>Đã giao hàng thành công</p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="timeline-item <?php echo $order['current_status_id'] >= 7 ? 'completed' : ''; ?>">
                            <div class="timeline-icon"><i class="fas fa-check-circle"></i></div>
                            <div class="timeline-content">
                                <strong>Đã hoàn thành</strong>
                                <?php if ($order['current_status_id'] == 7): ?>
                                    <p>Khách hàng đã xác nhận nhận hàng</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="order-info-card">
                <h3>Thông tin đơn hàng</h3>
                <div class="info-row">
                    <span class="label">Mã đơn hàng:</span>
                    <span class="value">#AYENLEA<?php echo str_pad($order['id'], 4, '0', STR_PAD_LEFT); ?></span>
                </div>
                <div class="info-row">
                    <span class="label">Ngày đặt:</span>
                    <span class="value"><?php echo date('d/m/Y H:i', strtotime($order['created_at'])); ?></span>
                </div>
                <div class="info-row">
                    <span class="label">Tổng tiền:</span>
                    <span class="value total"><?php echo number_format($order['total_amount'], 0, ',', '.'); ?>đ</span>
                </div>
            </div>

            <div class="order-info-card">
                <h3>Thông tin khách hàng</h3>
                <div class="info-row">
                    <span class="label">Tên:</span>
                    <span class="value"><?php echo htmlspecialchars($order['user_name']); ?></span>
                </div>
                <div class="info-row">
                    <span class="label">Email:</span>
                    <span class="value"><?php echo htmlspecialchars($order['user_email']); ?></span>
                </div>
                <div class="info-row">
                    <span class="label">Số điện thoại:</span>
                    <span class="value"><?php echo htmlspecialchars(!empty($order['user_phone']) ? $order['user_phone'] : ($order['address_phone'] ?? 'Chưa cập nhật')); ?></span>
                </div>
            </div>

            <div class="order-info-card">
                <h3>Địa chỉ nhận hàng</h3>
                <div class="address-box">
                    <p><strong><?php echo htmlspecialchars($order['address_name']); ?></strong></p>
                    <p><?php echo htmlspecialchars($order['address_phone']); ?></p>
                    <p><?php echo htmlspecialchars($order['address_line']); ?></p>
                    <?php 
                    $city = $order['city'] ?? '';
                    $district = $order['district'] ?? '';
                    $ward = $order['ward'] ?? '';
                    $hasErrors = (strpos($city, '<b>Warning</b>') !== false) || 
                                 (strpos($district, '<b>Warning</b>') !== false) || 
                                 (strpos($ward, '<b>Warning</b>') !== false);
                    if (!$hasErrors && !empty(trim($city . $district . $ward))): 
                    ?>
                        <p><?php echo htmlspecialchars(trim($ward . ', ' . $district . ', ' . $city), ENT_QUOTES, 'UTF-8'); ?></p>
                    <?php endif; ?>
                </div>
            </div>

            <div class="order-info-card">
                <h3>Sản phẩm</h3>
                <div class="items-list">
                    <?php foreach ($order['items'] as $item): ?>
                        <div class="item-row">
                            <div class="item-image">
                                <?php if (!empty($item['main_image'])): ?>
                                    <img src="<?= url($item['main_image']) ?>" alt="Product">
                                <?php else: ?>
                                    <div class="no-image"><i class="fas fa-image"></i></div>
                                <?php endif; ?>
                            </div>
                            <div class="item-info">
                                <h4><?php echo htmlspecialchars($item['product_name']); ?></h4>
                                <p class="item-sku">SKU: <?php echo htmlspecialchars($item['sku']); ?></p>
                                <?php if (!empty($item['color_name']) || !empty($item['size_name'])): ?>
                                    <p class="item-variant">
                                        <?php if (!empty($item['color_name'])): ?>
                                            Màu: <?php echo htmlspecialchars($item['color_name']); ?>
                                        <?php endif; ?>
                                        <?php if (!empty($item['size_name'])): ?>
                                            <?php echo !empty($item['color_name']) ? ' | ' : ''; ?>
                                            Size: <?php echo htmlspecialchars($item['size_name']); ?>
                                        <?php endif; ?>
                                    </p>
                                <?php endif; ?>
                                <p class="item-quantity">Số lượng: <?php echo $item['quantity']; ?></p>
                            </div>
                            <div class="item-price">
                                <p class="price"><?php echo number_format($item['price_each'], 0, ',', '.'); ?>đ</p>
                                <p class="subtotal">Tổng: <?php echo number_format($item['price_each'] * $item['quantity'], 0, ',', '.'); ?>đ</p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <div class="order-summary">
                    <div class="summary-row">
                        <span>Tạm tính:</span>
                        <span><?php echo number_format($order['subtotal_price'], 0, ',', '.'); ?>đ</span>
                    </div>
                    <?php if ($order['product_discount'] > 0): ?>
                    <div class="summary-row discount-row">
                        <span>
                            Giảm giá sản phẩm:
                            <?php if ($order['coupon_code']): ?>
                                <small>(<?php echo htmlspecialchars($order['coupon_code']); ?>)</small>
                            <?php endif; ?>
                        </span>
                        <span class="discount-amount">-<?php echo number_format($order['product_discount'], 0, ',', '.'); ?>đ</span>
                    </div>
                    <?php endif; ?>
                    <div class="summary-row">
                        <span>Phí vận chuyển:</span>
                        <span><?php echo number_format($order['shipping_fee'], 0, ',', '.'); ?>đ</span>
                    </div>
                    <?php if ($order['shipping_discount'] > 0): ?>
                    <div class="summary-row discount-row">
                        <span>
                            Giảm phí vận chuyển:
                            <?php if ($order['coupon_code']): ?>
                                <small>(<?php echo htmlspecialchars($order['coupon_code']); ?>)</small>
                            <?php endif; ?>
                        </span>
                        <span class="discount-amount">-<?php echo number_format($order['shipping_discount'], 0, ',', '.'); ?>đ</span>
                    </div>
                    <?php endif; ?>
                    <div class="summary-row total-row">
                        <span>Tổng cộng:</span>
                        <span><?php echo number_format($order['total_amount'], 0, ',', '.'); ?>đ</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>