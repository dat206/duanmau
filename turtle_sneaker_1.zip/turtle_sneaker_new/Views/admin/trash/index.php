<?php include __DIR__ . '/../sidebar.php'; ?>
<?php
    $trashedProductsCount = count($trashedProducts ?? []);
    $trashedCategoriesCount = count($trashedCategories ?? []);
    $trashedCouponsCount = count($trashedCoupons ?? []);
    $totalTrash = $trashedProductsCount + $trashedCategoriesCount + $trashedCouponsCount;
?>
<div class="admin-content">
    <div class="page-header">
        <div>
            <p class="page-subtitle">Khôi phục dữ liệu</p>
            <h1>Thùng rác</h1>
            <div class="page-meta">
                <span><i class="fas fa-trash-restore"></i> <?php echo $totalTrash; ?> mục đã xóa</span>
            </div>
        </div>
    </div>

    <?php if (isset($_SESSION['alert'])): ?>
        <div class="alert alert-<?php echo $_SESSION['alert']['type']; ?>">
            <?php echo htmlspecialchars($_SESSION['alert']['message']); ?>
        </div>
        <?php unset($_SESSION['alert']); ?>
    <?php endif; ?>

    <div class="insight-cards">
        <div class="insight-card">
            <span class="insight-label">Sản phẩm</span>
            <div class="insight-value"><?php echo $trashedProductsCount; ?></div>
            <span class="insight-meta">Chờ khôi phục hoặc xóa</span>
        </div>
        <div class="insight-card">
            <span class="insight-label">Danh mục</span>
            <div class="insight-value"><?php echo $trashedCategoriesCount; ?></div>
            <span class="insight-meta">Ảnh hưởng tới phân loại</span>
        </div>
        <div class="insight-card">
            <span class="insight-label">Mã giảm giá</span>
            <div class="insight-value"><?php echo $trashedCouponsCount; ?></div>
            <span class="insight-meta">Ưu đãi tạm khóa</span>
        </div>
    </div>

    <div class="trash-tabs">
        <a href="<?= route('admin.trash') ?>?type=products" class="tab-btn <?php echo $type === 'products' ? 'active' : ''; ?>">
            <i class="fas fa-box"></i> Sản phẩm (<?php echo $trashedProductsCount; ?>)
        </a>
        <a href="<?= route('admin.trash') ?>?type=categories" class="tab-btn <?php echo $type === 'categories' ? 'active' : ''; ?>">
            <i class="fas fa-list"></i> Danh mục (<?php echo $trashedCategoriesCount; ?>)
        </a>
        <a href="<?= route('admin.trash') ?>?type=coupons" class="tab-btn <?php echo $type === 'coupons' ? 'active' : ''; ?>">
            <i class="fas fa-ticket-alt"></i> Mã giảm giá (<?php echo $trashedCouponsCount; ?>)
        </a>
    </div>

    <?php if ($type === 'products'): ?>
        <?php if (!empty($trashedProducts)): ?>
            <div class="table-container table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Hình ảnh</th>
                            <th>Tên sản phẩm</th>
                            <th>Mã sản phẩm</th>
                            <th>Danh mục</th>
                            <th>Giá</th>
                            <th>Ngày xóa</th>
                            <th>Hành động</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($trashedProducts as $product): ?>
                            <tr>
                                <td><?php echo $product['id']; ?></td>
                                <td>
                                    <?php if (!empty($product['main_image'])): ?>
                                        <img src="<?= url($product['main_image']) ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" class="product-img">
                                    <?php else: ?>
                                        <div class="table-cell-meta">Không có ảnh</div>
                                    <?php endif; ?>
                                </td>
                                <td class="table-cell-title"><?php echo htmlspecialchars($product['name']); ?></td>
                                <td><?php echo htmlspecialchars($product['product_code']); ?></td>
                                <td><?php echo htmlspecialchars($product['category_name']); ?></td>
                                <td class="table-cell-title"><?php echo number_format($product['price'], 0, ',', '.'); ?>đ</td>
                                <td><?php echo date('d/m/Y H:i', strtotime($product['deleted_at'])); ?></td>
                                <td class="table-actions">
                                    <a href="<?= route('admin.trash.restore', ['id' => $product['id']]) ?>" class="btn btn-sm btn-success" onclick="return confirm('Khôi phục sản phẩm này?')">
                                        <i class="fas fa-undo"></i> Khôi phục
                                    </a>
                                    <a href="<?= route('admin.trash.force-delete', ['id' => $product['id']]) ?>" class="btn btn-sm btn-danger" onclick="return confirm('Xóa vĩnh viễn sản phẩm này?')">
                                        <i class="fas fa-trash"></i> Xóa vĩnh viễn
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <i class="fas fa-box"></i>
                <h3>Thùng rác sản phẩm trống</h3>
                <p>Không còn sản phẩm bị xóa tạm thời.</p>
            </div>
        <?php endif; ?>
    <?php elseif ($type === 'categories'): ?>
        <?php if (!empty($trashedCategories)): ?>
            <div class="table-container table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Tên danh mục</th>
                            <th>Mô tả</th>
                            <th>Ngày xóa</th>
                            <th>Hành động</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($trashedCategories as $category): ?>
                            <tr>
                                <td><?php echo $category['id']; ?></td>
                                <td class="table-cell-title"><?php echo htmlspecialchars($category['name']); ?></td>
                                <td>
                                    <div class="table-cell-meta"><?php echo htmlspecialchars($category['description']); ?></div>
                                </td>
                                <td><?php echo date('d/m/Y H:i', strtotime($category['deleted_at'])); ?></td>
                                <td class="table-actions">
                                    <a href="<?= route('admin.trash.category.restore', ['id' => $category['id']]) ?>" class="btn btn-sm btn-success" onclick="return confirm('Khôi phục danh mục này?')">
                                        <i class="fas fa-undo"></i> Khôi phục
                                    </a>
                                    <a href="<?= route('admin.trash.category.delete', ['id' => $category['id']]) ?>" class="btn btn-sm btn-danger" onclick="return confirm('Xóa vĩnh viễn danh mục này?')">
                                        <i class="fas fa-trash"></i> Xóa vĩnh viễn
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <i class="fas fa-list"></i>
                <h3>Không có danh mục bị xóa</h3>
                <p>Tất cả danh mục đều đang hoạt động.</p>
            </div>
        <?php endif; ?>
    <?php else: ?>
        <?php if (!empty($trashedCoupons)): ?>
            <div class="table-container table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Mã</th>
                            <th>Loại</th>
                            <th>Giá trị</th>
                            <th>Đơn tối thiểu</th>
                            <th>Ngày xóa</th>
                            <th>Hành động</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($trashedCoupons as $coupon): ?>
                            <tr>
                                <td><?php echo $coupon['id']; ?></td>
                                <td class="table-cell-title"><?php echo htmlspecialchars($coupon['code']); ?></td>
                                <td><?php echo $coupon['type'] === 'percentage' ? 'Phần trăm' : 'Số tiền'; ?></td>
                                <td>
                                    <?php if ($coupon['type'] === 'percentage'): ?>
                                        <?php echo $coupon['discount_amount'] * 100; ?>%
                                    <?php else: ?>
                                        <?php echo number_format($coupon['discount_amount'], 0, ',', '.'); ?>đ
                                    <?php endif; ?>
                                </td>
                                <td><?php echo number_format($coupon['min_order_value'], 0, ',', '.'); ?>đ</td>
                                <td><?php echo date('d/m/Y H:i', strtotime($coupon['deleted_at'])); ?></td>
                                <td class="table-actions">
                                    <a href="<?= route('admin.trash.coupon.restore', ['id' => $coupon['id']]) ?>" class="btn btn-sm btn-success" onclick="return confirm('Khôi phục mã giảm giá này?')">
                                        <i class="fas fa-undo"></i> Khôi phục
                                    </a>
                                    <a href="<?= route('admin.trash.coupon.delete', ['id' => $coupon['id']]) ?>" class="btn btn-sm btn-danger" onclick="return confirm('Xóa vĩnh viễn mã này?')">
                                        <i class="fas fa-trash"></i> Xóa vĩnh viễn
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <i class="fas fa-ticket-alt"></i>
                <h3>Không có mã giảm giá bị xóa</h3>
                <p>Tất cả mã giảm giá đều đang hoạt động.</p>
            </div>
        <?php endif; ?>
    <?php endif; ?>
</div>
</body>
</html>





