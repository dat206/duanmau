<?php
Route::get('/', 'HomeController@index')->name('home');
Route::get('/trang-chu', 'HomeController@index')->name('home.vi');

// About & Contact
Route::get('/gioi-thieu', 'AboutController@index')->name('about');

// ============================================
// PRODUCT ROUTES
// ============================================

// Product listing
Route::get('/san-pham', 'ProductController@index')->name('products');
// Specific routes must come before parameterized routes
Route::get('/san-pham/gia', 'ProductController@getPrice')->name('product.getPrice');
Route::get('/san-pham/{id}', 'ProductController@detail')->name('product.detail');

// Product search
Route::get('/tim-kiem', 'ProductController@search')->name('product.search');

// API: Get products by category (for AJAX)
Route::get('/api/san-pham/danh-muc', 'ProductController@getByCategory')->name('api.product.category');


// ============================================
// AUTHENTICATION ROUTES
// ============================================

// Login
Route::get('/dang-nhap', 'AuthController@showLogin')->name('login');
Route::post('/dang-nhap', 'AuthController@login')->name('login.post');

// Register
Route::get('/dang-ky', 'AuthController@showRegister')->name('register');
Route::post('/dang-ky', 'AuthController@register')->name('register.post');

// Logout
Route::post('/dang-xuat', 'AuthController@logout')->name('logout');
Route::get('/dang-xuat', 'AuthController@logout')->name('logout.get');

// ============================================
// USER ROUTES (Require Authentication)
// ============================================

Route::group(['middleware' => 'auth'], function() {
    
    // Profile
    Route::get('/tai-khoan', 'UserController@profile')->name('profile');
    Route::get('/tai-khoan/chinh-sua', 'UserController@edit')->name('profile.edit');
    Route::post('/tai-khoan/cap-nhat', 'UserController@update')->name('profile.update');
    Route::post('/tai-khoan/doi-mat-khau', 'UserController@changePassword')->name('profile.password');
    
    // Orders
    Route::get('/don-hang', 'UserController@orders')->name('orders');
    Route::get('/don-hang/{id}/thanh-toan-lai', 'UserController@retryVnpayPayment')->name('order.retry-payment');
    Route::get('/don-hang/{id}', 'UserController@orderDetail')->name('order.detail');
    Route::post('/don-hang/{id}/huy', 'UserController@cancelOrder')->name('order.cancel');
    Route::post('/don-hang/{id}/da-nhan', 'UserController@confirmReceived')->name('order.confirm');
    
    // Wishlist
    Route::get('/yeu-thich', 'UserController@wishlist')->name('wishlist');
    Route::post('/yeu-thich/them', 'UserController@toggleWishlist')->name('wishlist.toggle');
    Route::post('/yeu-thich/xoa', 'UserController@removeFromWishlist')->name('wishlist.remove');
    
    // Reviews
    Route::post('/danh-gia/them', 'UserController@submitReview')->name('review.add');
    Route::post('/danh-gia/xoa', 'UserController@deleteReview')->name('review.delete');
    
});

// ============================================
// CART & CHECKOUT ROUTES
// ============================================

// Cart (accessible to guests)
Route::get('/gio-hang', 'CartController@view')->name('cart');
Route::post('/gio-hang/them', 'CartController@addToCart')->name('cart.add');
Route::post('/gio-hang/mua-ngay', 'CartController@buyNow')->name('cart.buynow');
Route::post('/gio-hang/cap-nhat', 'CartController@updateQuantity')->name('cart.update');
Route::post('/gio-hang/xoa', 'CartController@removeItem')->name('cart.remove');
Route::post('/gio-hang/xoa-nhieu', 'CartController@removeMultipleItems')->name('cart.remove.multiple');
Route::post('/gio-hang/chon-san-pham', 'CartController@setSelectedItems')->name('cart.set.selected');
Route::post('/gio-hang/xoa-tat-ca', 'CartController@clear')->name('cart.clear');
Route::post('/gio-hang/kiem-tra-voucher', 'CartController@checkVoucher')->name('cart.checkVoucher');
Route::post('/gio-hang/luu-dia-chi', 'CartController@saveAddress')->name('cart.saveAddress');

// Checkout (requires authentication)
Route::group(['middleware' => 'auth'], function() {
    Route::get('/thanh-toan', 'CartController@checkout')->name('checkout');
    Route::post('/thanh-toan/xu-ly', 'CartController@placeOrder')->name('checkout.process');
    Route::get('/cam-on', 'CartController@thankYou')->name('thankyou');
    
    // Address management
    Route::post('/dia-chi/them', 'CartController@addAddress')->name('address.add');
    Route::post('/dia-chi/cap-nhat', 'CartController@updateAddress')->name('address.update');
    Route::post('/dia-chi/xoa', 'CartController@deleteAddress')->name('address.delete');
    
    // Coupon
    Route::post('/ma-giam-gia/ap-dung', 'CartController@applyCoupon')->name('coupon.apply');
    Route::post('/ma-giam-gia/xoa', 'CartController->removeCoupon')->name('coupon.remove');
});

// ============================================
// ADMIN ROUTES (Require Admin Authentication)
// ============================================

Route::group(['prefix' => 'admin', 'middleware' => 'admin'], function() {
    
    // Dashboard
    Route::get('/dashboard', 'AdminController@dashboard')->name('admin.dashboard');
    
    // Products Management
    Route::get('/san-pham', 'AdminController@products')->name('admin.products');
    Route::get('/san-pham/them', 'AdminController@createProduct')->name('admin.product.create');
    Route::post('/san-pham/luu', 'AdminController@storeProduct')->name('admin.product.store');
    Route::get('/san-pham/sua/{id}', 'AdminController@editProduct')->name('admin.product.edit');
    Route::post('/san-pham/cap-nhat/{id}', 'AdminController@updateProduct')->name('admin.product.update');
    Route::get('/san-pham/xoa/{id}', 'AdminController@deleteProduct')->name('admin.product.delete');
    Route::post('/san-pham/xoa/{id}', 'AdminController@deleteProduct')->name('admin.product.delete.post');
    
    // Trash
    Route::get('/thung-rac', 'AdminController@trash')->name('admin.trash');
    // Product trash
    Route::get('/thung-rac/khoi-phuc/{id}', 'AdminController@restoreProduct')->name('admin.trash.restore');
    Route::post('/thung-rac/khoi-phuc/{id}', 'AdminController@restoreProduct')->name('admin.trash.restore.post');
    Route::get('/thung-rac/xoa-vinh-vien/{id}', 'AdminController@forceDeleteProduct')->name('admin.trash.force-delete');
    Route::post('/thung-rac/xoa-vinh-vien/{id}', 'AdminController@forceDeleteProduct')->name('admin.trash.force-delete.post');
    // Category trash
    Route::get('/thung-rac/danh-muc/khoi-phuc/{id}', 'AdminController@restoreCategory')->name('admin.trash.category.restore');
    Route::get('/thung-rac/danh-muc/xoa/{id}', 'AdminController@forceDeleteCategory')->name('admin.trash.category.delete');
    // Coupon trash
    Route::get('/thung-rac/ma-giam-gia/khoi-phuc/{id}', 'AdminController@restoreCoupon')->name('admin.trash.coupon.restore');
    Route::get('/thung-rac/ma-giam-gia/xoa/{id}', 'AdminController@forceDeleteCoupon')->name('admin.trash.coupon.delete');
    
    // Orders Management
    Route::get('/don-hang', 'AdminController@orders')->name('admin.orders');
    Route::get('/don-hang/{id}', 'AdminController@orderDetail')->name('admin.order.detail');
    Route::post('/don-hang/{id}/cap-nhat-trang-thai', 'AdminController@updateOrderStatus')->name('admin.order.status');
    
    // Categories Management
    Route::get('/danh-muc', 'AdminController@categories')->name('admin.categories');
    Route::get('/danh-muc/them', 'AdminController@createCategory')->name('admin.category.create');
    Route::post('/danh-muc/luu', 'AdminController@storeCategory')->name('admin.category.store');
    Route::get('/danh-muc/sua/{id}', 'AdminController@editCategory')->name('admin.category.edit');
    Route::post('/danh-muc/cap-nhat/{id}', 'AdminController@updateCategory')->name('admin.category.update');
    Route::get('/danh-muc/xoa/{id}', 'AdminController@deleteCategory')->name('admin.category.delete');
    Route::post('/danh-muc/xoa/{id}', 'AdminController@deleteCategory')->name('admin.category.delete.post');
    
    // Coupons Management
    Route::get('/ma-giam-gia', 'AdminController@coupons')->name('admin.coupons');
    Route::get('/ma-giam-gia/them', 'AdminController@createCoupon')->name('admin.coupon.create');
    Route::post('/ma-giam-gia/luu', 'AdminController@storeCoupon')->name('admin.coupon.store');
    Route::get('/ma-giam-gia/sua/{id}', 'AdminController@editCoupon')->name('admin.coupon.edit');
    Route::post('/ma-giam-gia/cap-nhat/{id}', 'AdminController@updateCoupon')->name('admin.coupon.update');
    Route::get('/ma-giam-gia/xoa/{id}', 'AdminController@deleteCoupon')->name('admin.coupon.delete');
    Route::post('/ma-giam-gia/xoa/{id}', 'AdminController@deleteCoupon')->name('admin.coupon.delete.post');
    
    // Users Management
    Route::get('/nguoi-dung', 'AdminController@users')->name('admin.users');
    Route::get('/nguoi-dung/khoa-mo-khoa', 'AdminController@toggleUserLock')->name('admin.user.toggle');
    Route::post('/nguoi-dung/{id}/khoa', 'AdminController@lockUser')->name('admin.user.lock');
    Route::post('/nguoi-dung/{id}/mo-khoa', 'AdminController@unlockUser')->name('admin.user.unlock');
    
    // Comments/Reviews Management
    Route::get('/binh-luan', 'AdminController@comments')->name('admin.comments');
    Route::get('/binh-luan/{id}/duyet', 'AdminController@updateCommentStatus')->name('admin.comment.approve');
    Route::get('/binh-luan/{id}/an', 'AdminController@updateCommentStatus')->name('admin.comment.hide');
    Route::post('/binh-luan/{id}/duyet', 'AdminController@approveComment')->name('admin.comment.approve.post');
    Route::post('/binh-luan/{id}/xoa', 'AdminController@deleteComment')->name('admin.comment.delete');
    
});

// ============================================
// BACKWARD COMPATIBILITY (Old URL Format)
// ============================================

// Redirect old URLs to new format
if (isset($_GET['controller']) && isset($_GET['action'])) {
    $controller = $_GET['controller'];
    $action = $_GET['action'];
    $id = $_GET['id'] ?? null;
    
    // Map old URLs to new routes
    $urlMap = [
        'home' => ['index' => '/'],
        'product' => [
            'index' => '/san-pham',
            'detail' => '/san-pham/' . $id,
            'search' => '/tim-kiem'
        ],
        'auth' => [
            'login' => '/dang-nhap',
            'register' => '/dang-ky',
            'logout' => '/dang-xuat'
        ],
        'user' => [
            'profile' => '/tai-khoan',
            'orders' => '/don-hang',
            'wishlist' => '/yeu-thich'
        ],
        'cart' => [
            'index' => '/gio-hang',
            'checkout' => '/thanh-toan',
            'thankYou' => '/cam-on'
        ],
        'admin' => [
            'dashboard' => '/admin/dashboard',
            'products' => '/admin/san-pham',
            'orders' => '/admin/don-hang',
            'categories' => '/admin/danh-muc',
            'coupons' => '/admin/ma-giam-gia',
            'users' => '/admin/nguoi-dung',
            'comments' => '/admin/binh-luan',
            'trash' => '/admin/thung-rac'
        ],
        'about' => ['index' => '/gioi-thieu']
    ];
    
    
    // Allow AJAX endpoints to pass through without redirect
    if ($controller === 'product' && $action === 'getByCategory') {
        // Don't redirect, let it be handled by the ProductController
        // This is needed for AJAX calls that return JSON
    } elseif (isset($urlMap[$controller][$action])) {
        $newUrl = $urlMap[$controller][$action];
        redirect($newUrl, 301); // Permanent redirect
    }
}
